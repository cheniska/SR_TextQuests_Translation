# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Time until evening' [0..1440] тип=смерть
    старт: [0]
    [0..1440] You have: {([p1] mod 1440) div 60} h {[p1] mod 60} min
    критическое: You suddenly felt extremely disgusting. Looking at your watch, you realized why this was happening t…
- P2 'Your health' [0..100] тип=смерть
    старт: [100]
    [0..10] Like death warmed over
    [11..21] You are almost dead
    [22..32] You're feeling awful
    [33..43] You really aren't doing well
    [44..54] You feel slightly off
    [55..65] You don't feel bad
    [66..76] You feel all right
    [77..87] You're almost healthy
    [88..100] You are totally healthy
    критическое: You felt extremely horrible. Bloody circles danced before your eyes. Your entire body ached. Your le…
- P3 "You're carrying" [0..100] тип=обычный
    старт: [0]
    [0..19] You're walking light: <>%
    [20..39] You're carrying a small load: <>%
    [40..59] You're carrying a decent load: <>%
    [60..79] You're carrying a large load: <>%
    [80..100] You can't even move: <>%
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Warehouse password' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Total entered: <>
    критическое: Сообщение достижения критического значения параметром 8
- P5 'Worker' [0..1] тип=обычный
    старт: [0]
    [0..1] You have:
    критическое: Сообщение достижения критического значения параметром 4
- P6 'Net for a leg-eared' [0..1] тип=обычный
    старт: [0]
    [0..0] Defective net
    [1..1] Good net
    критическое: Сообщение достижения критического значения параметром 5
- P7 'Flask of sulfuric acid.' [0..100] тип=обычный
    старт: [0]
    [0..100] Flasks with sulfuric acid: <>
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Iron rod' [0..3] тип=обычный
    старт: [0]
    [0..0] Broken rod
    [1..1] Cracked iron rod
    [2..2] Bent iron rod
    [3..3] New iron rod
    критическое: Сообщение достижения критического значения параметром 6
- P9 'Tranquilizer gun' [0..60] тип=обычный
    старт: [0]
    [0..0] Unloaded tranquilizer gun
    [1..1] Tranquilizer gun with one dart
    [2..2] Tranquilizer gun with two darts
    [3..3] Tranquilizer gun with three darts
    [4..4] Tranquilizer gun with four darts
    [5..5] Tranquilizer gun with five darts
    [6..60] Tranquilizer gun with a whole pile of darts
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Assault blaster' [0..8] тип=обычный
    старт: [0]
    [0..0] Unloaded blaster
    [1..1] Blaster with one round
    [2..2] Blaster with two rounds
    [3..3] Blaster with three rounds
    [4..4] Blaster with four rounds
    [5..5] Blaster with five rounds
    [6..6] Blaster with six rounds
    [7..7] Blaster with seven rounds
    [8..8] Blaster with a full clip
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Symgrass for the gaal' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Symgrass for the gaal
    критическое: Сообщение достижения критического значения параметром 11
- P12 "Native's mood" [0..100] тип=смерть
    старт: [0]
    [0..24] The tarantula is ready to kill you
    [25..49] The tarantula is mad at you
    [50..74] The tarantula is somewhat cross with you
    [75..100] The tarantula is favorably disposed to you
    критическое: The tarantula endure you stream of nonsense. He thrust his fangs into you and pumped in poison...
- P13 'Money' [0..6000] тип=обычный деньги
    старт: [0]
    [0..6000] 
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Key to the second warehouse' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Incomprehensible baloney...' [0..1] тип=обычный
    старт: [0]
    [0..0] Unloaded, incomprehensible device
    [1..1] Loaded, incomprehensible device
    критическое: Сообщение достижения критического значения параметром 15
- P16 "Monster's health" [0..300] тип=обычный
    старт: [0]
    [0..300] 
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Trick in the safe :)' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Biting stump' [0..4] тип=обычный
    старт: [0]
    [0..4] 
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Sibolusovtus caught' [0..1] тип=обычный
    старт: [0]
    [0..0] Sibolusovtus not caught
    [1..1] Sibolusovtus caught
    критическое: Сообщение достижения критического значения параметром 21
- P20 'Gender of the Sibolusovtus...' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] 
    [2..2] 
    критическое: Сообщение достижения критического значения параметром 19
- P21 'Number of doses' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 20
- P22 'Gear from the third warehouse...' [0..1] тип=обычный
    старт: [0]
    [0..1] Little gear
    критическое: Сообщение достижения критического значения параметром 22
- P23 "Sibolusovtus's nerves" [0..10] тип=обычный
    старт: [0]
    [0..1] The sibolusovtus is still perfectly calm
    [2..3] The sibolusovtus is somewhat nervous
    [4..5] The sibolusovtus is very nervous
    [6..9] The sibolusovtus is in a panic
    [10..10] The sibolusovtus died from fright
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Gender of additional sibolusovtus' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] The sibolusovtus is male
    [2..2] The sibolusovtus is female
    критическое: Сообщение достижения критического значения параметром 24
- P25 'You were at the base' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 25
- P27 'Gloogle' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 27
- P28 'You gave grass to the gaal' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 28
- P29 'Lock' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 30
- P30 'Water level' [0..150] тип=смерть
    старт: [0]
    [0..150] Water level: <>% of 150%
    критическое: The water has risen to the critical level You swam about a few minutes longer, releasing the last bu…
- P31 'Lever 1' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Lever 2' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 29
- P33 'Lever 3' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Lever 4' [0..100] тип=смерть
    старт: [0]
    [0..100] Air in lungs: <>%
    критическое: You suddenly felt as though you didn't have any air left in your lungs, even at the bottom. / Once y…
- P35 "You've got a whip..." [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 35
- P36 "You've got a net" [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 36
- P37 'You have an incomprehensible thingamajig...' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 "You've got a blaster" [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 38
- P39 "You've got a tranquilizer gun" [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 39
- P40 'General warehouse 3' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Questions' [0..3] тип=обычный
    старт: [0]
    [0..0] You received an answer to <> questions
    [1..1] You received an answer to <> question
    [2..2] You received an answer to <> questions
    [3..3] You received an answer to <> questions
    критическое: Сообщение достижения критического значения параметром 41
- P42 'You know where a siba is' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 42
- P43 'Poison2' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 43
- P44 'You know how to get onto the roof' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 46
- P48 '1' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 45

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You carefully guided your ship over the tops of sky-high trees, chose a suitable clearing, and touched down. Then you exited the spaceship and immediately plopp…
    эффект: P1(Time until evening) +1440 [скрыт]
    эффект: P2(Your health) +100 [скрыт]
    эффект: P12(Native's mood) +100 [скрыт]
    эффект: P34(Lever 4) +100 [скрыт]
    скрыт: P3,P4,P5,P6,P7,P8,P9,P10,P11,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P27,P28,P29,P30,P31,P32,P33,P35,P36,P37,P38,P39,P40,P41,P42,P43,P44
  -> Path2 => Loc2  вер=1 порядок=5
       текст: Ask more specifically...
  -> Path3 => Loc4  вер=1 порядок=5
       текст: Faint...
  -> Path4 => Loc5  вер=1 порядок=5
       текст: Panic...

### Loc2 [обычная]
    Loc2-1: After all you've been through, you received the news about poison inside your body rather well. The important thing is to refrain from panicking until it's clea…
  -> Path6 => Loc3  вер=1 порядок=5
       текст: Kill yourself
       ответ: "This planet is just a nightmare. How am I supposed to catch this stupid sibolusovtus and carry it back to the laboratory? Wouldn't it be easier to take my own …
       скрыт: P1,P2,P3,P19
  -> Path190 => Loc6  вер=1
       текст: Go to the base
       ответ: You quickly ran after the gaal on the trodden path, trying not to deviate from the path even an inch, because some murky slush bubbled venomously along the edge…
       эффект: P1(Time until evening) -100 [показ]
       эффект: P25(You were at the base) +1
       показ: P2,P3,P5,P19

### Loc3 [СМЕРТЬ]
    выбор описания: {[1..2]}
    Loc3-1: You brought two of the fingers on your right hand up to your temple and, cocking your thumb slowly, said: / "Boom!" / Following this cowboy gesture, you blew th…
    Loc3-2: You returned to your ship; picked up a brick, which had been left there by some miracle; and began to intentionally beat yourself in the head. After the twentie…

### Loc4 [обычная]
    Loc4-1: "Why God?!" you screamed and, after closing your eyes, picturesquely fell right across the squashed leg-eared. / When you opened your eyes you saw the sad face …
  -> Path5 => Loc2  вер=1 порядок=5

### Loc5 [СМЕРТЬ]
    Loc5-1: You let out a heartrending howl and began running in circles around the clearing. / It all ended when the gaal spit on you as you ran past, and then left. / On …

### Loc6 [обычная]
    выбор описания: {([p12]>0)+([p12]>30)+([p12]>50)}
    Loc6-1: You are standing in the base's main area...  / If you go to the left, you'll end up in the laboratories, a great place for inventing things... If you go straigh…
  -> Path7 => Loc7  вер=1 порядок=3
       текст: To the laboratory
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {1}
  -> Path8 => Loc8  вер=1 порядок=2
       текст: To the hospital
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {1}
  -> Path9 => Loc9  вер=1 порядок=1
       текст: To the warehouse
       эффект: P1(Time until evening) -10
  -> Path202 => Loc33  вер=1 порядок=4
       текст: Go to the expedition leader's office...
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {3}
  -> Path368 => Loc139  вер=1
       текст: Go into the forest to look for a sibolusovtus
       ответ: Thus, you found yourself in a dense, impassable forest. Hungry eyes stared at you from all sides, and various animals, insects, and other spawn of the forest br…
       эффект: P1(Time until evening) -100

### Loc7 [обычная]
    выбор описания: {[p48]}
    Loc7-1: You looked sullenly at the right dim sky and went to the right. / The laboratories looked like several containers of ore that had been bolted together by passag…
    Loc7-2: With sharp eyes you looked over the racks and became pensive. All of the flasks and vials on them were identical and transparent, so each of them could contain …
    Loc7-3: You grabbed the closest flask and then tracked down a can of sulfuric acid in the cabinet. / The transfusion operation was over in three minutes. However, durin…
    эффект: P45(Реактивы №2) = {0}
    эффект: P46(Реактивы №3) = {0}
    эффект: P47(Реактивы №4) = {0}
  -> Path193 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Pour yourself a little cup of pure, medicinal...
       эффект: P48(1) = {2}
  -> Path195 => Loc30  вер=1 порядок=5
       текст: Pour a flask of sulfuric acid
       условия: логика {[p3]<100}
       эффект: P1(Time until evening) -10
       эффект: P2(Your health) -5
       эффект: P3(You're carrying) +1
       эффект: P7(Flask of sulfuric acid.) +1 [показ]
       эффект: P48(1) = {3}
  -> Path197 => Loc6  вер=1 порядок=5
       текст: Go to the main area of the base...
       ответ: You took a departing glance at the laboratory, exhaled sadly, and went outside after turning off the light...
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {1}

### Loc8 [обычная]
    выбор описания: {[p48]}
    Loc8-1: The hospital consisted of several airtight pavilions, an operating room, and a warehouse, that is a huge freezer. / You gave the premises a once-over to decide …
    Loc8-2: You entered the building and even your eyes ached - everything was so white, clean, and sparkling... / After ensuring that everything for a sibolusovtus autopsy…
  -> Path201 => Loc6  вер=1 порядок=5
       текст: Go to the main area...
  -> Path233 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Look around the storage room...
       ответ: You walked up to the storage room's heavy door, pulled with both hands, and opened it, though with some difficulty. A puff of fumes escaped and dispersed instan…
       эффект: P1(Time until evening) -20
  -> Path234 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Look around the storage room...
       ответ: You walked up to the storage room's heavy door, pulled with both hands, and opened it, though with some difficulty. A puff of fumes escaped and dispersed instan…
       эффект: P1(Time until evening) -20
  -> Path374 => Loc98  вер=1 порядок=5
       текст: Head toward the pavilion...
       эффект: P48(1) = {1}
  -> Path431 => Loc115  вер=1 порядок=5
       текст: Go to the operating room...
       эффект: P1(Time until evening) -15
       эффект: P48(1) = {2}

### Loc9 [обычная]
    Loc9-1: The warehouse consisted of three buildings, not connected to each other, standing in a semicircle on the edge of the area.
    эффект: P4(Warehouse password) = {0}
    эффект: P40(General warehouse 3) = {0}
  -> Path191 => Loc25  вер=1 порядок=5
       текст: Examine the first compartment...
       ответ: You approached the warehouse door and noticed a combination lock.  / "I wonder why they need such a sophisticated lock on an uninhabited planet," you thought to…
       показ: P4
  -> Path198 => Loc31  вер=1 порядок=5
       текст: Examine the second compartment...
  -> Path199 => Loc32  вер=1 порядок=5
       текст: Examine the third compartment...
  -> Path200 => Loc6  вер=1 порядок=5
       текст: Go to the main area...
       эффект: P1(Time until evening) -10

### Loc10 [обычная]
    Loc10-1: You walked down the path along a cliff resembling a wall, and suddenly you saw old, iron gates in front of you that were so big you could fly your ship through …
    эффект: P1(Time until evening) -30
  -> Path98 => Loc139  вер=1 порядок=5
       текст: Continue the search
  -> Path537 => Loc150  вер=1 порядок=4
       текст: Examine the mechanism more closely
       условия: логика {[p29]<10}

### Loc11 [обычная]
    Loc11-1: You walked peacefully down the path without hurting a thing when suddenly you saw an auropedal sibolusovtus right in front of you.  / You instantly stood at att…
    эффект: P1(Time until evening) -20
  -> Path28 => Loc15  вер=1 порядок=5
       текст: Continue on the path through the forest

### Loc12 [обычная]
    Loc12-1: You walked down the path, on the lookout for sibolusovtuses, but you didn't notice that you had strayed into some sort of wild reeds that stood at three times t…
    эффект: P1(Time until evening) -20
  -> Path524 => Loc132  вер=1 порядок=5
       текст: Look to see what's sparkling over there
       эффект: P34(Lever 4) = {100} [показ]
  -> Path533 => Loc139  вер=1 порядок=5
       текст: Pay no attention to the sparkle; continue the search

### Loc13 [пустая]
    эффект: P1(Time until evening) -20
  -> Path36 => Loc139  вер=1 порядок=5

### Loc14 [пустая]
    эффект: P1(Time until evening) -20
  -> Path77 => Loc139  вер=1 порядок=5

### Loc15 [обычная]
    Loc15-1: You went into clearing that was completely overgrown with strange, waist-high grass. But the strangest part was that it was a succulent, poison-blue color and i…
    эффект: P1(Time until evening) -10
  -> Path274 => Loc58  вер=1 порядок=5
       текст: Pay no attention...
       ответ: You thought that this must be your imagination. After all, science hasn't proven the existence of stumps with eyes. / The air was so nice and cool that you doze…
       эффект: P1(Time until evening) -10
  -> Path275 => Loc59  вер=1 порядок=5
       текст: Look closely...
       ответ: You looked even more closely at the stump. It immediately covered its eyes and hid its fangs, but this didn't disturb you...
       эффект: P1(Time until evening) -10

### Loc16 [пустая]
    эффект: P1(Time until evening) -20
  -> Path51 => Loc139  вер=1 порядок=5

### Loc17 [пустая]
    эффект: P1(Time until evening) -20
  -> Path42 => Loc139  вер=1 порядок=5

### Loc18 [обычная]
    Loc18-1: You walked down the path among short cliffs, and your eyes suddenly fell on a small cluster of grass that was exactly like what the gaal needs.
  -> Path335 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Go farther
       ответ: You vision didn't let you down, and you joyfully plucked up the plant. / "The gaal will be so happy, my precious," you remarked as you tucked the grass into you…
       условия: логика {[p11]=0}
       эффект: P1(Time until evening) -20
       эффект: P11(Symgrass for the gaal) +1 [показ]
  -> Path336 => Loc82  вер=1 порядок=5
       текст: Go farther
       ответ: Cliffs towered proudly above you, obstructing the sun which occasionally crept out from the storm clouds. The result was a penetrating, chilling darkness. / You…
       условия: логика {[p11]=0}
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) -5
  -> Path384 => Loc82  вер=1 порядок=5
       текст: Go farther
       ответ: "I've already got one like that," you thought and walked on...
       условия: логика {[p11]=1}
       эффект: P1(Time until evening) -20

### Loc19 [обычная]
    Loc19-1: You were walking down the path when suddenly some inner feeling ordered you to stop, which you did. / You cautiously looked out at the clearing from behind a tr…
    эффект: P1(Time until evening) -20
  -> Path318 => Loc77  вер=1 порядок=5
       текст: Throw yourself onto it as quickly as possible...
       ответ: You issued a war cry and threw yourself onto the poor little beast sleeping on the small stump. / While you were running toward the stump, dreadfully churning y…
       эффект: P1(Time until evening) -10
  -> Path319 => Loc78  вер=1 порядок=5
       текст: Cautiously creep closer...
       ответ: You hunkered down, held your breath, and stealthily tiptoed toward the utterly unsuspecting little beast...
       эффект: P1(Time until evening) -10

### Loc20 [пустая]
    эффект: P1(Time until evening) -20
  -> Path45 => Loc139  вер=1 порядок=5

### Loc21 [обычная]
    Loc21-1: You walked peacefully along a mossy part of the forest and unexpectedly stumbled into a stone wall which was built across the path. You surveyed it and conclude…
    эффект: P1(Time until evening) -5
  -> Path253 => Loc48  вер=1 порядок=5
       текст: Climb over the wall...
       ответ: You quickly climbed over the wall and jumped down to the other side.
       эффект: P1(Time until evening) -20
  -> Path254 => Loc48  вер=1 порядок=5
       текст: Look for a gate...
       ответ: You walked along the wall, examining it and trying to find an entrance. / When you had begun to feel quite exhausted, you finally found an entrance...  / You pa…
       эффект: P1(Time until evening) -60

### Loc22 [пустая]
    эффект: P1(Time until evening) -20
  -> Path26 => Loc139  вер=1 порядок=5

### Loc23 [обычная] визитов<=1
    Loc23-1: You were leisurely plodding through the swamp when a man in animal skins, hairy and stinky, jump from a tree to the ground right in front of your nose. You inst…
    эффект: P12(Native's mood) +50 [скрыт]
  -> Path493 => Loc117  вер=1 порядок=2
       текст: Run away...
  -> Path494 => Loc74  вер=1 порядок=1
       текст: Annihilate the nasty giant
       эффект: P12(Native's mood) -10
  -> Path495 => Loc83  вер=1
       текст: Talk with him...
  -> Path498 => Loc110  вер=1 порядок=2
       текст: Run away...
       ответ: You abruptly threw a flask of sulfuric acid into the native's eyes and bolted away like lightning. Behind you, you could heard a concert of diabolical screams a…
       условия: логика {[p7]>0}
       эффект: P7(Flask of sulfuric acid.) -1

### Loc24 [обычная]
    Loc24-1: That's does it. All of the openings were generously seasoned with acid and the lock was already literally hanging by a thread. / You knocked on the lock a few t…
  -> Path550 => Loc28  вер=1 порядок=5
       текст: The life of a great ranger came to a worthy end.

### Loc25 [обычная]
    Loc25-1: Select the number to add...
  -> Path203 => Loc9  вер=1 порядок=7
       текст: Walk away from the door.
       ответ: You stepped sorrowfully away from the door, cursing these strange archaeologists who pack things where needed; but where it's not needed, they put tricky locks …
       скрыт: P4
  -> Path204 => Loc34  вер=1
       текст: Enter 5
       эффект: P4(Warehouse password) +5
  -> Path205 => Loc34  вер=1 порядок=1
       текст: Enter 10
       эффект: P4(Warehouse password) +10
  -> Path206 => Loc34  вер=1 порядок=2
       текст: Enter 20
       эффект: P4(Warehouse password) +20
  -> Path207 => Loc34  вер=1 порядок=3
       текст: Enter 50
       эффект: P4(Warehouse password) +50
  -> Path208 => Loc34  вер=1 порядок=4
       текст: Enter 100
       эффект: P4(Warehouse password) +100
  -> Path221 => Loc34  вер=1 порядок=5
       текст: Enter 200
       эффект: P4(Warehouse password) +200
  -> Path556 => Loc34  вер=1 порядок=6
       текст: Zero out the code
       эффект: P4(Warehouse password) = {0}

### Loc26 [обычная]
    Loc26-1: Inside the warehouse proved to be just as small as the outside. Which, by the way, wasn't surprising. And the number of things in the warehouse also gave you th…
  -> Path192 => Loc35  вер=1 порядок=2
       текст: Pick up the iron rod...
       ответ: "This'll come in handy..." you thought as you lifted the rod from the ground. "Who knows. Some beast might attack me here. I've got to be prepared for everythin…
       условия: логика {[p3]<76 and [p35]=0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) +25
       эффект: P8(Iron rod) +4 [показ]
       эффект: P35(You've got a whip...) +1
  -> Path211 => Loc9  вер=1 порядок=6
       текст: Leave the warehouse...
       ответ: You left the warehouse and carefully closed the door behind you. The lock clicked, but you already knew the code, so this wasn't scary...
  -> Path215 => Loc36  вер=1 порядок=1
       текст: Take the net...
       ответ: You walked up to the net, glancing at it with a critical eye. Then you removed it from the hooks it was hanging on and wound it up all higgledy-piggledy. Then y…
       условия: логика {[p3]<56 and [p36]=0}
       эффект: P1(Time until evening) -10
       эффект: P3(You're carrying) +45
       эффект: P6(Net for a leg-eared) +1 [показ]
       эффект: P36(You've got a net) +1
  -> Path217 => Loc37  вер=1
       текст: Take the tranquilizer gun...
       ответ: You took the gun from the rack, looked at it all over, clicked the hammer a few times with a heavy heart, bemoaning the lack of tranquilizer darts, and stuffed …
       условия: логика {[p3]<76 and [p39]=0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) +25
       эффект: P39(You've got a tranquilizer gun) +1
       показ: P9
  -> Path222 => Loc39  вер=1 порядок=3
       текст: Take the assault blaster...
       ответ: You closely examined the bulky monstrosity from every side and even felt a twinge of nostalgia for the old, happier days of your youth when every self-respectin…
       условия: логика {[p3]<61 and [p38]=0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) +40
       эффект: P38(You've got a blaster) +1
       показ: P10
  -> Path487 => Loc40  вер=1 порядок=5
       текст: Get rid of the thingamajig...
       условия: логика {[p37]=1}
       эффект: P3(You're carrying) -50
       эффект: P15(Incomprehensible baloney...) = {0} [скрыт]
       эффект: P37(You have an incomprehensible thingamajig...) -1
  -> Path489 => Loc40  вер=1 порядок=5
       текст: Put the tranquilizer gun back in its place...
       условия: логика {[p39]=1}
       эффект: P3(You're carrying) -25
       эффект: P39(You've got a tranquilizer gun) -1
       скрыт: P9
  -> Path490 => Loc40  вер=1 порядок=5
       текст: Put the net back in its place...
       условия: логика {[p36]=1}
       эффект: P3(You're carrying) -45
       эффект: P6(Net for a leg-eared) = {0} [скрыт]
       эффект: P36(You've got a net) -1
  -> Path491 => Loc40  вер=1 порядок=5
       текст: Put the assault blaster back in its place...
       условия: логика {[p38]=1}
       эффект: P3(You're carrying) -40
       эффект: P38(You've got a blaster) -1
       скрыт: P10
  -> Path492 => Loc40  вер=1 порядок=5
       текст: Put the iron rod back in its place...
       условия: логика {[p35]=1}
       эффект: P3(You're carrying) -25
       эффект: P8(Iron rod) = {0} [скрыт]
       эффект: P35(You've got a whip...) -1

### Loc27 [обычная]
    Loc27-1: You poked one of the bodies with your finger and suddenly it froze in place. In vain, you pulled on your finger, but it wouldn't move. / You had already begun s…
    Loc27-2: You poked one of the bodies with your finger. Nothing happened and you left the building.
  -> Path235 => Loc8  вер=1 порядок=5
       текст: Go away from the storage room...
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {1}

### Loc28 [обычная]
    Loc28-1: However, as soon as you had fallen into the depths of despair, something began to happen around you. / It was as if small flashes of light began to spin in the …
    эффект: P1(Time until evening) -60
  -> Path551 => Loc190  вер=1 порядок=5
       текст: Leave the warehouse
       эффект: P25(You were at the base) +1

### Loc29 [пустая] визитов<=1
  -> Path194 => Loc7  вер=1 проходов<=1 порядок=5

### Loc30 [пустая]
  -> Path196 => Loc7  вер=1 порядок=5

### Loc31 [обычная]
    Loc31-1: You approached the door to the second compartment and noticed that it was locked. In order to open it, you need a key card...
  -> Path231 => Loc9  вер=1 порядок=5
       текст: Walk away from the door...
       ответ: You stepped sorrowfully away from the door, cursing these strange archaeologists who pack things where needed; but where it's not needed, they put tricky locks …
  -> Path232 => Loc42  вер=1 порядок=5
       текст: Open the warehouse with the key card...
       ответ: You inserted the key card you had taken from the gaal into the slot on the lock, and the door opened.
       условия: логика {[p14]=1}
       эффект: P48(1) = {1}

### Loc32 [обычная]
    выбор описания: {[p22]+1}
    Loc32-1: You looked closely and discovered that the door is equipped with a famous, gaalian gear lock, which, incidentally, has never, ever been broken into.  / If you d…
    Loc32-2: You looked closely and discovered that the door is equipped with a famous, gaalian gear lock, which, incidentally, has never, ever been broken into.  / But you …
  -> Path383 => Loc102  вер=1 порядок=5
       текст: Insert the gear you found into the opening in the lock...
       условия: логика {[p22]=1}
       эффект: P1(Time until evening) -5
  -> Path477 => Loc9  вер=1 порядок=5
       текст: Walk away from the door...

### Loc33 [обычная]
    выбор описания: {[p48]}
    Loc33-1: You scratched the back of your head and thought that you ought be doing something. That you ought to stop hanging around this mess all day.
    Loc33-2: You began rummaging through the papers but didn't find anything specific. You only managed to kick dust up to the ceiling. / Thundering out a couple of heroic s…
    Loc33-3: You approached the building. From the outside it appeared very old - as if it had survived many expeditions. The plastic on the roof had turned grey with time a…
  -> Path278 => Loc60  вер=1 порядок=5
       текст: Look in the safe...
       ответ: You walked up to the safe and cautiously opened the door a bit. A sharp, suffocating odor hit your nose and you staggered back. It's a good thing you did. Some …
       условия: логика {[p17]=0}
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -15
       эффект: P17(Trick in the safe :)) +1
       эффект: P48(1) = {1}
  -> Path279 => Loc60  вер=1 порядок=5
       текст: Look in the safe...
       ответ: You cautiously peered into the safe, fearful that some other beast had taken up residence there... Discovering that this wasn't the case, you sat down in front …
       условия: логика {[p17]=1}
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {1}
  -> Path280 => Loc6  вер=1 порядок=9
       текст: Flee the building...
       ответ: You tore yourself away from looking at the chaos going on in the building and left the building.
       эффект: P1(Time until evening) -5
  -> Path281 => Loc61  вер=1 порядок=5
       текст: Examine the writing desk...
       эффект: P48(1) = {1}
  -> Path282 => Loc62  вер=1 порядок=5
       текст: Rummage through the papers on the floor...
       эффект: P1(Time until evening) -50
       эффект: P48(1) = {2}

### Loc34 [обычная]
    Loc34-1: The number [p4] illuminated the screen.
  -> Path209 => Loc25  вер=1 порядок=5
       эффект: P1(Time until evening) -5
  -> Path210 => Loc26  вер=1 порядок=5
       текст: Open the door...
       ответ: You saw that the lock on the doors had changed from red to green, and realized that you were being invited in...
       условия: логика {[p4]=325}
       скрыт: P4

### Loc35 [пустая]
  -> Path212 => Loc26  вер=1 порядок=5

### Loc36 [пустая]
  -> Path216 => Loc26  вер=1 порядок=5

### Loc37 [пустая]
  -> Path218 => Loc26  вер=1 порядок=5

### Loc39 [пустая]
  -> Path224 => Loc26  вер=1 порядок=5

### Loc40 [пустая]
    эффект: P1(Time until evening) -10
  -> Path488 => Loc26  вер=1 порядок=5

### Loc41 [пустая]
  -> Path116 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the sixth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path126 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the seventh opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path127 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the eighth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path128 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the ninth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path140 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the tenth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path142 => Loc152  вер=1 порядок=5
       текст: Remaining openings
  -> Path599 => Loc139  вер=1 порядок=5
       текст: Continue the search and leave the lock alone
       условия: P7(Flask of sulfuric acid.) 0..0

### Loc42 [обычная]
    Loc42-1: You entered the warehouse. Ah, the promised land. The racks were breaking from the weight of ammunition and various machines. You found yourself blaster rounds,…
    Loc42-2: You found a box of tranquilizer darts and loaded the gun.
    Loc42-3: You walked up to the racks of ammunition and loaded your blaster.
    Loc42-4: You approached the strange apparatus that was standing on the support in the center of the room, and lifted it up a little bit. Heavy as a tank - and you have n…
  -> Path239 => Loc45  вер=1 порядок=5
       текст: Collect tranquilizer darts...
       условия: логика {[p39]=1 and [p9]<6}
       эффект: P1(Time until evening) -5
       эффект: P9(Tranquilizer gun) +6
       эффект: P48(1) = {2}
  -> Path241 => Loc44  вер=1 порядок=5
       текст: Collect rounds for the assault blaster...
       условия: логика {[p38]=1 and [p10]<8}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) +8
       эффект: P48(1) = {3}
  -> Path243 => Loc46  вер=1 порядок=5
       текст: Take the incomprehensible unit...
       условия: логика {[p3]<51 and [p37]=0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) +50
       эффект: P15(Incomprehensible baloney...) +1 [показ]
       эффект: P37(You have an incomprehensible thingamajig...) +1
       эффект: P48(1) = {4}
  -> Path481 => Loc47  вер=1 порядок=5
       текст: Put the incomprehensible unit back in its place...
       условия: логика {[p37]=1}
       эффект: P3(You're carrying) -50
       эффект: P15(Incomprehensible baloney...) = {0} [скрыт]
       эффект: P37(You have an incomprehensible thingamajig...) -1
  -> Path483 => Loc47  вер=1 порядок=5
       текст: Get rid of the tranquilizer gun...
       условия: логика {[p39]=1}
       эффект: P3(You're carrying) -25
       эффект: P39(You've got a tranquilizer gun) -1
       скрыт: P9
  -> Path484 => Loc47  вер=1 порядок=5
       текст: Get rid of the net...
       условия: логика {[p36]=1}
       эффект: P3(You're carrying) -45
       эффект: P6(Net for a leg-eared) = {0} [скрыт]
       эффект: P36(You've got a net) -1
  -> Path485 => Loc47  вер=1 порядок=5
       текст: Get rid of the iron rod...
       условия: логика {[p35]=1}
       эффект: P3(You're carrying) -25
       эффект: P8(Iron rod) = {0} [скрыт]
       эффект: P35(You've got a whip...) -1
  -> Path486 => Loc47  вер=1 порядок=5
       текст: Get rid of the assault blaster...
       условия: логика {[p38]=1}
       эффект: P3(You're carrying) -40
       эффект: P38(You've got a blaster) -1
       скрыт: P10
  -> Path519 => Loc9  вер=1 порядок=5
       текст: Leave the warehouse...

### Loc43 [обычная]
    Loc43-1: An analyzer began to buzz and lots of little lights started flashing.  / The sibolusovtus that could be seen through the small window in the door sat peacefully…
    эффект: P1(Time until evening) -30
  -> Path349 => Loc88  вер=2 порядок=5
       текст: Check the result...
       ответ: "The sibolusovtus is male. Confidence: 70%," read the analyzer's output.
       эффект: P20(Gender of the Sibolusovtus...) +2
       эффект: P24(Gender of additional sibolusovtus) +1
  -> Path350 => Loc89  вер=2 порядок=5
       текст: Check the result...
       ответ: "The sibolusovtus is female. Confidence: 70%," read the analyzer's output. / So if the analyzer wasn't mistaken, the sibolusovtus wasn't the right gender and yo…
       эффект: P20(Gender of the Sibolusovtus...) +1
       эффект: P24(Gender of additional sibolusovtus) +2
  -> Path354 => Loc88  вер=1 порядок=5
       текст: Check the result...
       ответ: "The sibolusovtus is male. Confidence: 70%," read the analyzer's output. / So if the analyzer wasn't mistaken, the sibolusovtus was the right gender and you sho…
       эффект: P20(Gender of the Sibolusovtus...) +1
       эффект: P24(Gender of additional sibolusovtus) +1
  -> Path355 => Loc89  вер=1 порядок=5
       текст: Check the result...
       ответ: "The sibolusovtus is female. Confidence: 70%," read the analyzer's output.
       эффект: P20(Gender of the Sibolusovtus...) +2
       эффект: P24(Gender of additional sibolusovtus) +2

### Loc44 [пустая]
  -> Path242 => Loc42  вер=1 порядок=5

### Loc45 [пустая]
  -> Path240 => Loc42  вер=1 порядок=5

### Loc46 [пустая]
  -> Path244 => Loc42  вер=1 порядок=5

### Loc47 [пустая]
    эффект: P1(Time until evening) -10
  -> Path482 => Loc42  вер=1 порядок=5

### Loc48 [обычная]
    Loc48-1: You looked around and observed that the path turned into a broad corridor paved with marble tiles. This would suggest that there was, or maybe even is, some for…
    Loc48-2: You looked around and observed that the path turned into a broad corridor paved with marble tiles. This would suggest that there was, or maybe even is, some for…
    эффект: P16(Monster's health) +100
  -> Path255 => Loc49  вер=1 порядок=5
       текст: Run away...
       ответ: You ran along the corridor to save yourself from the monster, who pranced after you, smacking and drooling and howling in anticipation of lunch. Despite your be…
       эффект: P1(Time until evening) -10
       эффект: P16(Monster's health) +20
  -> Path257 => Loc50  вер=1 порядок=5
       текст: Begin the battle...
       эффект: P1(Time until evening) -5

### Loc49 [обычная]
    Loc49-1: You dashed to the next intersection in the corridor and stopped to catch your breath. Soon panting and wheezing informed you that the monster was approaching...
  -> Path256 => Loc50  вер=1 порядок=5
       текст: Begin the battle...
       эффект: P1(Time until evening) -5
  -> Path259 => Loc51  вер=1 порядок=5
       текст: Continue to run away...
       ответ: You ran along the corridor to save yourself from the monster, who pranced after you, smacking and drooling and howling in anticipation of lunch. Despite your be…
       условия: логика {[p16]<300}
       эффект: P1(Time until evening) -10
       эффект: P16(Monster's health) +20
  -> Path479 => Loc67  вер=1 порядок=5
       текст: Continue to run away...
       ответ: You decided to show the monster who had won first place at the races, and you took off with all your might.  / Soon the wheezing at your back died down and you …
       условия: логика {[p16]<300}
       эффект: P1(Time until evening) -50
  -> Path480 => Loc51  вер=1 порядок=5
       текст: Continue to run away...
       ответ: You ran along the corridor to save yourself from the monster, who pranced after you, smacking and drooling and howling in anticipation of lunch. Despite your be…
       условия: логика {[p16]<300}
       эффект: P1(Time until evening) -10
       эффект: P16(Monster's health) +20
  -> Path532 => Loc52  вер=1 порядок=5
       текст: Stop
       ответ: The monster, who was still leisurely shuffling after you, stopped abruptly and let out a wild howl. You turned around and saw that it had cut its own chest to s…
       условия: логика {[p16]=300}

### Loc50 [обычная]
    Loc50-1: Suddenly you could see in your mind what you could use to destroy this fiendish fiend...
    Loc50-2: "Ha-ha!" you screamed. "Die, odious beast!"
    Loc50-3: The battle was remarkably difficult. Casualties numbered in the millions on both sides, yet nobody was thinking of a truce...
    Loc50-4: The beast hissed maliciously and tried to grab your head, but missed - making you very happy.
  -> Path169 => Loc53  вер=1 порядок=5
       текст: Engage the monster in hand-to-hand combat...
       ответ: You performed a super tricky boxing move and, after dodging, you drove your heavy boot into the monster's snout. / But this wasn't the monster's first rodeo and…
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -10
       эффект: P16(Monster's health) -10
  -> Path262 => Loc53  вер=1 порядок=5
       текст: Whack the monster with the iron rod...
       ответ: You moved a bit closer to the monster. Then you did a fake move and, after dodging its claws, you clubbed it with the rod as hard as you could.
       условия: логика {[p8]>0}
       эффект: P1(Time until evening) -5
       эффект: P8(Iron rod) -1
       эффект: P16(Monster's health) -30
  -> Path291 => Loc53  вер=1 порядок=5
       текст: Whack the monster with the iron rod...
       ответ: You moved a bit closer to the monster. Then you did a fake move and, after dodging its claws, you clubbed it with the rod as hard as you could. But you didn't t…
       условия: логика {[p8]>0}
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -10
       эффект: P8(Iron rod) -1
       эффект: P16(Monster's health) -30
  -> Path294 => Loc69  вер=1 порядок=5
       текст: Shoot the monster with the incomprehensible thingamajig...
       условия: логика {[p15]=1}
       эффект: P1(Time until evening) -5
  -> Path298 => Loc53  вер=1 порядок=5
       текст: Shoot with your assault blaster...
       ответ: You took aim and fired at the monster that was bounding toward you. Only green slime came splattering out in every direction...
       условия: логика {[p10]>0 and [p38]=1}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) -1
       эффект: P16(Monster's health) -40
  -> Path299 => Loc53  вер=1 порядок=5
       текст: Shoot with your assault blaster...
       ответ: You took aim at the monster bounding toward you and pulled the trigger. An opening appeared in the serpentine head of your opponent, but it was still alive and …
       условия: логика {[p10]>0 and [p38]=1}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) -1
       эффект: P16(Monster's health) -60
  -> Path300 => Loc53  вер=1 порядок=5
       текст: Shoot with the tranquilizer gun...
       ответ: You shot the monster with the tranquilizer gun, but it must have been immune, because not only did it not fall asleep, but it began galloping after you with twi…
       условия: логика {[p9]>0 and [p39]=1}
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -5
       эффект: P9(Tranquilizer gun) -1
       эффект: P16(Monster's health) -10
  -> Path302 => Loc53  вер=1 порядок=5
       текст: Throw the net over the monster...
       ответ: You threw the net over the monster, and a second later bits of it came sailing toward you. The rest decorated your opponent's paws and head.
       условия: логика {[p6]>0}
       эффект: P6(Net for a leg-eared) -1
  -> Path322 => Loc53  вер=1 порядок=5
       текст: Throw sulfuric acid at the monster...
       ответ: You lobbed a vial of sulfuric acid at the monster.  / This caused the monster to begin fuming and producing awful sounds that caused a sudden quaking in the kne…
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) -3
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P16(Monster's health) -30
  -> Path323 => Loc53  вер=1 порядок=5
       текст: Throw sulfuric acid at the monster...
       ответ: You lobbed a vial of sulfuric acid at the monster.  / This caused the monster to begin fuming and producing awful sounds that caused a sudden quaking in the kne…
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -10
       эффект: P3(You're carrying) -3
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P16(Monster's health) -30
  -> Path337 => Loc53  вер=1 порядок=5
       текст: Engage the monster in hand-to-hand combat...
       ответ: You threw yourself onto the monster despite the sudden weakness in your knees. / Nothing good came of this shenanigan. The monster literally smeared you across …
       эффект: P1(Time until evening) -5
       эффект: P2(Your health) -20
       эффект: P16(Monster's health) -5
  -> Path558 => Loc67  вер=5 порядок=5
       текст: Try to run away
       ответ: You began to dart away from the malevolent animal. But you didn't run very far, because it plunged its claws into your back and you found yourself hanging merri…
       эффект: P2(Your health) -100
  -> Path559 => Loc67  вер=1 порядок=5
       текст: Try to run away
       ответ: You made a mad dash down the corridor, incidentally smashing the galactic speed record, and to your great delight, you were successful. The wretch only managed …
       эффект: P2(Your health) -40

### Loc51 [обычная]
    Loc51-1: Drained of all your strength, you leaned against the wall and again cursed yourself for not staying in shape While you caught your breath, the monster's plainti…
  -> Path258 => Loc50  вер=1 порядок=5
       текст: Begin the battle...
  -> Path260 => Loc49  вер=1 порядок=5
       текст: continue to run away...
       ответ: You ran along the corridor to save yourself from the monster, who pranced after you, smacking and drooling and howling in anticipation of lunch. Despite your be…
       условия: логика {[p16]<300}
       эффект: P1(Time until evening) -10
       эффект: P16(Monster's health) +20
  -> Path261 => Loc52  вер=1 порядок=5
       текст: Stop
       ответ: The monster, who was still leisurely shuffling after you, stopped abruptly and let out a wild howl. You turned around and saw that it had cut its own chest to s…
       условия: логика {[p16]=300}
       эффект: P1(Time until evening) -10

### Loc52 [СМЕРТЬ]
    Loc52-1: You didn't like that and began to run more earnestly. But the little lumps turned out to be much faster than their progenitor, and they soon overran you. You fe…

### Loc53 [обычная]
    выбор описания: {([p16]=0)+2*([p16]>0)}
    Loc53-1: The monster let out one last bone-piercing howl and fell spasmodically at your feet... / You kicked it, feeling you had done your duty, and carried on...
    Loc53-2: Judging by the monster's appearance, [p16]% of its health remained.
  -> Path292 => Loc50  вер=1 порядок=5
       условия: логика {[p16]>0}
  -> Path293 => Loc139  вер=1 порядок=5
       текст: Continue...
       условия: логика {[p16]=0}
       эффект: P1(Time until evening) -50

### Loc58 [обычная]
    Loc58-1: You sat down on a small stump, sucked in a full chest of air, and relaxed...
    эффект: P18(Biting stump) +1
  -> Path304 => Loc70  вер=1 порядок=5
       текст: Run away...
       ответ: You shrank away from the stump and then stepped away for quite a distance. The idyllic atmosphere had disappeared instantly and you lost all desire for sleep. /…
       эффект: P1(Time until evening) -5
  -> Path305 => Loc72  вер=1 порядок=5
       текст: Continue to sit...
       ответ: You watched happily as a lovable striped insect crawled along a small leaf on the nearest plant. It was climbing to the very top of the plant, where you noticed…
       условия: логика {[p18]=1}
       эффект: P1(Time until evening) -20
       эффект: P18(Biting stump) +1
  -> Path308 => Loc72  вер=1 порядок=5
       текст: Continue to sit...
       ответ: You continued to sit on the stump and revel in the excellent weather. / Meanwhile, the insect had become distracted from its intentions at the top of the leaf. …
       условия: логика {[p18]=2}
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) -5
       эффект: P18(Biting stump) +1
  -> Path309 => Loc72  вер=1 порядок=5
       текст: Continue to sit...
       ответ: Evidently, the insect had had enough, because it spit out the bit that it until then been gobbling up with relish. Then it again began climbing upward. / The pr…
       условия: логика {[p18]=3}
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) -20
       эффект: P18(Biting stump) +1
  -> Path310 => Loc96  вер=1 порядок=5
       текст: Continue to sit...
       ответ: The insect, finally, reached the top of the leaf and curiously probed into the bird's nest with its feelers. The little bird shot out of its home like a bullet …
       условия: логика {[p18]=4}
       эффект: P1(Time until evening) -20
  -> Path315 => Loc75  вер=1 порядок=5
       текст: Attack the stump...
       ответ: You began to suspect that something wasn't right with this strange plant and, stepping away from it, you decided to engage in wholesale slaughter of all of the …
       эффект: P1(Time until evening) -5

### Loc59 [обычная]
    Loc59-1: "I'm not fooled!" you told the stump confidently. "You can stop pretending."
  -> Path307 => Loc70  вер=1 порядок=5
       текст: Run away...
       ответ: You shrank away from the stump and then stepped away for quite a distance. The idyllic atmosphere had disappeared instantly and you lost all desire for sleep. /…
       эффект: P1(Time until evening) -5
  -> Path369 => Loc75  вер=1 порядок=5
       текст: Annihilate the stump...
       ответ: You shrank away from the stump and then stepped away for quite a distance. The idyllic atmosphere had disappeared instantly and you lost all desire for sleep. /…
       эффект: P1(Time until evening) -5

### Loc60 [обычная]
    выбор описания: {[p48]}
    Loc60-1: Other than the choking odor left by the mysterious little animal's visit, the safe contained the following items: / - Gobs of paper. / - A key card with writing…
    Loc60-2: You picked up the cards and examined them. The first had a code <clr>504<clrEnd> written on it, the second had the code <clr>325<clrEnd> on it, and the third ha…
    Loc60-3: You sat down to look over the heap of papers in the safe. / After half an hour you decided that you wouldn't be able to look over the whole pile of waste paper,…
    Loc60-4: You took a few darts and put them in your pocket. / "These will come in handy," you remarked with some justification.
  -> Path283 => Loc63  вер=1
       текст: Examine the plastic cards
       эффект: P1(Time until evening) -5
       эффект: P48(1) = {2}
  -> Path284 => Loc64  вер=1 порядок=1
       текст: Examine the papers...
       эффект: P1(Time until evening) -30
       эффект: P48(1) = {3}
  -> Path285 => Loc65  вер=1 порядок=5
       текст: Pick up the darts...
       условия: логика {[p39]=1}
       эффект: P9(Tranquilizer gun) +3
       эффект: P48(1) = {4}
  -> Path286 => Loc33  вер=1 порядок=9
       текст: Walk away from the safe...
       эффект: P48(1) = {1}

### Loc61 [обычная]
    выбор описания: {[p48]}
    Loc61-1: There was nothing interesting on the table itself, but there were two boxes next to it. One on the right and one on the left...
    Loc61-2: You opened the box and instantly recoiled, because the box was filled to the brim with green worms that began to move, crawl out of the box, move in your direct…
    Loc61-3: After you had opened the right box, which took great effort, you observed an odd little gear that, in a writing desk, looked odd to say the least. / "That's not…
    Loc61-4: You opened it and poked around all over inside. There wasn't anything interesting in the box...
  -> Path365 => Loc95  вер=1
       текст: Look in the right drawer...
       условия: логика {[p22]=0}
       эффект: P1(Time until evening) -10
       эффект: P22(Gear from the third warehouse...) +1 [показ]
       эффект: P48(1) = {3}
  -> Path367 => Loc33  вер=1 порядок=9
       текст: Walk away from the table...
       эффект: P48(1) = {1}
  -> Path385 => Loc95  вер=1 порядок=5
       текст: Look in the right drawer...
       условия: логика {[p22]=1}
       эффект: P48(1) = {4}
  -> Path386 => Loc103  вер=1 проходов<=1 порядок=5
       текст: Look in the left drawer
       эффект: P1(Time until evening) -10
       эффект: P48(1) = {2}

### Loc62 [пустая]
  -> Path382 => Loc33  вер=1 порядок=5

### Loc63 [пустая]
  -> Path287 => Loc60  вер=1 порядок=5

### Loc64 [пустая]
  -> Path288 => Loc60  вер=1 порядок=5

### Loc65 [пустая]
  -> Path289 => Loc60  вер=1 порядок=5

### Loc67 [пустая]
    эффект: P16(Monster's health) = {0}
  -> Path527 => Loc139  вер=1 порядок=2

### Loc68 [обычная]
    выбор описания: {[p27]+1}
    Loc68-1: Just then your attention was drawn to the interactive display on the wall. It was labeled "Animal Anatomy".  / You walked up to the display, and typed <clr>"aur…
    Loc68-2: You walked straight past the information display to the operating room.
  -> Path344 => Loc84  вер=1 порядок=5
       текст: Pick a subject: "The Proper Way to Dress an <clr>Auropedal Sibolusovtus<clrEnd>"...
       условия: логика {[p27]=0}
  -> Path345 => Loc85  вер=1 порядок=5
       текст: Pick a subject: "Everything About <clr>Auropedal Sibolusovtuses<clrEnd>"...
       условия: логика {[p27]=0}
  -> Path346 => Loc86  вер=1 порядок=5
       текст: Pick a subject: "Naked, <clr>Leg-Eared<clrEnd> Fae Idly Splashes at <clr>sibolusovtus<clrEnd> in the Shower"...
       условия: логика {[p27]=0}
  -> Path553 => Loc123  вер=1 порядок=5
       текст: Get down to business
       условия: логика {[p27]=1}

### Loc69 [обычная]
    Loc69-1: You played around with the apparatus a bit and realized that among its control devices there were only three buttons. White, blue, and red...
  -> Path295 => Loc53  вер=1 порядок=5
       текст: Press the blue button...
       ответ: You pushed the blue button as far as it would go and watched in delight as a blizzard slammed into the monster's chest, freezing it and dropping the overall sur…
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) -5
       эффект: P15(Incomprehensible baloney...) -1
       эффект: P16(Monster's health) -100
  -> Path296 => Loc53  вер=1 порядок=5
       текст: Press the white button...
       ответ: You pressed the white button and watched what it did to the monster. / What it did was most unfortunate. The monster entirely ignored your efforts and gave you …
       эффект: P2(Your health) -40
       эффект: P15(Incomprehensible baloney...) -1
  -> Path297 => Loc53  вер=1 порядок=5
       текст: Press the red button...
       ответ: You pointed the weapon's barrel at the monster and pressed the red button as far as it would go. / The air was suddenly filled with the smell of burning fur, an…
       эффект: P1(Time until evening) -20
       эффект: P15(Incomprehensible baloney...) -1
       эффект: P16(Monster's health) -150

### Loc70 [обычная]
    Loc70-1: "I guess the gaal was right," you thought as you surveyed the surroundings. "Dying on this planet is much easier than surviving..."
    эффект: P18(Biting stump) = {0}
  -> Path97 => Loc139  вер=1 порядок=5
       текст: Continue the search
       ответ: You headed back in the hopes that you'd have better luck, but there was a sudden deluge... / You were instantly soaked through, as if you had been the victim of…

### Loc71 [пустая]
  -> Path316 => Loc75  вер=1 порядок=5

### Loc72 [пустая]
  -> Path311 => Loc58  вер=1 порядок=5

### Loc74 [обычная]
    Loc74-1: You tried to put out your gun, but the native threw himself on you and stopped you...
    эффект: P1(Time until evening) -10
  -> Path497 => Loc117  вер=1 порядок=5
       текст: Run away...
  -> Path500 => Loc83  вер=1 порядок=5
       текст: Talk with him...

### Loc75 [обычная]
    Loc75-1: The only thing left to do is choose what to use to destroy the vicious stump.
  -> Path306 => Loc76  вер=1 порядок=5
       текст: Shoot the stump with the assault blaster...
       ответ: You shot the stump, and it joyfully splintered into kindling...
       условия: логика {[p10]>0 and [p38]=1}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) -1
  -> Path312 => Loc71  вер=1 порядок=5
       текст: Shoot the stump with the tranquilizer gun...
       ответ: You planted a tranquilizer dart into the stump, but you couldn't understand what this did for you. Nobody has ever thought to put a tree to sleep...
       условия: логика {[p9]>0 and [p39]=1}
       эффект: P1(Time until evening) -10
       эффект: P9(Tranquilizer gun) -1
  -> Path313 => Loc71  вер=1 порядок=5
       текст: Hit the stump with the iron rod...
       ответ: You swung good and hard and whacked the stump with the rod.  / But since the tree was made out of wood, nothing bad happened to it. Except maybe a small scuff m…
       условия: логика {[p8]>0}
       эффект: P1(Time until evening) -10
  -> Path314 => Loc71  вер=1 порядок=5
       текст: Throw the net over the stump...
       ответ: With the accuracy of a sniper, you tossed the net over the stump. It wasn't clear what this gave you other than a ruined net...
       условия: логика {[p6]=1}
       эффект: P1(Time until evening) -10
       эффект: P6(Net for a leg-eared) -1
  -> Path324 => Loc76  вер=1 порядок=5
       текст: Throw sulfuric acid at the stump...
       ответ: You hurled a vial of sulfuric acid at the stump and happily observed that it was just as effective on the stump as it was on the laboratory floor. / "Perhaps th…
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) -3
       эффект: P7(Flask of sulfuric acid.) -1
  -> Path370 => Loc97  вер=1 порядок=5
       текст: Attack using the incomprehensible unit...
       ответ: You examined the unit, figured out approximately where its barrel was, pointed it at the stump, and prepared to attack...
       условия: логика {[p15]=1}
       эффект: P1(Time until evening) -10
  -> Path407 => Loc70  вер=1 порядок=5
       текст: Spit on the stump and leave...
       ответ: That's just what you did...

### Loc76 [обычная]
    Loc76-1: Thus, you were through with the stump and could peacefully continue on your way...
  -> Path317 => Loc70  вер=1 порядок=5
       текст: Leave this place...
       эффект: P1(Time until evening) -5

### Loc77 [обычная]
  -> Path32 => Loc139  вер=1 порядок=5

### Loc78 [обычная]
    Loc78-1: A sibolusovtus dozed peacefully on a little stump right in front of you. All you have to do is grab it to be healed...
  -> Path320 => Loc79  вер=1 порядок=5
       текст: Throw the net on the sibolusovtus...
       ответ: The sibolusovtus squealed, shrieked, kicked up its hind legs, stamped its hooves, fidgeted, scampered about, and tried to bolt - but the net pressed it securely…
       условия: логика {[p6]=1}
       эффект: P1(Time until evening) -10
       эффект: P6(Net for a leg-eared) -1
       эффект: P19(Sibolusovtus caught) +1
  -> Path321 => Loc80  вер=1 порядок=5
       текст: Shoot with your assault blaster
       ответ: You took the assault blaster from you shoulder and shot the serenely sleeping sibolusovtus.  / Judging by the gory scrap of a hide left on the stump swimming in…
       условия: логика {[p10]>0 and [p38]=1}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) -1
  -> Path325 => Loc77  вер=1 порядок=5
       текст: Shoot with the tranquilizer gun...
       ответ: You aimed carefully at the little animal and fired. / To your horror, you missed, but the sibolusovtus, who had been roused from slumber by the loud shot, hoppe…
       условия: логика {[p9]>0 and [p39]=1}
       эффект: P1(Time until evening) -5
       эффект: P9(Tranquilizer gun) -1
  -> Path326 => Loc79  вер=1 порядок=5
       текст: Shoot with the tranquilizer gun...
       ответ: You aimed carefully and shot the sibolusovtus with a tranquilizer dart. / The little animal twitched and instantly went limp as it sank into sleep... / You happ…
       условия: логика {[p9]>0 and [p39]=1}
       эффект: P1(Time until evening) -5
       эффект: P9(Tranquilizer gun) -1
       эффект: P19(Sibolusovtus caught) +1
  -> Path327 => Loc79  вер=1 порядок=5
       текст: Shoot with the tranquilizer gun...
       ответ: You aimed carefully at the sibolusovtus and fired. / To your horror, you missed your mark, but the sibolusovtus just scratched itself in its sleep, giving you a…
       условия: логика {[p9]>0 and [p39]=1}
       эффект: P1(Time until evening) -5
       эффект: P9(Tranquilizer gun) -1
  -> Path330 => Loc81  вер=1 порядок=5
       текст: Shoot with the incomprehensible unit...
       условия: логика {[p15]=1}
       эффект: P15(Incomprehensible baloney...) -1
  -> Path334 => Loc80  вер=1 порядок=5
       текст: Throw a jar of sulfuric acid into it...
       ответ: You swung your arm and heaved a vial of sulfuric acid at the stump. The stump joyfully smoked and melted away.  / It's not clear what you wanted to accomplish, …
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P3(You're carrying) -3
       эффект: P7(Flask of sulfuric acid.) -1
  -> Path338 => Loc79  вер=1 порядок=5
       текст: Dart toward the sibolusovtus with your bare hands...
       ответ: You threw yourself at the sleeping little animal and grabbed it by the leg. / Out of fright and anger from being woken up, the beast let out an irate roar and c…
       эффект: P19(Sibolusovtus caught) +1
  -> Path339 => Loc80  вер=1 порядок=5
       текст: Dart toward the sibolusovtus with your bare hands...
       ответ: You issued a war cry and threw yourself onto the poor little beast sleeping on the small stump. / When it spit some kind of sticky gunk into your eyes, you real…
       эффект: P1(Time until evening) -10
  -> Path471 => Loc79  вер=1 порядок=5
       текст: Shoot with your assault blaster
       ответ: You took the assault blaster from you shoulder and shot the serenely sleeping sibolusovtus.  / And you didn't miss, no sir - you had been hunting for six-legged…
       условия: логика {[p10]>0 and [p38]=1}
       эффект: P1(Time until evening) -5
       эффект: P10(Assault blaster) -1
       эффект: P19(Sibolusovtus caught) +1

### Loc79 [обычная]
    выбор описания: {[p19]+1}
    Loc79-1: The sibolusovtus wasn't caught, but kept right on sleeping unperturbed. / So you had the opportunity to try again...
    Loc79-2: So the deed was done and the sibolusovtus was in your hands.  / You just needed to bring him back to the camp, which you did. / Once back on the base, you moved…
  -> Path328 => Loc78  вер=1 порядок=5
       условия: логика {[p19]=0}
  -> Path340 => Loc68  вер=1 порядок=5
       условия: логика {[p19]=1}
       эффект: P1(Time until evening) -100

### Loc80 [обычная]
    Loc80-1: You succeeded in remaining alone, without the sibolusovtus. Now you will have to go and find another one...
  -> Path329 => Loc77  вер=1 порядок=5

### Loc81 [обычная]
    Loc81-1: You lifted the apparatus and saw three buttons on it. White, blue, and red... / Judging by appearances, the thingamajig shoots in a particular way depending on …
  -> Path331 => Loc79  вер=1 порядок=5
       текст: Press the white button...
       ответ: You pressed the white button on the gun and relished the result. / The sibolusovtus suddenly gave a start, raised its head, and looked at you. You pressed the b…
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1
       эффект: P19(Sibolusovtus caught) +1
  -> Path332 => Loc80  вер=1 порядок=5
       текст: Press the red button...
       ответ: You pointed the thingamajig toward the peacefully sleeping sibolusovtus and pressed the red button. / Well, judging by the smell, you got a nice roast out of th…
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1
  -> Path333 => Loc80  вер=1 порядок=5
       текст: Press the blue button...
       ответ: You directed the weapon toward the peacefully sleeping sibolusovtus and pulled the trigger.  / The meadow immediately became very cold. You blew on your frozen …
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1

### Loc82 [пустая]
  -> Path117 => Loc139  вер=1 порядок=5

### Loc83 [обычная]
    Loc83-1: "Maybe he just wants to talk," you thought, looking at the person with apprehension.
    эффект: P1(Time until evening) -10
    показ: P12
  -> Path501 => Loc124  вер=1 порядок=5
       текст: Get the behind me! Scram! Be gone, evil fiend!
       эффект: P12(Native's mood) -20
       эффект: P48(1) = {2}
  -> Path502 => Loc124  вер=1 порядок=5
       текст: Err... Maybe it would be better if we spoke together like civilized people?
       эффект: P48(1) = {1}
  -> Path503 => Loc124  вер=1 порядок=5
       текст: Ah, my old pal! How glad I am to see you!
       эффект: P12(Native's mood) -10
       эффект: P48(1) = {3}

### Loc84 [обычная]
    Loc84-1: First came a huge serving of spam, which you inadvertently began to read, thinking it was useful information. You realized your mistake only when you came to an…
    Loc84-2: First there was a huge serving of spam, which you inadvertently began to read, thinking it was useful information. You realized your mistake only when you came …
    эффект: P1(Time until evening) -150
  -> Path463 => Loc86  вер=1 порядок=5
       текст: Look at the link for "Naked, <clr>Leg-Eared<clrEnd> Fae Idly Splashes at <clr>Sibolusovtus<clrEnd> in the Shower"
  -> Path466 => Loc85  вер=1 порядок=5
       текст: Look at the link for "Everything About <clr>Auropedal Sibolusovtuses<clrEnd>"
  -> Path468 => Loc123  вер=1 порядок=5
       текст: Stop reading this crap...
       эффект: P27(Gloogle) +1

### Loc85 [обычная]
    Loc85-1: "Sibolusovtuses are very gentle and frail animals," wrote the textbook's author, "so they must be treated with love and kindness. They are also easily frightene…
    эффект: P1(Time until evening) -60
  -> Path464 => Loc86  вер=1 порядок=5
       текст: Look at the link for "Naked, <clr>Long-Eared<clrEnd> Fae Idly Splashes at <clr>Sibolusovtus<clrEnd> in the Shower"
  -> Path467 => Loc84  вер=1 порядок=5
       текст: Look at the link for "The Proper Way to Dress an <clr>Auropedal Sibolusovtus<clrEnd>"
  -> Path469 => Loc123  вер=1 порядок=5
       текст: Stop reading this crap...
       эффект: P27(Gloogle) +1

### Loc86 [обычная]
    Loc86-1: You clicked on the link and "Unauthorized access to a pornographic faeyan website" flashed across the screen.  / Apparently, the darn search engine once again f…
    эффект: P1(Time until evening) -5
  -> Path462 => Loc84  вер=1 порядок=5
       текст: Look at the link for "The Proper Way to Dress an <clr>Auropedal Sibolusoft<clrEnd>"
  -> Path465 => Loc85  вер=1 порядок=5
       текст: Look at the link for "Everything About <clr>Auropedal Sibolusovtuses<clrEnd>"
  -> Path470 => Loc123  вер=1 порядок=5
       текст: Stop reading this crap...
       эффект: P27(Gloogle) +1

### Loc87 [обычная]
    Loc87-1: In order to dissect a sibolusovtus and extract its poison gland, do the following: / 1. Put a frantic-eyed sibolusovtus to sleep. / 2. Dissect the quietly sleep…
    эффект: P1(Time until evening) -10
  -> Path358 => Loc93  вер=1 порядок=5
       текст: Put the sibolusovtus to sleep...
       ответ: You looked into the eyes of the poor little animal, which was pitifully wiping away tears with its snout, and you began to feel sorry for it...
  -> Path363 => Loc92  вер=1 порядок=5
       текст: Begin the operation
       ответ: You crossed your fingers and firmly tied the sibolusovtus to the operating table. Tears and cold sweat flowed down the poor little animal's snout. / "Well, why …
       эффект: P48(1) = {1}

### Loc88 [обычная]
    Loc88-1: Analysis complete...
    эффект: P1(Time until evening) -10
  -> Path353 => Loc87  вер=1 порядок=5
       текст: Begin the operation

### Loc89 [обычная]
    Loc89-1: Analysis complete...
    эффект: P1(Time until evening) -10
  -> Path352 => Loc139  вер=1 порядок=5
       текст: Head off to search once again...
       ответ: Feeling very grumpy, you looked at the female sibolusovtus, which was chattering in her own incomprehensible, animal language. You were seized with such rage th…
       эффект: P1(Time until evening) -60
       эффект: P19(Sibolusovtus caught) -1
       эффект: P24(Gender of additional sibolusovtus) = {0} [скрыт]
       скрыт: P20,P21,P23
  -> Path357 => Loc87  вер=1 порядок=5
       текст: Begin the operation anyway
       ответ: "Maybe the analyzer is wrong," you thought to yourself. "Maybe the sibolusovtus is actually a male. And I really, really don't want to go back into that wild ju…

### Loc90 [УСПЕХ]
    Loc90-1: You tracked down the landing site and, after you had flicked all the pesky termites from your ship, you flew away from this remarkable planet...
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P40,P44,P45,P46,P47,P48

### Loc91 [обычная]
    Loc91-1: Okay, the sibolusovtus is asleep. Now you should figure out what to do next...
    эффект: P1(Time until evening) -5
  -> Path364 => Loc92  вер=1 порядок=5
       текст: Begin the operation
       эффект: P48(1) = {1}
  -> Path554 => Loc186  вер=1 порядок=5
       текст: Take pity on the animal and give it a couple of doses
       эффект: P21(Number of doses) +1

### Loc92 [обычная]
    выбор описания: {[p48]}
    Loc92-1: You pulled on surgical gloves and an operating coat to avoid being splattered with blood...
    Loc92-2: The little animal's paw twitched a couple of times and then it dropped off to sleep. / You tenderly patted its trunk a while, then you pulled on surgical gloves…
    эффект: P1(Time until evening) -5
  -> Path440 => Loc94  вер=1 порядок=5
       текст: Take the scalpel...
  -> Path441 => Loc118  вер=1 порядок=5
       текст: Take the chainsaw...

### Loc93 [обычная]
    Loc93-1: "How do I put it to sleep?" you wondered in confusion.
    эффект: P1(Time until evening) -5
  -> Path359 => Loc91  вер=1 порядок=5
       текст: Administer a dose of sleeping aid to the sibolusovtus...
       ответ: You injected a dose to the leg-eared and it immediately dozed off, glancing up at you with one eye from time to time. Obviously, one dose wasn't enough.
  -> Path360 => Loc91  вер=1 порядок=5
       текст: Administer three doses of sleeping aid to the sibolusovtus...
       ответ: You measured out and administered three doses of sleeping aid to the sibolusovtus. He instantly dropped off to sleep happily, and you prepared yourself for the …
       эффект: P21(Number of doses) +1
  -> Path361 => Loc139  вер=1 порядок=5
       текст: Administer ten doses of sleeping aid to the sibolusovtus...
       ответ: The sibolusovtus twitched convulsively and died... / Frustrated, you looked at the lifeless body and headed toward the forest...
       эффект: P1(Time until evening) -60
       эффект: P19(Sibolusovtus caught) -1
       эффект: P21(Number of doses) = {0} [скрыт]
       эффект: P23(Sibolusovtus's nerves) = {0} [скрыт]
       эффект: P24(Gender of additional sibolusovtus) = {0} [скрыт]
       скрыт: P20
  -> Path362 => Loc91  вер=1 порядок=5
       текст: Stun the sibolusovtus with a blow to the head...
       ответ: You took aim and struck the sibolusovtus on the noggin. It squealed resentfully and spit on you. You again tried to knock it out. In vain. Then you became compl…
       эффект: P23(Sibolusovtus's nerves) +4

### Loc94 [обычная]
    Loc94-1: You picked up a scalpel and assumed a dramatic pose over the operating table...
    эффект: P1(Time until evening) -5
  -> Path445 => Loc119  вер=1 порядок=5
       текст: Cut from the fifth vertebrae...
       ответ: You cut the sibolusovtus off at the fifth vertebrae and suddenly realized that it had nearly regained consciousness.  / You quickly dashed for the sleeping aid,…
       условия: логика {[p21]=1}
  -> Path446 => Loc120  вер=1 порядок=5
       текст: Cut from the third vertebrae...
       ответ: You carefully cut the sibolusovtus and, trembling, reached inside its body to get its poison sack.
       условия: логика {[p21]=1}
  -> Path449 => Loc119  вер=1 порядок=5
       текст: Cut from the fifth vertebrae...
       ответ: For a few seconds the sibolusovtus watched in horror as  you cut it open, then it emitted a wild howl and died of fright and pain...
       условия: логика {[p21]=0}
       эффект: P23(Sibolusovtus's nerves) +10
  -> Path450 => Loc119  вер=1 порядок=5
       текст: Cut from the third vertebrae...
       ответ: You carefully cut the eerily chirping sibolusovtus and reached into the depths of its body to find its poison sack.  / The great interrogator in you must have d…
       условия: логика {[p21]=0}

### Loc95 [пустая]
  -> Path366 => Loc61  вер=1 порядок=5

### Loc96 [СМЕРТЬ]
    Loc96-1: One of the stump's roots suddenly flew up from the ground and punched through your chest near your heart. / You staggered and collapsed right onto the stump, wh…

### Loc97 [обычная]
    Loc97-1: Bristling with anger, you pointed the barrel of the apparatus at the stump and prepared to blast it to smithereens...
  -> Path371 => Loc71  вер=1 порядок=5
       текст: Press the white button...
       ответ: You pressed the white button, but nothing happened. All the while, the stump continued to savagely bat its eyes at you and bare its crooked teeth...
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1
  -> Path372 => Loc76  вер=1 порядок=5
       текст: Press the red button...
       ответ: You pressed the button as far as it would go and began kicking yourself that you didn't have any food with you... You could have had a nice little barbeque by t…
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1
  -> Path373 => Loc71  вер=1 порядок=5
       текст: Press the blue button...
       ответ: You pressed the button and a snowstorm pelted the stump, freezing everything around it. / You might think that a stump is a stump is a stump. / But whereas this…
       эффект: P1(Time until evening) -10
       эффект: P15(Incomprehensible baloney...) -1

### Loc98 [обычная]
    выбор описания: {[p48]}
    Loc98-1: You walked up to the canvas structures and looked them over. The first pavilion was marked "First aid". The second was marked "Warehouse."
    Loc98-2: You slightly opened the warehouse's obscenely creaking door and glanced inside. / There were numerous bales, boxes, barrels, bundles, bags, packages, and a pile…
    Loc98-3: You examined yourself and suddenly had an epiphany: you're nearly healthy. It wasn't clear at all why you would need treatment under these circumstances. / You …
    Loc98-4: Quick as flash, you wrapped the parts of your body that had suffered the most with hydro-bandages and, feeling much better, you went outside after turning off t…
    Loc98-5: You opened the first-aid kit and began to wrap yourself in bandages, swallow pills, pour powder all over yourself, and stick yourself with syringes. / After a l…
  -> Path375 => Loc99  вер=1 порядок=5
       текст: Look in the pavilion marked "First Aid"
       эффект: P48(1) = {1}
  -> Path376 => Loc100  вер=1 проходов<=1 порядок=5
       текст: Look in the warehouse...
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) -10
       эффект: P48(1) = {2}
  -> Path377 => Loc8  вер=1 порядок=5
       текст: Walk away from the pavilion...
       эффект: P48(1) = {1}

### Loc99 [обычная]
    Loc99-1: You stuck your head into the pavilion, where utter darkness reigned, and immediately banged your face on some sort of pipe. / Then you groped around until you f…
  -> Path378 => Loc101  вер=1 порядок=5
       текст: Apply a superficial treatment...
       условия: логика {[p2]<80}
       эффект: P1(Time until evening) -20
       эффект: P2(Your health) +20
       эффект: P48(1) = {4}
  -> Path379 => Loc101  вер=1 порядок=5
       текст: Apply a complete treatment...
       условия: логика {[p2]<30}
       эффект: P1(Time until evening) -120
       эффект: P2(Your health) +70
       эффект: P48(1) = {5}
  -> Path523 => Loc101  вер=1 порядок=5
       текст: Continue
       условия: логика {[p2]>79}
       эффект: P48(1) = {3}

### Loc100 [пустая] визитов<=1
  -> Path381 => Loc98  вер=1 проходов<=1 порядок=5

### Loc101 [пустая]
  -> Path380 => Loc98  вер=1 порядок=5

### Loc102 [обычная]
    Loc102-1: Of course, the right gear would have to have six teeth, because there were six divisions on the lock. From zero to six. This was an ancient gaalian system, and …
  -> Path408 => Loc109  вер=1 порядок=1
       текст: 1
  -> Path409 => Loc109  вер=1 порядок=2
       текст: 2
  -> Path410 => Loc109  вер=1 порядок=3
       текст: 3
  -> Path411 => Loc109  вер=1 порядок=4
       текст: 4
  -> Path412 => Loc109  вер=1 порядок=5
       текст: 5
       эффект: P40(General warehouse 3) +1
  -> Path418 => Loc9  вер=1 порядок=5
       текст: Walk away from the warehouse doors...
       ответ: You stepped sorrowfully away from the door, cursing these strange archaeologists who pack things where needed; but where it's not needed, they put tricky locks …
  -> Path421 => Loc109  вер=1
       текст: 0

### Loc103 [пустая] визитов<=1
  -> Path387 => Loc61  вер=1 проходов<=1 порядок=5

### Loc108 [обычная]
    Loc108-1: You went inside and understood that you didn't understand a thing. The warehouse was absolutely empty, but that wasn't the problem. The interior was lined with …
    эффект: P1(Time until evening) -20
  -> Path430 => Loc9  вер=1 порядок=5
       текст: Leave the warehouse...
       ответ: You looked around at the bare walls one more time and went outside...

### Loc109 [обычная]
    Loc109-1: So, the first number has been entered. What's next?
    эффект: P1(Time until evening) -1
  -> Path413 => Loc113  вер=1 порядок=1
       текст: 1
  -> Path414 => Loc113  вер=1 порядок=3
       текст: 3
  -> Path415 => Loc113  вер=1 порядок=2
       текст: 2
  -> Path416 => Loc113  вер=1 порядок=4
       текст: 4
  -> Path417 => Loc113  вер=1
       текст: 0
       эффект: P40(General warehouse 3) +1
  -> Path422 => Loc113  вер=1 порядок=5
       текст: 5

### Loc110 [пустая]
    эффект: P1(Time until evening) -10
    эффект: P12(Native's mood) = {50} [скрыт]
  -> Path530 => Loc139  вер=1 порядок=5

### Loc113 [обычная]
    Loc113-1: That's the second number. Just one more...
    эффект: P1(Time until evening) -1
  -> Path424 => Loc114  вер=1
       текст: 0
  -> Path425 => Loc114  вер=1 порядок=1
       текст: 1
  -> Path426 => Loc114  вер=1 порядок=2
       текст: 2
  -> Path427 => Loc114  вер=1 порядок=3
       текст: 3
  -> Path428 => Loc114  вер=1 порядок=4
       текст: 4
       эффект: P40(General warehouse 3) +1
  -> Path429 => Loc114  вер=1 порядок=5
       текст: 5

### Loc114 [обычная]
    Loc114-1: The code has been entered. Now you just need to verify that it is the correct code...
    эффект: P1(Time until evening) -1
  -> Path419 => Loc108  вер=1 порядок=5
       текст: Yank the door...
       ответ: The gear fell out of the lock into your hands, and the door slowly opened...
       условия: логика {[p40]=3}
  -> Path478 => Loc9  вер=1 порядок=5
       текст: Yank the door...
       ответ: You were disappointed to discover that the code was incorrect... / You sighed mournfully and walked away from the warehouse doors.
       условия: логика {[p40]<3}

### Loc115 [пустая]
  -> Path432 => Loc8  вер=1 порядок=5

### Loc117 [обычная]
    Loc117-1: In an instant you had made up your mind - you began running, but the somebody turned out to be faster. He ran in front of you and again blocked your path, mutte…
    эффект: P1(Time until evening) -10
  -> Path496 => Loc74  вер=1 порядок=5
       текст: Annihilate the nasty giant
       эффект: P12(Native's mood) -10
  -> Path499 => Loc83  вер=1 порядок=5
       текст: Talk with him...

### Loc118 [обычная]
    Loc118-1: You went into the far corner and dragged out a chainsaw. / The roar of the motor spread through the vicinity as you started it up. / You shook it over your head…
    эффект: P1(Time until evening) -5
  -> Path443 => Loc139  вер=1 порядок=5
       текст: Begin the operation...
       ответ: When the poor sibolusovtus noticed you holding the saw, it was so frightened it gave up the ghost. / In a rage, you hurled the now-useless saw aside and again h…
       условия: логика {[p21]=0}
       эффект: P1(Time until evening) -60
       эффект: P19(Sibolusovtus caught) -1
       эффект: P20(Gender of the Sibolusovtus...) = {0} [скрыт]
       эффект: P21(Number of doses) = {0} [скрыт]
       эффект: P23(Sibolusovtus's nerves) = {0} [скрыт]
       эффект: P24(Gender of additional sibolusovtus) = {0} [скрыт]
  -> Path444 => Loc139  вер=1 порядок=5
       текст: Begin the operation...
       ответ: As far as you understood, the sibolusovtus had to be sawn open at the third vertebrae... But the saw quickly spoiled all your plans, and in a minute lying in fr…
       эффект: P19(Sibolusovtus caught) -1
       эффект: P20(Gender of the Sibolusovtus...) = {0} [скрыт]
       эффект: P21(Number of doses) = {0} [скрыт]
       эффект: P23(Sibolusovtus's nerves) = {0} [скрыт]
       эффект: P24(Gender of additional sibolusovtus) = {0} [скрыт]

### Loc119 [обычная]
    Loc119-1: You carried the animal's carcass into the storehouse so it wouldn't go bad, and headed back into the forest...
    эффект: P1(Time until evening) -10
  -> Path448 => Loc139  вер=1 порядок=5
       текст: Head off to find a sibolusovtus...
       эффект: P1(Time until evening) -60
       эффект: P19(Sibolusovtus caught) -1
       эффект: P20(Gender of the Sibolusovtus...) = {0} [скрыт]
       эффект: P21(Number of doses) = {0} [скрыт]
       эффект: P23(Sibolusovtus's nerves) = {0} [скрыт]
       эффект: P24(Gender of additional sibolusovtus) = {0} [скрыт]

### Loc120 [обычная]
    Loc120-1: "The operation was a success," you said, reassuring yourself as you looked over your blood-stained operating coat...
    эффект: P1(Time until evening) -10
  -> Path451 => Loc121  вер=1 порядок=5
       текст: Verify that the sibolusovtus you disemboweled is actually a male...
       ответ: You began to painstakingly investigate the poison using a microscope. Five minutes later you discovered with delight that you weren't mistaken.
       условия: логика {[p20]=2}
  -> Path452 => Loc122  вер=1 порядок=5
       текст: Verify that the sibolusovtus you disemboweled is actually a male...
       ответ: You began to painstakingly investigate the poison using a microscope. Five minutes later you discovered with horror that the sibolusovtus was female. / This was…
       условия: логика {[p20]=1}

### Loc121 [обычная]
    Loc121-1: You quickly prepared the antidote according to the instructions you found in the operating table drawer, and twenty minutes later your life was no longer in dan…
    эффект: P23(Sibolusovtus's nerves) +10 [скрыт]
    скрыт: P1,P12,P14,P15,P16,P17,P18,P19,P20,P21,P22,P24
  -> Path166 => Loc90  вер=1 порядок=5
       текст: Talk with the gaal
       ответ: "Oh!" you cried, throwing yourself onto gaal, thoroughly irrigating him with your tears of gratitude. "My dear fellow, I'm so happy to see you!" / "Yes, I can s…
       условия: логика {[p28]=1}
  -> Path454 => Loc90  вер=1 порядок=5
       текст: Talk with the gaal
       ответ: "Oh!" you cried, throwing yourself onto gaal, thoroughly irrigating him with your tears of gratitude. "My dear fellow, I'm so happy to see you!" / "Yes, I can s…
       условия: логика {[p11]=1}
  -> Path455 => Loc90  вер=1 порядок=5
       текст: Talk with the gaal
       ответ: "Oh!" you cried, throwing yourself onto gaal, thoroughly irrigating him with your tears of gratitude. "My dear fellow, I'm so happy to see you!" / "Yes, I can s…
       условия: логика {[p11]=0}

### Loc122 [пустая]
  -> Path453 => Loc119  вер=1 порядок=5

### Loc123 [обычная]
    Loc123-1: You decided to not give it another thought, opting instead to work alone...
    эффект: P1(Time until evening) -5
    показ: P23
  -> Path347 => Loc43  вер=1 порядок=5
       текст: Put the sibolusovtus in the analyzer...
       ответ: You grabbed the sibolusoft, which was lethargically trying to escape, threw it into the analyzer, and immediately slammed the door shut to keep it from getting …
       показ: P24
  -> Path348 => Loc87  вер=2 порядок=5
       текст: Begin the operation
       ответ: You spit on the reference materials and decided to do it the old-school way, i.e. by trial-and-error. / The sibolusovtus watched you in horror, realizing that t…
       эффект: P20(Gender of the Sibolusovtus...) +1
  -> Path520 => Loc87  вер=1 порядок=5
       текст: Begin the operation
       ответ: You spit on the reference materials and decided to do it the old-school way, i.e. by trial-and-error. / The sibolusovtus watched you in horror, realizing that t…
       эффект: P20(Gender of the Sibolusovtus...) +2

### Loc124 [обычная]
    выбор описания: {[p48]}
    Loc124-1: "Okay," agreed the native, hiding his club. "Let's do this like civilized...
    Loc124-2: You crossed yourself superstitiously... / "What?" croaked the native. "Who are you callin' evil? Arrrrgghhh! My ancestors suffered ruin on this planet, but our …
    Loc124-3: You threw yourself onto the native's neck and began to spray him with tears of joy. / And you had no shortage of tears, since crying came so naturally to you. /…
    эффект: P1(Time until evening) -5
  -> Path504 => Loc125  вер=1 порядок=5
       текст: So, what are we going to talk about?
       эффект: P12(Native's mood) -10
       эффект: P48(1) = {2}
  -> Path505 => Loc125  вер=1 порядок=5
       текст: Well, to tell you the truth, you're a freak!
       эффект: P12(Native's mood) -20
       эффект: P48(1) = {1}
  -> Path506 => Loc125  вер=1 порядок=5
       текст: Let's talk about the weather.
       эффект: P48(1) = {3}

### Loc125 [обычная]
    выбор описания: {[p48]}
    Loc125-1: "What?" the native asked again. / "I said you're a freak," you repeated. / "And I can see you're completely off your rocker," responded the man angrily...
    Loc125-2: "I don't get it. Are you still waiting for me to come up with something to talk about?" said the native angrily.
    Loc125-3: "What is there to say about it?" wondered the man. "Weather is weather. It's always like this here." / "Well, not where I come from," you replied with a distant…
    эффект: P1(Time until evening) -5
  -> Path508 => Loc127  вер=1 порядок=5
       текст: Yuck! What's that sticky gunk in the sack on your back?
       эффект: P12(Native's mood) -20
       эффект: P48(1) = {2}
  -> Path509 => Loc127  вер=1 порядок=5
       текст: What do you think it would be like for us if the Klissans had won in the war?
       эффект: P48(1) = {3}
  -> Path510 => Loc127  вер=1 порядок=5
       текст: You're really handsome just the same!
       эффект: P12(Native's mood) +10
       эффект: P48(1) = {1}

### Loc126 [обычная]
    выбор описания: {[p48]}
    Loc126-1: "What?!" asked the native again fiercely. "How dare you ask such a thing of an immortal?! / "Excuse me," you said, full of embarrassment. "I didn't know you wer…
    Loc126-2: "Hmm," thought the tarantula. "I think the Klissan would win." / "Why?" you asked. / "I don't know who the dominators are." / "That makes sense," you agreed. / …
    Loc126-3: "What's that?" asked the native. / "It's a game," you explained. "It's on stereovision..." / "What's stereovision?" asked the native again. / "It's this three d…
    эффект: P1(Time until evening) -5
  -> Path514 => Loc128  вер=1 порядок=5
       текст: What came first? The chicken or the egg?
       эффект: P12(Native's mood) -20
       эффект: P48(1) = {1}
  -> Path515 => Loc128  вер=1 порядок=5
       текст: Hey, have you seen any sibolusovtuses around here?
       эффект: P12(Native's mood) -30
       эффект: P48(1) = {2}

### Loc127 [обычная]
    выбор описания: {[p48]}
    Loc127-1: The man was embarrassed and showed his green teeth in something like a smile, and you suddenly felt the need to vomit.  / You noticed that the native was sleepi…
    Loc127-2: The man looked over his shoulder and gnashed his teeth menacingly. / "How dare you call my food sticky gunk?! I spent two hours making it today!" / You noticed …
    Loc127-3: "Don't worry about it," replied the native impassively. "Who cares? They're all just protoplasm." / You noticed that the man was growing weary and starting to n…
    эффект: P1(Time until evening) -5
  -> Path511 => Loc126  вер=1 порядок=5
       текст: Hey, if the Klissans fought with the dominators, who would win?
       эффект: P48(1) = {2}
  -> Path512 => Loc126  вер=1 порядок=5
       текст: Who do you want to be in the next life?
       эффект: P12(Native's mood) -20
       эффект: P48(1) = {1}
  -> Path513 => Loc126  вер=1 порядок=5
       текст: Do you watch hatchball?
       эффект: P12(Native's mood) -10
       эффект: P48(1) = {3}

### Loc128 [обычная]
    выбор описания: {[p48]}
    Loc128-1: "What?!" exclaimed the native, jumping slightly. "How dare you speak of the most wicked enemies of my religion in my presence! You should be struck down by a bo…
    Loc128-2: You looked at the native hopefully, but then realized that you had said something stupid. / "That's one more," he said bleakly and took a step toward you. "When…
    эффект: P1(Time until evening) -10
  -> Path516 => Loc110  вер=1 порядок=5
       текст: Run away...
       ответ: You darted off on your tiptoes and only after half an hour were you able to stop to catch your breath...
       условия: логика {[p12]>29}
  -> Path517 => Loc129  вер=1 порядок=5
       текст: Run away...
       условия: логика {[p12]<30}

### Loc129 [СМЕРТЬ]
    Loc129-1: You began to run, but the native was apparently so angry with you that he was only pretending to be asleep.  / When he suddenly fell on you from the tree and sm…

### Loc132 [обычная]
    Loc132-1: You retrieved from your pocket your ranger diver's mask with a small supply of oxygen, and plunged underneath the water. There was nothing shiny anywhere. This …
  -> Path54 => Loc136  вер=1 порядок=5
       текст: Dive deeper
       эффект: P1(Time until evening) -10
       эффект: P34(Lever 4) -30
  -> Path58 => Loc135  вер=1 порядок=5
       текст: Swim right
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10
  -> Path64 => Loc148  вер=1
       текст: Resurface
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10
  -> Path534 => Loc134  вер=1 порядок=5
       текст: Swim to the left
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10

### Loc134 [обычная]
    Loc134-1: You grabbed the water plants and took a look around. Directly in front of you there was a small, oddly round shape - a hill - gleaming dimly with dark sides. Sm…
  -> Path16 => Loc144  вер=1 порядок=5
       текст: Swim beyond the hill
       эффект: P34(Lever 4) -20
  -> Path68 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P34(Lever 4) -10
  -> Path535 => Loc145  вер=1 проходов<=1 порядок=5
       текст: Check the sparkle by the hill
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20

### Loc135 [обычная]
    Loc135-1: You released several bubbles from your mouth and got your bearings. The dark arches of two caves stood directly in front of you. Both of them contained somethin…
  -> Path57 => Loc147  вер=1 проходов<=1 порядок=5
       текст: Swim into the left cave
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10
  -> Path69 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -10
       эффект: P34(Lever 4) -10
  -> Path536 => Loc146  вер=1 проходов<=1 порядок=5
       текст: Swim into the right cave
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10

### Loc136 [обычная]
    Loc136-1: You decided to see what the bottom was like, so you swam downward with powerful strokes. However, you soon discovered an unpleasant fact. The water here was muc…
  -> Path123 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -30

### Loc138 [обычная]
    Loc138-1: "Banzai!" you screamed and threw yourself into the monster's jaws. / Indeed, why wait for it to eat you up if you don't have to. / You stubbornly forced your wa…
  -> Path548 => Loc182  вер=1 порядок=5
       текст: Start a small campfire
  -> Path549 => Loc183  вер=1 порядок=5
       текст: Shoot with your assault blaster
       условия: логика {[p10]>0 and [p38]=1}
  -> Path552 => Loc184  вер=1 порядок=5
       текст: Throw some sulfuric acid
       условия: логика {[p7]>0}

### Loc139 [обычная]
    Loc139-1: You forced the dense branches aside and found yourself standing in front of an old military fighter from the Klissan war era.  / You walked up to it and examine…
    Loc139-2: You walked quietly along the sandy place when, suddenly, the path rose up and hit you painfully in the face.  / After a moment you realized that everything was …
    Loc139-3: You walked quietly along the sandy place and suddenly caught your foot on a root protruding up from the ground. It really wasn't fun.  / You became enraged and …
    Loc139-4: You decided to have a snack and began checking prices at the closest bush, which had huge yellow berries growing on it. / You reached your hand forward to pick …
    Loc139-5: You decided to take a breather and sat down on a large stone. / You had just caught your breath when the stone suddenly began to rock back and forth and walk. I…
    Loc139-6: You lazily turned your head to each side, keeping your eyes peeled for a sibolusovtus. You didn't notice the gigantic nest hanging dead ahead. It was so large t…
    Loc139-7: Everything around you seemed so quiet and ordinary that you began to relax. You shouldn't have. / Some sort of colossal beast flew full-speed out from behind a …
    Loc139-8: Walking through the forest, you decided to have a snack and dug into your pocket for a leftover sandwich.  / As soon as you had taken a bite, some unknown creat…
    Loc139-9: You decided to have a snack and dug into your pocket for a leftover sandwich.  / You had just managed to take a bite when, from out of the bushes, some unknown …
    Loc139-10: You forced aside the heavy branches and found yourself standing in front of a gargantuan black pyramid. It was cut properly and stood between two knolls that we…
  -> Path17 => Loc22  вер=1 порядок=5
       текст: Continue the search
  -> Path19 => Loc19  вер=10 порядок=5
       текст: Continue the search
  -> Path20 => Loc6  вер=1 порядок=5
       текст: Return to the base
       эффект: P1(Time until evening) -100
       эффект: P25(You were at the base) +1
  -> Path24 => Loc141  вер=1 проходов<=1 порядок=5
       текст: Go straight
  -> Path30 => Loc13  вер=1 порядок=5
       текст: Continue the search
  -> Path37 => Loc17  вер=1 порядок=5
       текст: Continue the search
  -> Path40 => Loc20  вер=1 порядок=5
       текст: Continue the search
  -> Path41 => Loc16  вер=1 порядок=5
       текст: Continue the search
  -> Path70 => Loc14  вер=1 порядок=5
       текст: Continue the search
  -> Path78 => Loc11  вер=1 порядок=5
       текст: Continue the search
  -> Path83 => Loc10  вер=2 порядок=5
       текст: Continue the search
  -> Path100 => Loc187  вер=1 порядок=5
       текст: Continue the search
       ответ: You went to the right in the hopes that you'd have better luck, but there was a sudden deluge... / You were instantly soaked through, and when you crawled out o…
  -> Path111 => Loc18  вер=1 порядок=5
       текст: Continue the search
  -> Path133 => Loc21  вер=1 порядок=5
       текст: Continue the search
  -> Path163 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You walked quietly through the forest. Then suddenly the silence was shattered by a resounding boom. The sky exploded and the treetops rocked. Birds squawked in…
  -> Path167 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You walked along some blue flowers, examining them carefully, but you were so preoccupied with this that you didn't noticed the gaal biologist right in your pat…
       условия: логика {[p11]=1}
       эффект: P11(Symgrass for the gaal) -1 [скрыт]
  -> Path213 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You shuffled off through the forest, carefully avoiding the holes with bubbling liquid. Suddenly something rocked you to one side and then the other, as if you …
  -> Path214 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You passed through two cliffs standing close to each other and suddenly heard strange voices behind the thick trees. The voices were shamefully familiar. You ca…
  -> Path223 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You entered a small meadow, which swelled to a small hill in the middle. / Moving closer, you took a seat on a small stump not far from the hill in order to sha…
  -> Path229 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You walked along some blue flowers, examining them carefully, but you were so preoccupied with this that you didn't noticed the gaalian biologist right in your …
       условия: логика {[p14]=0}
       эффект: P14(Key to the second warehouse) +1
  -> Path518 => Loc187  вер=1 проходов<=1 порядок=5
       текст: Continue the search
       ответ: You walked through the forest and suddenly fell face-first into some pit. / Curses passed your lips as you plummeted down dozens of meters and plopped into a sw…
  -> Path528 => Loc23  вер=1 проходов<=1 порядок=5
       текст: Continue the search
  -> Path529 => Loc12  вер=1 порядок=5
       текст: Continue the search

### Loc140 [обычная] визитов<=1
    Loc140-1: You held your breath and yanked the lever toward you. It cracked, creaked, and fell off - nevertheless, it did move to a new place.
  -> Path80 => Loc148  вер=1 порядок=5
       текст: Continue
       ответ: So you found the last lever and used it without incident. / In the distance you could hear thunderous gurgling, like a gigantic toilet being flushed, and the wa…
       условия: логика {[p31]=1 and [p32]=1 and [p33]=1}
       эффект: P1(Time until evening) -10
       скрыт: P30
  -> Path84 => Loc169  вер=1 порядок=5
       текст: Go east to look for the next lever
       условия: логика {[p31]=0 or [p32]=0 or [p33]=0}
  -> Path85 => Loc174  вер=1 порядок=5
       текст: Go west to look for the next lever
       условия: логика {[p31]=0 or [p32]=0 or [p33]=0}

### Loc141 [обычная] визитов<=1
    Loc141-1: "Being a rangers isn't about doing easy things!" you said pompously, loudly sharing some popular wisdom. Then you took aim, exhaled, and plowed into the impassa…
    эффект: P1(Time until evening) -120
  -> Path15 => Loc142  вер=1 порядок=5
       текст: Continue the search
  -> Path525 => Loc139  вер=1 порядок=5
       текст: Return to the meadow

### Loc142 [обычная]
    Loc142-1: You let out a war cry and again tried to blaze a trail. / The trees snapped; birds flew away, frightened off by your retribution; water bubbled up from under yo…
    эффект: P1(Time until evening) -120
  -> Path11 => Loc143  вер=1 порядок=5
       текст: Force your way farther
  -> Path526 => Loc139  вер=1 порядок=5
       текст: Return to the meadow

### Loc143 [СМЕРТЬ]
    Loc143-1: You continued your thankless job without noticing that the impassable woods had come to an end. For a while you still growled and waved out of habit. Then you g…

### Loc144 [обычная]
    Loc144-1: You swam in a circle around the hill, but you didn't see anything interesting, except for the fact that it wasn't a hill. Rather, it was a metal ball that came …
  -> Path122 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20

### Loc145 [обычная] визитов<=1
    Loc145-1: You swam up to the place where you had just seen the dim sparkle, but you didn't find anything except a solitary crab who started to wave its claws at you in fr…
  -> Path124 => Loc177  вер=1 порядок=5
       текст: Swim toward the sparkle
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -15
  -> Path125 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -10
       эффект: P34(Lever 4) -20

### Loc146 [обычная] визитов<=1
    Loc146-1: You swam over to the hole and got out your ranger flashlight, which you also carried with you in a special pocket on your uniform. / How great was your horror w…
  -> Path93 => Loc138  вер=1 порядок=5
       текст: Don't wait - throw yourself into the monster's jaws
  -> Path95 => Loc139  вер=1 порядок=5
       текст: Get out of the cave as quickly as possible
       ответ: You shrieked in fright and propelled yourself out of the cave. / Your screaming seemed to wake the monster and it leisurely swam after you. / You turned up the …
       эффект: P1(Time until evening) -10
       скрыт: P34

### Loc147 [обычная] визитов<=1
    Loc147-1: You caught hold of the edge of the hole and forced yourself inside. / It was extremely dark inside, so you turned on your ranger pocket flashlight. The surround…
  -> Path540 => Loc148  вер=1 порядок=5
       текст: Swim to the surface
       эффект: P1(Time until evening) -10
       эффект: P34(Lever 4) -20
  -> Path541 => Loc154  вер=1 порядок=5
       текст: Swim into the cave

### Loc148 [обычная]
    Loc148-1: You resurfaced and, while loudly sputtering and spitting, almost like a hippopotamus, you paddled toward the shore. / It turned out that you had swum to the opp…
    эффект: P30(Water level) = {0}
    скрыт: P34
  -> Path538 => Loc132  вер=1 порядок=5
       текст: Dive down again
       эффект: P34(Lever 4) = {100} [показ]
  -> Path539 => Loc139  вер=1 порядок=5
       текст: Walk on the path
       ответ: You strayed into some gooey, bright blue substance in the underbrush and, finally, found yourself at a fork...
       эффект: P1(Time until evening) -10

### Loc150 [обычная]
    Loc150-1: You walked around the gate-shutting mechanism for a while and knew that if you didn't open it, at the very least you would be letting a Great Big Secret pass yo…
  -> Path121 => Loc152  вер=1 порядок=5
       текст: Start breaking in
       условия: логика {[p7]>0}
  -> Path531 => Loc139  вер=1 порядок=5
       текст: Continue the search and leave the lock alone

### Loc152 [обычная]
    Loc152-1: The only thing you needed now was bottles of sulfuric acid. / "It doesn't matter even I don't have any," you said to yourself encouragingly. "I can cook somethi…
  -> Path96 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the first opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path102 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the second opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path104 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the third opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path105 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the fourth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path107 => Loc185  вер=1 проходов<=1 порядок=5
       текст: Fill the fifth opening
       условия: логика {[p7]>0}
       эффект: P1(Time until evening) -5
       эффект: P7(Flask of sulfuric acid.) -1
       эффект: P29(Lock) +1
  -> Path110 => Loc41  вер=1 порядок=5
       текст: Remaining openings
       условия: логика {[p7]>0}
  -> Path598 => Loc139  вер=1 порядок=5
       текст: Continue the search and leave the lock alone
       условия: P7(Flask of sulfuric acid.) 0..0

### Loc153 [обычная]
    Loc153-1: Your despair knew no bounds. To drown so far from the Motherland. And the Galaxy will never know what became of the ranger named <Ranger>.  / But you distress w…
    эффект: P1(Time until evening) -5
    показ: P30
  -> Path139 => Loc155  вер=1 порядок=5
       текст: Go look for a lever

### Loc154 [обычная]
    Loc154-1: You swam a bit farther into the cave and after a while you were amazed to find yourself back at the surface. In front of you, a dark tunnel, without any signs o…
    эффект: P1(Time until evening) -10
    эффект: P34(Lever 4) = {100} [скрыт]
  -> Path542 => Loc148  вер=1 порядок=5
       текст: Spit all over everything and get out of the cave
       ответ: You diligently spit all over the place and splashed into the water.  / Then there was nothing left for you to do but get yourself out of the cave and return to …
       эффект: P34(Lever 4) -30
  -> Path543 => Loc153  вер=1 порядок=5
       текст: Pull the lever
       ответ: "Well, whatever will be, will be," you said recklessly and yanked the rusted level. / Beyond the hatch in the wall there was a dull rumbling, like the stomach o…

### Loc155 [обычная]
    Loc155-1: The fork in the tunnel in no uncertain terms indicated that you had to either go to the west or to the east... / And your intuition told you that one of the lev…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path56 => Loc156  вер=1 порядок=5
       текст: Go west
  -> Path141 => Loc157  вер=1 порядок=5
       текст: Go east

### Loc156 [обычная]
    Loc156-1: You piled onto some dark corner, which, considering everything, must be a corner of the cave; you felt an intense desire to go back home, but you were pooped. /…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path135 => Loc160  вер=1 порядок=5
       текст: Go south
  -> Path137 => Loc155  вер=1 порядок=5
       текст: Go east

### Loc157 [обычная]
    Loc157-1: "How uncomfortable these caves are!" you thought as you plodded gloomily along the tunnel in cold water. "Not long before I'll catch a cold, fall ill, and then …
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path52 => Loc155  вер=1 порядок=5
       текст: Go west
  -> Path144 => Loc158  вер=1 порядок=5
       текст: Go east
  -> Path152 => Loc161  вер=1 порядок=5
       текст: Go south

### Loc158 [обычная]
    Loc158-1: You lost your footing on the dark-green slime and plunged into the water. The bath didn't help.  / "I really hope I don't get sick," you thought anxiously. "On …
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path49 => Loc157  вер=1 порядок=5
       текст: Go west
  -> Path145 => Loc159  вер=1 порядок=5
       текст: Go east

### Loc159 [обычная]
    выбор описания: {[p32]+1}
    Loc159-1: In the dark northeast corner of the tunnel, you finally discovered one of the levers. / This would have been a good reason to pop a bottle of champagne, but it …
    Loc159-2: You passed a piece of lever that you yourself had broken and realized that you had already been here. / Meanwhile the water was rising higher and higher...
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path39 => Loc158  вер=1 порядок=5
       текст: Go west
  -> Path88 => Loc180  вер=1 проходов<=1 порядок=5
       текст: Pull the lever
       эффект: P32(Lever 2) +1
  -> Path456 => Loc162  вер=1
       текст: Go south

### Loc160 [обычная]
    Loc160-1: The endless darkness of the tunnel devastated your nerves, and the levers were nowhere close.
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path38 => Loc156  вер=1 порядок=5
       текст: Go north
  -> Path138 => Loc163  вер=1 порядок=5
       текст: Go south

### Loc161 [обычная]
    Loc161-1: Strange reflections shimmered on the wall of the tunnel. You didn't like this much, so you decided to get out of this place as soon as possible. Fortunately, th…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path60 => Loc157  вер=1 порядок=5
       текст: Go north
  -> Path154 => Loc164  вер=1 порядок=5
       текст: Go south

### Loc162 [обычная]
    Loc162-1: "The water here seems to be colder than in the middle of the tunnel," you thought, stepping through the darkness. "Or does it just seem that way? Or does it not…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path12 => Loc165  вер=1 порядок=5
       текст: Go south
  -> Path79 => Loc159  вер=1 порядок=5
       текст: Go north

### Loc163 [обычная]
    Loc163-1: The dreary tunnel didn't exactly invite the most pleasant thoughts. More specifically, it invited the most unpleasant thoughts. / But you manfully drove them aw…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path34 => Loc160  вер=1 порядок=5
       текст: Go north
  -> Path148 => Loc166  вер=1 порядок=5
       текст: Go east
  -> Path150 => Loc173  вер=1 порядок=5
       текст: Go south

### Loc164 [обычная]
    Loc164-1: Judging all things, you've found your way into the middle of the local bizarre labyrinths.  / Four tunnels diverged in different directions: to the north, south…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path55 => Loc161  вер=1 порядок=5
       текст: Go north
  -> Path63 => Loc166  вер=1 порядок=5
       текст: Go west
  -> Path157 => Loc167  вер=1 порядок=5
       текст: Go east
  -> Path457 => Loc168  вер=1
       текст: Go south

### Loc165 [обычная]
    Loc165-1: The tunnel here forked. One path led toward the center, one led to the north, and another led to the south.
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path18 => Loc172  вер=1 порядок=5
       текст: Go south
  -> Path59 => Loc167  вер=1 порядок=5
       текст: Go west
  -> Path76 => Loc162  вер=1 порядок=5
       текст: Go north

### Loc166 [обычная]
    Loc166-1: Suddenly you slipped and fell to the tunnel floor. / What terror you felt when underwater you came face to face with a maloq skeleton. / You flew out of the wat…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path65 => Loc163  вер=1 порядок=5
       текст: Go west
  -> Path159 => Loc164  вер=1 порядок=5
       текст: Go east

### Loc167 [обычная]
    Loc167-1: Walking through icy water wasn't fun at all and, what's more, it was also cold.  / You started fantasizing about a hot cup of tea and soft faeyan buns, but then…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path62 => Loc164  вер=1 порядок=5
       текст: Go west
  -> Path158 => Loc165  вер=1 порядок=5
       текст: Go east

### Loc168 [обычная]
    Loc168-1: You decided to cheer yourself up with some funny stories and began to recall one: /  / "Once there was a camel walking through the desert. He had nearly died fr…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path44 => Loc164  вер=1 порядок=5
       текст: Go north
  -> Path458 => Loc169  вер=1
       текст: Go south

### Loc169 [обычная]
    Loc169-1: The tunnel splits three ways here. To the north, the east, and the west. You came from one direction, which means there are two left.
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path14 => Loc170  вер=1 порядок=5
       текст: Go east
  -> Path43 => Loc168  вер=1 порядок=5
       текст: Go north
  -> Path114 => Loc175  вер=1 порядок=5
       текст: Go west

### Loc170 [обычная]
    Loc170-1: The tunnel is utterly ordinary here; there's nothing to catch your eye... / There's was also nothing to grab with your hands as you lost your footing and floppe…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path23 => Loc171  вер=1 порядок=5
       текст: Go east
  -> Path103 => Loc169  вер=1 порядок=5
       текст: Go west

### Loc171 [обычная]
    Loc171-1: In the corner of the tunnel where you were located, you could hear the constant din of surging stream of water, and the water level seemed to be rising even fas…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path67 => Loc172  вер=1 порядок=5
       текст: Go north
  -> Path72 => Loc170  вер=1 порядок=5
       текст: Go west

### Loc172 [обычная]
    выбор описания: {[p31]+1}
    Loc172-1: Upon close examination, you saw that a small opening led out of the tunnel. Maybe there's a lever in there. Or maybe not...
    Loc172-2: The tunnel offshoot no longer held any value for you, not even aesthetic value.
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path21 => Loc171  вер=1 порядок=5
       текст: Go south
  -> Path27 => Loc176  вер=1 проходов<=1 порядок=5
       текст: Turn into the tunnel offshoot
  -> Path73 => Loc165  вер=1 порядок=5
       текст: Go north

### Loc173 [обычная]
    Loc173-1: You hurriedly rushed along the tunnel. Then suddenly a black rat swam across your path, then another, and another, and yet another. You quickly remembered that …
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path31 => Loc163  вер=1 порядок=5
       текст: Go north
  -> Path151 => Loc174  вер=1 порядок=5
       текст: Go south

### Loc174 [обычная]
    Loc174-1: "A lever! Hurrah!" you rejoiced after seeing something that looked like the outline of a lever off in the distance. "No, it's not a lever. It's just a sunken lo…
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path10 => Loc175  вер=1 порядок=5
       текст: Go east
  -> Path25 => Loc173  вер=1 порядок=5
       текст: Go north

### Loc175 [обычная]
    выбор описания: {[p33]+1}
    Loc175-1: Miraculously, you found a lever. / You danced a little jig around it and then after thoroughly examining it to confirm its reality, you pinched just in case. Yo…
    Loc175-2: You passed a piece of lever that you yourself had broken and realized that you had already been here. / Meanwhile the water was rising higher and higher...
    эффект: P1(Time until evening) -5
    эффект: P30(Water level) +5
  -> Path13 => Loc169  вер=1 порядок=5
       текст: Go east
  -> Path81 => Loc140  вер=1 проходов<=1 порядок=5
       текст: Pull the lever
       эффект: P33(Lever 3) +1
  -> Path120 => Loc174  вер=1 порядок=5
       текст: Go west

### Loc176 [обычная] визитов<=1
    Loc176-1: There was a miracle and you found one of the levers. All you had to do now was pull it with all your might. / The lever moved unexpectedly easily and you painfu…
    эффект: P2(Your health) -10
    эффект: P31(Lever 1) +1
  -> Path33 => Loc172  вер=1 порядок=5
       текст: Return to the main tunnel
       условия: логика {[p31]=0 or [p32]=0 or [p33]=0}
  -> Path92 => Loc148  вер=1 порядок=5
       текст: Continue
       ответ: So you found the last lever and used it without incident. / In the distance you could hear thunderous gurgling, like a gigantic toilet being flushed, and the wa…
       условия: логика {[p31]=1 and [p32]=1 and [p33]=1}
       эффект: P1(Time until evening) -10
       скрыт: P30

### Loc177 [обычная]
    Loc177-1: Despite the powerful opposing pushing, you reached the depression and began to explore it. / The blasted sparkle was nowhere to be seen - only water plants soft…
  -> Path129 => Loc178  вер=1 порядок=5
       текст: Continue swimming after the sparkle
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20
  -> Path544 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20

### Loc178 [обычная]
    Loc178-1: When you reached the ridge you were ready to explode with expletives, because, strange as it may seem, there wasn't any sparkle there. / But you were nearly acc…
  -> Path545 => Loc148  вер=1 порядок=5
       текст: Resurface
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20
  -> Path546 => Loc179  вер=1 порядок=5
       текст: Continue swimming after the sparkle
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -20

### Loc179 [обычная]
    Loc179-1: You swam sullenly toward the sparkle. When you got to the place you were looking for, you again found nothing. Annoyed, you smacked the seabed with your fist. Y…
  -> Path130 => Loc181  вер=1 порядок=5
       текст: Continue swimming after the sparkle
       эффект: P1(Time until evening) -5
  -> Path547 => Loc148  вер=1 порядок=5
       текст: Resurface
       ответ: As you were going up, you couldn't help yourself and you peeked into the safe to see if it had anything useful or not. / You were utterly horrified out fell a f…
       эффект: P1(Time until evening) -5
       эффект: P34(Lever 4) -10
       эффект: P13(Money) +5000

### Loc180 [обычная] визитов<=1
    Loc180-1: You held your breath and yanked the lever toward you. It cracked, creaked, and fell off - nevertheless, it did move to a new place.
  -> Path89 => Loc148  вер=1 порядок=5
       текст: Continue
       ответ: So you found the last lever and used it without incident. / In the distance you could hear thunderous gurgling, like a gigantic toilet being flushed, and the wa…
       условия: логика {[p31]=1 and [p32]=1 and [p33]=1}
       эффект: P1(Time until evening) -10
       скрыт: P30
  -> Path90 => Loc162  вер=1 порядок=5
       текст: Go south to look for the next lever
       условия: логика {[p31]=0 or [p32]=0 or [p33]=0}
  -> Path91 => Loc158  вер=1 порядок=5
       текст: Go north to look for the next lever
       условия: логика {[p31]=0 or [p32]=0 or [p33]=0}

### Loc181 [СМЕРТЬ]
    Loc181-1: You merrily raked around in the lake floor where the sparkle had been, but you didn't find anything. / However, you did meet an enormous cuttlefish, which swam …

### Loc182 [обычная]
    Loc182-1: You put on your thinking cap and remembered the material from your high school biology class that had been mercilessly crammed into your brain. / There couldn't…
    эффект: P2(Your health) -30
  -> Path156 => Loc148  вер=1 порядок=5
       текст: Continue to resurface
       эффект: P7(Flask of sulfuric acid.) -10

### Loc183 [обычная]
    Loc183-1: You shot at the stomach wall and rubbed your eyes in amazement. / The shot hadn't harmed the monster's body in the least.  / Another shot dissolved into the sto…
    эффект: P10(Assault blaster) -1
  -> Path143 => Loc182  вер=1 порядок=5
       текст: Start a small campfire
  -> Path146 => Loc184  вер=1 порядок=5
       текст: Throw some sulfuric acid
       условия: логика {[p7]>0}

### Loc184 [обычная]
    Loc184-1: You aimed carefully at the monster's stomach wall and lobbed a bottle of acid at it. / The bottle broke, and the acid slowly - with a small wisp of smoke - flow…
    эффект: P7(Flask of sulfuric acid.) -1
  -> Path149 => Loc182  вер=1 порядок=5
       текст: Start a small campfire
  -> Path155 => Loc183  вер=1 порядок=5
       текст: Shoot with your assault blaster
       условия: логика {[p10]>0 and [p38]=1}

### Loc185 [пустая]
  -> Path99 => Loc152  вер=1 порядок=5
       условия: логика {[p29]<10}
  -> Path101 => Loc24  вер=1 порядок=5
       условия: логика {[p29]=10}
  -> Path600 => Loc139  вер=1 порядок=5
       текст: Continue the search and leave the lock alone
       условия: P7(Flask of sulfuric acid.) 0..0

### Loc186 [пустая]
  -> Path555 => Loc92  вер=1 порядок=5
       эффект: P48(1) = {2}

### Loc187 [пустая]
  -> Path560 => Loc139  вер=1 порядок=5

### Loc190 [обычная]
    Loc190-1: You left the warehouse, and the door closed softly behind you. / You turned around and jerked it, but for some reason it was locked again. Then you turned aroun…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40
  -> Path561 => Loc191  вер=1 порядок=5
       текст: Approach the gaal in the bushes
  -> Path567 => Loc192  вер=1 порядок=5
       текст: Approach the gaal by the expedition leader's hut
  -> Path574 => Loc193  вер=1 порядок=5
       текст: Head toward the gaal on the warehouse roof

### Loc191 [обычная]
    Loc191-1: You approached the gaal in the bushes. He didn't pay any attention to this whatsoever.
  -> Path562 => Loc195  вер=1 порядок=5
       текст: Clear your throat...
  -> Path563 => Loc194  вер=1 порядок=5
       текст: Ask if the gaal lost something in the bushes

### Loc192 [обычная]
    Loc192-1: You approached the outer wall of the expedition leader's office along with the gaal who was sitting next to it. / He glanced at you and smiled. / "See I can tha…
    Loc192-2: "Ask another one. Don't be shy."
    Loc192-3: "I will satisfy your curiosity."
    Loc192-4: "Sorry, I can't help you with anything else," the gaal said, sighing wearily. "You're the one who picked the questions. Carry on your way, and may you have more…
    показ: P41
  -> Path568 => Loc196  вер=1 проходов<=1 порядок=5
       текст: What do I do if I've been poisoned?
       ответ: "Good question," said the gaal with a nod. "We have several bottles of auropedal poison here in the warehouse. You'll need one of them."
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1
       эффект: P42(You know where a siba is) +1
  -> Path569 => Loc196  вер=1 проходов<=1 порядок=5
       текст: What's going on here?
       ответ: You passed through alternating-flux-capacitating gates and found yourself in this dimension. There are many such dimensions, but we only found one - same as you…
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1
  -> Path571 => Loc196  вер=1 проходов<=1 порядок=5
       текст: How do I get out of here?
       ответ: "I don't know," said the gaal and shrugged his shoulders. "Logically, if I knew, I wouldn't be here anymore. But keep your chin up! See that character on the wa…
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1
       эффект: P44(You know how to get onto the roof) +1
  -> Path572 => Loc196  вер=1 проходов<=1 порядок=5
       текст: Where is your restroom?
       ответ: "It's opposite this hut."
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1
  -> Path573 => Loc197  вер=1 порядок=5
       текст: Go to the chilling chambers
       условия: P41(Questions) 3..3; P42(You know where a siba is) 1..1
       эффект: P25(You were at the base) = 0
       скрыт: P41
  -> Path577 => Loc198  вер=1 порядок=5
       текст: Go toward the gaal on the roof
       условия: P41(Questions) 3..3; P44(You know how to get onto the roof) 1..1
       эффект: P25(You were at the base) = 1
       скрыт: P41
  -> Path601 => Loc196  вер=1 проходов<=1 порядок=5
       текст: What is the most important, reliable, and accurate answer to all the questions of the universe?
       ответ: "Forty two," said the gaal after thinking for a while.
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1
  -> Path602 => Loc197  вер=1 порядок=5
       текст: Recognize that the answers to your questions haven't helped one bit...
       ответ: "That means you didn't ask the right questions," interrupted the gaal in a bossy tone.  / However, after seeing your melancholy face which was distorted from ha…
       условия: P41(Questions) 3..3; P42(You know where a siba is) 0..0; P44(You know how to get onto the roof) 0..0
       эффект: P25(You were at the base) = 0
       скрыт: P41
  -> Path604 => Loc196  вер=1 проходов<=1 порядок=5
       текст: Want some beer?
       ответ: "I do," sighed the gaal. / "Me too," you sighed.
       условия: P41(Questions) 0..2
       эффект: P41(Questions) +1

### Loc193 [обычная]
    Loc193-1: You approached the huge box that was the warehouse. The gaal didn't pay any attention to you - he just kept staring off somewhere beyond the warehouse. It wasn'…
  -> Path575 => Loc191  вер=1 порядок=5
       текст: Approach the gaal in the bushes
  -> Path576 => Loc192  вер=1 порядок=5
       текст: Approach the gaal by the expedition leader's hut

### Loc194 [обычная]
    Loc194-1: "Looking for something?" you asked warm-heartedly. / "The purpose of life, young wanderer," replied the gaal in a tired voice. / "Why?" you asked in surprise. /…
  -> Path565 => Loc192  вер=1 порядок=5
       текст: Approach the gaal by the expedition leader's hut

### Loc195 [обычная]
    Loc195-1: It would be just as easy to blow your nose. The gaal remained disinterested.
  -> Path564 => Loc194  вер=1 порядок=5
       текст: Ask if the gaal lost something in the bushes

### Loc196 [пустая]
  -> Path570 => Loc192  вер=1 порядок=5

### Loc197 [обычная]
    Loc197-1: You reached the chilling chamber and went inside. Without frittering away your strength on silly nonsense, you walked straight to the specimen refrigerator, whi…
  -> Path582 => Loc202  вер=1 порядок=5
       текст: Take some male sibolusovtus poison
       эффект: P42(You know where a siba is) -1
  -> Path583 => Loc202  вер=1 порядок=5
       текст: Take some female sibolusovtus poison

### Loc198 [обычная]
    Loc198-1: You approached the warehouse building and looked up. The gaal standing on the roof was still staring out at the pristine jungle. / Making a pass around the buil…
  -> Path578 => Loc199  вер=1 порядок=5
       текст: Climb up

### Loc199 [обычная]
    Loc199-1: "Uh...Hi?" you said cautiously to the gaal. / "Hi," he replied cheerfully, "just don't make me break my gaze. It's our only chance to return to the real world."…
  -> Path579 => Loc200  вер=1 порядок=5
       текст: Hey, you don't happen to know how to treat sibolusovtus poisoning, do you?
       условия: P42(You know where a siba is) 0..0

### Loc200 [обычная]
    Loc200-1: "Good question," said the gaal, nodding. "We have several bottles of long-eared poison here in the warehouse. You'll need one of them." / "That's wonderful news…
  -> Path581 => Loc197  вер=1 порядок=5
       текст: Go to the chilling chambers

### Loc201 [обычная]
    Loc201-1: You gave the base one last departing glance and ran for the exit. / Beyond the gate, the fog wasn't so dense, so you could examine your surroundings. Your surro…
  -> Path585 => Loc209  вер=1 порядок=5
       текст: Prepare for death...

### Loc202 [обычная]
    выбор описания: {[p42]}
    Loc202-1: In a decisive move, you grabbed the bottle from the refrigerator, yanked off the stopper, closed your eyes tight, and emptied its contents into your mouth. / Af…
    Loc202-2: In a decisive move, you grabbed the bottle from the refrigerator, yanked off the stopper, closed your eyes tight, and emptied its contents into your mouth. / Af…
  -> Path584 => Loc210  вер=1 порядок=5
       текст: Think of what to do next
       условия: P25(You were at the base) 0..0; P44(You know how to get onto the roof) 0..0
  -> Path592 => Loc211  вер=1 порядок=5
       текст: Go toward the gaal on the roof
       условия: P25(You were at the base) 0..0; P44(You know how to get onto the roof) 1..1
  -> Path605 => Loc201  вер=1 порядок=5
       текст: Tramp into the forest
       условия: P25(You were at the base) 1..1

### Loc209 [УСПЕХ]
    Loc209-1: "Stop shrieking, <Ranger>!" you heard a familiar voice say, once everything around you had stopped spinning and reeling. / The gaalian biologist came into your …

### Loc210 [обычная]
    Loc210-1: Contemplating what to do next, you went to the warehouse, where you again had no luck in your attempts to attract the attention of the non-communicative gaal. T…
  -> Path594 => Loc212  вер=1 порядок=5
       текст: Climb up to the gaal
  -> Path595 => Loc213  вер=1 порядок=5
       текст: Walk around

### Loc211 [обычная]
    Loc211-1: You approached the warehouse building and looked up. The gaal on the roof was still staring out at the pristine jungle. / Making a pass around the building, you…
  -> Path593 => Loc201  вер=1 порядок=5
       текст: Head toward the rock

### Loc212 [обычная]
    Loc212-1: "Uh...Hi?" you said cautiously to the gaal after you had climbed up. / "Hi," he replied cheerfully. "Just don't make me break my gaze. It's our only chance to r…
  -> Path597 => Loc201  вер=1 порядок=5
       текст: Make for the rock

### Loc213 [обычная]
    Loc213-1: Once again you walked around the perimeter of the base, which was blanketed in fog, and realized that the only person who could help you, at least in theory, wa…
  -> Path596 => Loc212  вер=1 порядок=5
       текст: Climb up to the gaal on the ladder

## Анализ
- стартовых: [1]
- концовки: {3: 'СМЕРТЬ', 5: 'СМЕРТЬ', 52: 'СМЕРТЬ', 90: 'УСПЕХ', 96: 'СМЕРТЬ', 129: 'СМЕРТЬ', 143: 'СМЕРТЬ', 181: 'СМЕРТЬ', 209: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
