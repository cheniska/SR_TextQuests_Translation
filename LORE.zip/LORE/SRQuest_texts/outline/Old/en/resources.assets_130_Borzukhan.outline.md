# Квест (формат 1111111126)
Сложность 30; стартовая локация: [2]; путей по умолчанию: 1

## Параметры
- P1 'Health' [0..100] тип=смерть
    старт: [100]
    [0..9] You are barely alive
    [10..39] You are seriously wounded
    [40..74] You are wounded
    [75..89] You are slightly wounded
    [90..99] You got a couple of scratches
    [100..100] You are totally healthy
    критическое: Your powers left you, and darkness surrounded you... /  / You died and failed your mission terribly.
- P2 'Flyer condition' [0..50] тип=смерть
    старт: [50]
    [0..9] The flyer is about to blast!
    [10..19] The flyer is seriously damaged
    [20..29] Flyer is damaged
    [30..39] Flyer is slightly scratched
    [40..50] Flyer is in perfect conditions
    критическое: That last hit was one too many for your flyer and it exploded together with you.
- P3 'Money' [0..10000] тип=обычный деньги
    старт: [5000]
    [0..10000] Your money: <>
    критическое: Сообщение достижения критического значения параметром 2
- P4 'Charges' [0..50] тип=обычный
    старт: [10]
    [0..0] You've got a laser gun with no charges
    [1..1] You've got a laser gun with one charge
    [2..50] You've got a laser gun with <> charges
    критическое: Сообщение достижения критического значения параметром 3
- P5 'Grenades' [0..15] тип=обычный
    старт: [2]
    [0..0] 
    [1..1] You've got <clr>one<clrEnd> grenade
    [2..4] You've got <> grenades
    [5..15] You've got <> grenades
    критическое: Сообщение достижения критического значения параметром 4
- P6 'Stunner' [0..1] тип=обычный
    старт: [0]
    [0..1] You've got a stunner
    критическое: Сообщение достижения критического значения параметром 5
- P7 'First-aid kit' [0..5] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You've got a first-aid kit
    [2..4] You've got <> first-aid kits
    [5..5] You've got <> first-aid kits
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Explosives' [0..1] тип=обычный
    старт: [1]
    [0..0] 
    [1..1] You've got a set of explosives and a detonator
    критическое: Сообщение достижения критического значения параметром 6
- P9 'Killed guards' [0..25] тип=обычный
    старт: [0]
    [0..25] 
    критическое: Сообщение достижения критического значения параметром 8
- P10 'Lyakusha' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You know about the cabin in the forest
    [2..2] Lyakusha Borzukhan is dead
    [3..3] Lyakusha Borzukhan was taken alive
    [4..4] The forest cabin has been blown up together with the tenant
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Knowledge of secret passage' [0..1] тип=обычный
    старт: [0]
    [0..1] You know about the secret passage to the coast
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Knowledge of cabin tenant' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 12: <>
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Recon flag' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter N 13: <>
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Result of se3arching the guard' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter N 14: <>
    критическое: Сообщение достижения критического значения параметром 14
- P15 'X' [0..200] тип=обычный
    старт: [0]
    [0..200] Parameter N 15: <>
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Counter for Pel. search at generator' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Counter L110' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Search counter (steppe)' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 18: <>
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Overheard conversation flag' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Counter L29' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Flag of killed Peleng at the generator' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Landslide flag' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Counter L80 and L112' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter N 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Killed sentry flag' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter N 24: <>
    критическое: Сообщение достижения критического значения параметром 24

## Локации и переходы

### Loc2 [СТАРТ]
    Loc2-1: In the camp you were met by the agent of planet <FromPlanet>. / - Dear <Ranger>, I am glad to meet you here at the planet of <ToPlanet>. My name is Carl. As you…
    скрыт: P2,P4,P5,P8,P9,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24
  -> Path3 => Loc4  вер=1 порядок=5
       текст: How do I find Borzukhan's base?
  -> Path4 => Loc3  вер=1 проходов<=1 порядок=5
       текст: How do I destroy the base?
  -> Path5 => Loc5  вер=1 проходов<=1
       текст: I'm ready!
  -> Path10 => Loc6  вер=1 порядок=5
       текст: Why didn't you locate the base yourselves?

### Loc3 [обычная]
    Loc3-1: - Of course we are not going to send you there unarmed. You will get a laser gun and several grenades in case you run into armed guards. In addition to that we …
  -> Path7 => Loc5  вер=1 проходов<=1
       текст: I'm ready!
  -> Path9 => Loc4  вер=1 порядок=5
       текст: How do I find Borzukhan's base?
  -> Path12 => Loc6  вер=1 порядок=5
       текст: Why didn't you locate the base yourselves?

### Loc4 [обычная]
    Loc4-1: - This may surely become a difficult task, since the planet is rather large. Although I could still advise you on the locations, where, we think, the base is mo…
    эффект: P13(Recon flag) = 1
  -> Path6 => Loc5  вер=1 проходов<=1
       текст: I'm ready!
  -> Path8 => Loc3  вер=1 порядок=5
       текст: How do I destroy the base?
  -> Path11 => Loc6  вер=1 порядок=5
       текст: Why didn't you locate the base yourselves?

### Loc5 [обычная] визитов<=1
    Loc5-1: - Excellent! But before you start off, you must receive your munitions. You are not going to fight Borzukhan empty-handed, are you? So: you will get an explosiv…
  -> Path16 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Climb into the flyer

### Loc6 [обычная]
    выбор описания: {[p15]+1}
    Loc6-1: - Of course, we could have sent our people in advance, so that they located the base, but we do not have any agents who'd be experienced enough to do the job. W…
    Loc6-2: - Of course, we could have sent our people in advance, so that they located the base, but we do not have any agents who'd be experienced enough to do the job. W…
    эффект: P13(Recon flag) = 1
  -> Path13 => Loc5  вер=1 проходов<=1
       текст: I'm ready!
  -> Path14 => Loc4  вер=1 порядок=5
       текст: How do I find Borzukhan's base?
  -> Path15 => Loc3  вер=1 порядок=5
       текст: How do I destroy the base?

### Loc7 [обычная]
    Loc7-1: You are sitting in a light flyer and contemplate where you should go.
    показ: P2,P4,P5
  -> Path17 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Circle over the camp and look around
  -> Path18 => Loc8  вер=1 порядок=5
       текст: Go north, to the mountains
       условия: логика {[p13]>=1}
  -> Path19 => Loc9  вер=1 порядок=5
       текст: Go southwest, to the forest
       условия: логика {[p13]>=1 and [p10]<=1}
  -> Path20 => Loc10  вер=1 порядок=5
       текст: Go to the east, to the sea
       условия: логика {[p13]>=1}
  -> Path210 => Loc106  вер=1 проходов<=1 порядок=5
       текст: Go back to the camp and get some medical assistance
       условия: логика {[p1]<100}

### Loc8 [обычная]
    Loc8-1: You circled over the mountains north of the camp and soon detected a cave opening.
  -> Path98 => Loc7  вер=1 порядок=5
       текст: Fly away
  -> Path99 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Fly back to the cave

### Loc9 [обычная]
    Loc9-1: You are circling over the woods. From this height you cannot see anything suspicious. Maybe you should descend?
  -> Path60 => Loc7  вер=1 порядок=5
       текст: Fly somewhere else
  -> Path61 => Loc28  вер=1 проходов<=3 порядок=5
       текст: Land and walk about the forest
       условия: логика {[p10]=0}
  -> Path62 => Loc29  вер=1 порядок=5
       текст: Land and look for the lyakusha's cabin
       условия: логика {[p10]<=1 and [p19]=1}
  -> Path171 => Loc29  вер=1 порядок=5
       текст: Go back to the cabin you found
       условия: логика {[p10]=1 and [p19]=0}

### Loc10 [обычная]
    Loc10-1: You landed the flyer in the coastal cliffs. Nothing suspicious around here.
  -> Path88 => Loc49  вер=50 проходов<=1 порядок=5
       текст: Take a swim in the sea
  -> Path89 => Loc48  вер=1 порядок=5
       текст: Go down to the sea and inspect the rocks more carefully
       условия: логика {[p22]=0}
  -> Path90 => Loc114  вер=1 порядок=5
       текст: Fly away
  -> Path165 => Loc89  вер=50 проходов<=1 порядок=5
       текст: Take a swim in the sea

### Loc11 [обычная] визитов<=1
    Loc11-1: You circled around the camp. To the north you saw a high range. To the west and south of the camp there was an endless swamp. In the south-west there was a fore…
    эффект: P13(Recon flag) = 2
  -> Path21 => Loc8  вер=1 проходов<=1 порядок=5
       текст: Go north, to the mountains
  -> Path22 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Go southwest, to the forest
       условия: логика {[p10]<=1}
  -> Path23 => Loc10  вер=1 порядок=5
       текст: Go to the east, to the sea
  -> Path24 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Fly to the smoke trace

### Loc12 [обычная] визитов<=1
    Loc12-1: You followed the smoke and soon beheld a group of creatures gathered around a fire. From this distance you still could not make out who they were or what they w…
  -> Path25 => Loc13  вер=1 проходов<=1 порядок=5
       текст: Land carefully not far from the fire
  -> Path26 => Loc14  вер=1 проходов<=1 порядок=5
       текст: Land the flyer by the fire
  -> Path27 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Fly closer to the fire and shoot from the laser gun
       ответ: You took out the laser gun and opened fire. However the Pelengs shot back and managed to hit the flyer a couple of times...
       условия: логика {[p4]>=8}
       эффект: P1(Health) = {[p1]-[8..12]}
       эффект: P2(Flyer condition) = {[p2]-[17..23]}
       эффект: P4(Charges) -8
  -> Path28 => Loc16  вер=1 проходов<=1 порядок=5
       текст: Fly closer to the fire and throw a grenade into the crowd.
       условия: логика {[p5]>0}
  -> Path32 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Turn back and fly away
  -> Path58 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Fly closer to the fire and shoot from the laser gun
       условия: логика {[p4]<8}

### Loc13 [обычная] визитов<=1
    Loc13-1: You carefully landed the flyer not far from the fire, behind a huge rock, where no one could see it. Now you could see a group of five very unfriendly looking P…
  -> Path44 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Fly away
  -> Path45 => Loc23  вер=1 проходов<=1 порядок=5
       текст: Listen to the Peleng conversation
  -> Path46 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Shoot the Pelengs from the laser gun
       условия: логика {[p4]>=5}
  -> Path47 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the Pelengs
       условия: логика {[p5]>0}

### Loc14 [обычная] визитов<=1
    Loc14-1: Without thinking twice, you headed your flyer right to the fire. When you closed in, you saw that the five creatures gathered around the fire were Pelengs. Then…
    эффект: P2(Flyer condition) = {[p2]-[11..15]}
  -> Path29 => Loc16  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade at them
       условия: логика {[p5]>0}
  -> Path30 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Shoot them all from the laser gun
       ответ: You took out the laser gun and opened fire. However the Pelengs shot back and managed to hit the flyer a couple of times...
       условия: логика {[p4]>=8}
       эффект: P1(Health) = {[p1]-[8..12]}
       эффект: P2(Flyer condition) = {[p2]-[17..23]}
       эффект: P4(Charges) -8
  -> Path31 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Turn back and fly away
  -> Path59 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Shoot them all from the laser gun
       условия: логика {[p4]>=1 and [p4]<8}

### Loc15 [обычная] визитов<=3
    Loc15-1: Several seconds later it was all over, although you got your portion as well. But since you did not have enough time to aim, you spent more charges than was req…
  -> Path36 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Fly away
  -> Path37 => Loc19  вер=1 проходов<=1 порядок=5
       текст: Examine the man
  -> Path38 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Search the Peleng bodies

### Loc16 [обычная] визитов<=1
    Loc16-1: You took a grenade and threw it right in the middle of the group. A loud explosion shook the air. Now the swamp was covered in fragments of green Peleng bodies.…
    эффект: P5(Grenades) -1
  -> Path34 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Fly away

### Loc17 [обычная] визитов<=1
    Loc17-1: You turned your flyer and flew away not wanting to mess with this bunch.
  -> Path33 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc18 [обычная] визитов<=1
    Loc18-1: You turned your flyer and flew away.
  -> Path35 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc19 [обычная] визитов<=1
    Loc19-1: You turned to the motionless man and tried to bring him back to consciousness. At first you couldn't do much about it but finally he opened his eyes and moaned:…
  -> Path39 => Loc21  вер=1 проходов<=1 порядок=5
       текст: Explain that you are ranger <Ranger> and are looking for Borzukhan's base

### Loc20 [обычная] визитов<=2
    Loc20-1: Having searched the bodies of the killed Pelengs, you found several laser gun charges on one of them. Looks like this guy did not have the time to use it. Well,…
    эффект: P4(Charges) = {[p4]+[2..4]}
    эффект: P6(Stunner) = 1
    эффект: P18(Search counter (steppe)) +1
  -> Path40 => Loc19  вер=1 проходов<=1 порядок=5
       текст: Examine the man
  -> Path41 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Fly away

### Loc21 [обычная] визитов<=1
    Loc21-1: - Thank you, <Ranger>, for... for s-saving me... f-from these scoundrels, - the man spoke with difficulty, - I-I was a simple... merchant... They captured me ri…
    эффект: P11(Knowledge of secret passage) = 1
  -> Path42 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Sure, no problem! I'll take you to the camp straight away and they'll help you there
       ответ: You took the rescued merchant back to the camp. He was then immediately taken to the medical station. And you had to continue on your mission.
  -> Path151 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Sure, I'll take you to the camp straightaway, let me just check if these scoundrels have anything useful on them...
       ответ: Having searched the bodies of the killed Pelengs, you found several laser gun charges on one of them. Looks like this guy did not have the time to use it. Well,…
       условия: логика {[p18]=0}
       эффект: P4(Charges) = {[p4]+[2..4]}
       эффект: P6(Stunner) = 1
       эффект: P18(Search counter (steppe)) = 1

### Loc23 [обычная] визитов<=1
    Loc23-1: You pricked up your ears and tried to make out what the Pelengs were talking about. By the fragments of their conversation you understood you were in the right:…
  -> Path51 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Shoot the pirates from the laser gun
       условия: логика {[p4]>=5}
  -> Path52 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the pirates
       условия: логика {[p5]>0}
  -> Path53 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Fly away
  -> Path54 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Continue listening
       условия: логика {[p10]<=1}
  -> Path253 => Loc117  вер=1 проходов<=1 порядок=5
       текст: Continue listening
       условия: логика {[p10]>=2}

### Loc24 [обычная] визитов<=2
    Loc24-1: Hiding behind the rock, you produced your laser gun, and taking your aim carefully opened fire at the Pelengs. After the first accurate shot, the remaining four…
    эффект: P4(Charges) -5
  -> Path48 => Loc19  вер=1 проходов<=1 порядок=5
       текст: Examine the man
  -> Path49 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Search the Peleng bodies

### Loc25 [обычная] визитов<=1
    Loc25-1: You took a grenade and threw it right in the middle of the group. A loud explosion shook the air. The unsuspecting Pelengs were blasted apart. Unfortunately the…
    эффект: P5(Grenades) -1
  -> Path50 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Fly away

### Loc26 [обычная] визитов<=1
    Loc26-1: You continued listening to the pirate conversation and heard one of them complain about the habit of their boss Borzukhan spend time all by himself in a small c…
    эффект: P10(Lyakusha) = 1
    эффект: P12(Knowledge of cabin tenant) = 1
    эффект: P19(Overheard conversation flag) = 1
  -> Path55 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the pirates
       условия: логика {[p5]>0}
  -> Path56 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Shoot the pirates from the laser gun
       условия: логика {[p4]>=5}
  -> Path57 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Fly away

### Loc27 [СМЕРТЬ]
    Loc27-1: You took out your laser gun and opened fire. However the enemy returned the fire, so you couldn't really aim properly, and soon were out of charges. You tried t…

### Loc28 [обычная] визитов<=3
    Loc28-1: You walked about the forest for a while, but found nothing suspicious.
  -> Path63 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Go back to the flyer and leave the forest
  -> Path162 => Loc88  вер=70 проходов<=1 порядок=5
       текст: Move deeper into the forest
       ответ: You decided to go deeper into the forest and take a better look, since you were sure of your weapons. However you forgot all about the primitive traps and stepp…
       эффект: P1(Health) -70
  -> Path170 => Loc29  вер=30 проходов<=1 порядок=5
       текст: Move deeper into the forest

### Loc29 [обычная]
    выбор описания: {[p19]+2*[p20]+1}
    Loc29-1: After a long walk about the forest, you went into a meadow, in the middle of which there was a small wooden cabin with glassed windows. Looks like even these da…
    Loc29-2: Remembering the conversation of the pirates that you'd overheard, you decided to find the cabin, which, they claimed, Lyakusha Borzukhan liked to spend his time…
    Loc29-3: You went back to the forest cabin.
    Loc29-4: You went back to the forest cabin.
    эффект: P10(Lyakusha) = 1
  -> Path66 => Loc31  вер=1 проходов<=1 порядок=5
       текст: Sneak up to the cabin and carefully look in the window
       эффект: P20(Counter L29) +1
  -> Path67 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the window
       условия: логика {[p5]>0 and [p12]=1}
       эффект: P20(Counter L29) +1
  -> Path68 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Kick the door in and burst into the house with your gun ready
       условия: логика {[p4]>0 or [p6]>0}
       эффект: P20(Counter L29) = 1
  -> Path69 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Walk up to the cabin and knock politely
       эффект: P20(Counter L29) +1
  -> Path77 => Loc114  вер=1 порядок=5
       текст: Go back to the flyer
       эффект: P20(Counter L29) +1
  -> Path172 => Loc91  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the window
       условия: логика {[p5]>0 and [p12]=0}
       эффект: P20(Counter L29) +1

### Loc31 [обычная] визитов<=1
    Loc31-1: You crawled up to the window and cautiously peeked inside. In the armchair right in the middle of an expensively furnished room sat Lyakusha Borzukhan himself. …
    эффект: P12(Knowledge of cabin tenant) = 1
  -> Path78 => Loc114  вер=1 порядок=5
       текст: Carefully move away from the cabin and go back to the flyer
  -> Path79 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Shoot Borzukhan from the laser gun
       ответ: You took out your gun, took aim, and shot. The unsuspecting Lyakusha jerked violently and sank down. There was a huge hole in his chest. Well, one problem less …
       условия: логика {[p5]>0}
       эффект: P4(Charges) -1
       эффект: P10(Lyakusha) = 2
  -> Path80 => Loc42  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Shoot the stunner through the window
       условия: P6(Stunner) 1..1
  -> Path212 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Carefully step away from the window

### Loc32 [обычная] визитов<=1
    Loc32-1: You took the grenade and threw it right through the window. An explosion thundered sending wooden splinters fly all around the place. When the smoke cleared you…
    эффект: P5(Grenades) -1
    эффект: P10(Lyakusha) = 2
  -> Path76 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Go back to the flyer

### Loc33 [обычная] визитов<=1
    Loc33-1: You kicked the door in and burst into the cabin. Borzukhan jumped up from his armchair searching frantically for his laser gun, that lay nearby.
  -> Path82 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Shoot the laser gun
       ответ: You shot at Borzukhan from your laser gun, but he ducked and the shot went past him. The Lyakusha reached quickly for his own weapon. But you aimed another time…
       условия: логика {[p4]>=2}
       эффект: P1(Health) -35
       эффект: P4(Charges) -2
       эффект: P10(Lyakusha) = 2
  -> Path83 => Loc46  вер=1 проходов<=1 порядок=5
       текст: Shoot the laser gun
       условия: логика {[p4]=1}
  -> Path85 => Loc45  вер=1 проходов<=1 порядок=5
       текст: Stun Borzukhan with a stunner
       условия: логика {[p6]=1}

### Loc34 [обычная] визитов<=1
    Loc34-1: You went to the door and knocked politely. You heard somebody pace quickly up to the door and stop - apparently the Peleng was studying you through the peephole…
  -> Path70 => Loc38  вер=1 проходов<=1 порядок=5
       текст: I am looking for Lyakusha Borzukhan!
  -> Path74 => Loc41  вер=1 проходов<=1 порядок=5
       текст: I was just passing by and decided to drop in!
  -> Path75 => Loc36  вер=1 проходов<=1 порядок=5
       текст: I am forester, me, need to talk to you.

### Loc36 [СМЕРТЬ] визитов<=1
    Loc36-1: You heard the Peleng burst out laughing: / - A forester?! Here on <ToPlanet>? Now that was a real-real good one, lad! Unfortunately I am afraid I can't let you …

### Loc38 [обычная] визитов<=1
    Loc38-1: - Looking for me, pal? Well, you found me. And what is it that you wanted to tell me?
  -> Path71 => Loc39  вер=1 проходов<=1 порядок=5
       текст: - Errr... I think I gotta go...
  -> Path72 => Loc40  вер=50 проходов<=1 порядок=5
       текст: Die, bastard! (Pull out the laser gun and shoot through the door...)
       условия: логика {[p5]>0}
  -> Path73 => Loc41  вер=1 проходов<=1 порядок=5
       текст: Surrender or die!
  -> Path168 => Loc114  вер=50 проходов<=1 порядок=5
       текст: Die, bastard! (Pull out the laser gun and shoot through the door...)
       ответ: You quickly shot through the door from your laser gun and heard somebody cry. The door swung open and you saw Lyakusha Borzukhan stand the his hands pressed aga…
       условия: логика {[p4]>0}
       эффект: P4(Charges) -1
       эффект: P10(Lyakusha) = 2

### Loc39 [СМЕРТЬ] визитов<=1
    Loc39-1: - No so fast, lad! What, you really thought you could come in here, tell me you were looking for me, and then just leave like that?!  / The door swung open and …

### Loc40 [СМЕРТЬ] визитов<=1
    Loc40-1: You shot your laser gun through the door, but the Lyakusha was not that stupid and stood to the side of the door so you missed. Borzukhan swung the door open an…
    эффект: P4(Charges) -1

### Loc41 [СМЕРТЬ]
    Loc41-1: The door swung open and you saw a laser gun pointed right at you. A second later the Peleng pulled the trigger and you rolled on the ground shrieking and trying…

### Loc42 [СМЕРТЬ] визитов<=1
    Loc42-1: You took out the stunner and shot. Unfortunately the glass on the window dispersed the energy charge and Borzukhan was only slightly concussed. He quickly jumpe…

### Loc44 [обычная] визитов<=1
    Loc44-1: Fortunately enough he wasn't that good a shot, and you were only scratched. Oh well, so much for Borzukhan, now it's time for his base.
  -> Path84 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Go back to the flyer

### Loc45 [обычная] визитов<=1
    Loc45-1: You quickly shot your stunner and Borzukhan sank down to the floor. The stunner was out of charges now and you threw it away.
    эффект: P6(Stunner) = 0
    эффект: P10(Lyakusha) = 3
  -> Path197 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Take the stunned Lyakusha back to the camp.
       ответ: You humped the stunned Lyakusha on your back and dragged him to the flyer. Watching him carefully in case he came to, you flew the flyer back to the camp. Carl …
       эффект: P3(Money) +1000

### Loc46 [СМЕРТЬ] визитов<=1
    Loc46-1: You shot at Borzukhan with your laser gun, but he ducked and the shot went past him. The Lyakusha reached quickly for his own weapon, and that brought a horrifi…
    эффект: P4(Charges) -1

### Loc48 [обычная]
    Loc48-1: Going down to the sea you found a grotto.
  -> Path91 => Loc114  вер=1 порядок=5
       текст: Go back to the flyer
  -> Path92 => Loc51  вер=1 порядок=5
       текст: Enter the grotto

### Loc49 [СМЕРТЬ] визитов<=1
    Loc49-1: You decided you needed to relax and undressing quickly went into the sea. The water was magnificent and - forgetting all caution - you swam too far from the coa…

### Loc51 [обычная]
    Loc51-1: You carefully stepped into the grotto and saw a huge tunnel that led to a cave. You went down the passage hoping to find Borzukhan's base but soon ran into a wa…
  -> Path95 => Loc114  вер=1 порядок=5
       текст: Go back to the flyer
  -> Path96 => Loc52  вер=1 порядок=5
       текст: Look for the secret passage
       условия: логика {[p11]=1}

### Loc52 [обычная]
    Loc52-1: Remembering the words of the rescued merchant about the secret tunnel, you decided to take a careful look around. Soon you found a well-masked lever on the wall…
  -> Path177 => Loc93  вер=65 порядок=5
       текст: Go through the passage
  -> Path178 => Loc53  вер=35 проходов<=1 порядок=5
       текст: Go through the passage

### Loc53 [обычная] визитов<=1
    Loc53-1: You followed the passage and soon found a door. Carefully pulling the handle you saw the door was not locked. How careless these pirates are!
  -> Path119 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Open the door and enter

### Loc54 [обычная] визитов<=1
    Loc54-1: You headed your flyer to the cave, when suddenly a group of pirates with laser guns ran out and opened fire at you!
    эффект: P1(Health) -10
    эффект: P2(Flyer condition) -15
    эффект: P15(X) = {[5..7]}
  -> Path100 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Turn back and fly away
  -> Path101 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the guards
       условия: логика {[p5]>0}
  -> Path102 => Loc57  вер=1 проходов<=1 порядок=5
       текст: Shoot the guards from the laser gun
       условия: логика {[p4]>=[p15]}
       эффект: P1(Health) = {[p1]-[15..25]}
       эффект: P2(Flyer condition) = {[p2]-[13..17]}
       эффект: P4(Charges) = {[p4]-[p15]}
  -> Path103 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Shoot the guards from the laser gun
       условия: логика {[p4]>=1 and [p4]<[p15]}
       эффект: P1(Health) = {[p1]-[30..40]}
       эффект: P2(Flyer condition) = {[p2]-[17..23]}
       эффект: P4(Charges) = 0

### Loc55 [ПРОВАЛ]
    Loc55-1: You quickly turned the flyer and flew away. You managed to get away alive but now the enemy has been warned and would surely take all the necessary precautions.…

### Loc56 [обычная] визитов<=1
    Loc56-1: You started firing at the guards from the laser gun, but they were all well hidden behind the rocks and you simply ran out of rounds. And the pirates continued …
  -> Path104 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Turn back and fly away

### Loc57 [обычная] визитов<=1
    Loc57-1: You started firing at the guards from the laser gun, but they were all well hidden behind the rocks and returned the fire. Finally you managed to wipe them all …
  -> Path106 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Land the flyer and enter the cave
       ответ: You landed the flyer behind a rock and cautiously stepped into the cave. In front of you there was a long corridor...

### Loc58 [обычная] визитов<=1
    Loc58-1: You took out a grenade and threw it at the guards. The explosion shook the rocks. You had a free way now.
    эффект: P5(Grenades) -1
    эффект: P24(Killed sentry flag) = 1
  -> Path105 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Land the flyer and enter the cave

### Loc59 [обычная] визитов<=1
    Loc59-1: You landed the flyer behind the nearest rock, and cautiously stepped into the cave. In front of you there was a long corridor. You made a few steps down, but so…
    эффект: P15(X) = {[6..10]}
  -> Path107 => Loc103  вер=1 проходов<=1 порядок=5
       текст: Shoot back from the laser gun
       ответ: You produced your laser gun and returned fire. The pirates fell one after another, but you couldn't constantly duck their shots either...
       условия: логика {[p4]>=[p15]}
       эффект: P1(Health) = {[p1]-[70..80]} «You produced your laser gun and returned fire. The pirates f…»
       эффект: P4(Charges) = {[p4]-[p15]}
  -> Path108 => Loc61  вер=1 порядок=5
       текст: Throw a grenade into the crowd
       условия: логика {[p5]>0}
  -> Path109 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Run out of the cave and escape in your flyer
  -> Path110 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Run out of the cave and hide behind a rock
  -> Path199 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Shoot back from the laser gun
       условия: логика {[p4]<[p15]}

### Loc60 [СМЕРТЬ]
    Loc60-1: You grabbed your laser gun and opened fire at the pirates. However there was too many of them and you had too few rounds, and very quickly you ended up shot.
    эффект: P4(Charges) = 0

### Loc61 [ПРОВАЛ]
    Loc61-1: You cast a grenade into the crowd of enemies. The explosion tore them apart, but the walls and ceiling crumbled as well, blocking the passage. Now you wouldn't …

### Loc62 [обычная] визитов<=1
    Loc62-1: You rushed out of the cave and crouched behind a rock. The enemies ran out and looked around searching for you.
  -> Path111 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Try to make it to the flyer and escape
  -> Path112 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Try to cautiously slip past the enemy back into the cave
  -> Path114 => Loc65  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the crowd of pirates
       условия: логика {[p5]>0}
  -> Path198 => Loc103  вер=1 проходов<=1 порядок=5
       текст: Try to shoot the pirates from the laser gun
       ответ: You produced your laser gun and returned fire. The pirates fell one after another, but you couldn't constantly duck their shots either...
       условия: логика {[p4]>=7}
       эффект: P1(Health) = {[p1]-[40..55]} «You took out the laser gun and started shooting back at the …»
       эффект: P4(Charges) -7
  -> Path200 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Try to shoot the pirates from the laser gun
       условия: логика {[p4]<8}
       эффект: P1(Health) = 0

### Loc63 [СМЕРТЬ] визитов<=1
    Loc63-1: You tried to circle the pirates and quietly sneak into the cave, but they noticed you and shot.

### Loc64 [СМЕРТЬ] визитов<=1
    Loc64-1: You tried to jump to your feet and run for the flyer, but they noticed you and shot.

### Loc65 [обычная] визитов<=1
    Loc65-1: You tossed a grenade into the crowd of pirates and blew them apart. Once again the way was free.
    эффект: P5(Grenades) -1
  -> Path115 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Go back to the cave

### Loc66 [обычная]
    Loc66-1: You went down the corridor. Several minutes later you ran into a ramification. One corridor on the left, one on the right. Nearby there was a door. Putting you …
  -> Path116 => Loc67  вер=1 проходов<=1 порядок=5
       текст: Go left
       эффект: P15(X) = 100
  -> Path117 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Enter the door
  -> Path118 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Go right
  -> Path124 => Loc72  вер=80 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path135 => Loc71  вер=1 проходов<=1 порядок=5
       текст: Go back to the exit
  -> Path157 => Loc82  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path158 => Loc115  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path225 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {76}

### Loc67 [обычная]
    выбор описания: {([p15]=67)+1}
    Loc67-1: Going left you ran into a row of barred cells. Looks like these were used to keep the pirates' prisoners. A guard slept peacefully nearby. "Right!" - you though…
    Loc67-2: You are standing at Borzukhan's prison sells. A guard is sleeping peacefully nearby.
  -> Path126 => Loc73  вер=1 проходов<=1 порядок=5
       текст: Go back to the crossing
       ответ: You turned and went back to the furcation, however the sound of your steps awoke the guard and he shot you in the back...
       условия: логика {[p4]>0}
       эффект: P1(Health) = {[p1]-[20..35]}
  -> Path127 => Loc74  вер=1 проходов<=1 порядок=5
       текст: Kill the sleeping guard
       ответ: You calmly shot the sleeping guard. Next time he won't be sleeping on duty! /  / Having searched the guard's body you found a clip with several laser charges.
       условия: логика {[p4]>0}
       эффект: P4(Charges) = {[p4]+[2..5]}
       эффект: P9(Killed guards) +1
       эффект: P17(Counter L110) = 1
  -> Path128 => Loc104  вер=1 проходов<=1 порядок=5
       текст: Set the explosive and leave
       ответ: You tried to set the explosive, but your fussing awoke the guard, he grabbed his weapon and shot...
       условия: логика {[p4]=0}
       эффект: P1(Health) = {[p1]-[25..35]}
  -> Path203 => Loc104  вер=1 проходов<=1 порядок=5
       текст: Go back to the crossing
       ответ: You turned and went back to the furcation, however the sound of your steps awoke the guard and he shot you in the back...
       условия: логика {[p4]=0}
       эффект: P1(Health) = {[p1]-[20..35]}
  -> Path204 => Loc105  вер=1 проходов<=1 порядок=5
       текст: Set the explosive and leave
       ответ: You tried to set the explosive, but your fussing awoke the guard, he grabbed his weapon and shot...
       условия: логика {[p4]>0}
       эффект: P1(Health) = {[p1]-[25..35]}
  -> Path229 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {67}
  -> Path260 => Loc118  вер=1 проходов<=1 порядок=5
       текст: Batter the sleeping guard with the butt of your gun
       ответ: You started battering the sleeping guard with the butt of your gun, but he turned out to be tougher than that, and even managed to shoot you once.
       условия: логика {[p4]>0}
       эффект: P1(Health) = {[p1]-[15..25]}
       эффект: P17(Counter L110) = 1

### Loc68 [обычная]
    выбор описания: {([p15]=68)+1}
    Loc68-1: You took the right corridor and soon reached a spacious hall with tables. Looks like this is a canteen. Luckily enough it was empty. In the opposite wall of the…
    Loc68-2: You are at Lyakusha Borzukhan's canteen.
  -> Path136 => Loc72  вер=65 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path137 => Loc77  вер=1 проходов<=4 порядок=5
       текст: Enter the left door
       условия: логика {[p21]=0}
  -> Path139 => Loc78  вер=1 проходов<=1 порядок=5
       текст: Enter the right door
  -> Path144 => Loc76  вер=25 порядок=5
       текст: Go back to the crossing
  -> Path155 => Loc82  вер=35 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path156 => Loc115  вер=35 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path187 => Loc97  вер=50 порядок=5
       текст: Go back to the crossing
  -> Path247 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {68}
  -> Path252 => Loc80  вер=1 порядок=5
       текст: Enter the left door
       условия: логика {[p21]=1}

### Loc69 [ПРОВАЛ]
    Loc69-1: You opened the door and stepped right in. Big mistake - you went right into the guardroom. The Pelengs surprised as they were by this intrusion quickly shot you…

### Loc70 [обычная]
    Loc70-1: You opened the door and cautiously stepped into a dimly lit room, noticing, that the door was carefully masked from the inside and was almost unnoticeable. One …
  -> Path120 => Loc67  вер=1 проходов<=1 порядок=5
       текст: Go left
       эффект: P15(X) = 100
  -> Path121 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Enter the door
  -> Path122 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Go right
  -> Path123 => Loc71  вер=1 проходов<=1 порядок=5
       текст: Go back to the exit
  -> Path125 => Loc72  вер=80 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path208 => Loc115  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path209 => Loc82  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path226 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0}
       эффект: P15(X) = {76}

### Loc71 [СМЕРТЬ]
    Loc71-1: You headed to the exit, when a door opened behind your back. A Peleng guard with a laser gun in his hands stepped out. He didn't think twice and shot you dead.

### Loc72 [ПРОВАЛ]
    Loc72-1: You set the explosives and quickly went back to the flyer. Pushing the detonator button you heard a loud explosion. But the base was only damaged - not destroye…
    эффект: P8(Explosives) = 0

### Loc73 [обычная] визитов<=1
    Loc73-1: The shot was not lethal however, and turning on your heel you killed the guard. Having searched his body you found a battery with several laser gun charges.
    эффект: P4(Charges) = {[p4]+[2..5]}
    эффект: P17(Counter L110) = 1
  -> Path202 => Loc76  вер=1 проходов<=1 порядок=5
       текст: Go forward to the fortification

### Loc74 [обычная]
    Loc74-1: You are standing by the prison cells. A dead guard is lying nearby.
  -> Path130 => Loc76  вер=50 проходов<=1 порядок=5
       текст: Go back to the crossing
  -> Path159 => Loc72  вер=95 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path160 => Loc82  вер=5 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path161 => Loc115  вер=5 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path186 => Loc97  вер=50 порядок=5
       текст: Go back to the crossing
  -> Path230 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {74}

### Loc76 [обычная]
    Loc76-1: You are standing at a ramification. One corridor on the left, one - on the right, and the third one leading back to the exit.  Nearby there is a door, from behi…
  -> Path131 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Enter the door
  -> Path132 => Loc68  вер=1 порядок=5
       текст: Go right
       эффект: P15(X) = 100
  -> Path134 => Loc71  вер=1 проходов<=1 порядок=5
       текст: Go back to the exit
  -> Path138 => Loc67  вер=1 порядок=5
       текст: Go left
       условия: логика {[p17]=0}
       эффект: P15(X) = 100
  -> Path224 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {76}
  -> Path251 => Loc74  вер=1 порядок=5
       текст: Go left
       условия: логика {[p17]=1}
       эффект: P15(X) = 100
  -> Path257 => Loc72  вер=80 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path258 => Loc82  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path259 => Loc115  вер=20 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}

### Loc77 [обычная] визитов<=4
    выбор описания: {[p21]+1}
    Loc77-1: You opened the door on the right and went into a small room with a huge power reactor in the middle. Right by the reactor, at a computer there sat a Peleng. See…
    Loc77-2: Opening the right door you returned to the reactor room.
  -> Path142 => Loc79  вер=1 проходов<=1 порядок=5
       текст: Leave
  -> Path143 => Loc80  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Shoot the Peleng
       условия: логика {[p4]>0 and [p21]=0}
       эффект: P4(Charges) -1
       эффект: P9(Killed guards) +1
  -> Path240 => Loc112  вер=1 проходов<=1 порядок=5
       текст: Try to concuss the Peleng
       ответ: You jumped over the Peleng and started battering him with the butt of your gun on the head. But he turned out to be one tough dog, resisting violently and even …
       эффект: P1(Health) = {[p1]-[45..65]}
  -> Path243 => Loc109  вер=1 проходов<=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100 and [p21]=1}
       эффект: P15(X) = {80}

### Loc78 [обычная]
    Loc78-1: Opening the right door you entered a toilet. Looks like this isn't what you've been looking for.
    Loc78-2: You are in the toilet at Borzukhan's base.
    Loc78-3: You are in the toilet at Borzukhan's base.
    Loc78-4: You are in the toilet at Borzukhan's base.
    Loc78-5: You are in the toilet at Borzukhan's base.
    Loc78-6: You are in the toilet at Borzukhan's base.
  -> Path140 => Loc72  вер=70 проходов<=1 порядок=5
       текст: Set the explosive and leave
  -> Path141 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Go back to the canteen
       эффект: P15(X) = 68
  -> Path153 => Loc82  вер=30 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path154 => Loc115  вер=30 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path227 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {78}

### Loc79 [СМЕРТЬ] визитов<=1
    Loc79-1: You tried to walk away but the Peleng sounded an alarm and you ran into a group of guards who quickly shot you dead.

### Loc80 [обычная]
    выбор описания: {[p23]}
    Loc80-1: You pulled out you laser gun and shot the Peleng.
    Loc80-2: You are in the main reactor room of Borzukhan's base. The killed Peleng is lying at your feet.
    эффект: P21(Flag of killed Peleng at the generator) = 1
    эффект: P23(Counter L80 and L112) +1
  -> Path145 => Loc115  вер=1 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path146 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path213 => Loc97  вер=50 порядок=5
       текст: Go back to the crossing
  -> Path214 => Loc76  вер=25 порядок=5
       текст: Go back to the crossing
  -> Path228 => Loc109  вер=1 порядок=5
       текст: Use the first-aid kit
       условия: логика {[p7]>0 and [p1]<100}
       эффект: P15(X) = {80}
  -> Path238 => Loc111  вер=1 проходов<=1 порядок=5
       текст: Search the body
       условия: логика {[p16]=0}

### Loc81 [обычная] визитов<=4
    Loc81-1: You set the explosives onto the reactor and headed back to the flyer. However there was a surprise committee waiting for you there - Lyakusha Borzukhan himself …
    эффект: P8(Explosives) = 0
  -> Path147 => Loc83  вер=1 проходов<=1 порядок=5
       текст: Stun Borzukhan with the stunner
       ответ: You grabbed the stunner and jumped on Borzukhan trying to stun him. However he managed to make a couple of rather accurate shots at you...
       условия: логика {[p6]=1}
       эффект: P1(Health) = {[p1]-[70..80]}
  -> Path148 => Loc84  вер=1 проходов<=1 порядок=5
       текст: Shoot Borzukhan
       ответ: You grabbed the gun and started firing at Borzukhan. He, in turn, crouched behind your flyer and returned the fire..
       условия: логика {[p4]>=4}
       эффект: P1(Health) = {[p1]-[30..50]} «Unfortunately you had been wounded way too many times for su…»
       эффект: P2(Flyer condition) = {[p2]-[5..10]} «Your flyer had been too much damaged in the previous encount…»
       эффект: P4(Charges) -4
  -> Path149 => Loc85  вер=1 проходов<=1 порядок=5
       текст: Shoot Borzukhan
       условия: логика {[p4]<4}
  -> Path242 => Loc113  вер=1 проходов<=1 порядок=5
       текст: Throw the grenade at Borzukhan
       ответ: You took a grenade and threw it at Borzukhan. The explosion tore him to pieces, but your flyer was damaged badly too...
       условия: логика {[p5]>0}
       эффект: P2(Flyer condition) = {[p2]-[30..40]} «Your flyer exploded. You didn't even have the time to think …»
       эффект: P5(Grenades) -1

### Loc82 [УСПЕХ]
    выбор описания: {[p10]-1}
    Loc82-1: You set the explosives onto the reactor and headed back to the flyer. Pushing the detonator button you heard a loud explosion and saw a huge mushroom of dust an…
    Loc82-2: You set the explosives onto the reactor and headed back to the flyer. Pushing the detonator button you heard a loud explosion and saw a huge mushroom of dust an…
    Loc82-3: You set the explosives onto the reactor and headed back to the flyer. Pushing the detonator button you heard a loud explosion and saw a huge mushroom of dust an…
    эффект: P8(Explosives) = 0

### Loc83 [УСПЕХ] визитов<=1
    Loc83-1: Despite being seriously wounded you managed to concuss Borzukhan. Then pressing the detonator button you watched the base explode  /  / Having completed your ob…
    эффект: P3(Money) +1000
    эффект: P6(Stunner) -1
    эффект: P10(Lyakusha) = 3

### Loc84 [УСПЕХ] визитов<=1
    Loc84-1: However after a short fire-exchange you managed to shoot Borzukhan dead. Then pressing the detonator button you watched the base explode  /  / Mission accomplis…
    эффект: P10(Lyakusha) = 2

### Loc85 [СМЕРТЬ] визитов<=1
    Loc85-1: You grabbed the gun and started firing at Borzukhan. He crouched behind your flyer and returned the fire. Finally you ran out of ammo and he shot you.

### Loc88 [обычная] визитов<=1
    Loc88-1: After some extended torment you finally managed to free yourself.
  -> Path163 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Go back to the flyer and fly away

### Loc89 [обычная] визитов<=1
    Loc89-1: You decided you needed to relax and undressing quickly went into the sea. The water was magnificent and you had a great time.
    эффект: P1(Health) +15
  -> Path166 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Fly away
  -> Path167 => Loc48  вер=1 проходов<=1 порядок=5
       текст: Examine the rocks on the coast more carefully
       условия: логика {[p22]=0}

### Loc91 [обычная] визитов<=1
    Loc91-1: You took the grenade and threw it right through the window. An explosion thundered sending wooden splinters fly all around the place. When the smoke cleared you…
    эффект: P5(Grenades) -1
    эффект: P10(Lyakusha) = 4
  -> Path176 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Report to Carl
       ответ: You reported back to the camp and told Carl about blowing up the cabin. He wasn't too happy about your hastiness, but assured you he had the means to identify t…

### Loc93 [обычная]
    Loc93-1: You went down the passage and stumbled into a door. You pulled the handle but the door was locked.
  -> Path179 => Loc114  вер=1 порядок=5
       текст: Go back to the flyer
  -> Path180 => Loc95  вер=1 проходов<=1 порядок=5
       текст: Carefully cut out the lock with the laser gun
       условия: логика {[p4]>=3}
  -> Path181 => Loc94  вер=1 проходов<=1 порядок=5
       текст: Move back and blow up the door with a grenade
       ответ: You went back into the tunnel and threw a grenade at the door. The explosion blasted the door apart, but unfortunately the cave ceiling crumbled too, blocking t…
       условия: логика {[p5]>0}
       эффект: P1(Health) = {[p1]-[25..40]}
       эффект: P5(Grenades) -1
  -> Path182 => Loc96  вер=1 порядок=5
       текст: Carefully cut out the lock with the laser gun
       условия: логика {[p4]<3}

### Loc94 [обычная] визитов<=1
    Loc94-1: You were quite lucky and stayed alive. On the downside though - now you will have to look for some other way to this base.
    эффект: P22(Landslide flag) = 1
  -> Path217 => Loc114  вер=1 проходов<=1 порядок=5
       текст: Go back to the flyer

### Loc95 [обычная] визитов<=1
    Loc95-1: You used your laser gun as a cutter and carefully cut the lock out of the door. You had to spend several charges for that, but now you could go to the base.
    эффект: P4(Charges) -3
  -> Path185 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Enter the base

### Loc96 [обычная]
    Loc96-1: You used your laser gun as a cutter and tried to cut out the lock. Unfortunately the charges you had left were not enough to complete that.
    эффект: P4(Charges) = 0
  -> Path183 => Loc94  вер=1 проходов<=1 порядок=5
       текст: Move back and blow up the door with a grenade
       ответ: You went back into the tunnel and threw a grenade at the door. The explosion blasted the door apart, but unfortunately the cave ceiling crumbled too, blocking t…
       условия: логика {[p5]>0}
       эффект: P1(Health) = {[p1]-[25..40]}
       эффект: P5(Grenades) -1
  -> Path184 => Loc114  вер=1 порядок=5
       текст: Go back to the flyer

### Loc97 [обычная]
    Loc97-1: You went back to the crossing, when suddenly you heard somebody's steps and saw guard walking right at you!
    эффект: P15(X) = {[1..100]}
  -> Path188 => Loc98  вер=25 порядок=5
       текст: Try to run away
  -> Path189 => Loc99  вер=75 проходов<=1 порядок=5
       текст: Try to run away
  -> Path190 => Loc107  вер=1 порядок=5
       текст: Shoot the guard
       условия: логика {([p4]>0) and ([p15]-5*[p9]>13)}
       эффект: P4(Charges) -1
       эффект: P15(X) = {1}
  -> Path192 => Loc107  вер=1 проходов<=1 порядок=5
       текст: Stun the guard with the stunner
       условия: логика {[p6]=1}
       эффект: P6(Stunner) = 0
       эффект: P15(X) = {2}
  -> Path194 => Loc102  вер=50 проходов<=1 порядок=5
       текст: Hide behind the corner and try to concuss the guard when he moves closer.
       условия: логика {[p15]-5*[p9]<=33}
  -> Path195 => Loc107  вер=50 порядок=5
       текст: Hide behind the corner and try to concuss the guard when he moves closer.
       условия: логика {[p15]-5*[p9]>33}
       эффект: P15(X) = {3}
  -> Path250 => Loc116  вер=1 порядок=5
       текст: Shoot the guard
       условия: логика {([p4]>0) and ([p15]-5*[p9]<=13)}
       эффект: P4(Charges) -1
       эффект: P15(X) = {1}

### Loc98 [ПРОВАЛ]
    Loc98-1: You rushed past the guard and ran forward. He shot you in the back but missed. You managed to stay alive but you <clr>still failed the mission<clrEnd>, since no…

### Loc99 [СМЕРТЬ] визитов<=1
    Loc99-1: You tried to dash forward past the guard but he tripped you and you fell on the floor. Without giving it a second thought he shot you dead...

### Loc102 [СМЕРТЬ] визитов<=1
    Loc102-1: You hid round the corner and when the guard reached you, you tried to take him out landing the butt of your gun on his Peleng head. However the guard turned out…

### Loc103 [обычная] визитов<=1
    Loc103-1: Although it took quite some effort you still managed to kill all the pirates. The way to the base was free now.
  -> Path201 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Go to the base

### Loc104 [СМЕРТЬ]
    Loc104-1: The wound was not a lethal one and you quickly snatched your own gun. Too late you remembered that you were out of ammo - the next shot of the guard ended your …

### Loc105 [обычная] визитов<=1
    Loc105-1: The wound was not a lethal one and - turning around swiftly - you shot the guard dead.
  -> Path205 => Loc82  вер=15 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]>=2}
  -> Path206 => Loc115  вер=15 проходов<=1 порядок=5
       текст: Set the explosive and leave
       условия: логика {[p10]<2}
  -> Path207 => Loc72  вер=85 проходов<=1 порядок=5
       текст: Set the explosive and leave

### Loc106 [обычная] визитов<=1
    Loc106-1: You decided to go back to the camp to get some treatment. You were taken to a medical post where they quickly treated your wounds - unfortunately you didn't hav…
    эффект: P1(Health) +30
  -> Path211 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc107 [обычная]
    выбор описания: {[p15]}
    Loc107-1: Not giving it a second thought you pulled out your laser gun and shot the guard dead before he even had a chance to see you.
    Loc107-2: You grabbed the stunned and quickly took the guard out. It is very unlikely that this guy will come to any time soon. But the stunner was out of battery and reg…
    Loc107-3: You hid round the corner and when the guard approached quickly jumped on him and took him out landing the butt of your gun on his head. The Peleng dropped to th…
    эффект: P9(Killed guards) +1
  -> Path219 => Loc108  вер=20 порядок=5
       текст: Search the guard
       условия: логика {[p4]<50}
       эффект: P4(Charges) = {[p4]+[2..5]}
       эффект: P14(Result of se3arching the guard) = 1
  -> Path220 => Loc108  вер=20 порядок=5
       текст: Search the guard
       условия: логика {[p7]<5}
       эффект: P7(First-aid kit) +1
       эффект: P14(Result of se3arching the guard) = 3
  -> Path221 => Loc108  вер=20 порядок=5
       текст: Search the guard
       условия: логика {[p5]<15}
       эффект: P5(Grenades) +1
       эффект: P14(Result of se3arching the guard) = 2
  -> Path222 => Loc108  вер=20 порядок=5
       текст: Search the guard
       эффект: P3(Money) = {[p3]+100}
       эффект: P14(Result of se3arching the guard) = 4
  -> Path246 => Loc108  вер=20 порядок=5
       текст: Search the guard
       эффект: P14(Result of se3arching the guard) = 0
  -> Path249 => Loc108  вер=10 порядок=5
       текст: Search the guard
       условия: логика {[p6]=0}
       эффект: P6(Stunner) +1
       эффект: P14(Result of se3arching the guard) = 5

### Loc108 [обычная]
    выбор описания: {[p14]+1}
    Loc108-1: You searched the guard but did not find anything useful on him.
    Loc108-2: You searched the guard and found out his laser gun was a copy of yours. Using the opportunity you pulled the power-clip from his gun and put it into yours. Alth…
    Loc108-3: Having searched the guard you found a grenade on him, and took it for yourself.
    Loc108-4: You searched the guard and found a first-aid kit.
    Loc108-5: Having searched the pockets of the killed guard you found <clr>100 cr<clrEnd>! Not a bad bonus to your main fee of <Money> cr, which they promised to you for th…
    Loc108-6: In the holster of the killed guard you found a stunner. Lucky you!
  -> Path223 => Loc76  вер=1 порядок=5
       текст: Go forward to the fortification

### Loc109 [обычная]
    Loc109-1: You took a first-aid kit and treated your wounds.
    эффект: P1(Health) = {[p1]+[25..45]}
    эффект: P7(First-aid kit) -1
  -> Path231 => Loc76  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=76}
  -> Path232 => Loc68  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=68}
  -> Path233 => Loc80  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=80}
  -> Path234 => Loc67  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=67}
  -> Path235 => Loc74  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=74}
  -> Path248 => Loc78  вер=1 порядок=5
       текст: Next
       условия: логика {[p15]=78}

### Loc111 [обычная] визитов<=1
    Loc111-1: Having searched the body of the killed Peleng, you found an almost spent power clip for a laser gun.
    эффект: P4(Charges) = {[p4]+[2..4]}
    эффект: P16(Counter for Pel. search at generator) +1
  -> Path239 => Loc80  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc112 [обычная] визитов<=1
    Loc112-1: Finally, after a long wrestling, you managed to take your opponent out. Having searched him you found an almost discharged laser gun clip and also - to your gre…
    эффект: P4(Charges) = {[p4]+[2..4]}
    эффект: P16(Counter for Pel. search at generator) +1
    эффект: P21(Flag of killed Peleng at the generator) = 1
    эффект: P23(Counter L80 and L112) +1
  -> Path241 => Loc80  вер=1 проходов<=1 порядок=5
       текст: Next
       эффект: P9(Killed guards) +1

### Loc113 [УСПЕХ] визитов<=1
    Loc113-1: Fortunately enough the flyer survived the explosion and with great difficulty you managed to take off and fly away. Then pushing the detonator button you watche…

### Loc114 [пустая]
  -> Path244 => Loc7  вер=1 порядок=5

### Loc115 [пустая] визитов<=4
  -> Path245 => Loc81  вер=1 проходов<=4 порядок=5

### Loc116 [СМЕРТЬ]
    Loc116-1: You raised your gun but the Peleng turned out to be faster than you...  /  / You died and failed your mission.

### Loc117 [обычная] визитов<=1
    Loc117-1: You listened a little longer but heard nothing interesting. Time to do something.
  -> Path254 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Fly away
  -> Path255 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Throw a grenade into the pirates
       условия: логика {[p5]>0}
  -> Path256 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Shoot the pirates from the laser gun
       условия: логика {[p4]>=5}

### Loc118 [обычная] визитов<=1
    Loc118-1: Having searched the guard's body you managed to find a power clip with several charges for a laser gun.
    эффект: P4(Charges) = {[p4]+[1..3]}
    эффект: P9(Killed guards) +1
    эффект: P17(Counter L110) = 1
  -> Path261 => Loc74  вер=1 проходов<=1 порядок=5
       текст: Next

## Анализ
- стартовых: [2]
- концовки: {27: 'СМЕРТЬ', 36: 'СМЕРТЬ', 39: 'СМЕРТЬ', 40: 'СМЕРТЬ', 41: 'СМЕРТЬ', 42: 'СМЕРТЬ', 46: 'СМЕРТЬ', 49: 'СМЕРТЬ', 55: 'ПРОВАЛ', 60: 'СМЕРТЬ', 61: 'ПРОВАЛ', 63: 'СМЕРТЬ', 64: 'СМЕРТЬ', 69: 'ПРОВАЛ', 71: 'СМЕРТЬ', 72: 'ПРОВАЛ', 79: 'СМЕРТЬ', 82: 'УСПЕХ', 83: 'УСПЕХ', 84: 'УСПЕХ', 85: 'СМЕРТЬ', 98: 'ПРОВАЛ', 99: 'СМЕРТЬ', 102: 'СМЕРТЬ', 104: 'СМЕРТЬ', 113: 'УСПЕХ', 116: 'СМЕРТЬ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
