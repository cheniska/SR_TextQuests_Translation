# Квест (формат 1111111126)
Сложность 40; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Number of trains' [0..30] тип=обычный
    старт: [30]
    [0..30] Number of trains - <>
    критическое: Вы успешно
- P2 '1' [0..29] тип=обычный
    старт: [0]
    [0..20] Railcars on the first track: <> <>
    [21..29] The first track is closed
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Type 1' [0..4] тип=обычный
    старт: [0]
    [0..0] Parameter 9: <>
    [1..1] Railcars with weapon
    [2..2] Railcars with soldiers
    [3..3] Railcars with fuel
    [4..4] Railcars with machinery
    критическое: Сообщение достижения критического значения параметром 9
- P4 'Delimiter' [0..1] тип=обычный
    старт: [0]
    [0..1] ==============
    критическое: Сообщение достижения критического значения параметром 14
- P5 '2' [0..29] тип=обычный
    старт: [0]
    [0..20] Railcars on the second track: <> <>
    [21..29] The second track is closed
    критическое: Сообщение достижения критического значения параметром 3
- P6 'Type 2' [0..4] тип=обычный
    старт: [0]
    [0..0] Parameter 10: <>
    [1..1] Railcars with weapon
    [2..2] Railcars with soldiers
    [3..3] Railcars with fuel
    [4..4] Railcars with machinery
    критическое: Сообщение достижения критического значения параметром 10
- P7 'Delimiter' [0..1] тип=обычный
    старт: [0]
    [0..1] ==============
    критическое: Сообщение достижения критического значения параметром 15
- P8 '3' [0..29] тип=обычный
    старт: [0]
    [0..20] Railcars on the third track: <> <>
    [21..29] The third track is closed
    критическое: Сообщение достижения критического значения параметром 4
- P9 'Type 3' [0..4] тип=обычный
    старт: [0]
    [0..0] Parameter 11: <>
    [1..1] Railcars with weapon
    [2..2] Railcars with soldiers
    [3..3] Railcars with fuel
    [4..4] Railcars with machinery
    критическое: Сообщение достижения критического значения параметром 11
- P10 'Delimiter' [0..1] тип=обычный
    старт: [0]
    [0..1] ==============
    критическое: Сообщение достижения критического значения параметром 16
- P11 '4' [0..29] тип=обычный
    старт: [0]
    [0..20] Railcars on the fourth track: <> <>
    [21..29] The fourth track is closed
    критическое: Сообщение достижения критического значения параметром 5
- P12 'Type 4' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Railcars with weapon
    [2..2] Railcars with soldiers
    [3..3] Railcars with fuel
    [4..4] Railcars with machinery
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Delimiter' [0..1] тип=обычный
    старт: [0]
    [0..1] ==============
    критическое: Сообщение достижения критического значения параметром 17
- P14 'Railcars' [1..11] тип=обычный
    старт: [11]
    [1..1] A locotractor is coming
    [2..10] Railcars in the train: <> <>
    [11..11] 
    критическое: Сообщение достижения критического значения параметром 6
- P15 'Parameter 7' [0..99999999] тип=обычный деньги
    старт: [10]
    [0..99999999] Parameter 7: <>
    критическое: Сообщение достижения критического значения параметром 7
- P16 'Fines' [0..4] тип=провал
    старт: [0]
    [0..4] Your fines: <>
    критическое: You even didn’t notice as Borzuhan entered the cabin. He said, / "Our generals are having real diffi…
- P17 'Type' [0..4] тип=обычный
    старт: [0]
    [0..4] Parameter 13: <>
    критическое: Сообщение достижения критического значения параметром 13
- P24 'Part' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Mini-locotractors' [1..5] тип=обычный
    старт: [1]
    [1..1] Argberger Locotractor
    [2..2] Tshaipyu Locotractor
    [3..3] Tosharak Locotractor
    [4..4] Sanleo Locotractor
    [5..5] Isou Locotractor
    критическое: Сообщение достижения критического значения параметром 25
- P27 'Mt1' [0..4] тип=обычный
    старт: [4]
    [0..4] Parameter 27: <>
    критическое: Сообщение достижения критического значения параметром 27
- P28 'Mt2' [0..3] тип=обычный
    старт: [3]
    [0..3] Parameter 28: <>
    критическое: Сообщение достижения критического значения параметром 28
- P29 'Mt3' [0..2] тип=обычный
    старт: [2]
    [0..2] Parameter 29: <>
    критическое: Сообщение достижения критического значения параметром 29
- P30 'Mt4' [0..1] тип=обычный
    старт: [1]
    [0..1] Parameter 30: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Mt5' [0..1] тип=обычный
    старт: [1]
    [0..1] Parameter 31: <>
    критическое: Сообщение достижения критического значения параметром 31
- P34 'descriptions' [1..5] тип=обычный
    старт: [1]
    [1..5] Parameter 34: <>
    критическое: Сообщение достижения критического значения параметром 34
- P48 'Railcars have been changed' [1..4] тип=обычный
    старт: [1]
    [1..4] Parameter 48: <>
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    выбор описания: {[p34]}
    Loc1-1: You returned to the planet's orbit. The military base was a gigantic iron box, about the size of an entire city block, suspended in orbit. There was something l…
    Loc1-2: The peleng sighed. / "Wow, <Ranger>. This is like two plus two. We're going to send you trains, and you sort them on the tracks. As soon as you have 20 cars on …
    Loc1-3: "The big locotractors will help you clear the cars from a track," explained the peleng. "We'll send you locotractors from time to time instead of the regular tr…
    Loc1-4: "Isn't that difficult to understand? You can't connect cars that contain different things. If you do connect cars that contain different things, we'll write you…
    скрыт: P1,P2,P4,P5,P7,P8,P10,P11,P13,P14,P15,P17,P19,P20,P21,P22,P24,P25,P27,P28,P29,P30,P31,P34,P48
  -> Path2 => Loc6  вер=1 порядок=9
       текст: Go to hell. I'm not going to get involved in this stupidity!
  -> Path3 => Loc2  вер=1
       текст: I'll take it!
       ответ: "Wonderful!" said peleng, leading you somewhere farther inside. "We have a little secret. The railcars that aren't attached to a train - the ones that stay on t…
  -> Path59 => Loc15  вер=1 порядок=1
       текст: I don't really get the main point of the mission
       эффект: P34(descriptions) = {2}
  -> Path61 => Loc15  вер=1 порядок=2
       текст: Can you tell me more about the locotractors?
       эффект: P34(descriptions) = {3}
  -> Path62 => Loc15  вер=1 порядок=3
       текст: I didn't understand the system with the different types of railcars...
       эффект: P34(descriptions) = {4}

### Loc2 [обычная]
    Loc2-1: From one of the numerous pockets on your threadbare ranger suit, you fish out a tin of your favorite Machpella Dark and make yourself more comfortable on the ro…
    Loc2-2: Waiting for the train was obviously good for your condition. You indulged in nostalgic thoughts about your past heroic deeds, clever ambushes, and long patrols.…
    Loc2-3: You got bored, took out a laptop, and turned it on. It greeted you with beautiful text and jingled a pleasant melody. You put on your headphones, started playin…
    Loc2-4: A boy ran into the cabin and said with a voice that was imploring, yet contemptuous and, at the same time, jolly ("He must have worked long and hard to produce …
    Loc2-5: You noticed a young peleng in military uniform marching around the cabin. You called him over and asked, / "What are you doing here, going back and forth?" / "P…
    Loc2-6: Life on the tracks was hectic. Switchmen, loaders, and repairmen ran every which way. Maybe if it wasn’t so corny, you would compare it with ant hill that had b…
    Loc2-7: A peleng worker caught your attention. He was carrying something under his upper right arm. It vaguely resembled a cross-tie that weighed no more than five kilo…
    скрыт: P1,P14
    показ: P2,P4,P5,P7,P8,P10,P11,P13
  -> Path4 => Loc4  вер=7 проходов<=26 порядок=5
       текст: Wait for a train
       условия: логика {[p24]=0}
       эффект: P1(Number of trains) -1
       эффект: P14(Railcars) = {[2..10]}
       эффект: P17(Type) = {[1..4]}
  -> Path5 => Loc5  вер=2 проходов<=4 порядок=5
       текст: Wait for a train
       ответ: The boy ran into your cabin and shouted, "There's a locotractor coming!" though this was quite evident even without him. A huge, awful machine raced along the r…
       условия: логика {([p2]>0 or [p5]>0 or [p8]>0 or [p11]>0) and [p24]=0}
       эффект: P1(Number of trains) -1
       эффект: P14(Railcars) = {1} [показ]
  -> Path11 => Loc7  вер=1e+08 порядок=5
       текст: Wait for a train
       ответ: You pushed the lever with all your might, and it obediently surrendered.
       условия: P1(Number of trains) 0..0; P24(Part) 0..0; логика {([p2]+[p5]+[p8]+[p11])*10-([p16]*50)>0}
       эффект: P15(Parameter 7) = {[p15]+([p2]+[p5]+[p8]+[p11])*10-([p16]*50)} [скрыт]
       скрыт: P1,P16,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P17
  -> Path30 => Loc7  вер=1e+10 порядок=5
       текст: Wait for a train
       ответ: You were prepared for the next train when the boy reported that everything had been sorted. You stretched and got up from your improvised chair. When Borzuhan c…
       условия: P1(Number of trains) 0..0; P24(Part) 0..0; логика {([p2]+[p5]+[p8]+[p11])*10-([p16]*50)<0}
       эффект: P15(Parameter 7) = {[p15]+([p2]+[p5]+[p8]+[p11])*10-([p16]*50)} [скрыт]
       скрыт: P1,P16,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P17
  -> Path31 => Loc7  вер=1 порядок=5
       текст: Wait for a train
       ответ: You were prepared for yet another train when the boy reported that everything had been sorted. You stretched and got up from your improvised chair. You thought …
       условия: P1(Number of trains) 0..0; P24(Part) 0..0; логика {([p2]+[p5]+[p8]+[p11])*10-([p16]*50)=0}
       скрыт: P1,P16,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P17
  -> Path32 => Loc10  вер=1 порядок=9
       текст: Use locotractors
       условия: логика {[p2]>0 or [p5]>0 or [p8]>0 or [p11]>0}
  -> Path47 => Loc12  вер=1 порядок=5
       текст: Wait for a train
       условия: P1(Number of trains) 0..0; P24(Part) 1..1
       эффект: P15(Parameter 7) = {[p15]+3000}
       эффект: P34(descriptions) = 3
  -> Path48 => Loc4  вер=7 проходов<=18 порядок=5
       текст: Wait for a train
       условия: логика {[p24]=1}
       эффект: P16(Fines) -1
       эффект: P1(Number of trains) -1
       эффект: P14(Railcars) = {[2..10]}
       эффект: P17(Type) = {[1..4]}
  -> Path49 => Loc5  вер=2 проходов<=2 порядок=5
       текст: Wait for a train
       ответ: The boy ran into your cabin and shouted, "There's a locotractor coming!" though this was quite evident even without him. A huge, awful machine raced along the r…
       условия: логика {([p2]>0 or [p5]>0 or [p8]>0) and [p24]=1}
       эффект: P16(Fines) +1
       эффект: P1(Number of trains) -1
       эффект: P14(Railcars) = 1 [показ]
  -> Path50 => Loc12  вер=1 порядок=5
       текст: Wait for a train
       условия: P1(Number of trains) 1..30; P2(1) 21..29; P5(2) 21..29; P8(3) 21..29; P11(4) 21..29
       эффект: P34(descriptions) = 2

### Loc4 [обычная]
    выбор описания: {([p17]=1)*[1..2]+([p17]=2)*[3..4]+([p17]=3)*[5..6]+([p17]=4)*[7..8]}
    Loc4-1: The head of the peleng errand boy popped into a crack in the door and declared: "A train with [p14] <clr>weaponry cars<clrEnd> is coming." You placed your hands…
    Loc4-2: The noise set in almost imperceptibly. It seems it was quiet just a moment ago, but now you had to cover your ears it was so loud. With wild groans and clatteri…
    Loc4-3: You glanced out the window and watched the shiny, slowly-approaching lunkers. It was a train of [p14] <clr>personnel cars<clrEnd>. The fact that it moved slowly…
    Loc4-4: You heard a soft buzz and invited the errand boy in. When he came in, you asked, / "Who's coming over there?" / "A king..." / "What king?" / "King? I don't know…
    Loc4-5: The boy ran to you, caught his breath, and reported, "A train with [p14] <clr>fuel cars<clrEnd> is coming."
    Loc4-6: The first thing you sensed was the smell. You didn't know what kind of smell it was, but you could detect ammonia and acetylene in bouquet of aromas. It was imp…
    Loc4-7: The approaching train reminded you of your childhood. You had always wanted a toy train like that, equipped with beautiful examples of military technology. With…
    Loc4-8: You glanced out the window and saw a rapidly approaching plasma tank. The scene would have been much scarier if the peleng loaders hadn't contrived to secretly …
    показ: P14
  -> Path6 => Loc9  вер=1 порядок=1
       текст: Put it on the first track
       ответ: Your predecessor evidently did not like the first track. The lever was so rusty that the switch could only be moved by bringing all your strength to bear.
       условия: P2(1) 0..20
       эффект: P2(1) = {[p2]+[p14]}
       эффект: P16(Fines) = {[p16]+([p3]<>[p17] and [p3]<>0)}
       эффект: P3(Type 1) = {[p17]}
       скрыт: P14
  -> Path7 => Loc9  вер=1 порядок=2
       текст: Put it on the second track
       ответ: It seems that the lever is conspiring with the train. While the lever resists your efforts, the train rushes straight toward your cabin without slowing. After a…
       условия: P5(2) 0..20
       эффект: P5(2) = {[p5]+[p14]}
       эффект: P16(Fines) = {[p16]+([p6]<>[p17] and [p6]<>0)}
       эффект: P6(Type 2) = {[p17]}
       скрыт: P14
  -> Path8 => Loc9  вер=1 порядок=3
       текст: Put it on the third track
       ответ: With great effort, you moved the lever for the third track. It wasn't going to give up so easily and scratched you deep enough to draw blood. You managed to thr…
       условия: P8(3) 0..20
       эффект: P8(3) = {[p8]+[p14]}
       эффект: P16(Fines) = {[p16]+([p9]<>[p17] and [p9]<>0)}
       эффект: P9(Type 3) = {[p17]}
       скрыт: P14
  -> Path9 => Loc9  вер=1 порядок=4
       текст: Put it on the fourth track
       ответ: You pushed the lever with all your might, and it obediently surrendered.
       условия: P11(4) 0..20
       эффект: P11(4) = {[p11]+[p14]}
       эффект: P16(Fines) = {[p16]+([p12]<>[p17] and [p12]<>0)}
       эффект: P12(Type 4) = {[p17]}
       скрыт: P14

### Loc5 [пустая]
  -> Path16 => Loc2  вер=1 порядок=1
       текст: Put it on the first track
       ответ: Your predecessor evidently did not like the first track. The lever was so rusty that the switch could only be moved by bringing all your strength to bear.
       условия: P2(1) 0..19
       эффект: P2(1) = {0}
       эффект: P3(Type 1) = 0
       скрыт: P14
  -> Path17 => Loc2  вер=1 порядок=2
       текст: Put it on the second track
       ответ: It seems that the lever is conspiring with the train. While the lever resists your efforts, the train rushes straight toward your cabin without slowing. After a…
       условия: P5(2) 0..19
       эффект: P5(2) = {0}
       эффект: P6(Type 2) = 0
       скрыт: P14
  -> Path18 => Loc2  вер=1 порядок=3
       текст: Put it on the third track
       ответ: With great effort, you moved the lever for the third track. It wasn't going to give up so easily and scratched you deep enough to draw blood. You managed to thr…
       условия: P8(3) 0..19
       эффект: P8(3) = {0}
       эффект: P9(Type 3) = 0
       скрыт: P14
  -> Path19 => Loc2  вер=1 порядок=4
       текст: Put it on the fourth track
       ответ: You pushed the lever with all your might, and it obediently surrendered.
       условия: P11(4) 0..19
       эффект: P11(4) = {0}
       эффект: P12(Type 4) = 0
       скрыт: P14

### Loc6 [ПРОВАЛ]
    Loc6-1: "This isn't a job for a real ranger!" you shouted and started toward your ship. "So what if I don't make some money on a couple of cannons or luxury freight? I'…

### Loc7 [пустая]
  -> Path44 => Loc12  вер=1 порядок=5
       текст: Decline
       эффект: P34(descriptions) = 1
  -> Path45 => Loc13  вер=1 порядок=5
       текст: Accept

### Loc9 [пустая]
  -> Path10 => Loc17  вер=1e+14 порядок=5
       условия: P1(Number of trains) 1..30; P2(1) 21..29; P5(2) 21..29; P8(3) 21..29; P11(4) 21..29; логика {[p2]>=21 and [p5]>=21 and [p8]>=21 and [p11]>=21}
  -> Path21 => Loc2  вер=1 порядок=5
       условия: P19(1з) 0..0; P20(2з) 0..0; P21(3з) 0..0; P22(4з) 0..0; логика {[p2]<>20 and [p5]<>20 and [p8]<>20 and [p11]<>20}
  -> Path22 => Loc2  вер=100 порядок=5
       ответ: The train assembled on the first track started its journey out into the big world and left the track itself free of unnecessary railcars.
       условия: P2(1) 20..20
       эффект: P2(1) = {0}
       эффект: P3(Type 1) = 0
  -> Path23 => Loc2  вер=100 порядок=5
       ответ: There was a stir on the second track, and soon the assembled train had cleared the track.
       условия: P5(2) 20..20
       эффект: P5(2) = {0}
       эффект: P6(Type 2) = 0
  -> Path24 => Loc2  вер=100 порядок=5
       ответ: There was a stir on the third track, and soon the assembled train had cleared the track.
       условия: P8(3) 20..20
       эффект: P8(3) = {0}
       эффект: P9(Type 3) = 0
  -> Path25 => Loc2  вер=100 порядок=5
       ответ: "The Lyanchak-Peykhats train is leaving on the fourth track! Be careful!" commanded an iron voice. The transport slowly departed and then rushed to its destinat…
       условия: P11(4) 20..20
       эффект: P11(4) = {0}
       эффект: P12(Type 4) = 0
  -> Path26 => Loc2  вер=1e+07 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the first track<clrEnd> can't withstand this many cars.
       условия: P2(1) 21..29; P24(Part) 0..0
       эффект: P16(Fines) +1
       эффект: P19(1з) +1
       скрыт: P3
  -> Path27 => Loc2  вер=1e+07 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the second track<clrEnd> can't withstand this many cars.
       условия: P5(2) 21..29; P24(Part) 0..0
       эффект: P16(Fines) +1
       эффект: P20(2з) +1
       скрыт: P6
  -> Path28 => Loc2  вер=1e+07 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the third track<clrEnd> can't withstand this many cars.
       условия: P8(3) 21..29; P24(Part) 0..0
       эффект: P16(Fines) +1
       эффект: P21(3з) +1
       скрыт: P9
  -> Path29 => Loc2  вер=1e+07 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the fourth track<clrEnd> can't withstand this many cars.
       условия: P11(4) 21..29; P24(Part) 0..0
       эффект: P16(Fines) +1
       эффект: P22(4з) +1
       скрыт: P12
  -> Path56 => Loc2  вер=10000 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the third track<clrEnd> can't withstand this many cars.
       условия: P8(3) 21..29; P24(Part) 1..1
       скрыт: P9
  -> Path57 => Loc2  вер=100 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the second track<clrEnd> can't withstand this many cars.
       условия: P5(2) 21..29; P24(Part) 1..1
       скрыт: P6
  -> Path58 => Loc2  вер=10000 проходов<=1 порядок=5
       ответ: A light blinked unexpectedly, and you heard the groan of heavy metal panels. It seems <clr>the first track<clrEnd> can't withstand this many cars.
       условия: P2(1) 21..29; P24(Part) 1..1
       скрыт: P3

### Loc10 [обычная]
    Loc10-1: You watched the screen to the right of the levers. Through the dusty, greasy glass, you can read: /  / "At your disposal, you have: / [p27] Argberger locotracto…
  -> Path33 => Loc2  вер=1 порядок=9
       текст: Do not use locotractors
  -> Path34 => Loc11  вер=1 проходов<=4 порядок=5
       текст: Use the Argberger locotractor
       эффект: P25(Mini-locotractors) = 1
       эффект: P27(Mt1) -1
  -> Path35 => Loc11  вер=1 проходов<=3 порядок=5
       текст: Use the Tshaipyu locotractor
       эффект: P25(Mini-locotractors) = 2
       эффект: P28(Mt2) -1
  -> Path36 => Loc11  вер=1 проходов<=2 порядок=5
       текст: Use the Tosharak locotractor
       эффект: P25(Mini-locotractors) = 3
       эффект: P29(Mt3) -1
  -> Path37 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Use the Sanleo locotractor
       эффект: P25(Mini-locotractors) = 4
       эффект: P30(Mt4) -1
  -> Path38 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Use the Isou locotractor
       эффект: P25(Mini-locotractors) = 5
       эффект: P31(Mt5) -1

### Loc11 [обычная]
    выбор описания: {[p25]}
    Loc11-1: The Argberger locotractor wasn't really like a locotractor. It was more like a regular passenger railcar. The errand peleng said that it was regular railcar, bu…
    Loc11-2: Something covered in soot came riding out from a lateral line. The construction resembled an ancient clothes iron. Steam and some sort of gas bellowed out of se…
    Loc11-3: The Tosharak resembled some torpedo with tubes protruding from each side. There wasn't a single tiny window on its smooth, shiny surface. It gave the impression…
    Loc11-4: The Sanleo locotractor looked like an iron chest with an engine. It had seen better days: on each side there were sheets of iron falling from the sideboards in …
    Loc11-5: If didn't already know that the Isou was a locotractor, you probably would have thought it was some endurance racecar. Sheer power seemed to emanate from the ma…
  -> Path40 => Loc14  вер=1
       текст: Put it on the first track
       условия: P2(1) 0..19
       эффект: P2(1) = {[p2]-[p25]}
       эффект: P48(Railcars have been changed) = {1}
  -> Path41 => Loc14  вер=1 порядок=2
       текст: Put it on the second track
       условия: P5(2) 0..19
       эффект: P5(2) = {[p5]-[p25]}
       эффект: P48(Railcars have been changed) = {2}
  -> Path42 => Loc14  вер=1 порядок=3
       текст: Put it on the third track
       условия: P8(3) 0..19
       эффект: P8(3) = {[p8]-[p25]}
       эффект: P48(Railcars have been changed) = {3}
  -> Path43 => Loc14  вер=1 порядок=4
       текст: Put it on the fourth track
       условия: P11(4) 0..19
       эффект: P11(4) = {[p11]-[p25]}
       эффект: P48(Railcars have been changed) = {4}

### Loc12 [УСПЕХ]
    выбор описания: {[p34]}
    Loc12-1: "Well, it’s up to you," answered the peleng without any well-wishing in his voice. / He led you to the engine house, where your spaceship was located. Sitting i…
    Loc12-2: Borzuhan knocked on the cabin door. He looked tired and sad. / "You gave us a lot of trouble. We have to unblock the trains in the few hours remaining before th…
    Loc12-3: A smiling Borzuhan knocked on the cabin door. You stepped outside, and he shook your hand with all four of his. / "I've never seen such clever humanoid!" / You …

### Loc13 [обычная]
    Loc13-1: "Okay, agreed then! By the way, since you're not a commanding officer, there won't be any fines!" the peleng called out with a wink.  / Apparently, the workday …
    эффект: P24(Part) = {1} [скрыт]
  -> Path46 => Loc2  вер=1 порядок=5
       текст: Get to work
       эффект: P16(Fines) = {0} [скрыт]
       эффект: P1(Number of trains) = {20}
       эффект: P2(1) = {0} [показ]
       эффект: P3(Type 1) = {0} [показ]
       эффект: P5(2) = {0} [показ]
       эффект: P6(Type 2) = {0} [показ]
       эффект: P8(3) = {0} [скрыт]
       эффект: P9(Type 3) = {0} [показ]
       эффект: P11(4) = {24} [показ]
       эффект: P12(Type 4) = {0} [показ]
       показ: P4,P7,P10,P13,P14

### Loc14 [пустая]
  -> Path51 => Loc2  вер=1 порядок=5
       условия: P2(1) 0..0; логика {[p2]=0 and [p48]=1}
       эффект: P3(Type 1) = 0
  -> Path52 => Loc2  вер=1 порядок=5
       условия: P5(2) 0..0; логика {[p5]=0 and [p48]=2}
       эффект: P6(Type 2) = {0}
  -> Path53 => Loc2  вер=1 порядок=5
       условия: P8(3) 0..0; логика {[p8]=0 and [p48]=3}
       эффект: P9(Type 3) = {0}
  -> Path54 => Loc2  вер=1 порядок=5
       условия: P11(4) 0..0; логика {[p11]=0 and [p48]=4}
       эффект: P12(Type 4) = {0}
  -> Path55 => Loc2  вер=1 порядок=5

### Loc15 [пустая]
    выбор описания: {[p34]}
  -> Path60 => Loc1  вер=1 порядок=5

### Loc16 [пустая]
    Loc16-1: Для включения счетчика оставшихся составов надо включить отображение параметра 1.

### Loc17 [ПРОВАЛ]
    Loc17-1: "Stop!!!" you shouted, as you ran out of the cabin as if the place was on fire. "All the tracks are closed!"  / The train stopped. Borzuhan, dark as a thundercl…

## Анализ
- стартовых: [1]
- концовки: {6: 'ПРОВАЛ', 12: 'УСПЕХ', 17: 'ПРОВАЛ'}
- недостижимые локации: [16]
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
