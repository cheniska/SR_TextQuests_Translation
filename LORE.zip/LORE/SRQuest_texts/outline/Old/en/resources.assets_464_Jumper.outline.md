# Квест (формат 1111111126)
Сложность 80; стартовая локация: [50]; путей по умолчанию: 1

## Параметры
- P1 'Active battery:' [0..2] тип=обычный
    старт: [0]
    [0..0] ACTIVE BATTERY: none
    [1..1] ACTIVE BATTERY: №1
    [2..2] ACTIVE BATTERY: №2
    критическое: Сообщение достижения критического значения параметром 1
- P2 "Active battery's charge" [0..20] тип=обычный
    старт: [0]
    [0..20] Active battery's charge: <> ergo
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Empty line' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 4
- P4 '1' [-1..20] тип=обычный
    старт: [0]
    [-1..-1] Battery No 1: active
    [0..0] Battery No 1: spent
    [1..20] Battery No 1: [p4] ergo
    критическое: Сообщение достижения критического значения параметром 3
- P5 '2' [-1..20] тип=обычный
    старт: [0]
    [-1..-1] Battery No 2: active
    [0..0] Battery No 2: spent
    [1..20] Battery No 2: <> ergo
    критическое: Сообщение достижения критического значения параметром 5
- P6 'Empty line' [0..6] тип=обычный
    старт: [0]
    [0..6] 
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Sector' [0..60] тип=обычный
    старт: [0]
    [0..10] You are at the starting point
    [11..20] Row: Yellow<br>Platform No {[p7] mod 10}
    [21..30] Row: Red<br>Platform No {[p7] mod 10}
    [31..40] Row: Violet<br>Platform No {[p7] mod 10}
    [41..50] Row: Blue<br>Platform No {[p7] mod 10}
    [51..59] Row: Green<br>Platform No {[p7] mod 10}
    [60..60] You are at the finishing point
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Empty line' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Teleport' [0..2] тип=обычный
    старт: [0]
    [0..1] Teleport is spent
    [2..2] Teleport is charged
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Jump 2' [0..15] тип=обычный
    старт: [4]
    [0..15] Power consumption:<br><clr>2 meters<clrEnd> - [p10] ergo,<br><clr>5 meters<clrEnd> - [p12] ergo, <br…
    критическое: Сообщение достижения критического значения параметром 20
- P11 'Jump 3-4' [0..15] тип=обычный
    старт: [5]
    [0..15] Parameter No 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P12 'Jump 5' [0..15] тип=обычный
    старт: [7]
    [0..15] Parameter No 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P13 'Jump 6-7' [0..15] тип=обычный
    старт: [8]
    [0..15] Parameter No 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P14 'Jump 8' [0..15] тип=обычный
    старт: [10]
    [0..15] Parameter No 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P15 'Jump 8-10' [0..15] тип=обычный
    старт: [15]
    [0..15] Parameter No 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P21 'Empty line' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 12
- P22 'Money' [0..99999999] тип=обычный деньги
    старт: [5000]
    [0..99999999] Your money: <>
    критическое: Сообщение достижения критического значения параметром 13
- P23 'Puzzle' [0..3] тип=обычный
    старт: [0]
    [0..3] Parameter No 14: <>
    критическое: Сообщение достижения критического значения параметром 14
- P24 'Battery replacement' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter No 15: <>
    критическое: Сообщение достижения критического значения параметром 15

## Локации и переходы

### Loc2 [обычная]
    выбор описания: {[p6]+1}
    Loc2-1: - You must test the jumping backpack - "Jumper". We rented a pavilion for the testing and tossed a facility. Your task is to go through the labyrinth made of ha…
    Loc2-2: Instead of answering Hab pointed to the window opening to the testing pavilion. There were half a dozen of platforms about two meters in diameter each hanging b…
    Loc2-3: - This is a portable device for impulse transfers at short distances, or a jumping backpack, - saying this, he pointed to something that really looked like a ba…
    Loc2-4: - There were some... But there is no science without sacrifice; you must know it! Naturally, nothing was left to accident! We have a permanent first aid on duty…
    Loc2-5: Depending on the length of the jump, the power consumption will be the following: /  / <clr>2<clrEnd> meters - [p10] ergo  / <clr>3-4<clrEnd> meters - [p11] erg…
    Loc2-6: - In the first place, you can <clr>replace the active battery with the spare one <clrEnd> on every <clr>platform with an even number <clrEnd> and use it for jum…
    Loc2-7: - You must go through the test labyrinth made of hanging platforms wearing this thing and jumping from one platform to another. The labyrinth consists of the st…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P10,P11,P12,P13,P14,P15,P23,P24
  -> Path3 => Loc3  вер=1 порядок=1
       текст: Please give me more details about the labyrinth's configuration and explain how I can go through it.
       эффект: P6(Empty line) = {1}
  -> Path5 => Loc4  вер=1 порядок=9
       текст: Oh, no - the disability pension is not big enough to affect grasshopper.
       эффект: P23(Puzzle) = {[p9]}
  -> Path121 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Can you tell me more about the "Jumper"? What's the hang of this device?
       эффект: P6(Empty line) = {2}
  -> Path122 => Loc3  вер=1 проходов<=1 порядок=7
       текст: What are your guarantees? Have you experienced any accidents?
       эффект: P6(Empty line) = {3}
  -> Path168 => Loc5  вер=1 проходов<=1
       текст: Take me to the scaffold... I mean, to the testing facility. I agree to stretch my legs a little bit... Lord forbid, of course!
       эффект: P9(Teleport) = {2}
  -> Path170 => Loc3  вер=1 порядок=2
       текст: What is the power consumption during jumping?
       эффект: P6(Empty line) = {4}
  -> Path183 => Loc3  вер=1 порядок=3
       текст: You said something about additional devices in the labyrinth...
       эффект: P6(Empty line) = {5}
  -> Path189 => Loc3  вер=1 порядок=4
       текст: Please tell me once again -what is my task?
       эффект: P6(Empty line) = 6

### Loc3 [пустая]
    выбор описания: {[p6]}
  -> Path4 => Loc2  вер=1 порядок=5

### Loc4 [ПРОВАЛ]
    Loc4-1: You banged the door proudly and left the IIII... You didn't earn anything but health before wealth.

### Loc5 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc5-1: The professor wished you good luck and blessed you. Then he took you to the test pavilion. / - Note that the battery replacement devices are installed on the ev…
    Loc5-2: You transferred to the starting point. The professor ran to you and hooked up the charger to the batteries: / - So, did you manage to study the labyrinth well e…
    эффект: P1(Active battery:) = {1} [показ]
    эффект: P2(Active battery's charge) = {20} [показ]
    эффект: P4(1) = {-1} [показ]
    эффект: P5(2) = {20} [показ]
    эффект: P7(Sector) = {0} [показ]
    показ: P6,P9
  -> Path9 => Loc7  вер=1 [всегда видна] порядок=2
       текст: To Yellow-1 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {11}
  -> Path10 => Loc9  вер=1 [всегда видна] порядок=3
       текст: To Yellow-2 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {12}
  -> Path11 => Loc6  вер=1 [всегда видна] порядок=5
       текст: To Yellow-3 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {13}
  -> Path12 => Loc8  вер=1 [всегда видна] порядок=6
       текст: To Yellow-4 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {14}

### Loc6 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc6-1: You landed softly onto the platform, which didn't even vibrate. There were a lot of footprints of all possible shapes and sizes - from sneakers to huge bare Mal…
    Loc6-2: There were a lot of footprints of all possible shapes and sizes on the platform - from sneakers to huge bare Maloq heels. / "I am no worse" - you thought and de…
  -> Path15 => Loc7  вер=1 [всегда видна] порядок=1
       текст: To Yellow-1 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {11}
  -> Path17 => Loc9  вер=1 [всегда видна] порядок=3
       текст: To Yellow-2 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {12}
  -> Path28 => Loc13  вер=1 [всегда видна] порядок=7
       текст: To Red-4 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {24}
  -> Path31 => Loc8  вер=1 [всегда видна] порядок=4
       текст: To Yellow-4 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {14}
  -> Path99 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc7 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc7-1: After landing on the nearest platform, you all but stepped on the banana peel left there by some unknown prankster. What you said was not wishing him health and…
    Loc7-2: After you all but stepped on the banana peel again, you took a fresh and ripe quanga - a gift from a Menzol friend - cut it to small pieces and put them accurat…
  -> Path18 => Loc9  вер=1 [всегда видна] порядок=1
       текст: To Yellow-2 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {12}
  -> Path19 => Loc11  вер=1 [всегда видна] порядок=5
       текст: To Red-1 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {21}
  -> Path20 => Loc10  вер=1 [всегда видна] порядок=6
       текст: To Red-2 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {22}
  -> Path29 => Loc6  вер=1 [всегда видна] порядок=3
       текст: To Yellow-3 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {13}
  -> Path98 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc8 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc8-1: You hit your heels on the platform nastily and groaned with pain. There was an inscription along the very edge of the platform scratched with some sharp thing: …
    Loc8-2: " Ranger Bob was here <CurDate>", - you saw that inscription for the second time already and these simple words awoke your creativity. Soon a new inscription sp…
  -> Path23 => Loc13  вер=1 [всегда видна] порядок=6
       текст: To Red-4 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {24}
  -> Path32 => Loc6  вер=1 [всегда видна] порядок=5
       текст: To Yellow-3 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {13}
  -> Path78 => Loc27  вер=1
       текст: Replace the battery
  -> Path102 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc9 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc9-1: You landed softly on the platform and all but hit your nose on the battery replacement device. There was a tablet hanging on the device: / "Do not jump off the …
    Loc9-2: You landed softly on the platform and all but hit your nose on the battery replacement device again. There were familiar words on the tablet: / "Do not jump off…
  -> Path14 => Loc12  вер=1 [всегда видна] порядок=7
       текст: To Red-3 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {23}
  -> Path21 => Loc10  вер=1 [всегда видна] порядок=5
       текст: To Red-2 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {22}
  -> Path22 => Loc13  вер=1 [всегда видна] порядок=8
       текст: To Red-4 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {24}
  -> Path26 => Loc7  вер=1 [всегда видна] порядок=1
       текст: To Yellow-1 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {11}
  -> Path27 => Loc6  вер=1 [всегда видна] порядок=2
       текст: To Yellow-3 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {13}
  -> Path97 => Loc27  вер=1
       текст: Replace the battery
  -> Path100 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc10 [обычная]
    Loc10-1: You landed on the platform and all but slip in a small pool of blood. You looked down from the platform and saw another pool, much bigger in size. Several teeth…
  -> Path25 => Loc11  вер=1 [всегда видна] порядок=2
       текст: To Red-1 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {21}
  -> Path35 => Loc12  вер=1 [всегда видна] порядок=3
       текст: To Red-3 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {23}
  -> Path39 => Loc14  вер=1 [всегда видна] порядок=6
       текст: To Violet-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {32}
  -> Path76 => Loc27  вер=1
       текст: Replace the battery
  -> Path105 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc11 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc11-1: This time you were down on your luck - you had to use your hands, feet, and teeth to miss falling down from the 20 meters height. But then your nails and teeth …
    Loc11-2: You were surprised to notice space-boot prints and clear scratches left by nails and teeth on the platform. And these were 60 deep scores! You tried to fit your…
  -> Path30 => Loc10  вер=1 [всегда видна] порядок=5
       текст: To Red-2 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {22}
  -> Path43 => Loc14  вер=1 [всегда видна] порядок=6
       текст: To Violet-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {32}
  -> Path44 => Loc16  вер=1 [всегда видна]
       текст: Teleportation to Violet-1 (6 meters for 1 ergo)
       условия: логика {[p2]>=1}
       эффект: P2(Active battery's charge) = {[p2]-1}
       эффект: P7(Sector) = {31}
  -> Path106 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc12 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc12-1: All that you found on the platform were some spit traces, an empty Cola can, and a scratched inscription: / "Bob's drunk a lot and ate a little here". And the c…
    Loc12-2: Souse traces (some spits, an empty Cola can giving an alcoholic odour, and an scratched inscription: " Bob's drunk a lot and ate a little here ") kept exciting …
  -> Path33 => Loc13  вер=1 [всегда видна] порядок=3
       текст: To Red-4 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {24}
  -> Path34 => Loc10  вер=1 [всегда видна] порядок=1
       текст: To Red-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {22}
  -> Path37 => Loc15  вер=1 [всегда видна] порядок=6
       текст: To Violet-3 (9 meters)
       условия: логика {[p2]>=[p15]}
       эффект: P2(Active battery's charge) = {[p2]-[p15]}
       эффект: P7(Sector) = {33}
  -> Path38 => Loc14  вер=1 [всегда видна] порядок=5
       текст: To Violet-2 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {32}
  -> Path42 => Loc17  вер=1 [всегда видна] порядок=7
       текст: To Violet-4 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {34}
  -> Path101 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc13 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc13-1: A soft fall with a roll and a roar of a parturient gobzaurus - you all but fell off the platform that turned out to be surprisingly slippery. You could hardly h…
    Loc13-2: You still remembered about the bad list so managed to hold up. /  / There is a battery replacement device here.
  -> Path36 => Loc12  вер=1 [всегда видна] порядок=5
       текст: To Red-3 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {23}
  -> Path40 => Loc18  вер=1 [всегда видна] порядок=7
       текст: To Violet-5 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {35}
  -> Path41 => Loc17  вер=1 [всегда видна] порядок=6
       текст: To Violet-4 (3 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {34}
  -> Path77 => Loc27  вер=1
       текст: Replace the battery
  -> Path103 => Loc31  вер=1 порядок=9
       текст: Push the emergency return button

### Loc14 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc14-1: You managed to group yourself in the air and it saved your life. This was the only reason why the iron-sided 57-sized boot lost by an unknown Maloq didn't knock…
    Loc14-2: After one more bang against the iron-sided 57-sized boot, you kicked it hastily trying to fling it down the platform. About ten minutes passed before the pain a…
  -> Path47 => Loc15  вер=1 [всегда видна] порядок=4
       текст: To Violet-3 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {33}
  -> Path48 => Loc16  вер=1 [всегда видна] порядок=3
       текст: To Violet-1 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {31}
  -> Path79 => Loc27  вер=1 порядок=2
       текст: Replace the battery
  -> Path108 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc15 [обычная]
    Loc15-1: Hardly had you landed onto the platform, an automated voice said: / "Active battery, current charge - {[p2]-12} ergo. Boost charging function is active. Boost c…
    эффект: P2(Active battery's charge) = {[p2]+12}
  -> Path54 => Loc21  вер=1 [всегда видна] порядок=6
       текст: To Blue-3 (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {43}
  -> Path55 => Loc22  вер=1 [всегда видна] порядок=7
       текст: To Blue-4 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {44}
  -> Path59 => Loc19  вер=1 [всегда видна] порядок=5
       текст: To Blue-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {42}
  -> Path109 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc16 [обычная]
    Loc16-1: "Down we dive, spouting our flame from under off with one hell-of-a-roar..." - you landed gracefully onto the platform. /  / - Well, I got skill, I got experien…
  -> Path45 => Loc15  вер=1 [всегда видна] порядок=4
       текст: To Violet-3 (9 meters)
       условия: логика {[p2]>=[p15]}
       эффект: P2(Active battery's charge) = {[p2]-[p15]}
       эффект: P7(Sector) = {33}
  -> Path46 => Loc14  вер=1 [всегда видна] порядок=2
       текст: To Violet-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {32}
  -> Path60 => Loc19  вер=1 [всегда видна] порядок=7
       текст: To Blue-2 (5 meters)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]-[p12]}
       эффект: P7(Sector) = {42}
  -> Path61 => Loc20  вер=1 [всегда видна] порядок=6
       текст: To Blue-1 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {41}
  -> Path107 => Loc32  вер=1 порядок=8
       текст: Push the emergency return button

### Loc17 [обычная]
    Loc17-1: The platform was flying at you. You tried to remember some prayers but only nasty stories and recipes of the Maloq cuisine came to your mind. You were lucky tho…
  -> Path50 => Loc18  вер=1 [всегда видна] порядок=3
       текст: To Violet-5 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {35}
  -> Path52 => Loc15  вер=1 [всегда видна] порядок=2
       текст: To Violet-3 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {33}
  -> Path80 => Loc27  вер=1
       текст: Replace the battery
  -> Path104 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc18 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc18-1: After landing onto the platform, you gave it a thought - you had already jumped rather far. And by the way, the professor never mentioned anything about the cal…
    Loc18-2: You landed and looked at the charge indicator - you had {[p2]+[p4]+[p5]+1} ergo left. / "Well, three-four more accurate jumps, and the torture will be over for …
  -> Path51 => Loc17  вер=1 [всегда видна] порядок=3
       текст: To Violet-4 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {34}
  -> Path53 => Loc15  вер=1 [всегда видна] порядок=1
       текст: To Violet-3 (7 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {33}
  -> Path56 => Loc22  вер=1 [всегда видна] порядок=6
       текст: To Blue-4 (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {44}
  -> Path110 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button

### Loc19 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc19-1: After you slammed on the platform, you realised what problems make the life of grasshoppers, fleas and jumpawaiians so hard and short. They pull such stunts one…
    Loc19-2: If your memory serves you well, last time you thought about grasshoppers' fate right on this place. Grasshoppers are nothing compared to you! They don't have to…
  -> Path62 => Loc20  вер=1 [всегда видна] порядок=5
       текст: To Blue-1 (3 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {41}
  -> Path65 => Loc23  вер=1 [всегда видна] порядок=6
       текст: To Green-1 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {51}
  -> Path67 => Loc25  вер=1 [всегда видна] порядок=8
       текст: To Green-2 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {52}
  -> Path81 => Loc27  вер=1 порядок=3
       текст: Replace the battery
  -> Path114 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path174 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc20 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc20-1: "Boeing 737 is landing, please clear the runway. Please clear the runway..." - you snuffled trying to boo a stupid bird that sat right on your way. The bird not…
    Loc20-2: This time the bird disappeared but you still managed to land right into the sticky and sickly traces of its presence there. / "What did she steal from the insti…
  -> Path63 => Loc19  вер=1 [всегда видна] порядок=5
       текст: TO Blue-2 (3 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {42}
  -> Path64 => Loc23  вер=1 [всегда видна] порядок=6
       текст: To Green-1 (1 meter for 6 ergo)
       условия: логика {[p2]>=6}
       эффект: P2(Active battery's charge) = {[p2]-6}
       эффект: P7(Sector) = {51}
  -> Path115 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path171 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc21 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc21-1: After landing onto the very edge of the platform, you saw a scratched inscription: / "Bob was h..." - after "h" it was chopped and a long deep scar along with f…
    Loc21-2: You landed near the familiar inscription "Bob was h..." and spent a few minutes immortalising your deed: / "<Ranger> have been here. I have also been there, and…
  -> Path57 => Loc22  вер=1 [всегда видна] порядок=4
       текст: To Blue-4 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {44}
  -> Path68 => Loc25  вер=1 [всегда видна] порядок=6
       текст: To Green-2 (8 meters)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]-[p14]}
       эффект: P7(Sector) = {52}
  -> Path70 => Loc24  вер=1 [всегда видна] порядок=7
       текст: To Green-3 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {53}
  -> Path113 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path173 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc22 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc22-1: "Ouch!" / The landing was abysmal this time - your feet were burning like on fire, and your completely new space-boots with magnetic soles squished softly and d…
    Loc22-2: Considering your previous experience, you managed to land onto the platform smoothly. You stepped on the edge and noticed your boot sole on the floor. There was…
  -> Path58 => Loc21  вер=1 [всегда видна] порядок=4
       текст: To Blue-3 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {43}
  -> Path71 => Loc24  вер=1 [всегда видна] порядок=6
       текст: To Green-3 (3 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {53}
  -> Path82 => Loc27  вер=1 порядок=3
       текст: Replace the battery
  -> Path111 => Loc32  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path172 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc23 [обычная]
    Loc23-1: This time you jumped not very far, but obviously high, as high as to raise a bump banging on the pavilion's ceiling. But you paid off and managed to scratch a s…
    Loc23-2: You admired your masterpiece with all the pride sailing up to the ceiling. This time it was not just a swearword that you managed to scratch but a whole poem wr…
  -> Path66 => Loc25  вер=1 [всегда видна] порядок=4
       текст: To Green-2 (4 meters)
       условия: логика {[p2]>=[p11]}
       эффект: P2(Active battery's charge) = {[p2]-[p11]}
       эффект: P7(Sector) = {52}
  -> Path72 => Loc26  вер=1 [всегда видна] порядок=2
       текст: To the finishing point (6 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {60}
  -> Path116 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path184 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc24 [обычная]
    Loc24-1: "We are the cha-a-ampions, my friend..." - you sang with your hands tightened desperately on the edge of the platform. You turned out to be lucky because otherw…
    Loc24-2: So you are here again. The Green row is the last one. Why did they paint the last row green, you wonder? It would have been more logical to make it red - most o…
  -> Path73 => Loc26  вер=1 [всегда видна] порядок=2
       текст: To the finishing point (7 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {60}
  -> Path74 => Loc25  вер=1 [всегда видна] порядок=5
       текст: To Green-2 (7 meters)
       условия: логика {[p2]>=[p13]}
       эффект: P2(Active battery's charge) = {[p2]-[p13]}
       эффект: P7(Sector) = {52}
  -> Path112 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path186 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc25 [обычная]
    выбор описания: {([p9]=1)+1}
    Loc25-1: You landed onto the platform and signed with relief - you almost reached the final point - it was close at hand. Rather hairy hand, one should say because only …
    Loc25-2: And there was your chance, so near, oh so near. It's final point already. One more successful jump - and you are there. If you are a little bit down on your luc…
  -> Path75 => Loc26  вер=1 [всегда видна] порядок=2
       текст: To the finishing point (2 meters)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]-[p10]}
       эффект: P7(Sector) = {60}
  -> Path117 => Loc33  вер=1 порядок=9
       текст: Push the emergency return button
  -> Path124 => Loc27  вер=1
       текст: Replace the battery
  -> Path185 => Loc51  вер=1 [всегда видна] порядок=1
       текст: Use the teleport
       условия: P9(Teleport) ∉[1]

### Loc26 [обычная] визитов<=1
    Loc26-1: Your last jump was unbelievably beautiful - a storm of applause came from underneath and in the last moment you realised that the crowd of on-lookers will soon …
  -> Path177 => Loc52  вер=1 проходов<=1 порядок=5
       текст: So what I am supposed to do? To jump while you're staking on me?

### Loc27 [пустая]
  -> Path83 => Loc29  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]
       эффект: P4(1) = {[p2]}
  -> Path86 => Loc29  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]
       эффект: P5(2) = {[p2]}

### Loc28 [пустая]
  -> Path85 => Loc30  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]
       эффект: P5(2) = {-1}
  -> Path88 => Loc30  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]
       эффект: P4(1) = {-1}

### Loc29 [пустая]
  -> Path84 => Loc28  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]
       эффект: P1(Active battery:) = {2}
       эффект: P2(Active battery's charge) = {[p5]}
  -> Path87 => Loc28  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]
       эффект: P1(Active battery:) = {1}
       эффект: P2(Active battery's charge) = {[p4]}

### Loc30 [пустая]
  -> Path89 => Loc9  вер=1 порядок=5
       условия: P7(Sector) ∈[12]
  -> Path90 => Loc8  вер=1 порядок=5
       условия: P7(Sector) ∈[14]
  -> Path91 => Loc13  вер=1 порядок=5
       условия: P7(Sector) ∈[24]
  -> Path92 => Loc10  вер=1 порядок=5
       условия: P7(Sector) ∈[22]
  -> Path93 => Loc14  вер=1 порядок=5
       условия: P7(Sector) ∈[32]
  -> Path94 => Loc17  вер=1 порядок=5
       условия: P7(Sector) ∈[34]
  -> Path95 => Loc19  вер=1 порядок=5
       условия: P7(Sector) ∈[42]
  -> Path96 => Loc22  вер=1 порядок=5
       условия: P7(Sector) ∈[44]
  -> Path123 => Loc25  вер=1 порядок=5
       условия: P7(Sector) ∈[52]

### Loc31 [пустая]
  -> Path118 => Loc34  вер=1 порядок=5

### Loc32 [пустая]
  -> Path119 => Loc34  вер=1 порядок=5

### Loc33 [пустая]
  -> Path120 => Loc34  вер=1 порядок=5

### Loc34 [ПРОВАЛ]
    Loc34-1: You pushed the urgent teleport button and landed in the lab in a minute. A whole crowd of scholars were looking at you with disappointment. The Maloq on crutche…

### Loc35 [обычная] визитов<=1
    Loc35-1: - Well, let's go. / The professor brought you to the neighbouring pavilion. Really, there turned out to be two platforms hanging at the height of 3 meters with …
  -> Path126 => Loc43  вер=1 порядок=5
       текст: Come up to the first platform
       эффект: P1(Active battery:) = {1} [показ]
       эффект: P2(Active battery's charge) = {[p10]} [показ]
       эффект: P4(1) = {-1} [показ]
       эффект: P5(2) = {0} [показ]
       эффект: P7(Sector) = {1}
       показ: P3
  -> Path127 => Loc38  вер=1 порядок=8
       текст: I think it's too difficult for me, I quit...
  -> Path147 => Loc42  вер=1 порядок=5
       текст: Come up to the second platform
       эффект: P1(Active battery:) = {1} [показ]
       эффект: P2(Active battery's charge) = {[p10]} [показ]
       эффект: P4(1) = {-1} [показ]
       эффект: P5(2) = {0} [показ]
       эффект: P7(Sector) = {2}
       показ: P3

### Loc37 [пустая]
  -> Path132 => Loc41  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[0]
       эффект: P24(Battery replacement) = {1}
       эффект: P4(1) = {-1}
       эффект: P5(2) = {[p5]-7}
  -> Path133 => Loc41  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[0]
       эффект: P24(Battery replacement) = {1}
       эффект: P4(1) = {[p4]-7}
       эффект: P5(2) = {-1}
  -> Path156 => Loc41  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[1]
       эффект: P5(2) = {-1}
  -> Path157 => Loc41  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[1]
       эффект: P4(1) = {-1}

### Loc38 [УСПЕХ]
    Loc38-1: Hmph. Air is not your cup of tea. Space vacuum is easier to harness. You failed to supply the device with enough power to display it but we can prepare the pate…

### Loc40 [пустая]
  -> Path130 => Loc37  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[0]
       эффект: P1(Active battery:) = {2}
       эффект: P2(Active battery's charge) = {7}
  -> Path131 => Loc37  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[0]
       эффект: P1(Active battery:) = {1}
       эффект: P2(Active battery's charge) = {7}
  -> Path154 => Loc37  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[1]
       эффект: P1(Active battery:) = {2}
       эффект: P2(Active battery's charge) = {[p5]}
  -> Path155 => Loc37  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[1]
       эффект: P1(Active battery:) = {1}
       эффект: P2(Active battery's charge) = {[p4]}

### Loc41 [пустая]
  -> Path138 => Loc43  вер=1 порядок=5
       условия: P7(Sector) ∈[1]
  -> Path139 => Loc42  вер=1 порядок=5
       условия: P7(Sector) ∈[2]

### Loc42 [обычная]
    Loc42-1: You are standing on the second platform in the prime testing room. There are several replenishing spheres hanging over you at different height. And there used t…
  -> Path137 => Loc38  вер=1 порядок=9
       текст: Cancel the testing
  -> Path140 => Loc43  вер=1 порядок=7
       текст: Go to the first platform
       эффект: P7(Sector) = {1}
  -> Path144 => Loc47  вер=1
       текст: The test is over and the batteries are charged!
       условия: логика {[p2]+[p4]+[p5]=39}
  -> Path162 => Loc44  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Use sphere 1 to charge the battery (height 8 meters, charge {[p14]+5} ergo)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]+5}
  -> Path163 => Loc44  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Use sphere 2 to charge the battery (height 2 meters, charge {[p10]+3} ergo)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]+3}
  -> Path164 => Loc44  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Use sphere 4 to charge the battery (height 5 meters, charge {[p12]+5} ergo)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]+5}
  -> Path165 => Loc44  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Use sphere 3 to charge the battery (height 5 meters, charge {[p12]+3} ergo)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]+3}
  -> Path187 => Loc46  вер=1 порядок=6
       текст: Replace the battery
       условия: P24(Battery replacement) ∈[1]
  -> Path188 => Loc46  вер=100 проходов<=1 порядок=6
       текст: Replace the battery
       условия: P24(Battery replacement) ∈[0]; логика {[p2]>=7}

### Loc43 [обычная]
    Loc43-1: You are standing on the first platform in the prime testing room. There are several replenishing spheres hanging over you at different height. You can see a lot…
  -> Path125 => Loc38  вер=1 порядок=9
       текст: Cancel the testing
  -> Path141 => Loc42  вер=1 порядок=7
       текст: Come up to the second platform
       эффект: P7(Sector) = {2}
  -> Path145 => Loc47  вер=1
       текст: The test is over and the batteries are charged!
       условия: логика {[p2]+[p4]+[p5]=39}
  -> Path146 => Loc45  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Use sphere 1 to charge the battery (height 2 meters, charge {[p10]+4} ergo)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]+4}
  -> Path149 => Loc46  вер=100 проходов<=1 порядок=6
       текст: Replace the battery
       условия: P24(Battery replacement) ∈[0]; логика {[p2]>=7}
  -> Path150 => Loc46  вер=1 порядок=6
       текст: Replace the battery
       условия: P24(Battery replacement) ∈[1]
  -> Path158 => Loc45  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Use sphere 2 to charge the battery (height 2 meters, charge {[p10]+2} ergo)
       условия: логика {[p2]>=[p10]}
       эффект: P2(Active battery's charge) = {[p2]+2}
  -> Path159 => Loc45  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Use sphere 3 to charge the battery (height 5 meters, charge {[p12]+4} ergo)
       условия: логика {[p2]>=[p12]}
       эффект: P2(Active battery's charge) = {[p2]+4}
  -> Path160 => Loc45  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Use sphere 4 to charge the battery (height 8 meters, charge {[p14]+6} ergo)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]+6}
  -> Path161 => Loc45  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Use sphere 5 to charge the battery (height 8 meters, charge {[p14]+4} ergo)
       условия: логика {[p2]>=[p14]}
       эффект: P2(Active battery's charge) = {[p2]+4}

### Loc44 [пустая]
  -> Path142 => Loc42  вер=1 порядок=5

### Loc45 [пустая]
  -> Path143 => Loc43  вер=1 порядок=5

### Loc46 [пустая]
  -> Path135 => Loc40  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[0]; логика {[p2]>=7}
       эффект: P5(2) = {[p2]}
  -> Path136 => Loc40  вер=100 проходов<=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[0]; логика {[p2]>=7}
       эффект: P4(1) = {[p2]}
  -> Path152 => Loc40  вер=1 порядок=5
       условия: P1(Active battery:) ∈[2]; P24(Battery replacement) ∈[1]
       эффект: P5(2) = {[p2]}
  -> Path153 => Loc40  вер=1 порядок=5
       условия: P1(Active battery:) ∈[1]; P24(Battery replacement) ∈[1]
       эффект: P4(1) = {[p2]}

### Loc47 [УСПЕХ]
    Loc47-1: You managed to supply the device with enough power to display it. The professor was glad to tell you 1000 cr - now the "Jumper" will be presented to the commiss…
    эффект: P22(Money) = {[p22]+1000}

### Loc50 [СТАРТ]
    выбор описания: {[p6]+1}
    Loc50-1: You took an aerocab that brought you to the Inventions and Innovations. It was near the Academy of Anthropological and Amorphous Anomalies. You entered and aske…
    Loc50-2: - See, it's very simple. And even not scary at all if you don't look down or close your eyes, which I don't recommend. Otherwise we'll have problems catching yo…
    Loc50-3: - This is elementary, the most important thing is to cut it fine estimating the battery charge. Timely battery replacement will also help a lot. This is why our…
    Loc50-4: - But I must warn you beforehand - if you fail and tumble, don't forget that you are a ranger, keep your emotions - there are women here. And don't you think th…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P9,P10,P11,P12,P13,P14,P15,P23,P24
  -> Path169 => Loc2  вер=1 проходов<=1 порядок=5
       текст: What exactly am I supposed to do?

### Loc51 [пустая]
  -> Path175 => Loc5  вер=1 порядок=5
       эффект: P9(Teleport) = {[p9]-1}

### Loc52 [обычная] визитов<=1
    Loc52-1: - Not at all. It's just additional money. You will get your <Money> credits for sure but you can also earn a little bit more... / - How far is this "more" and w…
    скрыт: P7,P9
  -> Path178 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Bad idea, I have already hit my jumping target for the next year. Good bye!
  -> Path179 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Alright, give me the details.

### Loc53 [УСПЕХ]
    Loc53-1: You left the building of IIII and went to the spaceport. You were very slow and careful going to the aerocab rank and skirted even the smallest puddles and ston…

### Loc54 [обычная] визитов<=1
    Loc54-1: - Wonderful! Here, I'm giving you a battery <clr> with <clrEnd> [p10] <clr>ergo<clrEnd>. The configuration consists of two platforms connected by a bridge with …
    показ: P10
  -> Path181 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Three times no. This is the final word and without any further appeal
  -> Path182 => Loc35  вер=1 проходов<=1 порядок=5
       текст: Alright, I'll buy that idea - put these pieces of iron on me

## Анализ
- стартовых: [50]
- концовки: {4: 'ПРОВАЛ', 34: 'ПРОВАЛ', 38: 'УСПЕХ', 47: 'УСПЕХ', 53: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: [8, 21]
