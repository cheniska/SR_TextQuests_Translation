# Квест (формат 1111111127)
Сложность 30; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 "Player's life" [0..200] тип=смерть
    старт: [100]
    [0..200] Player's life: <>
    критическое: The explosion flash was the last thing you saw.
- P2 "Enemy's life" [0..500] тип=обычный
    старт: [100]
    [0..500] Enemy's life: <>
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Are they going to provide you with the info?' [0..3] тип=обычный
    старт: [0]
    [0..3] Parameter No 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P4 'Blaster' [0..1] тип=обычный
    старт: [0]
    [0..0] Average blaster
    [1..1] Reinforced blaster
    критическое: Сообщение достижения критического значения параметром 4
- P5 'Rocket launcher' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter No 5: <>
    критическое: Сообщение достижения критического значения параметром 5
- P6 'Torpedo tube' [0..1] тип=обычный
    старт: [0]
    [0..0] Average torpedo tube
    [1..1] Reinforced torpedo tube
    критическое: Сообщение достижения критического значения параметром 6
- P7 'After the visit to the boxes' [0..1] тип=обычный
    старт: [1]
    [0..1] Your cash: <>
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Visits to the boxes' [0..3] тип=обычный
    старт: [0]
    [0..1] 
    [2..3] 
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Participants and their weapons' [0..6] тип=обычный
    старт: [0]
    [0..6] Enemies and their weapons <>
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Fights given' [0..10] тип=обычный
    старт: [0]
    [0..10] Fights given: <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Blaster charges' [0..10] тип=обычный
    старт: [0]
    [0..10] Blaster charges: <> pcs.
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Rockets' [0..10] тип=обычный
    старт: [0]
    [0..10] Rocket sets: <> pcs.
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Torpedoes' [0..10] тип=обычный
    старт: [0]
    [0..10] Torpedoes: <> pcs.
    критическое: Сообщение достижения критического значения параметром 13
- P14 "Enemy's blaster charges" [0..10] тип=обычный
    старт: [0]
    [0..10] Enemy's blasters: <> items
    критическое: Сообщение достижения критического значения параметром 14
- P15 "Enemy's rockets" [0..10] тип=обычный
    старт: [0]
    [0..10] Enemy's rockets: <> items
    критическое: Сообщение достижения критического значения параметром 15
- P16 "Enemy's torpedoes" [0..10] тип=обычный
    старт: [0]
    [0..10] Enemy's torpedoes: <> items
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Rocket hits' [0..3] тип=обычный
    старт: [0]
    [0..0] All the rockets missed their target
    [1..1] <> rockets
    [2..2] <> rockets
    [3..3] <> rockets
    критическое: Сообщение достижения критического значения параметром 17
- P19 'Path number' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter No 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Individuals you talked to' [0..7] тип=обычный
    старт: [0]
    [0..7] Parameter No 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Individuals you have info about' [0..4] тип=обычный
    старт: [0]
    [0..4] Parameter No 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Money' [0..100000000] тип=обычный деньги
    старт: [1000]
    [0..100000000] Your cash: <>
    критическое: Сообщение достижения критического значения параметром 3
- P23 'Stake' [0..32000] тип=обычный
    старт: [0]
    [0..32000] Parameter No 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Money received' [0..32000] тип=обычный
    старт: [0]
    [0..32000] Parameter No 24: <>
    критическое: Сообщение достижения критического значения параметром 24

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: After arrival to <ToPlanet>, you had no problems finding the Tournament Committee. /  / - Welcome to the combat robot battle tournament - BattleMech, - they tol…
    эффект: P7(After the visit to the boxes) = 0 [скрыт]
    эффект: P9(Participants and their weapons) = {[1..6]} [скрыт]
    скрыт: P1,P2,P3,P4,P5,P6,P8,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P23,P24
    показ: P22
  -> Path2 => Loc2  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Acquaint yourself with the rules
  -> Path4 => Loc38  вер=1 проходов<=1 порядок=5
       текст: I know the rules already
       эффект: P11(Blaster charges) = 2
       эффект: P12(Rockets) = 2
       эффект: P13(Torpedoes) = 2

### Loc2 [обычная] визитов<=1
    Loc2-1: <clr>Battle rules.<clrEnd> /  / You have tree types of weapons. / <clr>Blaster<clrEnd> - the weakest weapon but its sighting system is perfect. It is impossible…
    эффект: P1(Player's life) = 100
    эффект: P2(Enemy's life) = 100
  -> Path5 => Loc4  вер=1 порядок=6
       текст: I'd rather keep my skin. The money offered is not worthwhile taking such hazards.
  -> Path120 => Loc38  вер=1 проходов<=1 порядок=5
       текст: Thank you. Now I know what I'm going to face

### Loc3 [обычная]
    Loc3-1: Two sets for each type of weapon are inside already. You need to choose <clr>4<clrEnd> remaining sets. /  / Choose <clr>the first<clrEnd> set.
    эффект: P11(Blaster charges) = 2 [показ]
    эффект: P12(Rockets) = 2 [показ]
    эффект: P13(Torpedoes) = 2 [показ]
  -> Path6 => Loc5  вер=1 порядок=1
       текст: Take the blaster charge
       эффект: P11(Blaster charges) = {[p11]+1}
  -> Path7 => Loc5  вер=1 порядок=2
       текст: Take the rocket set
       эффект: P12(Rockets) = {[p12]+1}
  -> Path8 => Loc5  вер=1 порядок=3
       текст: Take the torpedo
       эффект: P13(Torpedoes) = {[p13]+1}

### Loc4 [ПРОВАЛ]
    Loc4-1: Cowardice has been considered disgraceful at all times and by all nations. On the other hand, sometimes they would call reasonable caution and indisposition for…

### Loc5 [обычная]
    Loc5-1: Choose <clr>the second<clrEnd> set.
  -> Path9 => Loc6  вер=1 порядок=1
       текст: Take the blaster charge
       эффект: P11(Blaster charges) = {[p11]+1}
  -> Path12 => Loc6  вер=1 порядок=2
       текст: Take the rocket set
       эффект: P12(Rockets) = {[p12]+1}
  -> Path15 => Loc6  вер=1 порядок=3
       текст: Take the torpedo
       эффект: P13(Torpedoes) = {[p13]+1}

### Loc6 [обычная]
    Loc6-1: Choose <clr>the third<clrEnd> set.
  -> Path10 => Loc7  вер=1 порядок=1
       текст: Take the blaster charge
       эффект: P11(Blaster charges) = {[p11]+1}
  -> Path13 => Loc7  вер=1 порядок=2
       текст: Take the rocket set
       эффект: P12(Rockets) = {[p12]+1}
  -> Path16 => Loc7  вер=1 порядок=3
       текст: Take the torpedo
       эффект: P13(Torpedoes) = {[p13]+1}

### Loc7 [обычная]
    Loc7-1: Choose <clr>the fourth<clrEnd> set.
  -> Path50 => Loc8  вер=1 порядок=1
       текст: Take the blaster charge
       эффект: P11(Blaster charges) = {[p11]+1}
  -> Path51 => Loc8  вер=1 порядок=2
       текст: Take the rocket set
       эффект: P12(Rockets) = {[p12]+1}
  -> Path52 => Loc8  вер=1 порядок=3
       текст: Take the torpedo
       эффект: P13(Torpedoes) = {[p13]+1}

### Loc8 [обычная]
    Loc8-1: Prepare for the fight.
  -> Path18 => Loc3  вер=1 порядок=5
       текст: I want to change my ammunition lot
       эффект: P11(Blaster charges) = 2
       эффект: P12(Rockets) = 2
       эффект: P13(Torpedoes) = 2
  -> Path59 => Loc19  вер=1 проходов<=1 порядок=5
       текст: With John "God" O'Damned
       условия: логика {[p9]=1 or [p9]=2}
       эффект: P10(Fights given) +1
  -> Path60 => Loc20  вер=1 проходов<=1 порядок=5
       текст: With Zen Cha-Cha
       условия: логика {[p9]=1 or [p9]=5}
       эффект: P10(Fights given) +2
  -> Path61 => Loc21  вер=1 проходов<=1 порядок=5
       текст: With Steel Silvester
       условия: логика {[p9]=1 or [p9]=3}
       эффект: P10(Fights given) +4
  -> Path244 => Loc20  вер=1 проходов<=1 порядок=5
       текст: With John "God" O'Damned
       условия: логика {[p9]=3 or [p9]=6}
       эффект: P10(Fights given) +1
  -> Path245 => Loc21  вер=1 проходов<=1 порядок=5
       текст: With John "God" O'Damned
       условия: логика {[p9]=4 or [p9]=5}
       эффект: P10(Fights given) +1
  -> Path246 => Loc19  вер=1 проходов<=1 порядок=5
       текст: With Zen Cha-Cha
       условия: логика {[p9]=3 or [p9]=4}
       эффект: P10(Fights given) +2
  -> Path247 => Loc21  вер=1 проходов<=1 порядок=5
       текст: With Zen Cha-Cha
       условия: логика {[p9]=2 or [p9]=6}
       эффект: P10(Fights given) +2
  -> Path248 => Loc20  вер=1 проходов<=1 порядок=5
       текст: With Steel Silvester
       условия: логика {[p9]=2 or [p9]=4}
       эффект: P10(Fights given) +4
  -> Path249 => Loc19  вер=1 проходов<=1 порядок=5
       текст: With Steel Silvester
       условия: логика {[p9]=5 or [p9]=6}
       эффект: P10(Fights given) +4

### Loc9 [пустая]
  -> Path32 => Loc18  вер=6 порядок=5
       текст: Shoot a torpedo
       условия: логика {[p13]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P13(Torpedoes) = {[p13]-1}
  -> Path56 => Loc16  вер=1 порядок=5
       текст: Blaster fire
       условия: логика {[p11]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P11(Blaster charges) = {[p11]-1}
  -> Path57 => Loc17  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) = {[p12]-1}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path150 => Loc17  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=1 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) -1
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path239 => Loc11  вер=1 проходов<=1 порядок=5
       ответ: The enemy blew off all his ammunition so they announced your victory due to ammunition superiority. After the honour round in front of the elated stands, you ca…
       условия: логика {([p14]=0) and ([p15]=0) and ([p16]=0)}

### Loc10 [пустая]
    выбор описания: {2-([p2]>0)}
  -> Path53 => Loc13  вер=1 [всегда видна] порядок=5
       текст: Activate the power shield
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path54 => Loc14  вер=1 [всегда видна] порядок=5
       текст: Manoeuvre to escape rockets
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
  -> Path55 => Loc15  вер=1 [всегда видна] порядок=5
       текст: Activate the noise generator
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path235 => Loc96  вер=1 проходов<=1 порядок=5
       текст: Come on
       условия: логика {[p11]=0 and [p12]=0 and [p13]=0}

### Loc11 [пустая]
  -> Path48 => Loc38  вер=1 порядок=5
       ответ: After you carried the remainders of your BattleMech to the boxes, you left the stadium.
       условия: логика {[p10]<7}
       эффект: P1(Player's life) = 100 [скрыт]
       эффект: P2(Enemy's life) = 100 [скрыт]
       эффект: P7(After the visit to the boxes) = 0
       эффект: P11(Blaster charges) = 2 [скрыт]
       эффект: P12(Rockets) = 2 [скрыт]
       эффект: P13(Torpedoes) = 2 [скрыт]
       эффект: P18(Был сегодня в мастерских) = 0
  -> Path178 => Loc63  вер=1 проходов<=1 порядок=5
       ответ: Hardly had you left the playground followed by the wild roar of the elated stands when some too cheeky Peleng appeared as if from nowhere and stood on your way.…
       условия: логика {[p10]=7}
       эффект: P11(Blaster charges) = 0 [скрыт]
       эффект: P12(Rockets) = 0 [скрыт]
       эффект: P13(Torpedoes) = 0 [скрыт]
       скрыт: P1,P2

### Loc12 [УСПЕХ]
    Loc12-1: Phew! This bloody nightmare is over at last. You left the playground with your legs shaking hardly believing that you managed to stay alive in this slaughter. W…

### Loc13 [пустая]
  -> Path34 => Loc87  вер=5 [всегда видна] порядок=5
       условия: логика {[p14]>0}
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path37 => Loc87  вер=1 [всегда видна] порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-15*[p17]} «Your mom told you to avoid activating the power shield when …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path38 => Loc87  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[30..45]} «A dreadful torpedo shook your machine. The explosion flash w…»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc14 [пустая]
  -> Path39 => Loc88  вер=5 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[35..45]} «The blaster shot outran your ill-timed manoeuvre. The explos…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path40 => Loc88  вер=1 [всегда видна] порядок=5
       условия: логика {[p15]>0}
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path41 => Loc88  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[35..50]} «Your machine that had just finished manoeuvring was knocked …»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc15 [пустая]
  -> Path42 => Loc89  вер=5 [всегда видна] порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[35..45]} «The enemy managed to outplay you. After you activated the no…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path45 => Loc89  вер=1 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-18*[p17]} «You saw the approaching rockets but it was too late to duck …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path46 => Loc89  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[5..10]}
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc16 [пустая]
  -> Path21 => Loc78  вер=1 [всегда видна] порядок=5
       эффект: P19(Path number) = 0
  -> Path22 => Loc78  вер=1 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 1
  -> Path23 => Loc78  вер=1 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 2

### Loc17 [пустая]
  -> Path26 => Loc79  вер=1 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-15*[p17]}
       эффект: P19(Path number) = 0
  -> Path27 => Loc79  вер=1 [всегда видна] порядок=5
       эффект: P19(Path number) = 1
  -> Path30 => Loc79  вер=1 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-18*[p17]}
       эффект: P19(Path number) = 2

### Loc18 [пустая]
  -> Path31 => Loc80  вер=1 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-[30..45]}
       эффект: P19(Path number) = 0
  -> Path33 => Loc80  вер=2 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-([5..10]+[p6]*5)}
       эффект: P19(Path number) = 2
  -> Path58 => Loc80  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[35..50]}
       эффект: P19(Path number) = 1

### Loc19 [обычная]
    выбор описания: {[p9]}
    Loc19-1: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    Loc19-2: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    Loc19-3: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    Loc19-4: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    Loc19-5: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    Loc19-6: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    показ: P1,P2
  -> Path19 => Loc9  вер=1 порядок=5
       текст: Here we go...
       ответ: It's time for your strike. Choose the weapon.
       эффект: P14(Enemy's blaster charges) = 6
       эффект: P15(Enemy's rockets) = 2
       эффект: P16(Enemy's torpedoes) = 2
  -> Path20 => Loc10  вер=1 порядок=5
       текст: Here we go...
       ответ: Choose what enemy's weapon you will defend yourself from.
       эффект: P14(Enemy's blaster charges) = 6
       эффект: P15(Enemy's rockets) = 2
       эффект: P16(Enemy's torpedoes) = 2

### Loc20 [обычная]
    выбор описания: {[p9]}
    Loc20-1: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    Loc20-2: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    Loc20-3: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    Loc20-4: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    Loc20-5: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    Loc20-6: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    показ: P1,P2
  -> Path62 => Loc22  вер=1 порядок=5
       текст: Here we go...
       ответ: It's time for your strike. Choose the weapon.
       эффект: P14(Enemy's blaster charges) = 2
       эффект: P15(Enemy's rockets) = 6
       эффект: P16(Enemy's torpedoes) = 2
  -> Path63 => Loc23  вер=1 порядок=5
       текст: Here we go...
       ответ: Choose what enemy's weapon you will defend yourself from.
       эффект: P14(Enemy's blaster charges) = 2
       эффект: P15(Enemy's rockets) = 6
       эффект: P16(Enemy's torpedoes) = 2

### Loc21 [обычная]
    выбор описания: {[p9]}
    Loc21-1: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    Loc21-2: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    Loc21-3: <clr>Steel Silvester<clrEnd>'s BattleMech was worked as a gobzaurus and looked awesome if not to say shocking. The spectators acclaimed him while your appearanc…
    Loc21-4: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    Loc21-5: So, the great and dreadful <clr>John "God" O'Damned <clrEnd> versus you! Stands kept their breath waiting for the fight. Huge monitors over them displayed a clo…
    Loc21-6: While you were preparing to go out to the playground, the crowd-puller <clr>Zen  Cha-Cha<clrEnd> was demonstrating the art of manipulating a BattleMech in front…
    показ: P1,P2
  -> Path91 => Loc33  вер=1 порядок=5
       текст: Here we go...
       ответ: Choose what enemy's weapon you will defend yourself from.
       эффект: P14(Enemy's blaster charges) = 2
       эффект: P15(Enemy's rockets) = 2
       эффект: P16(Enemy's torpedoes) = 6
  -> Path92 => Loc34  вер=1 порядок=5
       текст: Here we go...
       ответ: It's time for your strike. Choose the weapon.
       эффект: P14(Enemy's blaster charges) = 2
       эффект: P15(Enemy's rockets) = 2
       эффект: P16(Enemy's torpedoes) = 6

### Loc22 [пустая]
  -> Path66 => Loc27  вер=1 порядок=5
       текст: Blaster fire
       условия: логика {[p11]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P11(Blaster charges) = {[p11]-1}
  -> Path67 => Loc28  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) = {[p12]-1}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path68 => Loc29  вер=1 порядок=5
       текст: Shoot a torpedo
       условия: логика {[p13]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P13(Torpedoes) = {[p13]-1}
  -> Path151 => Loc28  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=1 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) -1
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path240 => Loc11  вер=1 проходов<=1 порядок=5
       ответ: The enemy blew off all his ammunition so they announced your victory due to ammunition superiority. After the honour round in front of the elated stands, you ca…
       условия: логика {([p14]=0) and ([p15]=0) and ([p16]=0)}

### Loc23 [пустая]
    выбор описания: {2-([p2]>0)}
  -> Path78 => Loc26  вер=1 порядок=5
       текст: Activate the power shield
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path79 => Loc25  вер=1 порядок=5
       текст: Manoeuvre to escape rockets
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
  -> Path80 => Loc24  вер=1 порядок=5
       текст: Activate the noise generator
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path236 => Loc96  вер=1 проходов<=1 порядок=5
       текст: Come on
       условия: логика {[p11]=0 and [p12]=0 and [p13]=0}

### Loc24 [пустая]
  -> Path88 => Loc74  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[22..30]} «The enemy managed to outplay you. After you activated the no…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path89 => Loc74  вер=4 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-18*[p17]} «You saw the approaching rockets but it was too late to duck …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path90 => Loc74  вер=1 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[5..10]}
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc25 [пустая]
  -> Path85 => Loc73  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[22..30]} «The blaster shot outran your ill-timed manoeuvre. The explos…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path86 => Loc73  вер=1 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[35..50]} «Your machine that had just finished manoeuvring was knocked …»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2
  -> Path87 => Loc73  вер=4 порядок=5
       условия: логика {[p15]>0}
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1

### Loc26 [пустая]
  -> Path82 => Loc72  вер=4 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-15*[p17]} «Your mom told you to avoid activating the power shield when …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path83 => Loc72  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path84 => Loc72  вер=1 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[30..45]} «A dreadful torpedo shook your machine. The explosion flash w…»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc27 [пустая]
  -> Path69 => Loc64  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 1
  -> Path70 => Loc64  вер=1 порядок=5
       эффект: P19(Path number) = 0
  -> Path71 => Loc64  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 2

### Loc28 [пустая]
  -> Path72 => Loc70  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-18*[p17]}
       эффект: P19(Path number) = 2
  -> Path73 => Loc70  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-15*[p17]}
       эффект: P19(Path number) = 0
  -> Path74 => Loc70  вер=5 порядок=5
       эффект: P19(Path number) = 1

### Loc29 [пустая]
  -> Path75 => Loc71  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[35..50]}
       эффект: P19(Path number) = {[4..6]}
  -> Path76 => Loc71  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[30..45]}
       эффект: P19(Path number) = {[1..3]}
  -> Path77 => Loc71  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([5..10]+[p6]*5)}
       эффект: P19(Path number) = {[7..9]}
  -> Path81 => Loc71  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([5..10]+[p6]*5)}
       эффект: P19(Path number) = 10

### Loc30 [пустая]
  -> Path110 => Loc92  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[22..30]} «The enemy managed to outplay you. After you activated the no…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = {[1..3]}
  -> Path111 => Loc92  вер=1 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-18*[p17]} «You saw the approaching rockets but it was too late to duck …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = {[4..6]}
  -> Path112 => Loc92  вер=2 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[5..10]}
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = {[7..9]}
  -> Path113 => Loc92  вер=1 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[35..50]}
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 10

### Loc31 [пустая]
  -> Path114 => Loc91  вер=3 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[35..50]} «Your machine that had just finished manoeuvring was knocked …»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2
  -> Path115 => Loc91  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[22..30]} «The blaster shot outran your ill-timed manoeuvre. The explos…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path116 => Loc91  вер=1 порядок=5
       условия: логика {[p15]>0}
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1

### Loc32 [пустая]
  -> Path117 => Loc90  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path118 => Loc90  вер=1 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-15*[p17]} «Your mom told you to avoid activating the power shield when …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path119 => Loc90  вер=3 порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[30..45]} «A dreadful torpedo shook your machine. The explosion flash w…»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc33 [пустая]
    выбор описания: {2-([p2]>0)}
  -> Path98 => Loc32  вер=1 порядок=5
       текст: Activate the power shield
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path99 => Loc31  вер=1 порядок=5
       текст: Manoeuvre to escape rockets
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
  -> Path100 => Loc30  вер=1 порядок=5
       текст: Activate the noise generator
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {1+([0..1]=0)+([0..1]=0)}
  -> Path237 => Loc96  вер=1 проходов<=1 порядок=5
       текст: Come on
       условия: логика {[p11]=0 and [p12]=0 and [p13]=0}

### Loc34 [пустая]
  -> Path95 => Loc35  вер=1 порядок=5
       текст: Blaster fire
       условия: логика {[p11]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P11(Blaster charges) = {[p11]-1}
  -> Path96 => Loc36  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) = {[p12]-1}
       эффект: P17(Rocket hits) = {1+([0..2]=0)+([0..2]=0)}
  -> Path97 => Loc37  вер=1 порядок=5
       текст: Shoot a torpedo
       условия: логика {[p13]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P13(Torpedoes) = {[p13]-1}
  -> Path152 => Loc36  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and [p5]=1 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) -1
       эффект: P17(Rocket hits) = {2+([0..3]=0)}
  -> Path241 => Loc11  вер=1 проходов<=1 порядок=5
       ответ: The enemy blew off all his ammunition so they announced your victory due to ammunition superiority. After the honour round in front of the elated stands, you ca…
       условия: логика {([p14]=0) and ([p15]=0) and ([p16]=0)}

### Loc35 [пустая]
  -> Path101 => Loc75  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 1
  -> Path102 => Loc75  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([22..30]+[p4]*10)}
       эффект: P19(Path number) = 2
  -> Path103 => Loc75  вер=1 порядок=5
       эффект: P19(Path number) = 0

### Loc36 [пустая]
  -> Path104 => Loc76  вер=2 порядок=5
       эффект: P19(Path number) = 1
  -> Path105 => Loc76  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-18*[p17]}
       эффект: P19(Path number) = 2
  -> Path106 => Loc76  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-15*[p17]}
       эффект: P19(Path number) = 0

### Loc37 [пустая]
  -> Path107 => Loc77  вер=1 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[30..45]}
       эффект: P19(Path number) = 0
  -> Path108 => Loc77  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[35..50]}
       эффект: P19(Path number) = 1
  -> Path109 => Loc77  вер=2 порядок=5
       эффект: P2(Enemy's life) = {[p2]-([5..10]+[p6]*5)}
       эффект: P19(Path number) = 2

### Loc38 [обычная]
    выбор описания: {[p7]+1}
    Loc38-1: The next fight will be only tomorrow, so now you can relax and have a rest. However, it is desirable that you visit <clr>the boxes<clrEnd> in the first place. M…
    Loc38-2: So, the upgrade will be complete by tomorrow. You left the boxes with a contented smile. /  / May be, it's worthwhile going to <clr>the bar<clrEnd> now and try …
  -> Path3 => Loc3  вер=1 [всегда видна] порядок=5
       текст: Go to bed
       ответ: You had a good night's rest and are ready for any trials.
       показ: P11,P12,P13
  -> Path121 => Loc39  вер=1 порядок=5
       текст: Go to the bar
       условия: логика {[p10]=0}
       эффект: P21(Individuals you have info about) = {[1;2;4]}
  -> Path145 => Loc53  вер=1 проходов<=3 порядок=5
       текст: Go to the boxes
       условия: логика {[p7]=0}
       эффект: P7(After the visit to the boxes) = 1
       эффект: P8(Visits to the boxes) +1
  -> Path192 => Loc39  вер=1 порядок=5
       текст: Go to the bar
       условия: логика {[p10]=1}
       эффект: P21(Individuals you have info about) = {[2;4]}
  -> Path193 => Loc39  вер=1 порядок=5
       текст: Go to the bar
       условия: логика {[p10]=2}
       эффект: P21(Individuals you have info about) = {[1;4]}
  -> Path194 => Loc39  вер=1 порядок=5
       текст: Go to the bar
       условия: логика {[p10]=4}
       эффект: P21(Individuals you have info about) = {[1;2]}
  -> Path195 => Loc39  вер=1 порядок=5
       текст: Go to the bar
       условия: логика {[p10] in [3;5;6]}
       эффект: P21(Individuals you have info about) = {7-[p10]}

### Loc39 [обычная]
    выбор описания: {[p20]+1}
    Loc39-1: There was nothing special about the bar. You must have seen thousands of such bars. And only several individuals attracted your attention. For example, a noisy …
    Loc39-2: The bar is still as dull as ditch-water. The Maloq seems to be out of the drinking bout and is recollecting his feelings in his room. But there is <clr>the Pele…
    Loc39-3: The bar was nicely gloomy and silent. There is no noisy fan group here today but the other regulars, in particular, <clr>the Maloq<clrEnd> and <clr>the Peleng<c…
    Loc39-4: The bar is namely empty today. Neither the merry fan group, nor the wild Maloq drunkard can be seen anywhere. There is just <clr>the Peleng<clrEnd> who's never …
    Loc39-5: So here you are again in the bar. / <clr>The Maloq<clrEnd> you saw last night, is hanging himself on again like he was doing yesterday. No Peleng today but ther…
    Loc39-6: There is neither the unblessed Maloq, nor the Peleng dodger in the bar today. But <clr>the fans<clrEnd> are still making a racket for all absent once.
    Loc39-7: What a bore it is in the bar today! There is nobody here but for the ever drunken <clr>Maloq<clrEnd> at the table in the corner so you have practically nobody t…
    эффект: P21(Individuals you have info about) = {([p21]=3)*4+([p21]<>3)*[p21]}
  -> Path122 => Loc40  вер=1 проходов<=1 порядок=5
       текст: Talk to the Maloq
       эффект: P20(Individuals you talked to) +1
  -> Path124 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Approach the Peleng
       эффект: P20(Individuals you talked to) +4
  -> Path187 => Loc38  вер=1 порядок=5
       текст: Go out of the bar
  -> Path213 => Loc84  вер=1 проходов<=1 порядок=5
       текст: Come to the fans
       эффект: P20(Individuals you talked to) +2

### Loc40 [обычная] визитов<=1
    Loc40-1: When you approached the Maloq, he could hardly raise his head, gave you a cloudy look and murmured: / - So, what the hell do you want? Sit down. Tap it!
    эффект: P3(Are they going to provide you with the info?) = {[0..2]}
  -> Path139 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Try to get the Maloq away from the bar
       ответ: You tried to talk him into going to his room and sleep himself sober but suddenly the Maloq took his hair down and plugged you in the eye with all the fury. Now…
       условия: логика {[p3]>0}
  -> Path140 => Loc50  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy the Maloq a drink (<clr>50 cr<clrEnd>)
       условия: логика {[p22]>=50}
       эффект: P22(Money) = {[p22]-50}
  -> Path196 => Loc50  вер=1 проходов<=1 порядок=5
       текст: Try to get the Maloq away from the bar
       ответ: You tried to get the Maloq away from the bar, but that beef was immovable. Vice versa, the Maloq grasped your shirt and forced you to sit down to his table. He …
       условия: логика {[p3]=0}

### Loc41 [обычная] визитов<=4
    Loc41-1: You decided that boozing together is the best way to get acquainted, so you ordered a glass of your favourite belly-wash, approached the fans and toasted:
  -> Path125 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Let's drink to the victory of John "God" O'Damned, the greatest fighter at all times and among all nations!
  -> Path126 => Loc44  вер=1 проходов<=1 порядок=5
       текст: I'd like to drink to our common idol Zen Cha-Cha!
  -> Path127 => Loc45  вер=1 проходов<=1 порядок=5
       текст: I'm going to empty this glass to the victory of the strongest fighter. Of course, I mean the invincible Steel Silvester!
  -> Path128 => Loc46  вер=1 проходов<=1 порядок=5
       текст: As a ranger, I don't err on the site of modesty, so I propose to drink to the future champ, that is, to me, the great ranger <Ranger>!

### Loc42 [обычная] визитов<=1
    Loc42-1: The Peleng noticed you as well so when you approached him, he gave you a nasty grin and asked: / - As far as I know, you are famous <Ranger>, a ranger, aren't y…
    эффект: P3(Are they going to provide you with the info?) = {[0..2]}
  -> Path133 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Oh, no. If you want to earn some money, tell me what you know and then you can stake on me easily.
       ответ: - Well...I propose, you refuse. Though it's a pity, of course, it could have been a stunning bargain, - the Peleng answered and turned away showing that the con…
       условия: логика {[p3]>0}
  -> Path134 => Loc47  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: So speak. I'll give you <clr>50 cr<clrEnd>. You don't deserve more so far
       условия: логика {[p22]>=50}
       эффект: P22(Money) = {[p22]-50}
  -> Path197 => Loc47  вер=1 проходов<=1 порядок=5
       текст: Oh, no. If you want to earn some money, tell me what you know and then you can stake on me easily.
       ответ: The Peleng gave it a thought estimating different chances and possible gains. / - You are a hustler, aren't you?... A fly customer! - he stated after a long pau…
       условия: логика {[p3]=0}

### Loc43 [обычная] визитов<=1
    выбор описания: {1+(([p21]=1)*(1+([p9]=3 or [p9]=6)+(2*([p9]=4 or [p9]=5))))}
    Loc43-1: Judging from the fan's unutterable fury and their desire to clean your clock, it was obvious that you dished out something wrong. After you could hardly get out…
    Loc43-2: Gleeful hubbub of approving exclamations was the reaction to your speech. After the third glass you managed to turn the conversation to the necessary topic and …
    Loc43-3: The fans noised approvingly, raised their glasses and had nothing against having a drink and paling with you. During the conversation, you found out that <clr>J…
    Loc43-4: After your toast the fans emptied their glasses and you became one of them. Booze unlocked your new friends' tongues and you had no problems to get the low-down…
  -> Path129 => Loc3  вер=1 проходов<=1 порядок=5

### Loc44 [обычная] визитов<=1
    выбор описания: {1+(([p21]=2)*(1+([p9]=3 or [p9]=4)+(2*([p9]=2 or [p9]=6))))}
    Loc44-1: Judging from the fan's unutterable fury and their desire to clean your clock, it was obvious that you dished out something wrong. After you could hardly get out…
    Loc44-2: The fans noised approvingly, raised their glasses and had nothing against having a drink and paling with you. During the conversation, you found out that <clr>Z…
    Loc44-3: Gleeful hubbub of approving exclamations was the reaction to your speech. After the third glass you managed to turn the conversation to the necessary topic and …
    Loc44-4: After your toast the fans emptied their glasses and you became one of them. Booze unlocked your new friends' tongues and you had no problems to get the low-down…
  -> Path132 => Loc3  вер=1 проходов<=1 порядок=5

### Loc45 [обычная] визитов<=1
    выбор описания: {1+(([p21]=4)*(1+([p9]=5 or [p9]=6)+(2*([p9]=2 or [p9]=4))))}
    Loc45-1: Judging from the fan's unutterable fury and their desire to clean your clock, it was obvious that you dished out something wrong. After you could hardly get out…
    Loc45-2: After your toast the fans emptied their glasses and you became one of them. Booze unlocked your new friends' tongues and you had no problems to get the low-down…
    Loc45-3: Gleeful hubbub of approving exclamations was the reaction to your speech. After the third glass you managed to turn the conversation to the necessary topic and …
    Loc45-4: The fans noised approvingly, raised their glasses and had nothing against having a drink and paling with you. During the conversation, you found out that <clr>S…
  -> Path130 => Loc3  вер=1 проходов<=1 порядок=5

### Loc46 [обычная] визитов<=1
    Loc46-1: You stroke the fans dumb by your cheek and they didn't know what to answer. After the silence became somewhat evil, you considered it wise to whistle off from t…
  -> Path131 => Loc3  вер=1 проходов<=1 порядок=5

### Loc47 [обычная] визитов<=2
    выбор описания: {[p21]}
    Loc47-1: The Peleng ordered himself a drink, waited until they brought it and said: / - We-e-ll. As far as I can judge, you are not very generous. Perhaps, the informati…
    Loc47-2: The Peleng ordered himself a drink, waited until they brought it and said: / - We-e-ll. As far as I can judge, you are not very generous. Perhaps, the informati…
    Loc47-4: The Peleng ordered himself a drink, waited until they brought it and said: / - We-e-ll. As far as I can judge, you are not very generous. Perhaps, the informati…
  -> Path136 => Loc69  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Take your <clr>50 cr<clrEnd>, ramper
       условия: логика {[p22]>=50}
       эффект: P3(Are they going to provide you with the info?) = 1
       эффект: P22(Money) = {[p22]-50}
  -> Path137 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Look at this arrogant fool! You can earn a pot of dibs putting a stake on me!
       эффект: P3(Are they going to provide you with the info?) = {[0..1]}

### Loc50 [обычная] визитов<=2
    выбор описания: {[p21]}
    Loc50-1: - You seem to be an adequate lad in contrast to the Gaalian bugger, <clr>John "God" O'Damned<clrEnd>. This bastard managed to beat me! Can you imagine that? ME!…
    Loc50-2: - Hey, dude. So you don't think that an EX-champ is too miserable to drink with, do you? This skipjack <clr>Zen Cha-Cha<clrEnd> did it to me! It's still a secre…
    Loc50-4: - You're a tough lad, aren't you?. But <clr>Steel Silvester <clrEnd> will beat you anyway! He pulverised even me, THE WORLD CHAMP AMONG MALOQS! Pulverised compl…
  -> Path141 => Loc68  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Alright, let's have another round, and you'll tell me what made you come down to such a condition... (order drinks for <clr>50 cr<clrEnd>)
       условия: логика {[p22]>=50}
       эффект: P3(Are they going to provide you with the info?) = 1
       эффект: P22(Money) = {[p22]-50}
  -> Path143 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Tell me how he beat you, and, upon my faith, I'll take the change out of him!
       эффект: P3(Are they going to provide you with the info?) = {[0..1]}

### Loc53 [обычная] визитов<=3
    выбор описания: {[p8]}
    Loc53-1: The first thing you did in the boxes was to acquaint yourself with the possible upgrade list. There were only three upgrading items for your model in the list. …
    Loc53-2: The first thing you did in the boxes was refreshing your memory about the possible upgrade list. There were only three upgrading items for your model in the lis…
    Loc53-3: The first thing you did in the boxes was refreshing your memory about the possible upgrade list. There were only three upgrading items for your model in the lis…
  -> Path146 => Loc38  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Install the laser intensifier.
       условия: логика {[p22]>=150}
       эффект: P4(Blaster) = 1
       эффект: P22(Money) -150
  -> Path147 => Loc38  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Install the upgraded rocket navigator
       условия: логика {[p22]>=200}
       эффект: P5(Rocket launcher) = 1
       эффект: P22(Money) -200
  -> Path148 => Loc38  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Install the heading on the torpedo tube
       условия: логика {[p22]>=100}
       эффект: P6(Torpedo tube) = 1
       эффект: P22(Money) -100
       скрыт: P10
  -> Path149 => Loc38  вер=1 порядок=5
       текст: No, thank you, I don't need anything
       эффект: P7(After the visit to the boxes) = 0

### Loc54 [пустая]
  -> Path153 => Loc55  вер=1 порядок=5
       текст: Blaster fire
       условия: логика {[p11]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P11(Blaster charges) = {[p11]-1}
  -> Path154 => Loc56  вер=1 порядок=5
       текст: Rocket volley
       условия: логика {[p12]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P12(Rockets) = {[p12]-1}
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path155 => Loc57  вер=6 порядок=5
       текст: Shoot a torpedo
       условия: логика {[p13]>0 and ([p14]>0 or [p15]>0 or [p16]>0)}
       эффект: P13(Torpedoes) = {[p13]-1}
  -> Path180 => Loc12  вер=1 проходов<=1 порядок=5
       текст: I give up!
       условия: логика {[p2]>0}
       эффект: P22(Money) = {[p22]-([p24]/2)}
  -> Path243 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Come on
       условия: логика {[p14]=0 and [p15]=0 and [p16]=0}

### Loc55 [пустая]
  -> Path156 => Loc81  вер=4 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-([32..40])}
       эффект: P19(Path number) = 2
  -> Path157 => Loc81  вер=2 [всегда видна] порядок=5
       эффект: P19(Path number) = 0
  -> Path158 => Loc81  вер=3 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-[32..40]}
       эффект: P19(Path number) = 1

### Loc56 [пустая]
  -> Path159 => Loc82  вер=2 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-15*[p17]}
       эффект: P19(Path number) = 0
  -> Path160 => Loc82  вер=4 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-18*[p17]}
       эффект: P19(Path number) = 2
  -> Path161 => Loc82  вер=3 [всегда видна] порядок=5
       эффект: P19(Path number) = 1

### Loc57 [пустая]
  -> Path162 => Loc83  вер=3 порядок=5
       эффект: P2(Enemy's life) = {[p2]-[35..50]}
       эффект: P19(Path number) = 1
  -> Path163 => Loc83  вер=2 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-[30..45]}
       эффект: P19(Path number) = 0
  -> Path164 => Loc83  вер=4 [всегда видна] порядок=5
       эффект: P2(Enemy's life) = {[p2]-[10..15]}
       эффект: P19(Path number) = 2

### Loc58 [пустая]
    выбор описания: {[p2]>0}
  -> Path165 => Loc59  вер=1 порядок=5
       текст: Activate the power shield
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path169 => Loc60  вер=1 порядок=5
       текст: Manoeuvre to escape rockets
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
  -> Path170 => Loc61  вер=1 порядок=5
       текст: Activate the noise generator
       условия: логика {[p2]>0 and ([p11]>0 or [p12]>0 or [p13]>0)}
       эффект: P17(Rocket hits) = {2+([0..1]=0)}
  -> Path181 => Loc12  вер=1 проходов<=1 порядок=5
       текст: I give up!
       условия: логика {[p2]>0}
       эффект: P22(Money) = {[p22]-([p24]/2)}
  -> Path238 => Loc96  вер=1 проходов<=1 порядок=5
       текст: Come on
       условия: логика {[p11]=0 and [p12]=0 and [p13]=0}

### Loc59 [пустая]
  -> Path166 => Loc93  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[30..45]-[p10]*5} «A dreadful torpedo shook your machine. The explosion flash w…»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2
  -> Path167 => Loc93  вер=1 [всегда видна] порядок=5
       условия: логика {[p14]>0}
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path168 => Loc93  вер=1 [всегда видна] порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-[p17]*(15+[p10]*2)} «Your mom told you to avoid activating the power shield when …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1

### Loc60 [пустая]
  -> Path171 => Loc94  вер=1 [всегда видна] порядок=5
       условия: логика {[p15]>0}
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path172 => Loc94  вер=1 порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[32..40]-[p10]*5}
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path173 => Loc94  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[35..50]-[p10]*5} «Your machine that had just finished manoeuvring was knocked …»
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc61 [пустая]
  -> Path174 => Loc95  вер=1 порядок=5
       условия: логика {[p15]>0}
       эффект: P1(Player's life) = {[p1]-[p17]*(18+[p10]*2)} «You saw the approaching rockets but it was too late to duck …»
       эффект: P15(Enemy's rockets) = {[p15]-1}
       эффект: P19(Path number) = 1
  -> Path175 => Loc95  вер=1 [всегда видна] порядок=5
       условия: логика {[p14]>0}
       эффект: P1(Player's life) = {[p1]-[32..40]-[p10]*5} «The enemy managed to outplay you. After you activated the no…»
       эффект: P14(Enemy's blaster charges) = {[p14]-1}
       эффект: P19(Path number) = 0
  -> Path176 => Loc95  вер=1 [всегда видна] порядок=5
       условия: логика {[p16]>0}
       эффект: P1(Player's life) = {[p1]-[10..15]-[p10]*3}
       эффект: P16(Enemy's torpedoes) = {[p16]-1}
       эффект: P19(Path number) = 2

### Loc62 [обычная]
    выбор описания: {([p2]=0)+1}
    Loc62-1: The enemy is biting the dust at last! After the honour round in front of the elated stands, you went to the boxes. /  / So, what do you feel like? Shall we go o…
    Loc62-2: The enemy blew off all his ammunition so they announced your victory due to ammunition superiority. After the honour round in front of the elated stands, you ca…
  -> Path49 => Loc54  вер=1 порядок=5
       текст: Money is never redundant. I'm ready for the fight
       ответ: After a short break during which the playground was put in order and the spectators staked again, you took your place of a pilot in the new combat machine and p…
       эффект: P1(Player's life) = 150 [показ]
       эффект: P2(Enemy's life) = {150+[p10]*20} [показ]
       эффект: P11(Blaster charges) = 5 [показ]
       эффект: P12(Rockets) = 5 [показ]
       эффект: P13(Torpedoes) = 5 [показ]
       эффект: P14(Enemy's blaster charges) = 5
       эффект: P15(Enemy's rockets) = 5
       эффект: P16(Enemy's torpedoes) = 5
       эффект: P23(Stake) = {[p23]*2}
  -> Path177 => Loc58  вер=1 порядок=5
       текст: Money is never redundant. I'm ready for the fight
       ответ: After a short break during which the playground was put in order and the spectators staked again, you took your place of a pilot in the new combat machine and p…
       эффект: P1(Player's life) = {150} [показ]
       эффект: P2(Enemy's life) = {150+[p10]*20} [показ]
       эффект: P11(Blaster charges) = 5 [показ]
       эффект: P12(Rockets) = 5 [показ]
       эффект: P13(Torpedoes) = 5 [показ]
       эффект: P14(Enemy's blaster charges) = 5
       эффект: P15(Enemy's rockets) = 5
       эффект: P16(Enemy's torpedoes) = 5
       эффект: P23(Stake) = {[p23]*2}
  -> Path179 => Loc12  вер=1 проходов<=1 порядок=5
       текст: No, thank you, I've already got my share of fighting. And I've had my fill of it too!

### Loc63 [обычная] визитов<=1
    Loc63-1: You took a separate room in the bar, the Peleng ordered dinner for two of you and continued. /  / - Backstreet fights are a little bit different from official o…
    эффект: P10(Fights given) = 0
  -> Path184 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Money is never redundant. I'm ready for the fight
       ответ: The Peleng let no grass grow under his feet and took you to the boxes where you received a new combat robot. After you checked it, you were ready. The box gates…
       эффект: P1(Player's life) = 150 [показ]
       эффект: P2(Enemy's life) = {150+[p10]*20} [показ]
       эффект: P10(Fights given) = 0 [показ]
       эффект: P11(Blaster charges) = 5 [показ]
       эффект: P12(Rockets) = 5 [показ]
       эффект: P13(Torpedoes) = 5 [показ]
       эффект: P14(Enemy's blaster charges) = 5
       эффект: P15(Enemy's rockets) = 5
       эффект: P16(Enemy's torpedoes) = 5
       эффект: P23(Stake) = {250}
  -> Path185 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Money is never redundant. I'm ready for the fight
       ответ: The Peleng let no grass grow under his feet and took you to the boxes where you received a new combat robot. After you checked it, you were ready. The box gates…
       эффект: P1(Player's life) = {150} [показ]
       эффект: P2(Enemy's life) = {150+[p10]*20} [показ]
       эффект: P10(Fights given) = 0 [показ]
       эффект: P11(Blaster charges) = 5 [показ]
       эффект: P12(Rockets) = 5 [показ]
       эффект: P13(Torpedoes) = 5 [показ]
       эффект: P14(Enemy's blaster charges) = 5
       эффект: P15(Enemy's rockets) = 5
       эффект: P16(Enemy's torpedoes) = 5
       эффект: P23(Stake) = {250}
  -> Path186 => Loc12  вер=1 проходов<=1 порядок=5
       текст: No, thank you, I've already got my share of fighting. And I've had my fill of it too!

### Loc64 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc64-1: The enemy activated the shield and the blaster did no harm to him.
    Loc64-2: What a reaction! How did he manage to activate the shield?
    Loc64-3: Humph... Bad luck! The enemy nicked your intentions and activated the shield.
    Loc64-4: Noises can protect from torpedoes, of course, but the blaster is dreadful too and your enemy should keep it in mind.
    Loc64-5: As skilful as you might be in zigzagging, nobody has escaped the blaster yet with the help of an antirocket manoeuvre!
    Loc64-6: The blaster's powerful hit didn't allow the enemy to finish his antirocket manoeuvre.
    Loc64-7: The enemy tried the antirocket manoeuvre but your blaster was faster.
    Loc64-8: The enemy activated the noise generator but it didn't help him to escape the blaster.
    Loc64-9: What a mercy! Despite the active noise generator your blaster caused serious damage to the enemy.
  -> Path199 => Loc23  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path230 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc68 [пустая] визитов<=4
  -> Path144 => Loc3  вер=1 проходов<=1 порядок=5
       ответ: Suddenly the Maloq kicked at me: / - Suddenly the Maloq boiled over me. Who the hell are you? You are not a shoulder to cry on!? Beat it or I'll stand up. And i…
       условия: логика {[p3]=0}
  -> Path255 => Loc103  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=1}
  -> Path256 => Loc98  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=2}
  -> Path257 => Loc99  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=4}

### Loc69 [пустая] визитов<=4
    выбор описания: {1+[p3]*[p21]}
  -> Path258 => Loc100  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=1}
  -> Path259 => Loc101  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=2}
  -> Path260 => Loc102  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]=1 and [p21]=4}
  -> Path261 => Loc3  вер=1 проходов<=1 порядок=5
       ответ: - We propose, you refuse. But I'm afraid nobody will moan on your grave, silly boy... - the irritated Peleng stood up and quickly left the bar. You had nothing …
       условия: логика {[p3]=0}

### Loc70 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc70-1: The enemy activated the power field but it didn't help much to absorb the shock. The rocket hit counter showed [p17].
    Loc70-2: The enemy's nerves snapped at last and he decided to activate the power shield. And all for nothing! The rocket hit counter showed [p17].
    Loc70-3: The protection field flashed in front of the enemy's robot. The enemy saw his mistake and tried to make a hairpin curve but it was too late. The rockets went ho…
    Loc70-4: The enemy's antirocket manoeuvre was well-done. Alas, all your rockets missed.
    Loc70-5: The stands applauded to the echo cheering the enemy's next well-done antirocket manoeuvre.
    Loc70-6: As usual, the enemy ducked all the rockets in a breeze.
    Loc70-7: The noise generator has never protected anybody from a rocket volley. The rocket hit counter showed [p17].
    Loc70-8: Just one second before the explosion, you saw the distorted features of your opponent on the monitor - this was the last video signal that came from his robot. …
    Loc70-9: Your enemy's intuition failed this time. He activated the noise generator instead of manoeuvring, and the rockets hit the target, which was almost stationary. T…
  -> Path64 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}
  -> Path188 => Loc23  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}

### Loc71 [обычная]
    выбор описания: {[p19]}
    Loc71-1: The power shield turned out to be vulnerable to the torpedo.
    Loc71-2: The torpedo ignored the enemy's poor attempts to activate the power shield.
    Loc71-3: A power shield against a torpedo? It's nonsense!
    Loc71-4: Even an antirocket manoeuvre didn't make the torpedo wander from the target.
    Loc71-5: It's hard to duck a torpedo. Almost impossible. Your enemy didn't manage it either.
    Loc71-6: Though the enemy's antirocket manoeuvre was perfect, the torpedo hit him any way.
    Loc71-7: The noise generator made the torpedo wander from the target but several fragments still shaved the enemy's robot.
    Loc71-8: Damn it! The enemy was quick enough to activate the noise generator. The torpedo exploded within several meters from the target. But the explosion shook up the …
    Loc71-9: The torpedo almost hit the enemy but the noise generator did its black deed. Well, at least the shock wave warped the enemy's machine though not too much.
    Loc71-10: The antirocket manoeuvre was so well-done that the torpedo missed. There were just several fragments that reached the enemy.
  -> Path200 => Loc23  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path229 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc72 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc72-1: The power shield made a good defence against the blaster.
    Loc72-2: The flash of the blaster's beam reached the power field and made you squint. But on the other hand, the field swallowed all its power and the machine was not da…
    Loc72-3: You managed to be one jump ahead of the enemy's blaster shot. The attack is repelled successfully!
    Loc72-4: The power shield provides poor protection from rockets. The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned…
    Loc72-5: Your mom told you to avoid activating the power shield when the rockets are approaching, didn't she? So, she was absolutely right! The self-diagnostic system im…
    Loc72-6: The enemy's rockets rushed to your machine leaving a smoky trace behind them. Why the hell did you activate the power shield?! The self-diagnostic system immedi…
    Loc72-7: The power shield is no obstacle for torpedoes.
    Loc72-8: The torpedo went through the power shield as if there was nothing at all on its way. High-powered explosion shook your combat machine.
    Loc72-9: The machine vibrated at the torpedo's terrible hit. Activating the power shield seemed to be a bad idea.
  -> Path201 => Loc22  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc73 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc73-1: Such a manoeuvre won't help you to escape the blaster.
    Loc73-2: While giving your joystick a wrench and trying to veer, you felt how quickly your robot's jacketing became hot. It looked like the blaster got you.
    Loc73-3: The blaster shot outran your ill-timed manoeuvre.
    Loc73-4: That was a perfect manoeuvre. All the enemy's rockets missed.
    Loc73-5: You ducked all the rockets manoeuvring elegantly and got a great tornado of applause on the stands.
    Loc73-6: Rockets are dreadful, of course but it won't be a big problem to duck them for an experienced ranger.
    Loc73-7: Your manoeuvre didn't misguide the torpedo's homing system.
    Loc73-8: Alas, the configuration of the torpedo's homing system won't let you escape it just manoeuvring.
    Loc73-9: Your machine that had just finished manoeuvring was nearly knocked over by the torpedo's high-powered hit.
  -> Path203 => Loc22  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc74 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc74-1: The generator didn't protect you from the blaster.
    Loc74-2: Damn it, the enemy managed to outplay you. After you activated the noise generator, he remained cool and hit you with a blaster.
    Loc74-3: Trying to misguide the enemy blaster beam with the help of the noise generator is rather insane!
    Loc74-4: The generator is no protection against rockets.  The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned out to…
    Loc74-5: Don't trust the noise generator if enemy rockets are flying in your direction. The self-diagnostic system immediately defined the number of rockets that hit you…
    Loc74-6: You saw the approaching rockets but it was too late to duck them. The self-diagnostic system immediately defined the number of rockets that hit your machine. Th…
    Loc74-7: The torpedo exploded nearby, so only several fragments reached the machine.
    Loc74-8: The noise generator did its work perfectly and the torpedo turned up the soil of the playground aside of you. However, the explosion still shook you up a little…
    Loc74-9: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
  -> Path202 => Loc22  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc75 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc75-1: The enemy activated the shield and the blaster did no harm to him.
    Loc75-2: What a reaction! How did he manage to activate the shield?
    Loc75-3: Humph... Bad luck! The enemy nicked your intentions and activated the shield.
    Loc75-4: The enemy activated the noise generator but it didn't help him to escape the blaster.
    Loc75-5: As skilful as you might be in zigzagging, nobody has escaped the blaster yet with the help of an antirocket manoeuvre!
    Loc75-6: The blaster's powerful hit didn't allow the enemy to finish his antirocket manoeuvre.
    Loc75-7: The enemy activated the noise generator but it didn't help him to escape the blaster.
    Loc75-8: Noises can protect from torpedoes, of course, but the blaster is dreadful too and your enemy should keep it in mind.
    Loc75-9: What a mercy! Despite the active noise generator your blaster caused serious damage to the enemy.
  -> Path204 => Loc33  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path232 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc76 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc76-1: The enemy activated the power field but it didn't help much to absorb the shock. The rocket hit counter showed [p17].
    Loc76-2: The enemy's nerves snapped at last and he decided to activate the power shield. And all for nothing! The rocket hit counter showed [p17].
    Loc76-3: The protection field flashed in front of the enemy's robot. The enemy saw his mistake and tried to make a hairpin curve but it was too late. The rockets went ho…
    Loc76-4: The enemy's antirocket manoeuvre was well-done. Alas, all your rockets missed.
    Loc76-5: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
    Loc76-6: It seemed that the enemy tarried before manoeuvring but in the last moment he managed to duck the rockets, which flew by within a few centimetres from the body.
    Loc76-7: The noise generator has never protected anybody from a rocket volley. The rocket hit counter showed [p17].
    Loc76-8: Just one second before the explosion, you saw the distorted features of your opponent on the monitor - this was the last video signal that came from his robot. …
    Loc76-9: Your enemy's intuition failed this time. He activated the noise generator instead of manoeuvring, and the rockets hit the target, which was almost stationary. T…
  -> Path205 => Loc33  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path231 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc77 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc77-1: The power shield turned out to be vulnerable to the torpedo.
    Loc77-2: The torpedo ignored the enemy's poor attempts to activate the power shield.
    Loc77-3: A power shield against a torpedo? It's nonsense!
    Loc77-4: Even an antirocket manoeuvre didn't make the torpedo wander from the target.
    Loc77-5: It's hard to duck a torpedo. Almost impossible. Your enemy didn't manage it either.
    Loc77-6: Though the enemy's antirocket manoeuvre was perfect, the torpedo hit him any way.
    Loc77-7: The noise generator made the torpedo wander from the target but several fragments still shaved the enemy's robot.
    Loc77-8: Damn it! The enemy was quick enough to activate the noise generator. The torpedo exploded within several meters from the target. But the explosion shook up the …
    Loc77-9: The torpedo almost hit the enemy but the noise generator did its black deed. Well, at least the shock wave warped the enemy's machine though not too much.
  -> Path94 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}
  -> Path206 => Loc33  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}

### Loc78 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc78-1: The enemy activated the shield and the blaster did no harm to him.
    Loc78-2: What a reaction! How did he manage to activate the shield?
    Loc78-3: Humph... Bad luck! The enemy nicked your intentions and activated the shield.
    Loc78-4: The enemy tried the antirocket manoeuvre but your blaster was faster.
    Loc78-5: As skilful as you might be in zigzagging, nobody has escaped the blaster yet with the help of an antirocket manoeuvre!
    Loc78-6: The blaster's powerful hit didn't allow the enemy to finish his antirocket manoeuvre.
    Loc78-7: The enemy activated the noise generator but it didn't help him to escape the blaster.
    Loc78-8: Noises can protect from torpedoes, of course, but the blaster is dreadful too and your enemy should keep it in mind.
    Loc78-9: What a mercy! Despite the active noise generator your blaster caused serious damage to the enemy.
  -> Path207 => Loc10  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path228 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc79 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc79-1: The enemy activated the power field but it didn't help much to absorb the shock. The rocket hit counter showed [p17].
    Loc79-2: The enemy's nerves snapped at last and he decided to activate the power shield. And all for nothing! The rocket hit counter showed [p17].
    Loc79-3: The protection field flashed in front of the enemy's robot. The enemy saw his mistake and tried to make a hairpin curve but it was too late. The rockets went ho…
    Loc79-4: The enemy's antirocket manoeuvre was well-done. Alas, all your rockets missed.
    Loc79-5: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
    Loc79-6: It seemed that the enemy tarried before manoeuvring but in the last moment he managed to duck the rockets, which flew by within a few centimetres from the body.
    Loc79-7: The noise generator has never protected anybody from a rocket volley. The rocket hit counter showed [p17].
    Loc79-8: Just one second before the explosion, you saw the distorted features of your opponent on the monitor - this was the last video signal that came from his robot. …
    Loc79-9: Your enemy's intuition failed this time. He activated the noise generator instead of manoeuvring, and the rockets hit the target, which was almost stationary. T…
  -> Path208 => Loc10  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path227 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}

### Loc80 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc80-1: The power shield turned out to be vulnerable to the torpedo.
    Loc80-2: The torpedo ignored the enemy's poor attempts to activate the power shield.
    Loc80-3: A power shield against a torpedo? It's nonsense!
    Loc80-4: Even an antirocket manoeuvre didn't make the torpedo wander from the target.
    Loc80-5: It's hard to duck a torpedo. Almost impossible. Your enemy didn't manage it either.
    Loc80-6: Though the enemy's antirocket manoeuvre was perfect, the torpedo hit him any way.
    Loc80-7: The noise generator made the torpedo wander from the target but several fragments still shaved the enemy's robot.
    Loc80-8: Damn it! The enemy was quick enough to activate the noise generator. The torpedo exploded within several meters from the target. But the explosion shook up the …
    Loc80-9: The torpedo almost hit the enemy but the noise generator did its black deed. Well, at least the shock wave warped the enemy's machine though not too much.
  -> Path47 => Loc11  вер=1 проходов<=1 порядок=5
       текст: The enemy is biting the dust at last! After the honour round in front of the elated stand, go to the boxes.
       условия: логика {[p2]=0}
  -> Path209 => Loc10  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}

### Loc81 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc81-1: The enemy activated the shield and the blaster did no harm to him.
    Loc81-2: What a reaction! How did he manage to activate the shield?
    Loc81-3: Humph... Bad luck! The enemy nicked your intentions and activated the shield.
    Loc81-4: The enemy tried the antirocket manoeuvre but your blaster was faster.
    Loc81-5: As skilful as you might be in zigzagging, nobody has escaped the blaster yet with the help of an antirocket manoeuvre!
    Loc81-6: The blaster's powerful hit didn't allow the enemy to finish his antirocket manoeuvre.
    Loc81-7: The enemy activated the noise generator but it didn't help him to escape the blaster.
    Loc81-8: Noises can protect from torpedoes, of course, but the blaster is dreadful too and your enemy should keep it in mind.
    Loc81-9: What a mercy! Despite the active noise generator your blaster caused serious damage to the enemy.
  -> Path210 => Loc58  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path234 => Loc62  вер=1 порядок=5
       условия: логика {[p2]=0}
       эффект: P10(Fights given) +1
       эффект: P22(Money) = {[p22]+[p23]}
       эффект: P24(Money received) = {[p24]+[p23]}
       скрыт: P1,P2,P11,P12,P13

### Loc82 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc82-1: The enemy activated the power field but it didn't help much to absorb the shock. The rocket hit counter showed [p17].
    Loc82-2: The enemy's nerves snapped at last and he decided to activate the power shield. And all for nothing! The rocket hit counter showed [p17].
    Loc82-3: The protection field flashed in front of the enemy's robot. The enemy saw his mistake and tried to make a hairpin curve but it was too late. The rockets went ho…
    Loc82-4: The enemy's antirocket manoeuvre was well-done. Alas, all your rockets missed.
    Loc82-5: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
    Loc82-6: It seemed that the enemy tarried before manoeuvring but in the last moment he managed to duck the rockets, which flew by within a few centimetres from the body.
    Loc82-7: The noise generator has never protected anybody from a rocket volley. The rocket hit counter showed [p17].
    Loc82-8: Just one second before the explosion, you saw the distorted features of your opponent on the monitor - this was the last video signal that came from his robot. …
    Loc82-9: Your enemy's intuition failed this time. He activated the noise generator instead of manoeuvring, and the rockets hit the target, which was almost stationary. T…
  -> Path211 => Loc58  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}
  -> Path233 => Loc62  вер=1 порядок=5
       условия: логика {[p2]=0}
       эффект: P10(Fights given) +1
       эффект: P22(Money) = {[p22]+[p23]}
       эффект: P24(Money received) = {[p24]+[p23]}
       скрыт: P1,P2,P11,P12,P13

### Loc83 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc83-1: The power shield turned out to be vulnerable to the torpedo.
    Loc83-2: The torpedo ignored the enemy's poor attempts to activate the power shield.
    Loc83-3: A power shield against a torpedo? It's nonsense!
    Loc83-4: Even an antirocket manoeuvre didn't make the torpedo wander from the target.
    Loc83-5: It's hard to duck a torpedo. Almost impossible. Your enemy didn't manage it either.
    Loc83-6: Though the enemy's antirocket manoeuvre was perfect, the torpedo hit him any way.
    Loc83-7: The noise generator made the torpedo wander from the target but several fragments still shaved the enemy's robot.
    Loc83-8: Damn it! The enemy was quick enough to activate the noise generator. The torpedo exploded within several meters from the target. But the explosion shook up the …
    Loc83-9: The torpedo almost hit the enemy but the noise generator did its black deed. Well, at least the shock wave warped the enemy's machine though not too much.
  -> Path182 => Loc62  вер=1 порядок=5
       условия: логика {[p2]=0}
       эффект: P10(Fights given) +1
       эффект: P22(Money) = {[p22]+[p23]}
       эффект: P24(Money received) = {[p24]+[p23]}
       скрыт: P1,P2,P11,P12,P13
  -> Path212 => Loc58  вер=1 порядок=5
       ответ: You need to do something for protection now.
       условия: логика {[p2]>0}

### Loc84 [обычная] визитов<=1
    Loc84-1: Looking at the merry Faeyan company, you still couldn't figure out whose fans they were. Of course, you could try and join the conversation at a venture; if you…
  -> Path123 => Loc41  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Try to get closer with the fan group
  -> Path214 => Loc85  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Insert <clr>50 cr<clrEnd> in the slot and listen to the conversation
       условия: логика {[p22]>=50}
       эффект: P22(Money) = {[p22]-50}

### Loc85 [обычная] визитов<=1
    выбор описания: {[p21]}
    Loc85-1: While you were gambling, they broadcast the interview with <clr>Zen Cha-Cha<clrEnd> on the bar stereovision. When the fans saw his face on the screen, they burs…
    Loc85-2: Hardly two minutes passed before one of the fans too excited due to all the booze inside of him, jumped onto the table and started yelling insulting words addre…
    Loc85-4: You gave an ear to what they were talking about and heard two fans' conversation about the yesterday's fight with <clr>John "God" O'Damned<clrEnd>'s fan group. …
  -> Path215 => Loc41  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Try to get closer with the fan group
  -> Path217 => Loc86  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Go on gambling and insert <clr>50 more cr<clrEnd>
       условия: логика {[p22]>=50}
       эффект: P22(Money) = {[p22]-50}

### Loc86 [обычная] визитов<=1
    выбор описания: {[p21]}
    Loc86-1: Soon there appeared one more fan group at the bar entrance yelling and praising <clr>Steel Silvester<clrEnd>'s valour. Your fan group roared in fury and flew at…
    Loc86-2: While you were torturing the slot-machine, two huge and uncommonly bosky thugs latched to the Gaalian passing by to the bar, and didn't let him go until he roar…
    Loc86-4: Once again you gave your ear to the conversation and heard a fan asking his buddy: "Why are you silent, <clr>CHA-CHAffy<clrEnd> thoughts"?. And the latter answe…
  -> Path216 => Loc41  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Try to get closer with the fan group

### Loc87 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc87-1: The power shield made a good defence against the blaster.
    Loc87-2: The flash of the blaster's beam reached the power field and made you squint. But on the other hand, the field swallowed all its power and the machine was not da…
    Loc87-3: You managed to be one jump ahead of the enemy's blaster shot. The attack is repelled successfully!
    Loc87-4: The power shield provides poor protection from rockets. The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned…
    Loc87-5: Your mom told you to avoid activating the power shield when the rockets are approaching, didn't she? So, she was absolutely right! The self-diagnostic system im…
    Loc87-6: The enemy's rockets rushed to your machine leaving a smoky trace behind them. Why the hell did you activate the power shield?! The self-diagnostic system immedi…
    Loc87-7: The power shield is no obstacle for torpedoes.
    Loc87-8: The torpedo went through the power shield as if there was nothing at all on its way. High-powered explosion shook your combat machine.
    Loc87-9: The machine vibrated at the torpedo's terrible hit. Activating the power shield seemed to be a bad idea.
  -> Path218 => Loc9  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc88 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc88-1: Such a manoeuvre won't help you to escape the blaster.
    Loc88-2: While giving your joystick a wrench and trying to veer, you felt how quickly your robot's jacketing became hot. It looked like the blaster got you.
    Loc88-3: The blaster shot outran your ill-timed manoeuvre.
    Loc88-4: That was a perfect manoeuvre. All the enemy's rockets missed.
    Loc88-5: You ducked all the rockets manoeuvring elegantly and got a great tornado of applause on the stands.
    Loc88-6: Rockets are dreadful, of course but it won't be a big problem to duck them for an experienced ranger.
    Loc88-7: Your manoeuvre didn't misguide the torpedo's homing system.
    Loc88-8: Alas, the configuration of the torpedo's homing system won't let you escape it just manoeuvring.
    Loc88-9: Your machine that had just finished manoeuvring was nearly knocked over by the torpedo's high-powered hit.
  -> Path219 => Loc9  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc89 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc89-1: The generator didn't protect you from the blaster.
    Loc89-2: Damn it, the enemy managed to outplay you. After you activated the noise generator, he remained cool and hit you with a blaster.
    Loc89-3: Trying to misguide the enemy blaster beam with the help of the noise generator is rather insane!
    Loc89-4: The generator is no protection against rockets.  The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned out to…
    Loc89-5: Don't trust the noise generator if enemy rockets are flying in your direction. The self-diagnostic system immediately defined the number of rockets that hit you…
    Loc89-6: You saw the approaching rockets but it was too late to duck them. The self-diagnostic system immediately defined the number of rockets that hit your machine. Th…
    Loc89-7: The torpedo exploded nearby, so only several fragments reached the machine.
    Loc89-8: The noise generator did its work perfectly and the torpedo turned up the soil of the playground aside of you. However, the explosion still shook you up a little…
    Loc89-9: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
  -> Path220 => Loc9  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc90 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc90-1: The power shield made a good defence against the blaster.
    Loc90-2: The flash of the blaster's beam reached the power field and made you squint. But on the other hand, the field swallowed all its power and the machine was not da…
    Loc90-3: You managed to be one jump ahead of the enemy's blaster shot. The attack is repelled successfully!
    Loc90-4: The power shield provides poor protection from rockets. The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned…
    Loc90-5: Your mom told you to avoid activating the power shield when the rockets are approaching, didn't she? So, she was absolutely right! The self-diagnostic system im…
    Loc90-6: The enemy's rockets rushed to your machine leaving a smoky trace behind them. Why the hell did you activate the power shield?! The self-diagnostic system immedi…
    Loc90-7: The power shield is no obstacle for torpedoes.
    Loc90-8: The torpedo went through the power shield as if there was nothing at all on its way. High-powered explosion shook your combat machine.
    Loc90-9: The machine vibrated at the torpedo's terrible hit. Activating the power shield seemed to be a bad idea.
  -> Path221 => Loc34  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc91 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc91-1: Such a manoeuvre won't help you to escape the blaster.
    Loc91-2: While giving your joystick a wrench and trying to veer, you felt how quickly your robot's jacketing became hot. It looked like the blaster got you.
    Loc91-3: The blaster shot outran your ill-timed manoeuvre.
    Loc91-4: That was a perfect manoeuvre. All the enemy's rockets missed.
    Loc91-5: You ducked all the rockets manoeuvring elegantly and got a great tornado of applause on the stands.
    Loc91-6: Rockets are dreadful, of course but it won't be a big problem to duck them for an experienced ranger.
    Loc91-7: Your manoeuvre didn't misguide the torpedo's homing system.
    Loc91-8: Alas, the configuration of the torpedo's homing system won't let you escape it just manoeuvring.
    Loc91-9: Your machine that had just finished manoeuvring was nearly knocked over by the torpedo's high-powered hit.
  -> Path222 => Loc34  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc92 [обычная]
    выбор описания: {[p19]}
    Loc92-1: The generator didn't protect you from the blaster.
    Loc92-2: Damn it, the enemy managed to outplay you. After you activated the noise generator, he remained cool and hit you with a blaster.
    Loc92-3: Trying to misguide the enemy blaster beam with the help of the noise generator is rather insane!
    Loc92-4: The generator is no protection against rockets.  The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned out to…
    Loc92-5: Don't trust the noise generator if enemy rockets are flying in your direction. The self-diagnostic system immediately defined the number of rockets that hit you…
    Loc92-6: You saw the approaching rockets but it was too late to duck them. The self-diagnostic system immediately defined the number of rockets that hit your machine. Th…
    Loc92-7: The torpedo exploded nearby, so only several fragments reached the machine.
    Loc92-8: The noise generator did its work perfectly and the torpedo turned up the soil of the playground aside of you. However, the explosion still shook you up a little…
    Loc92-9: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
    Loc92-10: Despite the noise generator, the torpedo went home.
  -> Path223 => Loc34  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc93 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc93-1: The power shield made a good defence against the blaster.
    Loc93-2: The flash of the blaster's beam reached the power field and made you squint. But on the other hand, the field swallowed all its power and the machine was not da…
    Loc93-3: You managed to be one jump ahead of the enemy's blaster shot. The attack is repelled successfully!
    Loc93-4: The power shield provides poor protection from rockets. The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned…
    Loc93-5: Your mom told you to avoid activating the power shield when the rockets are approaching, didn't she? So, she was absolutely right! The self-diagnostic system im…
    Loc93-6: The enemy's rockets rushed to your machine leaving a smoky trace behind them. Why the hell did you activate the power shield?! The self-diagnostic system immedi…
    Loc93-7: The power shield is no obstacle for torpedoes.
    Loc93-8: The torpedo went through the power shield as if there was nothing at all on its way. High-powered explosion shook your combat machine.
    Loc93-9: The machine vibrated at the torpedo's terrible hit. Activating the power shield seemed to be a bad idea.
  -> Path224 => Loc54  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc94 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc94-1: Such a manoeuvre won't help you to escape the blaster.
    Loc94-2: While giving your joystick a wrench and trying to veer, you felt how quickly your robot's jacketing became hot. It looked like the blaster got you.
    Loc94-3: The blaster shot outran your ill-timed manoeuvre.
    Loc94-4: That was a perfect manoeuvre. All the enemy's rockets missed.
    Loc94-5: You ducked all the rockets manoeuvring elegantly and got a great tornado of applause on the stands.
    Loc94-6: Rockets are dreadful, of course but it won't be a big problem to duck them for an experienced ranger.
    Loc94-7: Your manoeuvre didn't misguide the torpedo's homing system.
    Loc94-8: Alas, the configuration of the torpedo's homing system won't let you escape it just manoeuvring.
    Loc94-9: Your machine that had just finished manoeuvring was nearly knocked over by the torpedo's high-powered hit.
  -> Path225 => Loc54  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc95 [обычная]
    выбор описания: {[1..3]+[p19]*3}
    Loc95-1: The generator didn't protect you from the blaster.
    Loc95-2: Damn it, the enemy managed to outplay you. After you activated the noise generator, he remained cool and hit you with a blaster.
    Loc95-3: Trying to misguide the enemy blaster beam with the help of the noise generator is rather insane!
    Loc95-4: The generator is no protection against rockets.  The self-diagnostic system immediately defined the number of rockets that hit your machine. There turned out to…
    Loc95-5: Don't trust the noise generator if enemy rockets are flying in your direction. The self-diagnostic system immediately defined the number of rockets that hit you…
    Loc95-6: You saw the approaching rockets but it was too late to duck them. The self-diagnostic system immediately defined the number of rockets that hit your machine. Th…
    Loc95-7: The torpedo exploded nearby, so only several fragments reached the machine.
    Loc95-8: The noise generator did its work perfectly and the torpedo turned up the soil of the playground aside of you. However, the explosion still shook you up a little…
    Loc95-9: Though the torpedo passed by due to the generator, the charge was powerful enough to damage your machine a little.
  -> Path226 => Loc54  вер=1 порядок=5
       ответ: Choose the weapon for the attack

### Loc96 [ПРОВАЛ]
    Loc96-1: Unfortunately, you blew off all your charges and have nothing else to fight with. They announced your loss due to ammunition inferiority.  /  / Your mission fai…

### Loc98 [обычная] визитов<=1
    выбор описания: {1+([p9]=3 or [p9]=4)+(2*([p9]=2 or [p9]=6))}
    Loc98-1: - Damn <clr>pitiable Faeyan<clrEnd>! It's completely impossible <clr> to get him with rockets <clrEnd>. He is constantly manoeuvring in the most unimaginable wa…
    Loc98-2: - This Cha-Cha beat me with a blaster! Can you imagine that?! To beat THE GALAXY CHAMPION AMONG MALOQS with a crappy blaster! <clr>This nasty Faeyan has an unus…
    Loc98-3: - He is tough, this <clr>Zen Cha-Cha<clrEnd>. I won't be surprised if he wins the tournament. He has some <clr>unique torpedoes <clrEnd>. Even the noise doesn't…
  -> Path250 => Loc3  вер=1 проходов<=1 порядок=5

### Loc99 [обычная] визитов<=1
    выбор описания: {1+([p9]=5 or [p9]=6)+(2*([p9]=2 or [p9]=4))}
    Loc99-1: - He is tough, this <clr>Steel Silvester <clrEnd>. I won't be surprised if he wins the tournament. He has some <clr>unique torpedoes <clrEnd>. Even the noise do…
    Loc99-2: - He beat me with a blaster! Can you imagine that?! To beat THE GALAXY CHAMPION AMONG MALOQS with a crappy blaster! <clr>This Silvester has an unusually powerfu…
    Loc99-3: - Damn <clr>Silvester<clrEnd>! He is incredibly skilful at robot managing and is constantly manoeuvring in the most unimaginable way. He even <clr>manages to du…
  -> Path251 => Loc3  вер=1 проходов<=1 порядок=5

### Loc100 [обычная] визитов<=1
    выбор описания: {1+([p9]=3 or [p9]=6)+(2*([p9]=4 or [p9]=5))}
    Loc100-1: The Peleng grinned and continued: / -  Alright, let's go along! <clr>John "God" O'Damned<clrEnd> is not the strongest opponent at this tournament. He <clr>fears…
    Loc100-2: The Peleng grinned and continued: / - <clr>John "God" O'Damned<clrEnd> is a nimble lad. And very hard-working. He became so sharp at <clr>manoeuvring <clrEnd> d…
    Loc100-3: The Peleng grinned and continued: / - <clr>John "God" O'Damned<clrEnd> is one of the most dangerous opponents and the main contender to the title. But he also h…
  -> Path198 => Loc3  вер=1 проходов<=1 порядок=5

### Loc101 [обычная] визитов<=1
    выбор описания: {1+([p9]=3 or [p9]=4)+(2*([p9]=2 or [p9]=6))}
    Loc101-1: The Peleng grinned and continued: / -  Alright, let's go along! <clr>Zen Cha-Cha<clrEnd> is a nimble lad. And very hard-working. He became so sharp at <clr>mano…
    Loc101-2: The Peleng grinned and continued: / - <clr>Zen Cha-Cha<clrEnd> is not the strongest opponent at this tournament. He fears torpedoes more then anything else and …
    Loc101-3: The Peleng grinned and continued: / - <clr>Zen Cha-Cha<clrEnd> is one of the most dangerous opponents and the main contender to the title. But he also has his w…
  -> Path252 => Loc3  вер=1 проходов<=1 порядок=5

### Loc102 [обычная] визитов<=1
    выбор описания: {1+([p9]=5 or [p9]=6)+(2*([p9]=2 or [p9]=4))}
    Loc102-1: The Peleng grinned and continued: / - Alright, let's go along! <clr>Steel Silvester <clrEnd> is one of the most dangerous opponents and the main contender to th…
    Loc102-2: The Peleng grinned and continued: / - <clr>Steel Silvester<clrEnd> is not the strongest opponent at this tournament. He fears torpedoes more then anything else …
    Loc102-3: The Peleng grinned and continued: / - <clr>Steel Silvester<clrEnd> is a nimble lad. And very hard-working. He became so sharp at <clr>manoeuvring <clrEnd> due t…
  -> Path253 => Loc3  вер=1 проходов<=1 порядок=5

### Loc103 [обычная] визитов<=1
    выбор описания: {1+([p9]=3 or [p9]=6)+(2*([p9]=4 or [p9]=5))}
    Loc103-1: - He beat me with a blaster! Can you imagine that?! To beat THE GALAXY CHAMPION AMONG MALOQS with a crappy blaster! This <clr> Gaalian has an unusually powerful…
    Loc103-2: - Damn <clr>Gaalian<clrEnd>! It's completely <clr> impossible to get him with rockets <clrEnd>. He is constantly manoeuvring in the most unimaginable way. He ev…
    Loc103-3: - He is tough, this <clr> John "God" O'Damned <clrEnd>. I won't be surprised if he wins the tournament. He has some <clr>unique torpedoes <clrEnd>. Even the noi…
  -> Path254 => Loc3  вер=1 проходов<=1 порядок=5

## Анализ
- стартовых: [1]
- концовки: {4: 'ПРОВАЛ', 12: 'УСПЕХ', 96: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
