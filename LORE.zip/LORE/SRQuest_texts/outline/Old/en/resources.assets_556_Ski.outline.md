# Квест (формат 1111111126)
Сложность 40; стартовая локация: [54]; путей по умолчанию: 1

## Параметры
- P1 'Popularity' [0..100] тип=провал
    старт: [50]
    [0..0] They hate the resort
    [1..99] Popularity of the resort <> %
    [100..100] They adore the resort
    критическое: According to the interview data, your resort is declared to be the worst one on <ToPlanet>. Multiple…
- P2 'Money' [0..100000] тип=провал
    старт: [100]
    [0..0] No money!!!
    [1..100000] Money on the account: <><clr>.000<clrEnd> cr
    критическое: <clr>You mopped up all the money!<clrEnd> Your <clr>deputy<clrEnd> didn't lose his chance and immedi…
- P3 'Advertising' [0..10] тип=обычный
    старт: [0]
    [0..0] Advertising expenses: <clr>0<clrEnd> cr
    [1..10] Advertising expenses: {[p3]*10}<clr>.000<clrEnd> cr
    критическое: Сообщение достижения критического значения параметром 20
- P4 'Hotels' [0..12] тип=обычный
    старт: [1]
    [0..12] Hotels: <> ({60*[p4]} beds)
    критическое: Сообщение достижения критического значения параметром 13
- P5 'Restaurants' [0..12] тип=обычный
    старт: [1]
    [0..12] Restaurants: <> ({45*[p5]} seats)
    критическое: Сообщение достижения критического значения параметром 14
- P6 'Beginners left' [0..1000] тип=обычный
    старт: [0]
    [0..1000] TOTAL NUMBER OF VISITORS: {[p7]+[p8]}
    критическое: Сообщение достижения критического значения параметром 2
- P7 'Beginners' [0..1000] тип=обычный
    старт: [20]
    [0..1000] Beginners: <>
    критическое: Сообщение достижения критического значения параметром 3
- P8 'Pros' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Pros: <>
    критическое: Сообщение достижения критического значения параметром 4
- P9 'Beginners arrived' [0..1000] тип=обычный
    старт: [0]
    [0..1000] SKI LIFTS ({[p10]*30+50*[p11]} seats)
    критическое: Сообщение достижения критического значения параметром 1
- P10 'With chairs' [0..8] тип=обычный
    старт: [1]
    [0..8] With chairs: <>
    критическое: Сообщение достижения критического значения параметром 5
- P11 'With cabins' [0..8] тип=обычный
    старт: [0]
    [0..8] With cabins: <> <br>---
    критическое: Сообщение достижения критического значения параметром 6
- P12 'Green' [0..16] тип=обычный
    старт: [1]
    [0..16] Tracks for beginners: <>
    критическое: Сообщение достижения критического значения параметром 9
- P13 'Red' [0..16] тип=обычный
    старт: [0]
    [0..16] Average tracks: <>
    критическое: Сообщение достижения критического значения параметром 10
- P14 'Black' [0..16] тип=обычный
    старт: [0]
    [0..16] Tracks for pros: <>
    критическое: Сообщение достижения критического значения параметром 11
- P15 'Money2' [0..10000] тип=обычный
    старт: [100]
    [0..10000] Tracks receive:<br>beginners: {[p12]*20+10*[p13]};<br>pros: {10*[p13]+[p14]*20}
- P16 'Y' [-1000..1000] тип=обычный
    старт: [0]
    [-1000..1000] 
    критическое: Сообщение достижения критического значения параметром 15
- P17 'Evening beginners' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Evening pros' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 21
- P19 'Pros left' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 18
- P20 'Pros arrived' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 19
- P21 "Player's money" [0..10000000] тип=обычный деньги
    старт: [0]
    [0..10000000] 
    критическое: Сообщение достижения критического значения параметром 16
- P22 'X' [-1000..1000] тип=обычный
    старт: [0]
    [-1000..1000] 
    критическое: Сообщение достижения критического значения параметром 12
- P23 'Days' [-1..20] тип=обычный
    старт: [0]
    [-1..20] 
- P24 'Constructions' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 23

## Локации и переходы

### Loc8 [обычная]
    Loc8-1: You gave orders to the construction manager to have <clr>a restaurant<clrEnd> constructed urgently. In a few minutes you looked out of the window and saw severa…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-80}
    эффект: P5(Restaurants) +1
    эффект: P16(Y) = {[p16]+80}
    эффект: P24(Constructions) +1
  -> Path42 => Loc23  вер=1 порядок=5

### Loc9 [обычная]
    Loc9-1: You told the Maloq that you needed a new <clr>track for pros <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared on th…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-60}
    эффект: P14(Black) +1
    эффект: P16(Y) = {[p16]+60}
    эффект: P24(Constructions) +1
  -> Path46 => Loc23  вер=1 порядок=5

### Loc10 [обычная]
    Loc10-1: You told the Maloq that you needed a new <clr>track for beginners <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared …
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-30}
    эффект: P12(Green) +1
    эффект: P16(Y) = {[p16]+30}
    эффект: P24(Constructions) +1
  -> Path47 => Loc23  вер=1 порядок=5

### Loc11 [обычная]
    Loc11-1: You invited the Maloq and told him about your decision to have <clr>a hotel<clrEnd> constructed. He promised to finish the work by night. You looked out of the …
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-110}
    эффект: P4(Hotels) +1
    эффект: P16(Y) = {[p16]+110}
    эффект: P24(Constructions) +1
  -> Path44 => Loc23  вер=1 порядок=5

### Loc12 [обычная]
    Loc12-1: You told the Maloq that you needed a new <clr>average track <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared on the…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-45}
    эффект: P13(Red) +1
    эффект: P16(Y) = {[p16]+45}
    эффект: P24(Constructions) +1
  -> Path49 => Loc23  вер=1 порядок=5

### Loc13 [обычная]
    Loc13-1: Your invited the Maloq and told him that you needed <clr> a ski lift with chairs <clrEnd> to be constructed urgently. The Maloq promised you to take care of tha…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-80}
    эффект: P10(With chairs) +1
    эффект: P16(Y) = {[p16]+80}
    эффект: P24(Constructions) +1
  -> Path39 => Loc23  вер=1 порядок=5

### Loc14 [обычная]
    Loc14-1: You invited the Maloq and said that you needed <clr> a ski lift with cabins <clrEnd> to be constructed urgently. The Maloq told you that everything would be don…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-110}
    эффект: P11(With cabins) +1
    эффект: P16(Y) = {[p16]+110}
    эффект: P24(Constructions) +1
  -> Path40 => Loc23  вер=1 порядок=5

### Loc16 [обычная]
    Loc16-1: You told the Maloq that you needed a new <clr>track for beginners <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared …
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-30}
    эффект: P12(Green) +1
    эффект: P16(Y) = {[p16]+30}
    эффект: P24(Constructions) +1
  -> Path48 => Loc23  вер=1 порядок=5

### Loc17 [обычная]
    Loc17-1: You told the Maloq that you needed a new <clr>track for pros <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared on th…
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-60}
    эффект: P14(Black) +1
    эффект: P16(Y) = {[p16]+60}
    эффект: P24(Constructions) +1
  -> Path45 => Loc23  вер=1 порядок=5

### Loc18 [обычная]
    Loc18-1: You told the Maloq that you needed a new <clr> average track <clrEnd> to be laid. The Maloq gave appropriate orders, and soon several tracklayers appeared on th…
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-45}
    эффект: P13(Red) +1
    эффект: P16(Y) = {[p16]+45}
    эффект: P24(Constructions) +1
  -> Path50 => Loc23  вер=1 порядок=5

### Loc19 [обычная]
    Loc19-1: You invited the Maloq and said that you needed <clr>a ski lift with chairs <clrEnd> to be constructed urgently. The Maloq promised you to take care of that. Soo…
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-80}
    эффект: P10(With chairs) +1
    эффект: P16(Y) = {[p16]+80}
    эффект: P24(Constructions) +1
  -> Path38 => Loc23  вер=1 порядок=5

### Loc20 [обычная]
    Loc20-1: You invited the Maloq and said that you needed <clr> a ski lift with cabins <clrEnd> to be constructed urgently. The Maloq said the work would be done in severa…
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-110}
    эффект: P11(With cabins) +1
    эффект: P16(Y) = {[p16]+110}
    эффект: P24(Constructions) +1
  -> Path41 => Loc23  вер=1 порядок=5

### Loc23 [пустая]
  -> Path168 => Loc58  вер=1 порядок=5
       условия: P23(Days) 0..20
  -> Path203 => Loc74  вер=1 порядок=5
       условия: P23(Days) ∈[-1]

### Loc43 [обычная]
    Loc43-1: You gave orders to the construction manager to have <clr>a restaurant<clrEnd> built urgently. In a few minutes you looked out of the window and noticed several …
    эффект: P1(Popularity) = {[p1]+[2..5]}
    эффект: P2(Money) = {[p2]-80}
    эффект: P5(Restaurants) +1
    эффект: P16(Y) = {[p16]+80}
    эффект: P24(Constructions) +1
  -> Path99 => Loc23  вер=1 порядок=5

### Loc54 [СТАРТ]
    Loc54-1: The acting general manager of the mountain-ski resort, a Gaalian, met you in the spaceport; from now on while you take the position of the general manager, he w…
    скрыт: P16,P17,P18,P19,P20,P21,P22,P23
  -> Path143 => Loc57  вер=1 проходов<=1 порядок=9
       текст: Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}
  -> Path144 => Loc55  вер=1 порядок=5
       текст: Talk to the experts
       эффект: P22(X) = 1

### Loc55 [обычная]
    выбор описания: {[p22]}
    Loc55-1: Who do you want to talk to?
    Loc55-2: A Maloq - <clr>the construction manager<clrEnd> - made a brief report on the situation: /  / - We can construct up to <clr>two<clrEnd> buildings per day. Such s…
    Loc55-3: Your <clr>deputy<clrEnd> Gaalian gladly shared his experience with you: /  / - You need <clr>hotels<clrEnd> to invite more people and earn more money. One hotel…
    Loc55-4: The Faeyan <clr>accountant <clrEnd> prepared the balance for you: / <fix> / -------------------------------------------------- / <format=left,29></format>DEBIT …
    Loc55-5: The Faeyan <clr>accountant<clrEnd> prepared the balance for you: /  / <fix> / -------------------------------------------------- / <format=left,29></format>DEBI…
    Loc55-6: The Faeyan <clr>accountant <clrEnd> prepared the balance for you: /  / <fix> / -------------------------------------------------- / <format=left,29></format>DEB…
    Loc55-7: The Faeyan <clr>accountant <clrEnd> prepared the balance for you: /  / <fix> / -------------------------------------------------- / <format=left,29></format>DEB…
  -> Path145 => Loc62  вер=1 порядок=2
       текст: Talk to the construction manager
       эффект: P22(X) = 2
  -> Path146 => Loc61  вер=1 порядок=6
       текст: Talk to the advertising manager
       эффект: P22(X) = {1+([p3]=0)*2}
  -> Path147 => Loc62  вер=1 порядок=3
       текст: Talk to the accountant
       эффект: P22(X) = {4+2*([p3]=0)+([p16]=0)}
  -> Path151 => Loc63  вер=1 порядок=5
       текст: Talk to the economist
       эффект: P22(X) = 1
  -> Path153 => Loc62  вер=1
       текст: Talk to the deputy
       эффект: P22(X) = 3
  -> Path162 => Loc56  вер=1 порядок=7
       текст: Build something
       условия: P23(Days) ∉[0]; P24(Constructions) 0..1
  -> Path165 => Loc57  вер=1 порядок=9
       текст: Let's call it a day! Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}
  -> Path173 => Loc58  вер=1 порядок=8
       текст: Look through the report as of yesterday
       условия: P23(Days) 1..20
  -> Path201 => Loc74  вер=1 порядок=8
       текст: Look through the report as of yesterday
       условия: P23(Days) ∈[-1]

### Loc56 [обычная]
    Loc56-1: What are you going to build?  /  / 1) Hotel - <clr>110.000<clrEnd> cr / 2) Restaurant - <clr>80.000<clrEnd> cr / 3) Track for beginners - <clr>30.000<clrEnd> cr…
  -> Path12 => Loc43  вер=1 [всегда видна] порядок=1
       текст: Build a restaurant
       условия: логика {([p2]>=80) and ([p24]<2) and ([p7]+[p8]<=45*[p5])}
  -> Path13 => Loc11  вер=1 [всегда видна]
       текст: Build a hotel
       условия: логика {([p24]<2) and ([p2]>=110) and (([p7]+[p8])<(60*[p4]))}
  -> Path14 => Loc10  вер=1 [всегда видна] порядок=3
       текст: Lay a track for beginners
       условия: логика {([p7]>=20*[p12]+10*[p13]) and ([p2]>=30) and ([p24]<2)}
  -> Path15 => Loc13  вер=1 [всегда видна] порядок=6
       текст: Construct a ski lift with chairs
       условия: логика {([p7]+[p8]<30*[p10]+40*[p11]) and ([p2]>=80) and ([p24]<2)}
  -> Path16 => Loc12  вер=1 [всегда видна] порядок=4
       текст: Lay an average track
       условия: логика {(([p7]<20*[p12]+10*[p13]) or ([p8]<20*[p14]+10*[p13])) and ([p2]>=45) and ([p24]<2)}
  -> Path17 => Loc9  вер=1 [всегда видна] порядок=5
       текст: Lay a track for pros
       условия: логика {([p8]<20*[p14]+10*[p13]) and ([p2]>=60) and ([p24]<2)}
  -> Path18 => Loc14  вер=1 [всегда видна] порядок=7
       текст: Construct a ski lift with cabins
       условия: логика {([p7]+[p8]<30*[p10]+40*[p11]) and ([p2]>=110) and ([p24]<2)}
  -> Path20 => Loc16  вер=1 [всегда видна] порядок=3
       текст: Lay a track for beginners
       условия: логика {([p7]<20*[p12]+10*[p13]) and ([p2]>=30) and ([p24]<2)}
  -> Path21 => Loc18  вер=1 [всегда видна] порядок=4
       текст: Lay an average track
       условия: логика {(([p7]>=20*[p12]+10*[p13]) or ([p8]>=20*[p14]+10*[p13])) and ([p2]>=45) and ([p24]<2)}
  -> Path22 => Loc17  вер=1 [всегда видна] порядок=5
       текст: Lay a track for pros
       условия: логика {([p8]>=20*[p14]+10*[p13]) and ([p2]>=60) and ([p24]<2)}
  -> Path23 => Loc19  вер=1 [всегда видна] порядок=6
       текст: Construct a ski lift with chairs
       условия: логика {([p7]+[p8]>=30*[p10]+40*[p11]) and ([p2]>=80) and ([p24]<2)}
  -> Path24 => Loc20  вер=1 [всегда видна] порядок=7
       текст: Construct a ski lift with cabins
       условия: логика {([p7]+[p8]>=30*[p10]+40*[p11]) and ([p2]>=110) and ([p24]<2)}
  -> Path98 => Loc8  вер=1 [всегда видна] порядок=1
       текст: Build a restaurant
       условия: логика {([p2]>=80) and ([p24]<2) and ([p7]+[p8]>45*[p5])}
  -> Path167 => Loc58  вер=1 порядок=9
       текст: Don't build anything
       условия: P23(Days) 0..20
  -> Path175 => Loc66  вер=1 [всегда видна]
       текст: Build a hotel
       условия: логика {([p24]<2) and ([p2]>=110) and (([p7]+[p8])=(60*[p4]))}
  -> Path198 => Loc74  вер=1 порядок=9
       текст: Don't build anything
       условия: P23(Days) ∈[-1]

### Loc57 [обычная]
    выбор описания: {[p16]}
    Loc57-1: Being a civilised individual, you spent the rest of the evening in the local bar, thanks to free of charge services. It was very late already when you pottered …
    Loc57-2: So, why don't you command the services of your own resort? After choosing the softest track, you put on the skies and rose to the top of the hill. However, moun…
    Loc57-3: You went to your bedroom and spent the rest of the evening watching stereoTV. There - they raised the Maloq stool market in the Pepper sector! Heh, what a barga…
    Loc57-4: The rest of the day you watched the tourists sliding downhill on their skies. Whatever might happen, your business is great and rewarding! Reassured by such a s…
    Loc57-5: Today you decided to play cards with your deputy and within several hours lost <clr>1.000<clrEnd> cr. Well, they are right warning that one should better avoid …
    Loc57-6: You asked your deputy to give you a ride around the neighbourhood on his aerocar. One should mention that your resort looks even more beautiful from the bird's-…
    Loc57-7: The rest of the day you were yawning your life away. What fun do these dull tourists find in such a poky hole of a place as your resort?! Indeed, a true space a…
    Loc57-8: You spent the whole day searching in the planet web net. There, they soak professionals at the neighbouring resort charging 7 thousands per day! Though their po…
    Loc57-9: Today you found yourself falling into talk with your construction manager. And it turned out that he used to be a ranger in his youth too! But once he got a mis…
    Loc57-10: No sooner had you come down to the bar for the deserved rest than some nimble Peleng who turned out to be a local journalist waylaid you. You had to spend all e…
    эффект: P1(Popularity) = {[p1]+2*([p16]=10)}
    эффект: P2(Money) = {[p2]-([p16]=5)}
    эффект: P6(Beginners left) = 0
    эффект: P9(Beginners arrived) = {0}
    эффект: P17(Evening beginners) = {[p7]}
    эффект: P18(Evening pros) = {[p8]}
    эффект: P19(Pros left) = {0}
    эффект: P20(Pros arrived) = {0}
    эффект: P22(X) = {[p7]+[p8]-[p10]*30-[p11]*50}
  -> Path171 => Loc59  вер=1 порядок=5
       текст: Further
       условия: логика {[p22]<=0}
  -> Path177 => Loc59  вер=1 порядок=5
       текст: Further
       условия: логика {[p22]>0}
       эффект: P6(Beginners left) = {[p6]+(0 to ([p22]*(([p7]-[p22])>0)+[p7]*(([p7]-[p22])<=0)))}
       эффект: P19(Pros left) = {[p19]+(0 to (2*[p22]*(([p8]-2*[p22])>0)+[p8]*(([p8]-2*[p22])<=0)))}

### Loc58 [обычная]
    выбор описания: {2*([p18]=0)+4*([p17]=0)+([p3]<>0)+1}
    Loc58-1: Today is <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eyes…
    Loc58-2: Today is <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eyes…
    Loc58-3: Today is <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eyes…
    Loc58-4: Today is  <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eye…
    Loc58-5: Today is  <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eye…
    Loc58-6: Today is  <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eye…
    Loc58-7: Today is  <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eye…
    Loc58-8: Today is  <CurDate>, day [p23] of your resort management. Days left: {20-[p23]}. /  / You're in your office with the report as of yesterday in front of your eye…
  -> Path169 => Loc55  вер=1 порядок=5
       текст: Talk to the experts
       эффект: P22(X) = 1
  -> Path170 => Loc57  вер=1 порядок=9
       текст: Everything is fine! Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}
  -> Path172 => Loc56  вер=1 порядок=8
       текст: Build something
       условия: P23(Days) 1..20; P24(Constructions) 0..1

### Loc59 [пустая]
    эффект: P2(Money) = {[p2]+[p17]*2+[p18]*6-10*[p3]-[p12]*10-[p13]*15-[p14]*20}
    эффект: P7(Beginners) = {[p17]-[p6]}
    эффект: P8(Pros) = {[p18]-[p19]}
    эффект: P22(X) = {[p17]+[p18]-[p5]*45}
  -> Path180 => Loc67  вер=1 порядок=5
       условия: логика {[p22]<=0}
  -> Path181 => Loc67  вер=1 порядок=5
       условия: логика {[p22]>0}
       эффект: P6(Beginners left) = {[p6]+(0 to ([p22]*(([p7]-[p22])>0)+[p7]*(([p7]-[p22])<=0)))}
       эффект: P19(Pros left) = {[p19]+(0 to (2*[p22]*(([p8]-2*[p22])>0)+[p8]*(([p8]-2*[p22])<=0)))}

### Loc61 [обычная]
    выбор описания: {[p22]}
    Loc61-1: A merry young man was responsible for the resort <clr>advertising<clrEnd>. His report was the following: /  / - At the present time the resort's <clr>popularity…
    Loc61-2: - Can do! - the advertising manager said. - The current advertising expenses are equal to [p3]<clr>0.000<clrEnd> cr per day.
    Loc61-3: A merry young man was responsible for the resort <clr>advertising<clrEnd>. His report was the following: /  / - At the present time the resort's <clr>popularity…
    Loc61-4: - Can do! - the advertising manager said. - The current advertising expenses are equal to <clr>0<clrEnd> cr per day.
  -> Path149 => Loc55  вер=1 порядок=7
       текст: Consult somebody else
       эффект: P22(X) = 1
  -> Path154 => Loc64  вер=1
       текст: Spend 0 cr per day on advertising
       условия: P3(Advertising) ∉[0]
       эффект: P3(Advertising) = 0
  -> Path156 => Loc64  вер=1 порядок=1
       текст: Spend 10.000 cr per day on advertising
       условия: P3(Advertising) ∉[1]
       эффект: P3(Advertising) = 1
  -> Path157 => Loc64  вер=1 порядок=2
       текст: Spend 20.000 cr per day on advertising
       условия: P3(Advertising) ∉[2]
       эффект: P3(Advertising) = 2
  -> Path158 => Loc64  вер=1 порядок=3
       текст: Spend 30.000 cr per day on advertising
       условия: P3(Advertising) ∉[3]
       эффект: P3(Advertising) = 3
  -> Path159 => Loc64  вер=1 порядок=4
       текст: Spend 40.000 cr per day on advertising
       условия: P3(Advertising) ∉[4]
       эффект: P3(Advertising) = 4
  -> Path160 => Loc64  вер=1 порядок=5
       текст: Spend 50.000 cr per day on advertising
       условия: P3(Advertising) ∉[5]
       эффект: P3(Advertising) = 5
  -> Path161 => Loc56  вер=1 порядок=8
       текст: Build something
       условия: P23(Days) ∉[0]; P24(Constructions) 0..1
  -> Path164 => Loc57  вер=1 порядок=9
       текст: Let's call it a day! Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}

### Loc62 [пустая]
  -> Path150 => Loc55  вер=1 порядок=5

### Loc63 [обычная]
    выбор описания: {1+(45*[p5]<([p7]+[p8]))+2*((30*[p10]+50*[p11])<([p7]+[p8]))+4*(((20*[p12]+10*[p13])<[p7]) or ((20*[p14]+10*[p13])<[p8]))}
    Loc63-1: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-2: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-3: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-4: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-5: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-6: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-7: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
    Loc63-8: <clr>The economist<clrEnd> turned out to be a man of immense format whose report was brief and to the point: /  / - At present the following number of tourists …
  -> Path152 => Loc55  вер=1 порядок=5
       текст: Consult somebody else
       эффект: P22(X) = 1
  -> Path163 => Loc56  вер=1 порядок=7
       текст: Build something
       условия: P23(Days) ∉[0]; P24(Constructions) 0..1
  -> Path166 => Loc57  вер=1 порядок=9
       текст: Let's call it a day! Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}
  -> Path174 => Loc58  вер=1 порядок=8
       текст: Look through the report as of yesterday
       условия: P23(Days) 1..20
  -> Path202 => Loc74  вер=1 порядок=8
       текст: Look through the report as of yesterday
       условия: P23(Days) ∈[-1]

### Loc64 [пустая]
  -> Path155 => Loc61  вер=1 порядок=5
       эффект: P22(X) = {2+([p3]=0)*2}

### Loc66 [обычная]
    Loc66-1: You called the Maloq and told him about your decision to have <clr>a hotel<clrEnd> constructed. The Maloq promised to finish the work by night. You looked out o…
    эффект: P1(Popularity) = {[p1]+[5..10]}
    эффект: P2(Money) = {[p2]-110}
    эффект: P4(Hotels) +1
    эффект: P7(Beginners) = {[p7]+[5..10]}
    эффект: P8(Pros) = {[p8]+[0..5]}
    эффект: P16(Y) = {[p16]+110}
    эффект: P24(Constructions) +1
  -> Path176 => Loc23  вер=1 порядок=5

### Loc67 [пустая]
    эффект: P7(Beginners) = {[p17]-[p6]}
    эффект: P8(Pros) = {[p18]-[p19]}
    эффект: P16(Y) = {[p17]-[p12]*20-[p13]*10}
    эффект: P22(X) = {[p18]-[p14]*20-[p13]*10}
  -> Path182 => Loc68  вер=1 порядок=5
       условия: логика {([p22]<=0) and ([p16]>0)}
       эффект: P6(Beginners left) = {[p6]+(0 to (2*[p16]*(([p7]-2*[p16])>0)+[p7]*(([p7]-2*[p16])<=0)))}
  -> Path183 => Loc68  вер=1 порядок=5
       условия: логика {([p22]<=0) and ([p16]<=0)}
  -> Path184 => Loc68  вер=1 порядок=5
       условия: логика {([p22]>0) and ([p16]<=0)}
       эффект: P19(Pros left) = {[p19]+(0 to (3*[p22]*(([p8]-3*[p22])>0)+[p8]*(([p8]-3*[p22])<=0)))}
  -> Path185 => Loc68  вер=1 порядок=5
       условия: логика {([p22]>0) and ([p16]>0)}
       эффект: P6(Beginners left) = {[p6]+(0 to (2*[p16]*(([p7]-2*[p16])>0)+[p7]*(([p7]-2*[p16])<=0)))}
       эффект: P19(Pros left) = {[p19]+(0 to (3*[p22]*(([p8]-3*[p22])>0)+[p8]*(([p8]-3*[p22])<=0)))}

### Loc68 [пустая]
    эффект: P1(Popularity) = {[p1]+[p3]*[2..5]-[5..10]-[p6]-2*[p19]}
    эффект: P16(Y) = {(0 to (9*([p7]>=9)+[p7]*([p7]<9)))}
    эффект: P22(X) = {(0 to (4*([p8]>=4)+[p8]*([p8]<4)))}
  -> Path186 => Loc70  вер=1 порядок=5
       эффект: P6(Beginners left) = {[p6]+[p16]}
       эффект: P19(Pros left) = {[p19]+[p22]}

### Loc69 [пустая]
    эффект: P7(Beginners) = {[p7]+[p16]}
    эффект: P8(Pros) = {[p8]+[p22]}
    эффект: P9(Beginners arrived) = {[p16]}
    эффект: P15(Money2) = {[p2]}
    эффект: P16(Y) = 0
    эффект: P20(Pros arrived) = {[p22]}
    эффект: P24(Constructions) = 0
  -> Path190 => Loc58  вер=1 порядок=5
       условия: P15(Money2) 0..999; P23(Days) 0..19
       эффект: P23(Days) +1
  -> Path191 => Loc71  вер=1 порядок=5
       условия: P15(Money2) 0..999; P23(Days) 20..20
  -> Path192 => Loc72  вер=1 порядок=5
       условия: P15(Money2) 1000..10000; P23(Days) 0..20
  -> Path193 => Loc73  вер=1 порядок=5
       условия: P15(Money2) 10000..10000; P23(Days) ∈[-1]
       эффект: P21(Player's money) = {[p21]+10000}
  -> Path194 => Loc74  вер=1 порядок=5
       условия: P15(Money2) 0..9999; P23(Days) ∈[-1]

### Loc70 [пустая]
    эффект: P7(Beginners) = {[p17]-[p6]}
    эффект: P8(Pros) = {[p18]-[p19]}
    эффект: P16(Y) = {[1..5]+[10..25]*[p1]/100}
    эффект: P22(X) = {[0..2]+[10..20]*[p1]*[p1]/10000}
  -> Path187 => Loc69  вер=1 порядок=5
       условия: логика {([p22]+[p7]+[p8]+[p16]<=60*[p4])}
  -> Path188 => Loc69  вер=1 порядок=5
       условия: логика {([p22]+[p7]+[p8]>60*[p4])}
       эффект: P16(Y) = {0}
       эффект: P22(X) = {60*[p4]-[p7]-[p8]}
  -> Path189 => Loc69  вер=1 порядок=5
       условия: логика {([p22]+[p7]+[p8]+[p16]>60*[p4]) and (([p7]+[p8]+[p22]<=60*[p4]))}
       эффект: P16(Y) = {60*[p4]-[p7]-[p8]-[p22]}

### Loc71 [ПРОВАЛ]
    Loc71-1: The time <FromPlanet>had given to you to make the resort more popular and to earn one million ran out. You didn't manage to earn the required amount and thereby…

### Loc72 [обычная]
    Loc72-1: You checked the resort's account and was completely happy to find out that there were more than <clr>1.000.000<clrEnd> cr there! Your mission was complete! You …
  -> Path195 => Loc75  вер=1 порядок=6
       текст: No
  -> Path196 => Loc74  вер=1 порядок=5
       текст: Yes
       эффект: P23(Days) = -1

### Loc73 [УСПЕХ]
    Loc73-1: You checked the resort's account and was completely happy to find out that there were more than <clr>1.000.000<clrEnd> cr there! Your mission was complete! You …

### Loc74 [обычная]
    выбор описания: {2*([p18]=0)+4*([p17]=0)+([p3]<>0)+1}
    Loc74-1: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-2: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-3: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-4: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-5: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-6: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-7: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
    Loc74-8: Today is <CurDate>. You're in your office with the report as of yesterday in front of your eyes: /  / Beginners - <clr>initial number<clrEnd>: [p17], <clr>left<…
  -> Path197 => Loc57  вер=1 порядок=8
       текст: Everything is fine! Have a break for the rest of the day
       эффект: P16(Y) = {[1..10]}
  -> Path199 => Loc56  вер=1 порядок=7
       текст: Build something
       условия: P24(Constructions) 0..1
  -> Path200 => Loc55  вер=1 порядок=5
       текст: Talk to the experts
       эффект: P22(X) = 1
  -> Path204 => Loc75  вер=1 порядок=9
       текст: You're sick and tired of this! Your main mission is complete so it's time to leave
       условия: P23(Days) -1..-1

### Loc75 [УСПЕХ]
    Loc75-1: You've had you fill of these hotels, skiers and the whole planet. It's time to get back to the space! The more so because you need to visit <FromPlanet> to get …

## Анализ
- стартовых: [54]
- концовки: {71: 'ПРОВАЛ', 73: 'УСПЕХ', 75: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
