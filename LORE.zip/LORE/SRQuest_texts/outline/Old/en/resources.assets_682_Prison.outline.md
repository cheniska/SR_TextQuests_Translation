# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Days' [0..210] тип=обычный
    старт: [0]
    [0..210] 
    критическое: В камеру зашел охранник. / - Заключенный <Ranger>! Вы отбыли свой срок и согласно решению верховного…
- P2 'Weekday' [0..6] тип=обычный
    старт: [0]
    [0..6] 
    критическое: Сообщение достижения критического значения параметром 8
- P3 'Term' [0..300] тип=успех
    старт: [90]
    [0..300] 
    критическое: A guard entered your cell. /  / - Convict <Ranger>! You have served your term, and according to the …
- P4 'Health' [0..100] тип=смерть
    старт: [90]
    [0..9] You are almost dead
    [10..19] You health has been damaged
    [20..29] You are feeling awful
    [30..39] You whole body is aching
    [40..49] You are not feeling well
    [50..59] Your health is worse than average
    [60..69] Could feel better, could feel worse
    [70..79] You are feeling good
    [80..89] You are feeling great
    [90..100] You are feeling super
    критическое: A sharp jolt of pain jerked right through you, you felt the taste of blood in your mouth. You sank d…
- P5 'Strength' [0..100] тип=обычный
    старт: [50]
    [0..9] The weakest guy in the cell!
    [10..19] Skin and bone
    [20..29] You are a weakling
    [30..39] You are of average strength
    [40..49] You are rather strong
    [50..59] You are very strong
    [60..69] You are nearly tough guy
    [70..79] You are one huge guy
    [80..89] You are a true gorilla!
    [90..100] You are super-gorilla!!!
    критическое: Сообщение достижения критического значения параметром 2
- P6 'Intellect' [0..100] тип=обычный
    старт: [50]
    [0..9] Moron
    [10..19] You are an idiot
    [20..29] You are a fool
    [30..39] You are not very clever
    [40..49] You intellect is average
    [50..59] You are clever
    [60..69] You are very clever
    [70..79] You are one big brain
    [80..89] You are the smartest guy in the cell
    [90..100] You are a local genius!
    критическое: Сообщение достижения критического значения параметром 13
- P7 "Authorities' attitude" [0..100] тип=успех
    старт: [50]
    [0..9] Rotten scoundrel
    [10..19] Scoundrel
    [20..29] Bad inmate
    [30..39] Low and worthless type
    [40..49] You are on the right path
    [50..59] You are turning over a new leaf
    [60..69] Good inmate
    [70..79] Role model of an inmate
    [80..89] They are preparing papers to release you
    [90..100] The jail release papers are being processed
    критическое: The jail radio sounded: / "Having reviewed the behaviour of the convicts with the best conduct recor…
- P8 "Guards' attitude" [0..100] тип=обычный
    старт: [50]
    [0..9] The guards hate you
    [10..19] The guards despise you
    [20..29] The guards treat you suspiciously
    [30..39] The guards do not like you very much
    [40..49] The guards' attitude to you is cold
    [50..59] The guards' attitude to you is neutral
    [60..69] The guards' attitude to you is good
    [70..79] The guards' attitude to you is rather warm
    [80..89] You are friends with the guards
    [90..100] You are good friends with the guards
    критическое: Сообщение достижения критического значения параметром 5
- P9 'Reputation' [0..99] тип=смерть
    старт: [50]
    [0..9] The other inmates are ready to kill you
    [10..19] You are a downcast
    [20..29] You are a punk
    [30..39] Other inmates despise you
    [40..49] The inmates are neutral to you
    [50..59] You are an OK chap
    [60..69] The inmates respect you
    [70..79] You are a respected criminal
    [80..89] You are a local criminal authority
    [90..99] You are a Don
    критическое: The open hostility of your cellmates came to the point of a rebellion: / - For how long this scum <R…
- P10 'Stoolie' [0..1] тип=обычный
    старт: [0]
    [0..1] You are a stoolie
    критическое: Сообщение достижения критического значения параметром 6
- P11 'Hand-to-hand combat experience' [0..5] тип=обычный
    старт: [0]
    [0..5] Fights held: <>
    критическое: Сообщение достижения критического значения параметром 10
- P12 'pp 3' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 30
- P13 'pp 2' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 26
- P14 'Janizary' [0..9] тип=обычный
    старт: [0]
    [0..0] | J . . . . . . . . . |
    [1..1] | . J . . . . . . . . |
    [2..2] | . . J . . . . . . . |
    [3..3] | . . . J . . . . . . |
    [4..4] | . . . . J . . . . . |
    [5..5] | . . . . . J . . . . |
    [6..6] | . . . . . . J . . . |
    [7..7] | . . . . . . . J . . |
    [8..8] | . . . . . . . . J . |
    [9..9] | . . . . . . . . . J |
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Runner' [0..9] тип=обычный
    старт: [0]
    [0..0] | R . . . . . . . . . |
    [1..1] | . R . . . . . . . . |
    [2..2] | . . R . . . . . . . |
    [3..3] | . . . R . . . . . . |
    [4..4] | . . . . R . . . . . |
    [5..5] | . . . . . R . . . . |
    [6..6] | . . . . . . R . . . |
    [7..7] | . . . . . . . R . . |
    [8..8] | . . . . . . . . R . |
    [9..9] | . . . . . . . . . R |
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Penchekryak' [0..9] тип=обычный
    старт: [0]
    [0..0] | P . . . . . . . . . |
    [1..1] | . P . . . . . . . . |
    [2..2] | . . P . . . . . . . |
    [3..3] | . . . P . . . . . . |
    [4..4] | . . . . P . . . . . |
    [5..5] | . . . . . P . . . . |
    [6..6] | . . . . . . P . . . |
    [7..7] | . . . . . . . P . . |
    [8..8] | . . . . . . . . P . |
    [9..9] | . . . . . . . . . P |
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Tamerlane' [0..9] тип=обычный
    старт: [0]
    [0..0] | T . . . . . . . . . |
    [1..1] | . T . . . . . . . . |
    [2..2] | . . T . . . . . . . |
    [3..3] | . . . T . . . . . . |
    [4..4] | . . . . T . . . . . |
    [5..5] | . . . . . T . . . . |
    [6..6] | . . . . . . T . . . |
    [7..7] | . . . . . . . T . . |
    [8..8] | . . . . . . . . T . |
    [9..9] | . . . . . . . . . T |
    критическое: Сообщение достижения критического значения параметром 17
- P18 'X1' [0..100] тип=обычный
    старт: [50]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 18
- P19 'X2' [0..100] тип=обычный
    старт: [50]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 19
- P20 'X3' [0..100] тип=обычный
    старт: [50]
    [0..100] Your sum: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'X4' [0..100] тип=обычный
    старт: [50]
    [0..100] Sheitan-Babai's sum: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Y' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 22
- P23 'X0' [0..5] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You staked on the Janizary
    [2..2] You staked on the Runner
    [3..3] You staked on the Penchekryak
    [4..4] You staked on Tamerlane
    [5..5] Your Cockroach runs on track 4!
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Stake' [0..100] тип=обычный
    старт: [0]
    [0..100] Your stake: <> cr
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Sap' [0..100] тип=обычный
    старт: [0]
    [0..100] Sap length: <> m
    критическое: Сообщение достижения критического значения параметром 29
- P26 'dimensions' [0..100] тип=обычный
    старт: [0]
    [0..100] YOUR PROPERTY:
    критическое: Сообщение достижения критического значения параметром 28
- P27 'Cockroach' [0..100] тип=обычный
    старт: [0]
    [0..99] Cockroach: <> m/h
    [100..100] Super-Cockroach
    критическое: Сообщение достижения критического значения параметром 9
- P28 'Money' [0..1000000000] тип=обычный деньги
    старт: [1500]
    [0..1000000000] Money: [p28] cr
    критическое: Сообщение достижения критического значения параметром 11
- P29 'tape recorder' [1..10] тип=обычный
    старт: [1]
    [1..10] Tape recorder
    критическое: Сообщение достижения критического значения параметром 33
- P30 'Fork and spoon' [0..10] тип=обычный
    старт: [0]
    [0..10] Fork and spoon
    критическое: Сообщение достижения критического значения параметром 27
- P31 'Alcohol' [0..1] тип=обычный
    старт: [0]
    [0..1] Bottle of alcohol
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Pipe' [0..10] тип=обычный
    старт: [0]
    [0..10] Fife
    критическое: Сообщение достижения критического значения параметром 34
- P33 'cube' [0..1] тип=обычный
    старт: [0]
    [0..1] Cube Puzzle
    критическое: Сообщение достижения критического значения параметром 35
- P34 'next' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 32
- P35 'x' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 25
- P36 'Tape recorder price' [0..2000] тип=обычный
    старт: [100]
    [0..2000] 
    критическое: Сообщение достижения критического значения параметром 36
- P37 'canteen' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 37

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You case was tried. The jury unanimously declared that [p3] days of incarceration would definitely do you good and become a good lesson for the future. /  / And…
    эффект: P3(Term) = {[6..9]*10+[5..10]} [скрыт]
    эффект: P4(Health) = {[81..99]}
    эффект: P5(Strength) = {[41..59]}
    эффект: P6(Intellect) = {[41..59]}
    эффект: P7(Authorities' attitude) = {[41..59]}
    эффект: P8(Guards' attitude) = {[41..59]}
    эффект: P9(Reputation) = {[41..59]}
    эффект: P29(tape recorder) = 1 [скрыт]
    скрыт: P2,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P30,P31,P32,P33,P34,P35,P36,P1
    показ: P26
  -> Path2 => Loc2  вер=1 проходов<=1 порядок=5
       текст: Try to run away
  -> Path3 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Sit tight, you'll have enough time to make the acquaintances

### Loc2 [обычная] визитов<=1
    Loc2-1: The rest of it is simple. You have to figure out how you should make your escape.
  -> Path4 => Loc4  вер=1 проходов<=1 порядок=5
       текст: Pretend to be sick
  -> Path5 => Loc5  вер=1 проходов<=1 порядок=5
       текст: Start a fight with the inmates
  -> Path6 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Forget it and just stay put

### Loc3 [обычная] визитов<=1
    Loc3-1: Soon the bus reached a grim-looking fence, and all the convicts were lead outside. The warden himself went out to greet the inmates. His ardent speech got throu…
  -> Path29 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Submit your belongings and go to the cell

### Loc4 [обычная] визитов<=1
    Loc4-1: You gripped yourself by the throat and your mouth started foaming, you whole body started to jerk violently.  / The bus was halted to a stop and the guard appro…
  -> Path7 => Loc7  вер=5 проходов<=1 порядок=5
       текст: Kick the guard between the legs and snatch the hand-cuff key from him
       эффект: P8(Guards' attitude) -10
  -> Path8 => Loc6  вер=1 проходов<=1 порядок=5
       текст: Smells like big trouble. Better continue foaming so that the guard does not suspect anything
  -> Path9 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Kick the guard between the legs and snatch the hand-cuff key from him
       ответ: Your punch didn't even visibly bother the guard. Convinced of your insincerity, he became outraged and started methodically battering you on the head with his b…
       эффект: P4(Health) -10
       эффект: P6(Intellect) -5
       эффект: P8(Guards' attitude) -5

### Loc5 [обычная] визитов<=1
    Loc5-1: You head-butted the inmate who was sitting right next to you. His reaction was quite obvious and in half a second a fight broke out.  / The bus was halted to a …
  -> Path15 => Loc14  вер=1 проходов<=1 порядок=5
       текст: Try to snatch the gun from one of the guards
       эффект: P9(Reputation) +10
       эффект: P8(Guards' attitude) -10
  -> Path16 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Shout: "He wanted to escape and I only stopped him!"
       ответ: The guard looked at you approvingly and started battering the other inmate. Most positively you just made friends with the guards, and made a large number of en…
       эффект: P9(Reputation) -25
       эффект: P8(Guards' attitude) +20

### Loc6 [обычная] визитов<=1
    Loc6-1: The guard was obviously intro non-traditional medicine. He hit you on the head with his baton full swing, causing the foaming to stop. Putting his face right in…
    эффект: P4(Health) -5
  -> Path14 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Pretend that you are feeling better

### Loc7 [обычная] визитов<=1
    Loc7-1: You caught him right where you wanted. The guard moaned and bent in half in pain. You snatched the keys and undid your handcuffs. The other guard turned out to …
    эффект: P4(Health) -10
    эффект: P5(Strength) -10
    эффект: P9(Reputation) +10
  -> Path10 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Using the body of the guard as a shield, pull the gun out and return fire.
       эффект: P8(Guards' attitude) -10
  -> Path11 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Drop the weapon and surrender

### Loc8 [обычная] визитов<=1
    Loc8-1: Trying to escape the bloodhounds you ran for the spaceport. Finally you reached your target - now you only had to get to your ship.
  -> Path25 => Loc19  вер=3 порядок=5
       текст: Sneak onto the ship
       ответ: You noticed a spaceport employee, and beckoned him to come over. Showing him your gun, you took his clothes and passing off as a repair worker got to your space…
  -> Path27 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Sneak onto the ship
       эффект: P35(x) = 3

### Loc9 [обычная] визитов<=1
    выбор описания: {[p35]}
    Loc9-1: Hiding did not work for long. The bloodhounds quickly found you, and the guards brought you back handcuffed and slightly beaten but very proud of yourself to th…
    Loc9-2: You stopped the bus and went out hands up. You were immediately handcuffed and dragged to the isolation ward. /  / Your case was tried again. And the sentence w…
    Loc9-3: You dashed forward to your ship. But the spaceport guards had already been warned about your escape and spotted you. They caught you right at the ladder of your…
    эффект: P3(Term) = {[p3]+[2..5]*10}
    эффект: P7(Authorities' attitude) -100
    эффект: P8(Guards' attitude) -100
  -> Path23 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Go to prison

### Loc10 [обычная] визитов<=1
    Loc10-1: You opened fire. / But your wound hampered your aiming and you wasted the entire clip in vain. The cop's partner used you defencelessness jumped over you and in…
    эффект: P4(Health) -10
    эффект: P8(Guards' attitude) -10
    эффект: P9(Reputation) +20
  -> Path12 => Loc13  вер=1 проходов<=1 порядок=5
       текст: Fall unconscious

### Loc11 [обычная] визитов<=1
    Loc11-1: You tossed the gun aside and raised your hands up in the air. The second guard quickly handcuffed you and brought his unconscious partner back to his senses. To…
    эффект: P4(Health) -10
    эффект: P9(Reputation) +3
  -> Path13 => Loc13  вер=1 проходов<=1 порядок=5
       текст: Fall unconscious

### Loc12 [обычная] визитов<=1
    Loc12-1: Alone, handcuffed and blindfolded, escorted by a whole police squad, you were delivered to the prison gate. The warden himself went out to meet you:  / - I am w…
  -> Path24 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Submit your belongings and go to the cell

### Loc13 [обычная] визитов<=2
    Loc13-1: When you came to you were already back in your cell. A tricky looking old guy loomed over you smiling. / - Hey, you are one tough guy! You have been the talk of…
  -> Path39 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Alright, sure, but what do I do with it?
       ответ: - You must take good care of it, feed and constantly train it, so that the roach's speed rate are increasing all the time. And - yes - you and your pet can take…
       условия: P28(Money) 250..1000000000
       эффект: P28(Money) = {[p28]-250}
       эффект: P27(Cockroach) = {[20..30]}
  -> Path125 => Loc18  вер=1 проходов<=1 порядок=5
       текст: Thanks, but I think I'll skip it
       ответ: - Well, whatever, make yourself at home!

### Loc14 [обычная] визитов<=1
    Loc14-1: Despite the cuffs you snatched the guard's gun. Noticing that his partner drew out his weapon.
  -> Path17 => Loc16  вер=3 проходов<=1 порядок=5
       текст: Shoot the guards
       эффект: P8(Guards' attitude) -50
  -> Path18 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Put down your gun and raise your hands
       ответ: The guards quickly had the situation under control - batons, heavy fists, and long legs were used as a common denominator that denominated you to one big human-…
       эффект: P9(Reputation) -3
       эффект: P8(Guards' attitude) +3
  -> Path31 => Loc21  вер=1 проходов<=1 порядок=5
       текст: Shoot the guards

### Loc15 [обычная] визитов<=3
    выбор описания: {[p35]}
    Loc15-1: You rushed to free the other inmates. Soon all were free and you even killed the bus driver who was screaming something frantically into his radio. /  / Then yo…
    Loc15-2: Before you made your escape you had to also kill the bus-driver that was screaming something frantically into his radio. /  / Then you turned the bus and took f…
  -> Path21 => Loc8  вер=3 проходов<=1 порядок=5
       текст: Leave the bus and disappear
  -> Path22 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Surrender to the authorities
       эффект: P35(x) = 2
  -> Path26 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Leave the bus and disappear
       эффект: P35(x) = 1

### Loc16 [обычная] визитов<=1
    Loc16-1: You shot the armed guard first, and then send a bullet through his unarmed partner.
  -> Path19 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Free other inmates
       эффект: P9(Reputation) +20
       эффект: P35(x) = 1
  -> Path20 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Run yourself, forget about the rest
       эффект: P9(Reputation) -30
       эффект: P35(x) = 2

### Loc17 [обычная] визитов<=1
    Loc17-1: - Oh, so you are one tough guy, you won't give your friends in, eh?.. / The guards started beating you up, covering your body with bruises, gallings and other s…
    эффект: P4(Health) = {[p4]-[12..20]}
    эффект: P9(Reputation) = {[p9]+[8..12]}
  -> Path43 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Crawl to the library

### Loc18 [обычная] визитов<=2
    Loc18-1: You looked around your cell. A rotten place if you ever saw one. Some were lying on the cots, some were playing cards, and some bull eyed you... Everything was …
  -> Path32 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Proceed to the library
  -> Path41 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Proceed to the library
       условия: P8(Guards' attitude) 0..40

### Loc19 [ПРОВАЛ]
    Loc19-1: The ship was intact - safe and sound - just like the rest of your belongings. Now nothing prevents you from leaving the planet of <FromPlanet>.

### Loc20 [обычная] визитов<=1
    Loc20-1: - There's a good lad! And in order for you to be sure that you made the right choice, get this, - the big guy punched you in the gut and kicked you. - And now l…
    эффект: P4(Health) -3
    эффект: P8(Guards' attitude) +20
    эффект: P10(Stoolie) +1
  -> Path40 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Yes, I'd like to read something

### Loc21 [СМЕРТЬ] визитов<=1
    Loc21-1: You tried to shoot first, but the guard turned out to be faster and a sent his bullet right between your eyes. If you could have another go, everything would ha…

### Loc22 [обычная]
    Loc22-1: You came up to a thin Faeyan who was making stylish tats for everyone who wanted one. / - I want to tat something cool, so that everyone respects me. / - No pro…
  -> Path52 => Loc27  вер=1 проходов<=1 порядок=7
       текст: Space-boat anchor on your belly (350 cr)
       ответ: The Faeyan spent a whole lot of time tatting your anchor. He pierced your belly with his needles putting an intricate texture over the anchor.  / Soon the work …
       условия: P28(Money) 350..1000000000
       эффект: P28(Money) = {[p28]-350}
       эффект: P9(Reputation) = {[p9]+[15..20]}
  -> Path64 => Loc27  вер=1 проходов<=1 порядок=6
       текст: Naked chick on the chest (250 cr)
       ответ: The Faeyan got down to work, and an hour later your chest was endorsed with a real Human babe, wind playing in her hair. The impression was that the wind was bl…
       условия: P28(Money) 250..1000000000
       эффект: P28(Money) = {[p28]-250}
       эффект: P9(Reputation) = {[p9]+[10..15]}
  -> Path90 => Loc27  вер=1 проходов<=1 порядок=4
       текст: Your name - <Ranger> - on the wrist (150 cr)
       ответ: The Faeyan spent a whole lot of time tracing the name "<Ranger>". He wrote it in capitals and added a ranger badge to it, so it looked real cool.
       условия: P28(Money) 150..1000000000
       эффект: P28(Money) = {[p28]-150}
       эффект: P9(Reputation) = {[p9]+[7..12]}
  -> Path94 => Loc27  вер=1 проходов<=1 порядок=1
       текст: Flower on the right shoulder (50 cr)
       ответ: The Faeyan got down to work and already one hour later your shoulder was endorsed with a huge red bud of some exotic flower, which could only be found in the Ga…
       условия: P28(Money) 50..1000000000
       эффект: P28(Money) -50
       эффект: P9(Reputation) = {[p9]+[3..7]}
  -> Path95 => Loc27  вер=1 проходов<=1 порядок=8
       текст: A Masonic sign all over your back (500 cr)
       ответ: First the Faeyan drew a sketch and then, spent the entire day working on your back. By the end of the day your back featured something truly horrible. Everyone …
       условия: P28(Money) 500..1000000000
       эффект: P28(Money) = {[p28]-500}
       эффект: P9(Reputation) = {[p9]+[20..30]}
  -> Path96 => Loc27  вер=1 проходов<=1 порядок=2
       текст: Broken heart on the left shoulder (100 cr)
       ответ: The Faeyan got down to work and already one hour later your shoulder was endorsed with a huge red four-chamber heart with a Faeyan dropper piercing it through. …
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]+[5..10]}
  -> Path97 => Loc27  вер=1 проходов<=1
       текст: A cussword on the buttocks (free)
       ответ: The Faeyan was trying to refuse, failing to understand what you wanted from him, but you kept insisting. As a result your buttocks were endorsed with a proud "P…
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
  -> Path150 => Loc23  вер=1 порядок=9
       текст: I reconsidered
       ответ: You refused to decorate your body with pictures, but spent the entire day watching at the magnificent work of the skilful Faeyan as if mesmerised.

### Loc23 [обычная]
    выбор описания: {[p1] mod 7+1}
    Loc23-1: Today <CurDate>, is <clr>Sunday<clrEnd>, the day of denunciation. This is the day when the head of the guards is expecting messages from his informers. This is …
    Loc23-2: - <clr>Monday<clrEnd>, get to work! - the guard yelled.  /  / Some of the inmates went to work, while the rest tried to talk themselves out of it by pretending …
    Loc23-3: <clr>Tuesday<clrEnd>, <CurDate> - an ordinary day in jail. You have been sitting here for {[p1]} days already, and you will spend there another {[p3]}. Today th…
    Loc23-4: Today <CurDate>, is <clr>Wednesday<clrEnd>, a working day. You've spent {[p1]} days in, and it's {[p3]} days before you go out. Part of the inmates has already …
    Loc23-5: Today is <clr>Thursday<clrEnd>, <CurDate>, {[p1]} days in prison. {[p3]} days left. / The weather is beautiful and both the library and the gym are open. But so…
    Loc23-6: <clr>Friday<clrEnd>, the favourite day of the week. Weekend is coming and this is the last working day. The majority of the inmates have already left for work, …
    Loc23-7: Today is <CurDate>, <clr>Saturday,<clrEnd> day-off. It's your {[p1]} days behind bars, and you still have to spend {[p3]} days here. / Everyone is chilling out,…
    эффект: P1(Days) +1
    эффект: P2(Weekday) = {([p1]+1) mod 7}
    эффект: P3(Term) -1
    эффект: P4(Health) = {[p4]-[0..1]}
    эффект: P5(Strength) = {[p5]-[0..1]}
    эффект: P6(Intellect) = {[p6]-[0..1]}
  -> Path56 => Loc29  вер=1 порядок=5
       текст: Call the guard and tell him you wanted to speak to the chief.
       условия: P2(Weekday) ∈[0]
  -> Path93 => Loc22  вер=1 порядок=2
       текст: Time to get yourself a new tat
       условия: P1(Days) кратно[10]; P2(Weekday) ∉[0]
  -> Path99 => Loc108  вер=1 порядок=5
       текст: I do not have the slightest intention of becoming a stoolie, I think I'll just go and get some rest
       условия: P2(Weekday) ∈[0]; P10(Stoolie) 0..0
  -> Path104 => Loc34  вер=0.7 порядок=5
       текст: Oh! Today they are holding a fist-fighting championship - gotta go and see it
       условия: P1(Days) кратно[3]; P2(Weekday) ∉[0]; P11(Hand-to-hand combat experience) 0..4
  -> Path123 => Loc74  вер=0.1 порядок=2
       текст: Today is the day of the cockroach races - go there, quick
       условия: P1(Days) некратно[10]; P2(Weekday) ∉[0]
  -> Path138 => Loc46  вер=1 порядок=1
       текст: Go to work
       условия: P2(Weekday) ∈[1, 2, 3, 4, 5]
  -> Path139 => Loc48  вер=1 порядок=4
       текст: Go to the library
       условия: P2(Weekday) ∈[2, 4, 6]
  -> Path140 => Loc49  вер=1 порядок=3
       текст: Go to the gym
       условия: P2(Weekday) ∈[2, 4]
  -> Path141 => Loc50  вер=1
       текст: Go to the canteen
       условия: P2(Weekday) ∉[0]
  -> Path143 => Loc52  вер=1 порядок=3
       текст: Gamble
       условия: P2(Weekday) ∈[1, 3, 5, 6]
       эффект: P9(Reputation) = {[p9]+[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]-[0..2]}
       эффект: P8(Guards' attitude) = {[p8]-[0..2]}
       эффект: P22(Y) = 0
       скрыт: P23
  -> Path144 => Loc53  вер=1 порядок=7
       текст: Go to the jail yard to train your pet there
       условия: P2(Weekday) ∉[0]; P27(Cockroach) 1..99
  -> Path220 => Loc74  вер=1 порядок=2
       текст: Today is the day of the cockroach races - go there, quick
       условия: P2(Weekday) ∈[6]
  -> Path276 => Loc108  вер=1 порядок=5
       текст: I may be a stoolie, but I never promised I was going to keep my word!
       ответ: The chief guard never received the report he was expecting from you that day. This was going to cost - the chief was notorious for his rancour...
       условия: P2(Weekday) ∈[0]; P10(Stoolie) 1..1
       эффект: P8(Guards' attitude) = {[p8]-[20..30]}
  -> Path427 => Loc126  вер=5 порядок=8
       текст: Go to the medical station
       условия: P2(Weekday) ∈[5]
       эффект: P13(pp 2) = {0}
       эффект: P35(x) = {1}
  -> Path446 => Loc142  вер=1 порядок=5
       текст: Go to the concert
       условия: P2(Weekday) ∈[3]
  -> Path467 => Loc138  вер=1 порядок=5
       текст: Dig the sap
       условия: P2(Weekday) ∉[0]; P5(Strength) 40..79; P30(Fork and spoon) 1..1
       эффект: P5(Strength) = {[p5]-[3..6]}
       эффект: P12(pp 3) = {[1..4]}
       эффект: P25(Sap) = {[p25]+[3..9]}
  -> Path543 => Loc138  вер=1 порядок=5
       текст: Dig the sap
       условия: P2(Weekday) ∉[0]; P5(Strength) 80..100; P30(Fork and spoon) 1..1
       эффект: P5(Strength) = {[p5]-[5..10]}
       эффект: P12(pp 3) = {[5..6]}
       эффект: P25(Sap) = {[p25]+[8..15]}
  -> Path544 => Loc138  вер=1 порядок=5
       текст: Dig the sap
       условия: P2(Weekday) ∉[0]; P5(Strength) 21..39; P30(Fork and spoon) 1..1
       эффект: P5(Strength) = {[p5]-[3..6]}
       эффект: P12(pp 3) = {[7..8]}
       эффект: P25(Sap) = {[p25]+[3..9]}
  -> Path545 => Loc138  вер=1 порядок=5
       текст: Dig the sap
       условия: P2(Weekday) ∉[0]; P5(Strength) 1..20; P30(Fork and spoon) 1..1
       эффект: P5(Strength) = {[p5]-[1..3]}
       эффект: P4(Health) = {[p4]-[2..7]}
       эффект: P12(pp 3) = {[9..10]}
       эффект: P25(Sap) = {[p25]+[0..2]}
  -> Path571 => Loc163  вер=1 проходов<=1 порядок=5
       текст: Go to the medical station
       условия: P2(Weekday) ∈[5]
       эффект: P13(pp 2) = {0}
       эффект: P35(x) = {1}

### Loc24 [обычная] визитов<=1
    Loc24-1: You followed the guard out. Finally he stopped at a door and pushed you forward. Behind the door a group of guards was already waiting for you, judging by the l…
  -> Path28 => Loc17  вер=1 проходов<=1 порядок=5
       текст: I am not going to give my guys in!
  -> Path42 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Sure, I will be your stoolie

### Loc25 [обычная]
    Loc25-1: The librarian greeted you with a happy smile. You could tell it straight away the library was not the most popular place in this prison, which was not really su…
  -> Path44 => Loc23  вер=1 проходов<=1 порядок=5
       текст: Head back to your cell
  -> Path248 => Loc160  вер=1 [всегда видна] порядок=5
       текст: Throw 5 cr to the blind man
       условия: P28(Money) 5..1000000000
       эффект: P28(Money) -5

### Loc26 [обычная]
    Loc26-1: A tall Gaalian was shuffling the deck. / - I am not explaining the rules since everybody knows them. How do we play - big-time or small-time?
  -> Path302 => Loc23  вер=1 порядок=8
       текст: I reconsidered I am not going to play!
       ответ: - Why did you sit at the table in the first place then?!! - the spectators flared. - Look at this kind of a ranger, doesn't even keep his word! / You reputation…
       условия: P22(Y) 0..0
       эффект: P9(Reputation) -20%
       эффект: P6(Intellect) = {[p6]+[1..7]}
  -> Path303 => Loc104  вер=1 [всегда видна] порядок=6
       текст: Play high! (500 cr)
       ответ: - Let's play high! - you said. - We are grownups aren't we?! /  / No one argued with you and everyone threw in {500} cr
       условия: P28(Money) 500..1000000000
       эффект: P28(Money) = {[p28]-500}
       эффект: P9(Reputation) = {[p9]+[0..5]}
       эффект: P6(Intellect) = {[p6]+[0..1]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..5]}
       эффект: P8(Guards' attitude) = {[p8]-[0..4]}
       эффект: P23(X0) = 5
  -> Path304 => Loc104  вер=1 [всегда видна] порядок=1
       текст: Let's play low (100 cr)!
       ответ: - Let's play low! - you suggested - I want to get a better knack of the rules of the game! /  / Nobody argued and everyone threw in {100} cr.
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]+[0..1]}
       эффект: P6(Intellect) = {[p6]+[0..5]}
       эффект: P23(X0) = 1

### Loc27 [пустая]
  -> Path98 => Loc23  вер=1 порядок=5

### Loc28 [пустая]
    эффект: P22(Y) = {[2..5]}
  -> Path55 => Loc47  вер=1 порядок=5
       ответ: The guard accompanying you suddenly stopped half-way down the corridor and said:  / - <Ranger>, I thought you were our stoolie. Then why don't you ever come ove…
       условия: P8(Guards' attitude) 0..49; P10(Stoolie) 1..1
       эффект: P4(Health) = {[p4]-[1..4]}
  -> Path62 => Loc30  вер=0.4 проходов<=3 порядок=5
       условия: P8(Guards' attitude) 0..60; P10(Stoolie) 0..0
  -> Path63 => Loc31  вер=0.5 порядок=5
       условия: P9(Reputation) 1..39
  -> Path68 => Loc47  вер=1 порядок=5
       ответ: A large hoodlum appeared in your way... / - Got you some rest, professor? Well, one thing you have to know, we don't like eggheads here, and we like weaklings e…
       условия: P5(Strength) 0..60; P6(Intellect) 50..100; P7(Authorities' attitude) 50..100; P9(Reputation) 1..49
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P4(Health) = {[p4]-[8..12]}
  -> Path70 => Loc47  вер=1 порядок=5
       ответ: A large hoodlum appeared in your way... / - Got you some rest, professor? Well, one thing you have to know, we don't like eggheads here, and we like weaklings e…
       условия: P5(Strength) 50..70; P6(Intellect) 50..100; P7(Authorities' attitude) 50..100; P9(Reputation) 1..49
       эффект: P9(Reputation) = {[p9]+[3..10]}
  -> Path71 => Loc30  вер=0.2 проходов<=2 порядок=5
       условия: P10(Stoolie) 0..0
  -> Path74 => Loc47  вер=1 порядок=5
       ответ: Near the cell the Don was waiting for you: / - Listen, <Ranger>, you are one smart guy and everyone respects you, y'know. Can you help me write an amnesty plea?…
       условия: P6(Intellect) 70..100; P9(Reputation) 60..89
       эффект: P6(Intellect) = {[p6]+[2..5]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P28(Money) = {[p28]+100}
  -> Path75 => Loc47  вер=3 порядок=5
       ответ: The evening went calm, and you managed to get some rest.
       эффект: P4(Health) = {[p4]+[2..5]}
  -> Path82 => Loc47  вер=1 порядок=5
       ответ: There was some really bad news in store for you. One of the guards accidentally blurted it out that you were an informer. He said he was sorry. This meant that …
       условия: P8(Guards' attitude) 60..100; P9(Reputation) 60..99; P10(Stoolie) 1..1
       эффект: P9(Reputation) -80%
  -> Path83 => Loc47  вер=1 порядок=5
       ответ: Unawares you were pacing back to your prison cell when a whole group of convicts blocked your way. The guy who looked like he was the chief around here proceede…
       условия: P4(Health) 70..100; P5(Strength) 70..100; P9(Reputation) 1..29
       эффект: P4(Health) = {[p4]-[8..12]}
       эффект: P5(Strength) = {[p5]-[2..5]}
       эффект: P9(Reputation) -1
  -> Path84 => Loc47  вер=1 порядок=5
       ответ: One of the Don's closer assistants was waiting for you near the cell. /  / - You worthless scum! I say your cot shall be next to the shit-hole, and I strongly a…
       условия: P5(Strength) 0..40; P9(Reputation) 1..29
       эффект: P5(Strength) = {[p5]-[2..5]}
       эффект: P9(Reputation) = {[p9]-[1..4]}
       эффект: P4(Health) = {[p4]-[8..12]}
  -> Path85 => Loc47  вер=1 порядок=5
       ответ: - Hey, punk. Get yourself over here - a big guy told you. /  / He was definitely hostile and no wonder. You reputation among the convicts was way down. Your who…
       условия: P5(Strength) 0..59; P9(Reputation) 1..19
       эффект: P9(Reputation) = {[p9]-[1..4]}
       эффект: P4(Health) = {[p4]-[8..12]}
  -> Path86 => Loc47  вер=2 порядок=5
       ответ: Some rotten type approached you.  /  / - I know you are a stoolie. I will tell everyone, and you will answer for this, got it?
       условия: P10(Stoolie) 1..1
       эффект: P9(Reputation) = {[p9]-[7..10]}
  -> Path87 => Loc116  вер=1 порядок=5
       ответ: You went back to your cell and went to bed. Suddenly you heard a siren, guards broke into the cell and started searching everyone. As a result they found a bag …
       условия: P6(Intellect) 0..70; P7(Authorities' attitude) 50..100; P8(Guards' attitude) 40..100; P9(Reputation) 1..29
       эффект: P6(Intellect) = {[p6]-[10..20]}
       эффект: P7(Authorities' attitude) = {[p7]-[15..45]}
       эффект: P8(Guards' attitude) = {[p8]-[8..12]}
       эффект: P4(Health) -50%
       эффект: P1(Days) +7
       эффект: P3(Term) -7
       эффект: P5(Strength) = {[p5]-[20..30]}
       эффект: P22(Y) = 0
  -> Path88 => Loc47  вер=1 порядок=5
       ответ: You went back to your cell and went to bed. Suddenly you heard a siren, guards broke into the cell and started searching everyone. They did not find anything bu…
       условия: P7(Authorities' attitude) 60..100; P8(Guards' attitude) 70..100; P9(Reputation) 1..29
       эффект: P9(Reputation) -50%
       эффект: P4(Health) -60%
  -> Path89 => Loc115  вер=1 порядок=5
       ответ: You went back to your cell and went to bed. Suddenly you heard a siren, guards broke into the cell and started searching everyone. They did not find anything bu…
       условия: P7(Authorities' attitude) 40..100; P8(Guards' attitude) 0..69; P9(Reputation) 1..19; P10(Stoolie) 0..0
       эффект: P7(Authorities' attitude) = {[p7]-[5..15]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}
       эффект: P4(Health) -10%
       эффект: P1(Days) +2
       эффект: P3(Term) -2
       эффект: P5(Strength) = {[p5]-[3..7]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P22(Y) = 0
  -> Path264 => Loc47  вер=0.5 порядок=5
       ответ: A small Faeyan approached you. /  / - Sya, <Ranger>, tomorrow is my last day in prison. I need some good lad to take care of my <clr>cockroach<clrEnd>. How is t…
       условия: P9(Reputation) 30..69; P27(Cockroach) 0..0
       эффект: P27(Cockroach) = {[p27]+[5..15]}
  -> Path265 => Loc93  вер=1 порядок=5
       условия: P5(Strength) 10..100; P9(Reputation) 1..19
  -> Path272 => Loc47  вер=0.2 порядок=5
       ответ: On your way back to the cell you found a banknote worth {50*([p22] div 2)} cr. You stealthily slipped it into your pocket - this definitely looked like your luc…
       эффект: P28(Money) = {[p28]+50*([p22] div 2)}
  -> Path273 => Loc47  вер=1 порядок=5
       ответ: That night the Don said half-jokingly: / - I am going to give {500} cr to him who runs a hundred times up and down the corridor.  / You decided to earn a quick …
       условия: P5(Strength) 30..70; P6(Intellect) 0..29
       эффект: P5(Strength) = {[p5]-[1..3]}
       эффект: P6(Intellect) = {[p6]-[3..5]}
       эффект: P4(Health) = {[p4]+[5..10]}
       эффект: P9(Reputation) = {[p9]-[1..4]}
       эффект: P22(Y) = {[50..99]}
  -> Path274 => Loc47  вер=1 порядок=5
       ответ: You dared one Maloq {100} cr, that you could do 500 push-ups. This required a lot of strength but you won and got the money!
       условия: P5(Strength) 70..100
       эффект: P5(Strength) = {[p5]-[8..12]}
       эффект: P28(Money) = {[p28]+100}
  -> Path275 => Loc47  вер=1 порядок=5
       ответ: When you came back to the cell you found out that {10*[p22]} cr was missing from your locker. Tough luck!
       условия: P28(Money) 50..1000000000
       эффект: P28(Money) = {[p28]-10*[p22]}
  -> Path286 => Loc47  вер=1 порядок=5
       ответ: In the evening you had this crazy idea of starting a philosophical argument with a Gaalian OG. You couldn't convince him in anything, and it all ended with his …
       условия: P6(Intellect) 0..49; P9(Reputation) 1..49
       эффект: P6(Intellect) +1
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P4(Health) = {[p4]-[2..5]}
  -> Path337 => Loc47  вер=1 порядок=5
       ответ: One of the Maloqs, who just lost a game of cards, decided to let off some steam on you and punched you in the gut. It's no good being that weak!
       условия: P5(Strength) 0..29; P9(Reputation) 1..59
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P4(Health) = {[p4]-[1..4]}
  -> Path338 => Loc47  вер=1 порядок=5
       ответ: One of the guards, who wanted to avenge you for some alleged wrongdoing, told everyone you were a stoolie. Fortunately enough, you had the brains to claim this …
       условия: P6(Intellect) 30..100; P8(Guards' attitude) 0..29; P9(Reputation) 51..99; P10(Stoolie) 1..1
       эффект: P9(Reputation) -30%
  -> Path339 => Loc47  вер=1 порядок=5
       ответ: One of the guards, who wanted to avenge you for some alleged wrongdoing, told everyone you were a stoolie. Your excuses sounded lame and unconvincing, so the tr…
       условия: P6(Intellect) 0..49; P8(Guards' attitude) 0..29; P9(Reputation) 51..99; P10(Stoolie) 1..1
       эффект: P9(Reputation) -65%
  -> Path349 => Loc47  вер=1 порядок=5
       ответ: A group of oversized Humans and Maloqs met you in the corner. / - You know, <Ranger>, an OG that you are we sill know that you are a weakling, and now is paybac…
       условия: P5(Strength) 0..39; P9(Reputation) 70..99
       эффект: P4(Health) = {[p4]-[8..12]}
  -> Path350 => Loc110  вер=0.7 порядок=5
       условия: P28(Money) 250..1000000000
  -> Path353 => Loc47  вер=1 порядок=5
       ответ: A group of pretty hostile guards together with the chief of security was waiting for you near the cell. The chief said: / - I see, <Ranger>, that you think you …
       условия: P8(Guards' attitude) 0..59; P9(Reputation) 71..99; P10(Stoolie) 0..0
       эффект: P4(Health) = {[p4]-[10..15]}
       эффект: P5(Strength) = {[p5]-[2..7]}
       эффект: P6(Intellect) = {[p6]-[1..5]}
  -> Path365 => Loc113  вер=0.8 порядок=5
       условия: P9(Reputation) 1..79; P27(Cockroach) 30..100
  -> Path371 => Loc47  вер=0.5 порядок=5
       ответ: You dared one of the Maloqs for {100} cr, that you could do 500 push-ups. Unfortunately after {[p22]} push-ups you were already completely spent. Too bad!
       условия: P5(Strength) 40..80; P6(Intellect) 0..79; P28(Money) 100..1000000000
       эффект: P5(Strength) = {[p5]-[5..9]}
       эффект: P28(Money) = {[p28]-100}
       эффект: P22(Y) = {[300..499]}
  -> Path372 => Loc47  вер=1 порядок=5
       ответ: Today for some reason you had this silly idea of making a sign on the wall, that read: "The Warden is a pig!" The inmates were absolutely overjoyed at your idea…
       условия: P6(Intellect) 0..39; P8(Guards' attitude) 0..59
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
  -> Path398 => Loc120  вер=0.1 порядок=5
  -> Path403 => Loc121  вер=0.4 порядок=5
       условия: P9(Reputation) 90..99
  -> Path441 => Loc130  вер=0.4 проходов<=1 порядок=5
       условия: P6(Intellect) 0..59; P9(Reputation) 1..69
       эффект: P13(pp 2) = {1}
  -> Path532 => Loc47  вер=1 порядок=5
       ответ: On your way back to the cell you saw a Maloq who was fumbling about with a <clr>cube puzzle<clrEnd>. You stopped, but he paid not attention all wrapped up in an…
       условия: P33(cube) 0..0
       эффект: P33(cube) = {1} [показ]
       показ: P26
  -> Path597 => Loc159  вер=1 порядок=5
       условия: P9(Reputation) 20..99; P10(Stoolie) 0..0; P29(tape recorder) 1..1
       эффект: P36(Tape recorder price) = {[50..200]}
  -> Path601 => Loc47  вер=1 порядок=5
       ответ: You stopped by the toilet and found a <clr>pipe<clrEnd> lying on the floor- apparently somebody had left it there by chance. You examined the instrument and see…
       условия: P32(Pipe) 0..0
       эффект: P32(Pipe) +1 [показ]
       показ: P26

### Loc29 [обычная]
    Loc29-1: The guard understood everything and led you to his boss. The guard chief turned out to be a fat pig with piggy eyes.  /  / - What brings you here, <Ranger>? Wan…
  -> Path57 => Loc170  вер=1 порядок=4
       текст: I want to be your informer
       ответ: - Oh, really! Positively you are on the right way out of this prison. Well in that case you must come here once a week and tell me what is going on in your cell…
       условия: P10(Stoolie) 0..0
       эффект: P10(Stoolie) +1
       эффект: P9(Reputation) = {[p9]-[3..8]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}
       эффект: P8(Guards' attitude) = {[p8]+[15..25]}
  -> Path58 => Loc170  вер=1 порядок=5
       текст: I want to report
       ответ: You told him about everything that was going on in the cell. The chief was pleased. /  / - Good job, lad, I will tell the warden that ranger <Ranger> is on the …
       условия: P10(Stoolie) 1..1
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}
       эффект: P8(Guards' attitude) = {[p8]+[5..10]}
  -> Path59 => Loc170  вер=1 порядок=6
       текст: I am not going to be your stoolie any longer
       ответ: The pig narrowed his slanty eyes and croaked:  / - Right, <Ranger>, think you are so smart, eh? Don't wanna be a stoolie? Wanna stay clean?!! Alright, get lost …
       условия: P10(Stoolie) 1..1
       эффект: P10(Stoolie) -1
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[20..30]}
  -> Path346 => Loc170  вер=1 порядок=1
       текст: I want to give you {250} cr as a token of my deep respect to you.
       ответ: The warden was impressed by your deed, he even treated you to a cup of real tea. But the inmates started some very nasty rumours about you..
       условия: P10(Stoolie) 0..0; P28(Money) 250..1000000000
       эффект: P28(Money) = {[p28]-250}
       эффект: P4(Health) +5
       эффект: P9(Reputation) = {[p9]*5/9}
       эффект: P8(Guards' attitude) = {[p8]+[20..30]}
  -> Path599 => Loc170  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: I wanted to ask you for a tape-recorder - I am going to need it on the mission
       ответ: - Ha, that's an excellent idea, <Ranger>! - the chief of security exclaimed. - How come I did not think of it myself?!  /  / With these words the chief of secur…
       условия: P10(Stoolie) 1..1; P29(tape recorder) 1..1
       эффект: P29(tape recorder) = 2
       эффект: P9(Reputation) = {[p9]-[4..9]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[5..10]}

### Loc30 [обычная]
    Loc30-1: Right by the library a guard stopped you and asked you to follow him. He brought you to the chief guard, a fat pig with piggy eyes.  /  / - We need somebody to …
  -> Path60 => Loc23  вер=1 порядок=5
       текст: Sure, I will be your stoolie
       ответ: - There's a good lad. Each Sunday I am expecting you to come here and tell me everything that you know. Got it, <Ranger>? And now back to your cell.
       эффект: P9(Reputation) = {[p9]-[8..12]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P10(Stoolie) +1
  -> Path61 => Loc23  вер=1 порядок=5
       текст: I am not going to give my boys in
       ответ: - Oh, look at Mr. Righteous here, you are not going to give your boys in, you say... / And the guards started battering you. You health has considerably worsene…
       эффект: P4(Health) = {[p4]-[8..12]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}

### Loc31 [обычная]
    Loc31-1: Looks like something is going on round the corner. You turned and saw two guards battering one of the inmates you knew. What should you do? Help your friend or …
  -> Path73 => Loc170  вер=1 порядок=5
       текст: Help a friend
       ответ: You tried to interfere, but the guards called for reinforcements. Soon they investigated into the incident, and you got a dressing-down from the prison authorit…
       условия: P5(Strength) 50..100
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]+[25..50]}
       эффект: P7(Authorities' attitude) = {[p7]-[5..10]}
       эффект: P8(Guards' attitude) = {[p8]-[20..40]}
  -> Path81 => Loc170  вер=1 порядок=5
       текст: Help a friend
       ответ: You interfered, but the guards turned out to be stronger and gave you both a good berating. Nonetheless, when the other inmates learned about what you did, thei…
       условия: P5(Strength) 20..59
       эффект: P4(Health) = {[p4]-[10..25]}
       эффект: P9(Reputation) = {[p9]+[10..25]}
       эффект: P8(Guards' attitude) = {[p8]-[10..15]}
  -> Path103 => Loc170  вер=1 порядок=5
       текст: Disappear unnoticed
       ответ: Unfortunately the guy who was being battered recognised you and told the entire cell in the evening what a coward you were...
       эффект: P9(Reputation) -20%
  -> Path307 => Loc170  вер=3 порядок=5
       текст: Deliver a speech advocating the rights of the jailed
       ответ: Unfortunately your speech did not make much of an impression on the guards. As a result you got your portion of beating as well. The inmates started paying you …
       условия: P6(Intellect) 20..59
       эффект: P6(Intellect) +1
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}
  -> Path308 => Loc170  вер=1 порядок=5
       текст: Deliver a speech advocating the rights of the jailed
       ответ: You spoke like a top-paid lawyer spicing your speech with proper legal terms. The guards decided not to mess with you and let your friend go. Your reputation in…
       условия: P6(Intellect) 50..100
       эффект: P6(Intellect) = {[p6]+[3..7]}
       эффект: P9(Reputation) = {[p9]+[8..12]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}
  -> Path354 => Loc170  вер=1 порядок=5
       текст: Disappear unnoticed
       ответ: Fortunately enough the guy on the floor did not recognise you and the incident went without consequences.

### Loc33 [пустая]
  -> Path322 => Loc91  вер=1 порядок=5

### Loc34 [обычная]
    Loc34-1: As usual a fight gathered a large audience. The prison warden himself had a huge liking for such bloody displays.
  -> Path105 => Loc35  вер=1 проходов<=5 порядок=5
       текст: Submit a request to take part in the tournament
  -> Path106 => Loc23  вер=0.5 порядок=5
       текст: Submit a request to take part in the tournament
       ответ: You said you wanted to participate and were about to submit your request, when the chief guard approached you: / - So, <Ranger>, you want to take part in the to…
       условия: P8(Guards' attitude) 0..40
       эффект: P4(Health) -10
  -> Path114 => Loc23  вер=1 порядок=5
       текст: Just watch
       ответ: You spent a wonderful day looking at the pumped up convicts beat the crap out of each other. You had great fun and your spirits were on the rise. The show culmi…
  -> Path151 => Loc57  вер=1 [всегда видна] порядок=5
       текст: Stake {100} cr on one of the fighters
       ответ: Since you've never participated in these competitions yourself you did not manage to assess the situation properly, and the guy whom you staked on got knocked o…
       условия: P11(Hand-to-hand combat experience) 0..0; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
  -> Path152 => Loc57  вер=3 порядок=5
       текст: Stake {100} cr on one of the fighters
       ответ: You already could call yourself an expert in fist-fighting so you were not surprised to see that the fighter you staked on won the battle. And you received {100…
       условия: P11(Hand-to-hand combat experience) 3..5; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]+100}
  -> Path153 => Loc57  вер=1 порядок=5
       текст: Stake {100} cr on one of the fighters
       ответ: You weren't really an expert in fist-fights but you got lucky. You won {100} cr, since your fighter has become a champion. / You spent a wonderful day watching …
       условия: P11(Hand-to-hand combat experience) 1..2; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]+100}
  -> Path154 => Loc57  вер=1 порядок=5
       текст: Stake {100} cr on one of the fighters
       ответ: You staked your money on a very strong fighter. He almost made it to the finals but lost. The point is that your personal experience is not enough, to always st…
       условия: P11(Hand-to-hand combat experience) 1..3; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}

### Loc35 [обычная] визитов<=5
    Loc35-1: A young handsome Peleng was registering the fighters. / - In order to win in this competition, one must have excellent health, be in good physical shape, and of…
    Loc35-2: A young handsome Peleng was registering the fighters. / - Oh, <Ranger>, feeling lucky again? You are doing it right - experience comes with bruises and broken b…
    Loc35-3: Seeing you, the Peleng who was registering the fighters, smiled: / - <Ranger>, my homie! You already have fans here. Last time you really showed'em! You are in …
    Loc35-4: You approached the young Peleng. / - Oh, Great Master <Ranger> himself! Last time you almost made it to victory. I am so sure you are going to make it this time…
    Loc35-5: You approached the young Peleng. / - Greeting, master of fist-fight <Ranger>! Thank you for honouring our show with you presence. The audience is already chanti…
  -> Path107 => Loc36  вер=2 проходов<=5 порядок=5
       текст: Go and fight
  -> Path109 => Loc37  вер=5 проходов<=1 порядок=5
       текст: Go and fight
       ответ: Your experience coupled with your physical abilities were at their best. Without much trouble you went into the finals and won the last match against the strong…
       условия: P4(Health) 80..100; P5(Strength) 80..100; P11(Hand-to-hand combat experience) 2..5
  -> Path110 => Loc37  вер=3 проходов<=1 порядок=5
       текст: Go and fight
       ответ: Your experience coupled with your physical abilities were at their best. Without much trouble you went into the finals and won the last match against the strong…
       условия: P4(Health) 90..100; P5(Strength) 90..100; P11(Hand-to-hand combat experience) 1..5
  -> Path111 => Loc37  вер=7 проходов<=1 порядок=5
       текст: Go and fight
       ответ: Your experience coupled with your physical abilities were at their best. Without much trouble you went into the finals and won the last match against the strong…
       условия: P4(Health) 70..100; P5(Strength) 60..100; P11(Hand-to-hand combat experience) 3..5
  -> Path112 => Loc37  вер=10 проходов<=1 порядок=5
       текст: Go and fight
       ответ: Your experience coupled with your physical abilities were at their best. Without much trouble you went into the finals and won the last match against the strong…
       условия: P4(Health) 50..100; P5(Strength) 40..100; P11(Hand-to-hand combat experience) 4..5
  -> Path113 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Go and fight
       ответ: Your physical abilities were at their best. Without much trouble you went into the finals and won the last match against the strongest fighter showing a beautif…
       условия: P4(Health) 90..100; P5(Strength) 95..100

### Loc36 [обычная] визитов<=5
    Loc36-1: A bloody fight broke out. You did not have any fighting experience, which is why you had to move into defence and save up your strength. You lost the fight, flo…
    Loc36-2: A bloody fight broke out. Your previous experience helped you stay on your feet a little longer this time and become more efficient, but the real skill was stil…
    Loc36-3: You held a whole series of fights. Skilfully dodging the punches of your opponents, you landed accurate and powerful jabs onto them. The fans roared, cheering f…
    Loc36-4: You fought like a pro and your opponents had nothing to offer in response. Unfortunately you still didn't make it to the finals, missing your chance by a tiny b…
    Loc36-5: Demonstrating your professionalism throughout the entire series of fights you got to the finals. In that last fight you stoop up against Master Lee, an expert i…
    эффект: P4(Health) = {[p4]-[20..25]+([p11]-2)*[0..2]}
    эффект: P5(Strength) = {[p5]-[10..15]+([p11]-2)*[0..1]}
    эффект: P6(Intellect) = {[p6]-[2..3]*([p11]+1)}
    эффект: P7(Authorities' attitude) = {[p7]+[5..10]}
    эффект: P8(Guards' attitude) = {[p8]+[1..3]}
    эффект: P9(Reputation) = {[p9]+[1..2]*([p11]+1)}
    эффект: P11(Hand-to-hand combat experience) +1
  -> Path108 => Loc23  вер=1 проходов<=5 порядок=5
       текст: Go back to the cell

### Loc37 [УСПЕХ]
    Loc37-1: - Convict <Ranger>, I want to express my admiration with your combat abilities! A warrior like that should not be wasting his talent here in this dirt-hole on p…

### Loc38 [обычная] визитов<=1
    Loc38-1: Then all of a sudden a small and quick cockroach ran right out onto the front page... Lazily, you decided to blow it off, so that not to soil the pages, but the…
  -> Path117 => Loc89  вер=1 проходов<=1 порядок=5
       текст: Take a cockroach
       ответ: You liked its will for victory, and decided to make a real cockroach run champion out of it. You took it carefully and put it in a matchbox.
       эффект: P27(Cockroach) = {[p27]+[5..15]}
  -> Path118 => Loc89  вер=1 проходов<=1 порядок=5
       текст: Throw the manuscript away in disgust
       ответ: The librarian saw what you did and read you a notation on the proper rules of behaviour in a library. In the end, a s a punishment, he forced you to put all the…
       эффект: P7(Authorities' attitude) -1

### Loc40 [обычная]
    Loc40-1: Not caring much about yourself, you spent the entire day with your pet. Teaching it all kinds of victory strategies you made quite a progress. The roach was run…
    Loc40-2: Today the cockroach looked gloomy. The rain outside did not help its appetite. It did not want to eat and you nearly had to force-feed it. On the other hand the…
    Loc40-3: The roach's good mood shifted onto you - the old bird and a star-fighter. Watching it scud along, gaining a couple of seconds on each lap, you knew it that this…
    Loc40-4: It seemed to you that your pet had become somewhat weak. Taking a closer look, it suddenly dawned on you that it was all about women! You quickly found two fema…
    Loc40-5: You opened the box, but the pet would not come out and train. You decided that it had gone completely lazy and looked inside... / And that was what the roach wa…
    эффект: P4(Health) = {[p4]+[0..1]}
    эффект: P6(Intellect) = {[p6]+[0..1]}
  -> Path364 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc43 [пустая]
    Loc43-1: The fans screamed, cheering for the champions, and soon you were caught in the excitement of the race:
    Loc43-2: Everyone was screaming and shouting, and you did your best keeping up with them:
    Loc43-3: You ears went numb because of the screams around you but the sight was worth it! And you did not refuse yourself the pleasure of a little input into the ambient…
    Loc43-4: You screamed your lungs out, sounding out the roar of your neighbours:
    Loc43-5: The fans clapped, screamed, and even jumped up cheering for their champions. You jumped and yelled together with everyone else:
    Loc43-6: Everyone were screaming their heads off and you decided not to stand apart from the crowd:
    Loc43-7: The noise was overwhelming, but you did your best to sound them out:
    Loc43-8: It was noisy as hell, and soon you were caught in the madness as well:
    Loc43-9: Your own aria sounded out the numerous choir of other spectators:
    Loc43-10: Just like everyone else you gladly let your emotions go:
    эффект: P22(Y) = {[1..10]}
    показ: P14,P15,P16,P17
  -> Path196 => Loc75  вер=1 порядок=5
       текст: Come on!!!
       условия: P22(Y) 1..1
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path216 => Loc75  вер=1 порядок=5
       текст: Go-go-go!!!
       условия: P22(Y) 4..4
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path217 => Loc75  вер=1 порядок=5
       текст: Come on, do it?!!
       условия: P22(Y) 10..10
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path218 => Loc75  вер=1 порядок=5
       текст: Faster!!!
       условия: P22(Y) 7..7
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path219 => Loc75  вер=1 порядок=5
       текст: Go for it, boy!!!
       условия: P22(Y) 9..9
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path241 => Loc75  вер=1 порядок=5
       текст: Move your ass!!!
       условия: P22(Y) 3..3
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path242 => Loc75  вер=1 порядок=5
       текст: Show'em boy!!!
       условия: P22(Y) 6..6
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path243 => Loc75  вер=1 порядок=5
       текст: Kill'em all!!!
       условия: P22(Y) 2..2
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path244 => Loc75  вер=1 порядок=5
       текст: Full speed ahead!!!
       условия: P22(Y) 5..5
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}
  -> Path245 => Loc75  вер=1 порядок=5
       текст: Come on, move it, boy, move it!!!
       условия: P22(Y) 8..8
       эффект: P14(Janizary) = {[p14]+([p18]-[41..80])/20}
       эффект: P15(Runner) = {[p15]+([p19]-[41..80])/20}
       эффект: P16(Penchekryak) = {[p16]+([p20]-[41..80])/20}
       эффект: P17(Tamerlane) = {[p17]+([p21]-[41..80])/20}

### Loc46 [пустая]
  -> Path156 => Loc63  вер=2 порядок=5
       условия: P8(Guards' attitude) 0..29
  -> Path157 => Loc58  вер=1 порядок=5
       условия: P8(Guards' attitude) 0..39
  -> Path158 => Loc59  вер=1 порядок=5
       условия: P8(Guards' attitude) 10..59
  -> Path159 => Loc60  вер=1 порядок=5
       условия: P8(Guards' attitude) 30..79
  -> Path160 => Loc61  вер=1 порядок=5
       условия: P6(Intellect) 50..100; P7(Authorities' attitude) 56..100; P8(Guards' attitude) 60..100
  -> Path161 => Loc62  вер=1 порядок=5
       условия: P6(Intellect) 80..100; P7(Authorities' attitude) 60..100; P8(Guards' attitude) 50..100
  -> Path162 => Loc64  вер=1 порядок=5
       условия: P8(Guards' attitude) 40..89
  -> Path163 => Loc65  вер=1 порядок=5
       условия: P8(Guards' attitude) 70..100
  -> Path180 => Loc68  вер=1 порядок=5
       условия: P8(Guards' attitude) 30..69

### Loc47 [пустая]
  -> Path261 => Loc91  вер=1 порядок=5

### Loc48 [пустая]
  -> Path33 => Loc89  вер=1 порядок=5
       ответ: You decided to get some belletristic reading - point one: it won't be so boring here then, point two: the authorities will think better of you. The interesting …
       эффект: P4(Health) = {[p4]+[0..2]}
       эффект: P9(Reputation) = {[p9]-[1..4]}
       эффект: P6(Intellect) = {[p6]+[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..5]}
       эффект: P8(Guards' attitude) = {[p8]-[1..4]}
  -> Path65 => Loc89  вер=1 порядок=5
       ответ: Today you started reading scientific literature hoping that this will make the best possible impression on the prison authorities. And that was exactly what hap…
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P9(Reputation) = {[p9]-[3..8]}
       эффект: P6(Intellect) = {[p6]+[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..8]}
  -> Path66 => Loc89  вер=1 порядок=5
       ответ: You stuck to comic books. Not really a smart reading, but you had yourself a good laugh and were feeling much better.
       эффект: P4(Health) = {[p4]+[3..7]}
       эффект: P9(Reputation) = {[p9]+[0..1]}
       эффект: P6(Intellect) = {[p6]-[1..3]}
  -> Path67 => Loc30  вер=0.3 проходов<=2 порядок=5
       условия: P8(Guards' attitude) 0..60; P10(Stoolie) 0..0
  -> Path116 => Loc38  вер=0.4 проходов<=1 порядок=5
       ответ: You came into the library and started digging in the old books hoping to find something useful there. Finally you ran into an old Gaalian manuscript, or rather …
       условия: P27(Cockroach) 0..0
       эффект: P9(Reputation) = {[p9]-[0..1]}
       эффект: P6(Intellect) = {[p6]+[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]+[0..2]}
  -> Path251 => Loc89  вер=1 порядок=5
       ответ: You took a book called <clr>"The Criminal Code in the Understanding of Different Races" <clrEnd>, hoping that this would make a good impression on the prison au…
       эффект: P9(Reputation) = {[p9]-[5..7]}
       эффект: P6(Intellect) = {[p6]+[1..4]}
       эффект: P7(Authorities' attitude) = {[p7]+[5..7]}
  -> Path252 => Loc89  вер=2 порядок=5
       ответ: You started reading the <clr>Criminal Code<clrEnd>, hoping to make a good impression on the prison authorities. However the guards who were hostile to you repor…
       условия: P8(Guards' attitude) 0..39
       эффект: P9(Reputation) = {[p9]+[3..5]}
       эффект: P6(Intellect) = {[p6]+[3..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[7..11]}
  -> Path287 => Loc89  вер=1 порядок=5
       ответ: You decided to read some romantic fiction intended for housewives. After three hours of intense reading you became a lot more stupid. The authorities appreciate…
       условия: P6(Intellect) 0..49
       эффект: P6(Intellect) = {[p6]-[2..5]}
       эффект: P9(Reputation) = {[p9]-[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..4]}
       эффект: P8(Guards' attitude) = {[p8]-[0..2]}
  -> Path309 => Loc89  вер=1 порядок=5
       ответ: You picked a book of jokes. Not really an intellectual reading, but it improved your spirits, and in the evening you told all the best jokes to your cellmates, …
       эффект: P4(Health) = {[p4]+[2..5]}
       эффект: P9(Reputation) = {[p9]+[1..4]}
       эффект: P6(Intellect) = {[p6]-[0..2]}
  -> Path383 => Loc89  вер=1 порядок=5
       ответ: You sat down to read a very ancient novel called "War and Peace". Unfortunately already on page 20 you were fast asleep. The authorities did not like it, but yo…
       эффект: P4(Health) = {[p4]+[3..5]}
       эффект: P5(Strength) = {[p5]+[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..4]}
  -> Path385 => Loc89  вер=0.5 порядок=5
       ответ: Today you ran into a very exotic book called "Teach Yourself to Speak Menzol" by R. McAlister. You studied it for some three hours and finally managed to perfec…
       эффект: P9(Reputation) = {[p9]+[0..3]}
       эффект: P6(Intellect) = {[p6]+[0..3]}
       эффект: P7(Authorities' attitude) = {[p7]+[0..3]}
       эффект: P8(Guards' attitude) = {[p8]+[0..3]}
  -> Path386 => Loc89  вер=1 порядок=5
       ответ: Today you took one of the volumes of the Big Galaxy Encyclopaedia and started reading about all sorts of things at random. By evening your head started aching b…
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]-[3..5]}
       эффект: P6(Intellect) = {[p6]+[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[0..1]}

### Loc49 [пустая]
  -> Path50 => Loc70  вер=1 порядок=5
       ответ: You did some training and developed a bit of a muscle. You strength was growing.
       условия: P9(Reputation) 20..99
       эффект: P5(Strength) = {[p5]+[8..13]}
  -> Path53 => Loc70  вер=1 порядок=5
       ответ: You did some training and developed a bit of a muscle. You strength was growing.  Although closer to the end of the training, you overdid it and dropped the bar…
       условия: P5(Strength) 0..59; P9(Reputation) 20..99
       эффект: P5(Strength) = {[p5]+[5..10]}
       эффект: P4(Health) = {[p4]-[2..5]}
  -> Path193 => Loc70  вер=4 порядок=5
       ответ: A group of huge Maloqs met you at the entrance: /  / - Say, <Ranger>, wassup with that?! Punks are not wanted here!!!  /  / You tried to argue, but quickly shut…
       условия: P5(Strength) 0..70; P9(Reputation) 1..19
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P4(Health) = {[p4]-[3..9]}
  -> Path334 => Loc70  вер=2 порядок=5
       ответ: You did a good work-out and built up some muscle.
       условия: P5(Strength) 70..100
       эффект: P5(Strength) = {[p5]+[10..15]}
  -> Path384 => Loc70  вер=1 порядок=5
       ответ: The moment you mounted the exercycle, the lights went out in the gym and a drunken Maloq voice said: /  / - Go back to your library, <Ranger>! We really don't l…
       условия: P5(Strength) 0..70; P6(Intellect) 60..100; P9(Reputation) 20..99
       эффект: P5(Strength) = {[p5]+[3..7]}
  -> Path416 => Loc70  вер=1 порядок=5
       ответ: <clr>Power attracts power<clrEnd> - this was the rule which you decided to use when working out. The bigger the muscle mass, the more trouble you will be able t…
       условия: P5(Strength) 70..100; P9(Reputation) 20..99
       эффект: P5(Strength) = {[p5]+[12..17]}

### Loc50 [обычная]
    Loc50-1: Now you had to figure out what were you going to order. The jail menu looked as follows: / 1. You can eat for absolutely <clr>free<clrEnd>. A standard portion o…
    эффект: P28(Money) = {[p28]}
  -> Path51 => Loc69  вер=1 порядок=1
       текст: Pay {15} cr and get an "OG portion"
       ответ: Today you were resting like a real man. Lots of nutritious food, meat, and all that - dirt cheap. Nonetheless the other inmates were not looking kindly upon you…
       условия: P9(Reputation) 1..60; P28(Money) 15..1000000000
       эффект: P9(Reputation) = {[p9]-[5..10]}
       эффект: P28(Money) -15
       эффект: P4(Health) = {[p4]+[10..14]}
  -> Path54 => Loc69  вер=1
       текст: Take a free set
       ответ: The skilly was as disgusting as only a skilly could be. You ate, rested, and felt a little better.
       эффект: P4(Health) = {[p4]+[3..5]}
  -> Path189 => Loc69  вер=1 порядок=1
       текст: Pay {15} cr and get an "OG portion"
       ответ: Being the boss you let yourself relax for all it was worth. The punks were bringing you food and you sharked it like there was no tomorrow, all of that was quit…
       условия: P9(Reputation) 60..99; P28(Money) 15..1000000000
       эффект: P9(Reputation) = {[p9]+[1..3]}
       эффект: P28(Money) -15
       эффект: P4(Health) = {[p4]+[10..14]}
       эффект: P8(Guards' attitude) = {[p8]-[3..8]}
  -> Path391 => Loc69  вер=1 порядок=2
       текст: Pay {40} cr for the "champ dinner"
       ответ: You ate very well for that money. No wonder, {100} cr - is a monthly fee of your average guard. You've recovered you strength and your spirits grew high. A cham…
       условия: P11(Hand-to-hand combat experience) 1..5; P28(Money) 40..1000000000
       эффект: P28(Money) = {[p28]-40}
       эффект: P4(Health) = {[p4]+[16..20]}
       эффект: P8(Guards' attitude) = {[p8]-[5..10]}
  -> Path392 => Loc23  вер=1 порядок=2
       текст: Pay {40} cr for the "champ dinner"
       ответ: No one has expected such an impudence from you. You haven't been to the ring once! By ordering a "champion's dinner", you insulted the other fighters and they j…
       условия: P11(Hand-to-hand combat experience) 0..0; P28(Money) 40..1000000000
       эффект: P28(Money) = {[p28]-40}
       эффект: P4(Health) = {[p4]-[16..20]}
       эффект: P9(Reputation) = {[p9]-[1..5]}
  -> Path393 => Loc69  вер=1 порядок=8
       текст: Let's have a party! :Let's treat everyone, after all it's only {800} cr!
       ответ: There was a huge bash. Everyone was having fun and eating for free. You have instantly become a respected man among all the inmates and were having fun like a t…
       условия: P28(Money) 800..1000000000
       эффект: P28(Money) = {[p28]-800}
       эффект: P4(Health) = {[p4]+[16..20]}
       эффект: P9(Reputation) = {[p9]+[50..70]}
       эффект: P7(Authorities' attitude) = {[p7]-[7..12]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}
  -> Path415 => Loc69  вер=1 проходов<=1 порядок=6
       текст: Treat the tired guards at the entrance - {100} cr!
       ответ: - This is a token of gratitude to our honourable officers on guard of the prison's peace, - you said half-mockingly, - I would like to express my gratitude by t…
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) -100
       эффект: P9(Reputation) = {[p9]-[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]-[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[10..15]}
  -> Path421 => Loc69  вер=1 порядок=9
       текст: Try the treats from the inmates
       ответ: Indeed the lunch was swell. Back on the freeside this would have probably been enough to organise a wedding party. Roasted meat of milk oinkers, seafood delicac…
       условия: P37(canteen) 1..1
       эффект: P37(canteen) -1
       эффект: P4(Health) = {[p4]+[10..20]}
       эффект: P9(Reputation) = {[p9]-[3..8]}
       эффект: P5(Strength) = {[p5]+[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[7..12]}
       эффект: P8(Guards' attitude) = {[p8]-[3..8]}
  -> Path437 => Loc69  вер=1 порядок=7
       текст: Treat your cellmate to the spirit
       ответ: You got the spirit and sat down together with your cellmates at a separate table in the far corner. Man that was one heck of a party! As a result you understood…
       условия: P31(Alcohol) 1..1
       эффект: P31(Alcohol) -1 [скрыт]
       эффект: P35(x) = {0}

### Loc52 [обычная]
    Loc52-1: Several Faeyans, Gaalians, and Humans are playing some weird card game. You can join them. Or else you could opt for a game of dice with a dark-faced old human …
    скрыт: P24
  -> Path45 => Loc26  вер=1 порядок=5
       текст: Play cards
       эффект: P9(Reputation) = {[p9]+[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]-[0..1]}
       эффект: P8(Guards' attitude) = {[p8]-[0..1]}
  -> Path46 => Loc26  вер=3 порядок=5
       текст: Play cards
       ответ: You headed towards the gamblers. But a huge Maloq tripped you and laughed heartily as he watched you sprawl on the floor. / - Hey, <Ranger>, you are a punk. Car…
       условия: P5(Strength) 0..40; P9(Reputation) 1..59
       эффект: P4(Health) -2
       эффект: P7(Authorities' attitude) = {[p7]-[0..1]}
       эффект: P8(Guards' attitude) = {[p8]-[0..1]}
  -> Path288 => Loc98  вер=1 порядок=5
       текст: Play dice
  -> Path310 => Loc102  вер=5 порядок=5
       текст: Play cards
       ответ: A huge Maloq, an accomplice of the Don, walked over to you: / - Today the Don will play. He will not sit at one table with a scumbag, like you! So, <Ranger>, ge…
       условия: P9(Reputation) 1..19
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P4(Health) = {[p4]-[1..4]}
  -> Path361 => Loc112  вер=1 порядок=5
       текст: Play cards
       ответ: The moment you sat at the table the guards broke into the cell and had everyone down on the floor.. / - Time to put an end to this card plague in this prison! -…
       условия: P6(Intellect) 70..100; P7(Authorities' attitude) 0..39; P8(Guards' attitude) 0..49; P9(Reputation) 70..99
       эффект: P6(Intellect) = {[p6]-[8..12]}
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P4(Health) = {[p4]-[12..17]}
       эффект: P1(Days) +7
       эффект: P3(Term) -7
       эффект: P5(Strength) = {[p5]-[8..12]}
       эффект: P22(Y) = 0
  -> Path594 => Loc112  вер=5 порядок=5
       текст: Play cards
       ответ: The moment you sat at the table the guards broke into the cell and had everyone down on the floor.. / - Time to put an end to this card plague in this prison! -…
       условия: P6(Intellect) 70..100; P7(Authorities' attitude) 0..19; P8(Guards' attitude) 0..29; P9(Reputation) 70..99
       эффект: P6(Intellect) = {[p6]-[8..12]}
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P4(Health) = {[p4]-[12..17]}
       эффект: P1(Days) +7
       эффект: P3(Term) -7
       эффект: P5(Strength) = {[p5]-[8..12]}
       эффект: P22(Y) = 0

### Loc53 [пустая]
  -> Path145 => Loc40  вер=5 порядок=5
       эффект: P27(Cockroach) = {[p27]+[5..10]+[p27]/[10..15]}
  -> Path146 => Loc54  вер=3 порядок=5
       условия: P27(Cockroach) 80..100
  -> Path147 => Loc54  вер=1 порядок=5
       условия: P27(Cockroach) 70..100
  -> Path148 => Loc54  вер=5 порядок=5
       условия: P27(Cockroach) 90..100

### Loc54 [обычная]
    Loc54-1: You were running the poor insect all through the day forcing it to develop unimaginable speed until you drove it to a seizure. The veterinarians could do nothin…
    эффект: P27(Cockroach) -100
  -> Path363 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc55 [обычная]
    Loc55-1: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - If you don't want to do any hard work, make frie…
    Loc55-2: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Good food will help you improve your health, but…
    Loc55-3: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - They say, that the last fist-fighting champion w…
    Loc55-4: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - A cellmate read it to me from some newspaper tha…
    Loc55-5: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Cockroach races are a traditional entertainment …
    Loc55-6: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - The jail gym has excellent equipment and by work…
    Loc55-7: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - They say, that fools are always lucky, but I wou…
    Loc55-8: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Try not to lose your cellmates' respect! They do…
    Loc55-9: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom:  / - During the weekends the real criminals like to …
    Loc55-10: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - On Sundays the prison authorities become a nice …
  -> Path258 => Loc90  вер=1 [всегда видна] порядок=5
       текст: Throw another 5 cr to the blind man
       условия: P28(Money) 5..1000000000
       эффект: P28(Money) -5
  -> Path271 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc57 [пустая]
  -> Path155 => Loc23  вер=1 порядок=5
       текст: Go back to the cell

### Loc58 [обычная]
    Loc58-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path166 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path174 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day cleaning the garbage at the jail dump site. A dull and dirty job as it was, it surely did not help your reputation among the inmates, b…
       условия: P27(Cockroach) 0..0
       эффект: P27(Cockroach) = {[10..25]}
       эффект: P9(Reputation) = {[p9]*2/3}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..5]}
       эффект: P8(Guards' attitude) = {[p8]+[2..4]}
  -> Path184 => Loc67  вер=4
       текст: Go to work
       ответ: You spent the entire day cleaning the garbage at the jail dumpsite. A dull and dirty job as it was, it surely did not help your reputation among the inmates, bu…
       эффект: P9(Reputation) = {[p9]*2/3}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..5]}
       эффект: P8(Guards' attitude) = {[p8]+[2..4]}

### Loc59 [обычная]
    Loc59-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path167 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path173 => Loc67  вер=1
       текст: Go to work
       ответ: You were lead to the hospital. Fiddling about with the sick inmates was the dullest job there could possibly be, and you were openly flunking, which did not add…
       эффект: P9(Reputation) -2
       эффект: P7(Authorities' attitude) -2
  -> Path183 => Loc67  вер=2
       текст: Go to work
       ответ: You went to the hospital. There you took your task seriously and took good care of the sick. As a result you caught yourself a cold, your throat went sore, but …
       эффект: P4(Health) = {[p4]-[7..12]}
       эффект: P9(Reputation) +1
       эффект: P7(Authorities' attitude) = {[p7]+[3..5]}
       эффект: P8(Guards' attitude) = {[p8]+[1..3]}

### Loc60 [обычная]
    Loc60-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path168 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path175 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day unloading the heavy bags with food for the canteen. This took quite some effort and by the end of the day you were completely spent. Bu…
       условия: P5(Strength) 30..100
       эффект: P5(Strength) = {[p5]-[8..12]}
       эффект: P4(Health) = {[p4]-[3..5]}
       эффект: P9(Reputation) -7%
       эффект: P7(Authorities' attitude) = {[p7]+[5..9]}
       эффект: P8(Guards' attitude) = {[p8]+[3..5]}
  -> Path335 => Loc67  вер=2
       текст: Go to work
       ответ: You spent the entire day unloading the heavy bags with food for the canteen. This took quite some effort and by the end of the day you were completely spent. Mo…
       условия: P5(Strength) 0..50
       эффект: P5(Strength) = {[p5]-[5..10]}
       эффект: P4(Health) = {[p4]-[3..5]}
       эффект: P9(Reputation) -5%
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}
       эффект: P8(Guards' attitude) = {[p8]+[1..3]}
  -> Path356 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day unloading the heavy bags with food for the canteen. The work was very hard and you ended up hanging back on most of it, which did not g…
       условия: P5(Strength) 0..29
       эффект: P5(Strength) -2
       эффект: P7(Authorities' attitude) = {[p7]-[3..5]}
       эффект: P8(Guards' attitude) -2

### Loc61 [обычная]
    Loc61-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path171 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path178 => Loc67  вер=1
       текст: Go to work
       ответ: You were repairing the warden's car really trying to do your best. The warden remained very content with you, but the other inmates were giving you the looks wh…
       эффект: P9(Reputation) -15%
       эффект: P7(Authorities' attitude) = {[p7]+[8..12]}

### Loc62 [обычная]
    Loc62-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path172 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path179 => Loc67  вер=1
       текст: Go to work
       ответ: You wrote an excellent essay for the warden's son, spicing it with slightly modified details of your own biography. And the prison warden was so impressed, that…
       эффект: P4(Health) = {[p4]+[8..12]}
       эффект: P9(Reputation) -25%
       эффект: P7(Authorities' attitude) = {[p7]+[20..25]}

### Loc63 [обычная]
    Loc63-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path164 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path165 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day cleaning the refuse in the huge jail toilet. The work was not too difficult, but it was very monotonous and dirty. You reputation dropp…
       эффект: P9(Reputation) = {[p9]/2}
       эффект: P6(Intellect) = {[p6]-[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..5]}
       эффект: P8(Guards' attitude) = {[p8]+[3..5]}

### Loc64 [обычная]
    Loc64-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path169 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path176 => Loc67  вер=1 порядок=5
       текст: Go to work
       ответ: Together with a bunch of other inmates you went to paint the jail fence. You tried to distinguish yourself from the rest drawing some weird patterns on the fenc…
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}
       эффект: P8(Guards' attitude) = {[p8]-[15..20]}
  -> Path336 => Loc67  вер=2
       текст: Go to work
       ответ: Together with a bunch of other inmates you went to paint the jail fence. You tried to distinguish yourself from the rest drawing some weird patterns on the fenc…
       эффект: P9(Reputation) -10%
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) +1
  -> Path357 => Loc67  вер=2
       текст: Go to work
       ответ: Together with other inmates you went over to paint the jail fence. You did not put much effort into it, but nonetheless coped with this rather easy task.
       эффект: P9(Reputation) = {[p9]-[3..5]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..4]}
       эффект: P8(Guards' attitude) +1
  -> Path527 => Loc67  вер=2
       текст: Go to work
       ответ: You did not put a lot of effort in your work looking mostly at your feet and thinking about what you could do. Suddenly you spotted a stick with little holes in…
       условия: P32(Pipe) 0..0
       эффект: P32(Pipe) = {1} [показ]

### Loc65 [обычная]
    Loc65-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path170 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path177 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day working in the kitchen and stealthily eating the remains of all kinds of dishes. The catering surely helped your health and strength. O…
       эффект: P4(Health) = {[p4]+[5..9]}
       эффект: P9(Reputation) = {[p9]-[5..7]}
       эффект: P5(Strength) = {[p5]+[1..4]}
       эффект: P7(Authorities' attitude) = {[p7]+[0..3]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P28(Money) = {[p28]+100}
  -> Path186 => Loc67  вер=4
       текст: Go to work
       ответ: You spent the entire day working in the kitchen and stealthily eating the remains of all kinds of dishes. The catering surely helped your health and strength. O…
       эффект: P4(Health) = {[p4]+[5..9]}
       эффект: P9(Reputation) = {[p9]-[5..7]}
       эффект: P5(Strength) = {[p5]+[1..4]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}
  -> Path187 => Loc67  вер=9
       текст: Go to work
       ответ: You spent the entire day working in the kitchen and stealthily eating the remains of all kinds of dishes. The catering surely helped your health and strength.  …
       условия: P9(Reputation) 1..19
       эффект: P9(Reputation) -1
       эффект: P4(Health) = {[p4]+[5..9]}
       эффект: P5(Strength) = {[p5]+[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[10..15]}
  -> Path188 => Loc67  вер=1
       текст: Go to work
       ответ: You spent the entire day working in the kitchen and stealthily eating the remains of all kinds of dishes. The catering surely helped your health and strength. O…
       условия: P27(Cockroach) 0..0
       эффект: P27(Cockroach) = {[30..55]}
       эффект: P4(Health) = {[p8]+[5..9]}
       эффект: P9(Reputation) = {[p9]-[5..7]}
       эффект: P5(Strength) = {[p5]+[1..4]}
       эффект: P7(Authorities' attitude) = {[p7]+[1..3]}

### Loc66 [обычная]
    Loc66-1: - I am not going to do this work! - you declared to the guards. / Not giving it much thought (in fact they don't think to often or for too long anyway), they ga…
    эффект: P4(Health) = {[p4]-[7..12]}
    эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
    эффект: P8(Guards' attitude) = {[p8]-[8..12]}
    эффект: P9(Reputation) = {[p9]+[10..20]}
  -> Path257 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc67 [пустая]
  -> Path256 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc68 [обычная]
    Loc68-1: The guards were quarrelling with each other as part of the regular routine throwing an occasional glance at the long row of the inmates, who were awaiting their…
  -> Path181 => Loc66  вер=1 порядок=1
       текст: Refuse to work
  -> Path182 => Loc67  вер=1
       текст: Go to work
       ответ: You were given a device that emits toxic gas, and were sent about the cells to disinfect everyone and everything there. You managed just fine, until you acciden…
       эффект: P9(Reputation) -15
       эффект: P7(Authorities' attitude) +5
       эффект: P8(Guards' attitude) +10
  -> Path185 => Loc67  вер=2
       текст: Go to work
       ответ: You were given a device that emits toxic gas, and were sent about the cells to disinfect everyone and everything there. You managed to do so successfully, but s…
       эффект: P4(Health) -7
       эффект: P7(Authorities' attitude) +5
       эффект: P8(Guards' attitude) +2
  -> Path355 => Loc67  вер=2
       текст: Go to work
       ответ: You were given a device that emits toxic gas, and were sent about the cells to disinfect everyone and everything there. You managed to carry your task out well,…
       условия: P6(Intellect) 50..100
       эффект: P4(Health) -2
       эффект: P7(Authorities' attitude) +5

### Loc69 [пустая]
  -> Path255 => Loc28  вер=3 порядок=5
       текст: Go back to the cell, taking a spoon and a fork with you
       ответ: You managed to slip <clr>a fork and a spoon<clrEnd> into your pocket and carry them out of the canteen unnoticed. Now you had to find a good way to apply these …
       условия: P30(Fork and spoon) 0..0
       эффект: P30(Fork and spoon) +1 [показ]
  -> Path602 => Loc28  вер=1 порядок=5
       текст: Go back to the cell
  -> Path603 => Loc28  вер=2 порядок=5
       текст: Go back to the cell, taking a spoon and a fork with you
       ответ: You slipped the fork and spoon into your pocket and tried to sneak out of the canteen. But it was not that easy. The guard a the door stopped you and prevented …
       условия: P30(Fork and spoon) 0..0
       эффект: P4(Health) = {[p4]-[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..3]}
       эффект: P8(Guards' attitude) = {[p8]-[1..3]}
       показ: P30

### Loc70 [пустая]
  -> Path254 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc73 [обычная]
    Loc73-1: Finally the roster was complete. The chief referee announced the entire list: / - Gentlemen, make your stakes!!!  / On the first track is Janizary the Third, a …
  -> Path221 => Loc86  вер=1 порядок=9
       текст: Just watch
       эффект: P24(Stake) = 0
  -> Path222 => Loc85  вер=1 порядок=1
       текст: Stake 100 cr
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P24(Stake) +100
  -> Path223 => Loc85  вер=1 порядок=3
       текст: Stake 50 cr
       условия: P28(Money) 50..1000000000
       эффект: P28(Money) -50
       эффект: P24(Stake) +50
  -> Path224 => Loc85  вер=1 порядок=5
       текст: Stake 20 cr
       условия: P28(Money) 20..1000000000
       эффект: P28(Money) -20
       эффект: P24(Stake) +20
  -> Path225 => Loc85  вер=1 порядок=7
       текст: Stake 10 cr
       условия: P28(Money) 10..1000000000
       эффект: P28(Money) -10
       эффект: P24(Stake) +10

### Loc74 [обычная]
    Loc74-1: The crazy fans of all races gathered together around a large tub, made especially for the roaches. The tub was divided with wooden planks into four tracks, and …
    эффект: P14(Janizary) -9 [скрыт]
    эффект: P15(Runner) -9 [скрыт]
    эффект: P16(Penchekryak) -9 [скрыт]
    эффект: P17(Tamerlane) -9 [скрыт]
    эффект: P18(X1) = {[67..95]} [скрыт]
    эффект: P19(X2) = {[65..91]} [скрыт]
    эффект: P20(X3) = {[63..87]} [скрыт]
    эффект: P21(X4) = {[61..83]} [скрыт]
    эффект: P22(Y) = 0
    эффект: P23(X0) = 0 [показ]
    эффект: P24(Stake) = 0
  -> Path124 => Loc86  вер=1 порядок=5
       текст: You have to put your pet on the race too. What if it wins?!!
       ответ: - An excellent species! - the head judge seemed delighted at the sight of your pet. - It will run on the fourth track. What's it called? / And then you remember…
       условия: P27(Cockroach) 56..100
       эффект: P21(X4) = {[p27]}
       эффект: P23(X0) +5
  -> Path194 => Loc73  вер=1 порядок=5
       текст: Put a stake
  -> Path195 => Loc73  вер=1 порядок=5
       текст: You have to put your pet on the race too. What if it wins?!!
       ответ: - No, your roach is too weak yet, train it some more! - the head judge said. - We got better runners here! But sure you can gamble.
       условия: P27(Cockroach) 1..60

### Loc75 [пустая]
  -> Path197 => Loc43  вер=1000 порядок=5
       условия: P14(Janizary) 0..8; P15(Runner) 0..8; P16(Penchekryak) 0..8; P17(Tamerlane) 0..8
  -> Path199 => Loc76  вер=1 порядок=5
       условия: логика {[p14]<=[p15] and [p16]<=[p17]}
  -> Path200 => Loc79  вер=1 порядок=5
       условия: логика {[p14]>=[p15] and [p16]<=[p17]}
  -> Path201 => Loc77  вер=1 порядок=5
       условия: логика {[p14]>=[p15] and [p16]>=[p17]}
  -> Path202 => Loc78  вер=1 порядок=5
       условия: логика {[p14]<=[p15] and [p16]>=[p17]}

### Loc76 [пустая]
  -> Path207 => Loc81  вер=1 порядок=5
       условия: логика {[p15]>=[p17]}
  -> Path208 => Loc83  вер=1 порядок=5
       условия: логика {[p15]<=[p17]}

### Loc77 [пустая]
  -> Path205 => Loc82  вер=1 порядок=5
       условия: логика {[p14]<=[p16]}
  -> Path206 => Loc80  вер=1 порядок=5
       условия: логика {[p14]>=[p16]}

### Loc78 [пустая]
  -> Path203 => Loc81  вер=1 порядок=5
       условия: логика {[p15]>=[p16]}
  -> Path204 => Loc82  вер=1 порядок=5
       условия: логика {[p15]<=[p16]}

### Loc79 [пустая]
  -> Path209 => Loc83  вер=1 порядок=5
       условия: логика {[p14]<=[p17]}
  -> Path210 => Loc80  вер=1 порядок=5
       условия: логика {[p14]>=[p17]}

### Loc80 [пустая]
    Loc80-1: Suddenly, one judge shout snubbed all the fans. "Finish!" – yelled big maloq, and the walls were shaking.
  -> Path211 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS JANIZARY III". / You won! With great pleasure you took the {2*[p24]} cr from the …
       условия: P23(X0) ∈[1]
       эффект: P28(Money) = {[p28]+2*[p24]}
  -> Path231 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS JANIZARY III". / Your pet could not offer any notable resistance to the winner, a…
       условия: P23(X0) ∈[5]
       эффект: P27(Cockroach) = {[p27]-[5..15]}
  -> Path239 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS JANIZARY III". / You lost [p24] cr! That's awful.
       условия: P23(X0) ∉[1, 5]; P24(Stake) 1..100
  -> Path394 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS JANIZARY III ". / You could of won a pot of money, if you had made a stake!
       условия: P23(X0) ∉[1, 5]; P24(Stake) 0..0

### Loc81 [пустая]
    Loc81-1: Suddenly, one judge shout snubbed all the fans. "Finish!" – yelled big maloq, and the walls were shaking.
  -> Path212 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS RAKHISH RUNNER ". / You won! With great pleasure you took the {5*[p24]/2} cr from…
       условия: P23(X0) ∈[2]
       эффект: P28(Money) = {[p28]+5*[p24]/2}
  -> Path232 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS RAKHISH RUNNER ". / Your pet could not offer any notable resistance to the winner…
       условия: P23(X0) ∈[5]
       эффект: P27(Cockroach) = {[p27]-[5..15]}
  -> Path238 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS RAKHISH RUNNER ". / You lost [p24] cr! That's awful.
       условия: P23(X0) ∉[2, 5]; P24(Stake) 1..100
  -> Path395 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS RAKHISH RUNNER".  / You could of won a pot of money, if you had made a stake!
       условия: P23(X0) ∉[2, 5]; P24(Stake) 0..0

### Loc82 [пустая]
    Loc82-1: Suddenly, one judge shout snubbed all the fans. "Finish!" – yelled big maloq, and the walls were shaking.
  -> Path213 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS PENCHEKRYAK THE IDEAL". / Your pet could not offer any notable resistance to the …
       условия: P23(X0) ∈[5]
       эффект: P27(Cockroach) = {[p27]-[5..15]}
  -> Path233 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS PENCHEKRYAK THE IDEAL". / You won! With great pleasure you took the {3*[p24]} cr …
       условия: P23(X0) ∈[3]
       эффект: P28(Money) = {[p28]+3*[p24]}
  -> Path237 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS PENCHEKRYAK THE IDEAL". / You lost [p24] cr! That's awful.
       условия: P23(X0) ∉[3, 5]; P24(Stake) 1..100
  -> Path396 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS PENCHEKRYAK THE IDEAL". / You could of won a pot of money, if you had made a stak…
       условия: P23(X0) ∉[3, 5]; P24(Stake) 0..0

### Loc83 [пустая]
    Loc83-1: Suddenly, one judge shout snubbed all the fans. "Finish!" – yelled big maloq, and the walls were shaking.
  -> Path214 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS TAMERLANE". / You lost [p24] cr! That's awful.
       условия: P23(X0) ∉[4, 5]; P24(Stake) 1..100
  -> Path234 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS TAMERLANE". / You won! With great pleasure you took the {4*[p24]} cr from the for…
       условия: P23(X0) ∈[4]
       эффект: P28(Money) = {[p28]+4*[p24]}
  -> Path235 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS THE ROACH". / Your pet did it! This was the sensation of the race. The jail radio…
       условия: P23(X0) ∈[5]
       эффект: P4(Health) = {[p4]+[1..5]}
       эффект: P9(Reputation) = {[p9]+[8..12]}
       эффект: P6(Intellect) = {[p6]+[3..5]}
       эффект: P7(Authorities' attitude) = {[p7]+[15..25]}
       эффект: P8(Guards' attitude) = {[p8]+[8..12]}
       эффект: P27(Cockroach) = {[p27]-[20..35]}
       эффект: P28(Money) = {[p28]+250}
  -> Path397 => Loc84  вер=1 порядок=5
       ответ: After a short discussion the referees passed out their verdict: "THE WINNER IS TAMERLANE". / You could of won a pot of money, if you had made a stake!
       условия: P23(X0) ∉[4, 5]; P24(Stake) 0..0

### Loc84 [пустая]
  -> Path246 => Loc23  вер=1 порядок=5
       текст: Discuss the race
       ответ: Till late in the evening the spectators were discussing the details of today's race, until the guard-on-duty told everyone to go to bed.
       эффект: P4(Health) = {[p4]+[0..3]} [показ]
       показ: P9,P5,P6,P7,P8,P11
       скрыт: P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24

### Loc85 [обычная]
    Loc85-1: - Who will it be? - the bookmaker asked taking the money from you.
    показ: P24
  -> Path226 => Loc86  вер=1 порядок=5
       текст: I'll stake on Penchekryak the Ideal!
       эффект: P23(X0) +3
  -> Path227 => Loc86  вер=1 порядок=8
       текст: I'll stake on Tamerlane!
       эффект: P23(X0) +4
  -> Path228 => Loc86  вер=1 порядок=1
       текст: I'll stake on Janizary III!
       эффект: P23(X0) +1
  -> Path229 => Loc86  вер=1 порядок=3
       текст: I'll stake on Rakhish Runner!
       эффект: P23(X0) +2

### Loc86 [обычная]
    Loc86-1: - Stakes are closed!!! No more stakes accepted! - the bookmaker announced. / The roaches picked by the referees lined up in their tracks. Finally the referee ca…
    скрыт: P4,P5,P6,P7,P8,P9,P11
    показ: P14,P15,P16,P17
  -> Path230 => Loc43  вер=1 порядок=5
       текст: Go!!!

### Loc88 [пустая]
  -> Path247 => Loc160  вер=1 порядок=5

### Loc89 [обычная]
    Loc89-1: At the exit you ran into a blind man with his hat sitting in front of him. / - Give 5 credits to the blind guy, and he'll give you some advice! - the blind-man …
  -> Path253 => Loc28  вер=1 порядок=5
       текст: Go back to the cell
  -> Path259 => Loc55  вер=1 [всегда видна] порядок=5
       текст: Throw 5 cr to the blind man
       условия: P28(Money) 5..1000000000
       эффект: P28(Money) -5
  -> Path518 => Loc154  вер=1 [всегда видна] порядок=5
       текст: Throw 5 cr to the blind man
       условия: P28(Money) 5..1000000000
       эффект: P28(Money) -5

### Loc90 [пустая]
  -> Path260 => Loc55  вер=1 порядок=5
  -> Path605 => Loc154  вер=1 порядок=5

### Loc91 [пустая]
    эффект: P22(Y) = 0
  -> Path262 => Loc170  вер=1 порядок=5

### Loc93 [обычная]
    Loc93-1: Today the jail criminal authorities came up with a new type of entertainment for themselves: the outcast races. Each of them has picked up a "horse" for himself…
  -> Path266 => Loc47  вер=1 [всегда видна] порядок=5
       текст: Buy your way out of the race for 100 cr
       ответ: The Don took the money and they let you be for today. Now you could take some rest.
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P4(Health) = {[p4]+[2..5]}
  -> Path267 => Loc47  вер=1 порядок=5
       текст: Refuse from attending
       ответ: You told the Don to go and shove it you know. The next second the Don accompanied by several other OG's was all over you giving you a sound battering. However t…
       условия: P5(Strength) 0..79
       эффект: P5(Strength) -3
       эффект: P4(Health) = {[p4]-[8..12]}
       эффект: P9(Reputation) = {[p9]+[4..8]}
  -> Path268 => Loc47  вер=1 порядок=5
       текст: Refuse from attending
       ответ: You told the Don to go and shove it you know, supporting your words with a mighty uppercut. The other OG's didn't have the guts to join in, seeing what you did …
       условия: P5(Strength) 70..100
       эффект: P9(Reputation) = {[p9]+[8..12]}
  -> Path269 => Loc47  вер=1 порядок=5
       текст: Let him mount you and run for all it's worth
       ответ: You did your utmost and finally made it first to the finish-line. You reputation dropped a good deal, but at least nobody was beating you like they did to other…
       эффект: P9(Reputation) -20%
       эффект: P5(Strength) = {[p5]-[7..10]}
       эффект: P6(Intellect) = {[p6]-[3..5]}
  -> Path270 => Loc47  вер=1 порядок=5
       текст: Let him mount you but not run to your full capacity.
       ответ: You were one of the last to make it to the finish-line. You weren't really tired but the Don was in proper fury and gave you a severe beating.
       эффект: P4(Health) = {[p4]-[5..9]}
       эффект: P9(Reputation) -1
       эффект: P5(Strength) -2

### Loc94 [пустая]
  -> Path321 => Loc91  вер=1 порядок=5

### Loc95 [обычная]
    Loc95-1: One of the real criminals approached you. / - Listen, <Ranger>, from time to time all of the inmates must throw in some money into the common bank. Especially t…
  -> Path313 => Loc96  вер=1 [всегда видна] порядок=5
       текст: Pay 100 cr
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
  -> Path314 => Loc33  вер=2 [всегда видна] порядок=5
       текст: Refuse and start a fight
       ответ: You tried to start a fight, but the OG had you knocked flat on the floor in a single jab, causing the cell to awe. Without further ado he proceeded to search yo…
       условия: P5(Strength) 0..39; P28(Money) 150..1000000000
       эффект: P28(Money) = {[p28]-150}
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P9(Reputation) -3
  -> Path315 => Loc33  вер=1 [всегда видна] порядок=5
       текст: Refuse and start a fight
       ответ: You jabbed the OG in the face, but his friends rushed for help, and a serious fight broke out. As a result you spent a lot of strength and health, but you kept …
       условия: P5(Strength) 70..100
       эффект: P5(Strength) = {[p5]-[3..7]}
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P7(Authorities' attitude) -1
       эффект: P8(Guards' attitude) -1
  -> Path316 => Loc96  вер=1 порядок=5
       текст: Say that you do not have 100 cr, and offer a smaller sum
       ответ: Forcing you to turn out your pockets and seeing that you in fact did not have the money, the OG said: /  / - Alright, <Ranger>, live. Gimme what you've got! I'l…
       условия: P28(Money) 1..99
       эффект: P28(Money) = {0}
  -> Path318 => Loc33  вер=1 порядок=5
       текст: Tell'em you don't have the money now
       ответ: Forcing you to turn out all of your pockets and seeing that you actually had no money on you the OG screamed: / - Are you screwing around with me, <Ranger>, are…
       условия: P28(Money) 0..0
       эффект: P4(Health) -10
  -> Path369 => Loc33  вер=2 [всегда видна] порядок=5
       текст: Refuse and start a fight
       ответ: You punched the OG in the face and but his friends rushed forward and gave you a sound beating. However you kept your money and your reputation has grown somewh…
       условия: P5(Strength) 10..75
       эффект: P4(Health) = {[p4]-[10..20]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
  -> Path370 => Loc33  вер=2 [всегда видна] порядок=5
       текст: Refuse and start a fight
       ответ: You tried to stand up to him, but the OG had you down on the floor with one punch to the great amusement of everyone around you. Without further ado the OG sear…
       условия: P5(Strength) 0..39; P28(Money) 0..150
       эффект: P28(Money) = 0
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P9(Reputation) -3

### Loc96 [обычная]
    Loc96-1: Today you finally have some time for yourself. What are you going to do?
  -> Path281 => Loc94  вер=1 порядок=5
       текст: Write an amnesty petition
       ответ: You spent the entire day writing an amnesty plea. The result looked quite good to you. But in the evening one of the guards came over to you: / - That was a ver…
       условия: P6(Intellect) 30..100; P8(Guards' attitude) 0..49
  -> Path282 => Loc94  вер=3 порядок=5
       текст: Write an amnesty petition
       ответ: You spent the entire day writing an amnesty plea. The result looked quite good to you. But in the evening one of the guards came over to you: / - That was a ver…
       условия: P6(Intellect) 50..79; P8(Guards' attitude) 0..29
  -> Path283 => Loc94  вер=3 [всегда видна] порядок=5
       текст: Write an amnesty petition
       ответ: You spent the entire day writing an amnesty plea. The result looked quite good to you.  / But the prison authorities disagreed with you on that. They were of a …
       условия: P6(Intellect) 10..49
       эффект: P7(Authorities' attitude) -5
  -> Path284 => Loc94  вер=2 порядок=5
       текст: Write an amnesty petition
       ответ: You spent the entire day writing an amnesty plea. The result looked quite good to you and the prison authorities were of the same opinion.
       условия: P6(Intellect) 40..79; P8(Guards' attitude) 30..100
       эффект: P7(Authorities' attitude) +5
  -> Path285 => Loc94  вер=3 порядок=5
       текст: Write an amnesty petition
       ответ: You spent the entire day writing an amnesty plea. The result looked excellent to you. You were convincing the committee that this prison had the best warden the…
       условия: P6(Intellect) 70..100; P8(Guards' attitude) 20..100
       эффект: P7(Authorities' attitude) +15
  -> Path324 => Loc91  вер=1 порядок=5
       текст: Just get some rest
       ответ: You spent the day lying on the cot and exchanging harmless jokes with your cellmates. The pastime was quite nice and you had yourself a good rest and gained som…
       эффект: P4(Health) = {[p4]+[3..7]}
       эффект: P5(Strength) = {[p5]+[2..5]}
       эффект: P6(Intellect) = {[p6]+[1..3]}
  -> Path325 => Loc106  вер=1 [всегда видна] порядок=5
       текст: Racket the inmates
       условия: P9(Reputation) 70..99
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[1..5]}
       эффект: P35(x) = {0}
  -> Path340 => Loc109  вер=3 порядок=5
       текст: Ask the guards to get you some drinks and organise a party for your cellmates, in order to improve your reputation (cost - 100 cr)
       ответ: The guard answered to your request and brought you a couple of bottles of some cheap swill. You had a great time with your cellmates, but in the morning you wer…
       условия: P8(Guards' attitude) 70..100; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]+[8..12]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
  -> Path341 => Loc109  вер=1 [всегда видна] порядок=5
       текст: Ask the guards to get you some drinks and organise a party for your cellmates, in order to improve your reputation (cost - 100 cr)
       ответ: The friendly guard completed your request and brought you several bottles of import brandy. The cellmates were quite impressed at your coolness. You had a great…
       условия: P8(Guards' attitude) 80..100; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P7(Authorities' attitude) = {[p7]-[5..10]}
  -> Path342 => Loc109  вер=1 порядок=5
       текст: Ask the guards to get you some drinks and organise a party for your cellmates, in order to improve your reputation (cost - 100 cr)
       ответ: The guard answered to your request and brought you a couple of bottles of some cheap swill. You had a great time with your cellmates, but in the morning you wer…
       условия: P8(Guards' attitude) 40..100; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]+[8..12]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
  -> Path343 => Loc109  вер=3 порядок=5
       текст: Ask the guards to get you some drinks and organise a party for your cellmates, in order to improve your reputation (cost - 100 cr)
       ответ: You waited for the guards to come back, but they never did. And judging by their drunken yells, they obviously did find a better use for your money. The entire …
       условия: P8(Guards' attitude) 0..49; P28(Money) 100..1000000000
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]-[1..5]}
  -> Path344 => Loc109  вер=2 порядок=5
       текст: Ask the guards to get you some drinks and organise a party for your cellmates, in order to improve your reputation (cost - 100 cr)
       ответ: The guard could not believe such an impudence, and thinking this was a provocation took the money to the prison warden with a detailed report on what you told h…
       условия: P8(Guards' attitude) 0..29; P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]-[1..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[8..12]}
  -> Path345 => Loc91  вер=1 [всегда видна] порядок=5
       текст: Donate 500 cr for penitentiary needs.
       ответ: You asked the guard to call the warden and solemnly presented 500 cr to him for the needs of the prison. The warden was very pleased with you, and delivered a l…
       условия: P28(Money) 500..1000000000
       эффект: P28(Money) = {[p28]-500}
       эффект: P9(Reputation) -15
       эффект: P7(Authorities' attitude) +25
       эффект: P8(Guards' attitude) +10

### Loc97 [пустая]
  -> Path323 => Loc91  вер=1 порядок=5

### Loc98 [обычная]
    Loc98-1: - Want to play a game of shesh-besh with old guy? Good boy! - the old man smiled at you. - Stakes are {20} cr, you roll the dice, okay? Then it's my turn to rol…
    эффект: P24(Stake) = 0 [скрыт]
    скрыт: P20,P21
  -> Path289 => Loc23  вер=1 порядок=5
       текст: Enough of gambling for today
       ответ: Nonetheless you spent the rest of the day watching Sheitan-Babai win against each and every opponent. "Something's gotta be wrong with that!" - you thought to y…
       условия: P22(Y) 1..14
       эффект: P6(Intellect) = {[p6]+[1..3]}
  -> Path290 => Loc103  вер=1 [всегда видна] порядок=5
       текст: Alright - 20 cr! Give me the dice...
       условия: P22(Y) 0..14; P28(Money) 20..1000000000
       эффект: P28(Money) -20
       эффект: P24(Stake) +20 [показ]
  -> Path291 => Loc103  вер=1 [всегда видна] порядок=5
       текст: 20 cr?! Ha!!! You're kidding me right?! 50 cr at least!
       ответ: The spectators eyed you with respect. / - 20 cr too small? - the old man asked. - You wants to rob poor old Sheitan-Babai of all he has! Alright, 50 cr it will …
       условия: P22(Y) 0..14; P28(Money) 50..1000000000
       эффект: P28(Money) = {[p28]-50}
       эффект: P9(Reputation) = {[p9]+[0..2]}
       эффект: P6(Intellect) = {[p6]-[0..1]}
       эффект: P24(Stake) +50 [показ]
  -> Path297 => Loc23  вер=1 порядок=5
       текст: Too late, time to go to bed!
       условия: P22(Y) 15..1000
  -> Path301 => Loc23  вер=1 порядок=5
       текст: Enough of gambling for today
       ответ: - You did not play one game! - the spectators flared. - Why say that you want to play, when you are so greedy and cowardly? / Your reputation dropped slightly a…
       условия: P22(Y) 0..0
       эффект: P9(Reputation) -5
       эффект: P6(Intellect) = {[p6]+[1..3]}

### Loc99 [обычная]
    Loc99-1: You shook and rubbed the dice for some time, whispering ancient cusswords that brought luck in gambling. Finally the dice hit the table and rolled over. Everyon…
    эффект: P20(X3) = {[p18]+[p19]} [показ]
  -> Path292 => Loc101  вер=3 порядок=5
       текст: Come on, roll!
       условия: P6(Intellect) 0..19
       эффект: P18(X1) = {[3..6]}
       эффект: P19(X2) = {[3..6]}
  -> Path293 => Loc101  вер=3 порядок=5
       текст: Come on, roll!
       условия: P6(Intellect) 10..69
       эффект: P18(X1) = {[1..6]}
       эффект: P19(X2) = {[1..6]}
  -> Path294 => Loc101  вер=2 порядок=5
       текст: Come on, roll!
       условия: P6(Intellect) 70..100
       эффект: P18(X1) = {[1..4]}
       эффект: P19(X2) = {[1..6]}
  -> Path373 => Loc101  вер=1 порядок=5
       текст: Come on, roll!
       условия: P6(Intellect) 10..89
       эффект: P18(X1) = {[1..6]}
       эффект: P19(X2) = {[1..4]}

### Loc101 [обычная]
    Loc101-1: The old man was shaking the dice, wailing something like: "Allah-akbar! Help Sheitan-Babai!" Then he suddenly tossed the dice on the table in a swift move so th…
    эффект: P21(X4) = {[p18]+[p19]} [показ]
  -> Path298 => Loc98  вер=1 порядок=5
       текст: Alas, you lost...
       ответ: - Shesh-Besh is not yer check-mate! - Sheitan-Babai said in a nagging voice and took the money. - It's a thinking game!
       условия: логика {[p20]<[p21]}
       эффект: P6(Intellect) = {[p6]+[0..1]}
  -> Path299 => Loc98  вер=1 порядок=5
       текст: You won!!! Take the money!
       ответ: - Oh my! Allah forgot all about the poor old Sheitan-Babai... - the old man sighed as you put the {2*[p24]} cr into your pocket.
       условия: логика {[p20]>[p21]}
       эффект: P28(Money) = {[p28]+2*[p24]}
  -> Path300 => Loc103  вер=1 порядок=5
       текст: Draw! Roll again
       условия: логика {[p20]=[p21]}

### Loc102 [пустая]
  -> Path311 => Loc98  вер=1 порядок=5

### Loc103 [пустая]
    эффект: P22(Y) +1
    скрыт: P20,P21
  -> Path296 => Loc99  вер=1 [всегда видна] порядок=5
       эффект: P18(X1) = {[1..6]}
       эффект: P19(X2) = {[1..6]}

### Loc104 [пустая]
    эффект: P22(Y) = {[2..8]}
  -> Path305 => Loc23  вер=2 порядок=5
       ответ: The game was complicated and multi-staged. It went on till late in the evening. You had to bargain for a widow, then follow a certain pitch and take tricks. The…
       эффект: P28(Money) = {[p28]+(5*[p23]*([p22]+([p6] div 4)-([p23]-1)*(7-([p6] div 10))>0)*([p22]+([p6] div 4)-([p23]-1)*(7-([p6] div 10)))+5)/2+50*[p23]}
  -> Path347 => Loc23  вер=1 порядок=5
       ответ: The game was complicated and multi-staged. It went on till late in the evening. You had to bargain for a widow, then follow a certain pitch and take tricks. The…
       условия: P6(Intellect) 80..100; P9(Reputation) 1..69; P23(X0) 5..5
       эффект: P28(Money) = {[p28]+(5*[p23]*([p22]-3+([p6] div 4)-([p23]-1)*(8-([p6] div 10))>0)*([p22]-3+([p6] div 4)-([p23]-1)*(8-([p6] div 10)))+5)/2+50*[p23]}
  -> Path595 => Loc23  вер=3 порядок=5
       ответ: The game was complicated and multi-staged. It went on till late in the evening. You had to bargain for a widow, then follow a certain pitch and take tricks. The…
       условия: P23(X0) 1..1; P28(Money) 0..1000
       эффект: P28(Money) = {[p28]+100+5*[p22]}
  -> Path596 => Loc23  вер=7 порядок=5
       ответ: The game was complicated and multi-staged. It went on till late in the evening. You had to bargain for a widow, then follow a certain pitch and take tricks. The…
       условия: P23(X0) 1..1; P28(Money) 0..100
       эффект: P28(Money) = {[p28]+100+10*[p22]}

### Loc105 [УСПЕХ]
    Loc105-1: The door to the cell swung open and in came the warden accompanied by several guards. / - Due to the re-election of the beloved president of Planet <ToPlanet> f…

### Loc106 [обычная]
    выбор описания: {[p35]}
    Loc106-1: Your proposal to collect the money from other cellmates was met by other criminals with much enthusiasm.  / - Who do we take from? - one of the more respected c…
  -> Path326 => Loc107  вер=3 порядок=1
       текст: Shake'em all!
       ответ: The larger part of the inmates refused to pay, and even after a severe fight you did not manage to force them to reconsider. As a result your reputation was sli…
       условия: P5(Strength) 10..70
       эффект: P5(Strength) = {[p5]-[3..7]}
       эффект: P4(Health) = {[p4]-[8..12]}
       эффект: P9(Reputation) = {[p9]-[4..9]}
       эффект: P22(Y) = {[10..100]}
  -> Path327 => Loc107  вер=1 порядок=1
       текст: Shake'em all!
       ответ: You obviously overestimated yourself. Flared at your arrogance the cellmates teamed up and gave you a sound battering. That incident surely affected your reputa…
       условия: P5(Strength) 0..59; P9(Reputation) 1..79
       эффект: P5(Strength) = {[p5]-[5..10]}
       эффект: P9(Reputation) = {[p9]-[10..20]}
       эффект: P4(Health) = {[p4]-[10..20]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P22(Y) = {0}
  -> Path328 => Loc107  вер=3 порядок=1
       текст: Shake'em all!
       ответ: You reputation spoke for itself, and so did the size of your muscles, that no one had the guts to mess with you. Everyone paid more than willingly. And after th…
       условия: P5(Strength) 50..100; P9(Reputation) 90..99
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P22(Y) = {[125..200]}
  -> Path329 => Loc107  вер=1 порядок=1
       текст: Shake'em all!
       ответ: You spent the entire day together with other criminals extorting the money from the inmates. Some of them, who were not too willing to co-operate, had to be for…
       условия: P5(Strength) 30..100
       эффект: P5(Strength) = {[p5]-[3..8]}
       эффект: P4(Health) = {[p9]-[2..7]}
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P6(Intellect) = {[p6]-[2..5]}
       эффект: P22(Y) = {[100..200]}
  -> Path331 => Loc107  вер=1 порядок=2
       текст: Shake the scum only
       ответ: The downcast did not have the guts to argue with you. But what could you take from them? After the entire day of racketing and splitting the toll, your share to…
       эффект: P22(Y) = {[10..100]}
  -> Path332 => Loc107  вер=2 порядок=2
       текст: Shake the scum only
       ответ: The scum, for the better part, did not argue, but one of them decided to be a hero and punched you right in the face sending you down on the floor. Of course yo…
       условия: P5(Strength) 0..29; P9(Reputation) 1..84
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P4(Health) = {[p4]-[1..5]}
       эффект: P6(Intellect) -1
       эффект: P22(Y) = {[10..100]}
  -> Path389 => Loc107  вер=1 порядок=1
       текст: Shake'em all!
       ответ: You obviously overestimated yourself. Flared at your arrogance the cellmates teamed up and gave you a sound battering. That incident surely affected your reputa…
       условия: P5(Strength) 0..49; P9(Reputation) 1..89
       эффект: P5(Strength) = {[p5]-[5..10]}
       эффект: P9(Reputation) = {[p9]-[10..20]}
       эффект: P4(Health) = {[p4]-[10..20]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P22(Y) = {0}
  -> Path390 => Loc107  вер=5 порядок=1
       текст: Shake'em all!
       ответ: You obviously overestimated yourself. Flared at your arrogance the cellmates teamed up and gave you a sound battering. That incident surely affected your reputa…
       условия: P5(Strength) 0..29
       эффект: P5(Strength) = {[p5]-[5..10]}
       эффект: P4(Health) = {[p4]-[10..20]}
       эффект: P9(Reputation) = {[p9]-[10..20]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P22(Y) = {0}
  -> Path417 => Loc124  вер=1 [всегда видна] порядок=3
       текст: No we are not going to shake anyone down. Let them lay a table for me from the parcels that they'd received from their homes.
       ответ: The inmates were glad to get away from it that easily, and quickly laid the table for you. But the other original gangsters did not approve of that decision, th…
       условия: P9(Reputation) 70..89
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P37(canteen) +1
  -> Path419 => Loc124  вер=1 [всегда видна] порядок=3
       текст: No we are not going to shake anyone down. Let them lay a table for me from the parcels that they'd received from their homes.
       ответ: The best way for a Don to be is use the policy of peaceful authority. Do not extort money too often, and just ask the other inmates nicely to feed you. Eat your…
       условия: P9(Reputation) 90..99
       эффект: P37(canteen) +1

### Loc107 [пустая]
    эффект: P28(Money) = {[p28]+[p22]*(([p9] div 10)-6)+5}
  -> Path330 => Loc91  вер=1 порядок=5

### Loc108 [пустая]
    эффект: P22(Y) = 0
  -> Path277 => Loc96  вер=3 порядок=5
  -> Path278 => Loc95  вер=3 порядок=5
       условия: P9(Reputation) 1..19; P28(Money) 1..1000000000
  -> Path279 => Loc95  вер=1 порядок=5
       условия: P9(Reputation) 1..69; P28(Money) 1..1000000000
  -> Path280 => Loc95  вер=2 порядок=5
       условия: P9(Reputation) 1..39; P28(Money) 1..1000000000
  -> Path312 => Loc93  вер=2 порядок=5
       условия: P5(Strength) 10..100; P9(Reputation) 1..19
  -> Path317 => Loc97  вер=0.3 порядок=5
       ответ: A guard entered the cell and said: / - <Ranger>, we got a parcel for you! Follow me! / You were quite surprised but followed the guard. However instead of the p…
       условия: P8(Guards' attitude) 0..49; P10(Stoolie) 1..1
       эффект: P4(Health) -15
       эффект: P6(Intellect) -9
  -> Path319 => Loc97  вер=0.3 порядок=5
       ответ: A guard came into the cell and said: / - <Ranger>, we got a parcel for you! Follow me! / Surprised you followed him. And indeed, a ranger friend of yours who ha…
       условия: P8(Guards' attitude) 20..100
       эффект: P4(Health) +2
       эффект: P9(Reputation) +5
       эффект: P28(Money) = {[p28]+75}
  -> Path320 => Loc105  вер=0.3 порядок=5
       условия: P3(Term) 0..30
  -> Path333 => Loc96  вер=0.3 порядок=5
       ответ: Suddenly on the wall you spotted a cockroach that looked a little bigger than its kin. Deciding to make a champion out of it you caught it and put it in your ma…
       условия: P27(Cockroach) 0..0
       эффект: P27(Cockroach) = {[1..10]}
  -> Path358 => Loc97  вер=0.7 порядок=5
       ответ: A guard entered the cell and said: / - <Ranger>, we got a parcel for you! follow me! / You were quite surprised but followed the guard. However instead of the p…
       условия: P7(Authorities' attitude) 0..30; P8(Guards' attitude) 0..19; P9(Reputation) 71..99
       эффект: P4(Health) -15
       эффект: P5(Strength) -3
       эффект: P6(Intellect) -10

### Loc109 [пустая]
  -> Path348 => Loc91  вер=1 порядок=5

### Loc110 [обычная]
    Loc110-1: Back on your way to the cell you ran into a half-drunk guard. /  / - Listen, <Ranger>, gimme {100} cr, if it's not much trouble! I know you have it! I need me a…
  -> Path351 => Loc47  вер=1 [всегда видна] порядок=5
       текст: Give them 100 cr
       ответ: - Thank you, <Ranger>! I will never forget this! - the guard responded joyfully.
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[10..15]}
  -> Path352 => Loc47  вер=1 порядок=5
       текст: Tell him you don't have that money
       ответ: - You greedy son of a gun! - the guard said spitefully. - I'll get back at you!
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}

### Loc111 [обычная]
    Loc111-1: The blind Gaalian massaged you all during the day, relaxing the tired muscles and removing the ache from the joints. You felt much better!
    эффект: P4(Health) = {[p4]+[25..50]}
    эффект: P5(Strength) = {[p5]+[5..15]}
  -> Path359 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc112 [пустая]
  -> Path362 => Loc23  вер=1 порядок=5
       условия: P22(Y) 7..1000
       эффект: P22(Y) = 0
  -> Path374 => Loc114  вер=1 порядок=5
       условия: P22(Y) 0..6

### Loc113 [обычная]
    Loc113-1: On your way to the cell, a Peleng pickpocket lifted the matchbox with your pet from your inside pocket. Showing the stolen thing to you he sneered: / - I am tak…
  -> Path366 => Loc47  вер=1 [всегда видна] порядок=5
       текст: Pay
       ответ: You paid the 100 cr and got your pet back safe and sound.
       условия: P28(Money) 100..1000000000
       эффект: P28(Money) = {[p28]-100}
       эффект: P9(Reputation) = {[p9]-[1..3]}
  -> Path367 => Loc47  вер=1 порядок=5
       текст: Try to take the matchbox with force
       ответ: One punch was enough to smear the impudent thief across the wall. You carefully picked up the matchbox that fell out of his hand, and to your great relief found…
       условия: P5(Strength) 40..100
       эффект: P9(Reputation) = {[p9]+[3..7]}
  -> Path368 => Loc47  вер=1 порядок=5
       текст: Try to take the matchbox with force
       ответ: You bravely rushed into a fight and finally won. But, alas, your pet has been crushed mercilessly in the fight...
       условия: P5(Strength) 0..59
       эффект: P9(Reputation) = {[p9]+[1..3]}
       эффект: P27(Cockroach) = 0

### Loc114 [пустая]
    эффект: P22(Y) +1
  -> Path375 => Loc112  вер=1 порядок=5

### Loc115 [пустая]
  -> Path376 => Loc117  вер=1 порядок=5
       условия: P22(Y) 0..1
  -> Path378 => Loc91  вер=1 порядок=5
       условия: P22(Y) 2..1000

### Loc116 [пустая]
  -> Path381 => Loc118  вер=1 порядок=5
       условия: P22(Y) 0..6
  -> Path382 => Loc91  вер=1 порядок=5
       условия: P22(Y) 7..1000

### Loc117 [пустая]
    эффект: P22(Y) +1
  -> Path377 => Loc115  вер=1 порядок=5

### Loc118 [пустая]
    эффект: P22(Y) +1
  -> Path379 => Loc116  вер=1 порядок=5

### Loc120 [обычная]
    Loc120-1: Suddenly the prison warden appeared in front of you. Surprisingly enough, he was even smiling! He was followed by a very serious group of Humans, Gaalians and F…
  -> Path399 => Loc162  вер=1 порядок=5
       текст: Complain about your hard life in prison
       ответ: - Life in here is awful! This is the worst prison for ten systems away. The guards are always drunk and they'd always batter the inmates, and the authorities co…
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]-[5..10]}
       эффект: P8(Guards' attitude) = {[p8]-[0..3]}
  -> Path400 => Loc162  вер=1 порядок=5
       текст: Say something good about the prison
       ответ: You've got to help the warden out on this one and then, maybe, he will help you out too. That's the best choice you got. You started speaking: /  / - I've been …
       эффект: P9(Reputation) = {[p9]-[7..15]}
       эффект: P7(Authorities' attitude) = {[p7]+[7..15]}
  -> Path402 => Loc162  вер=1 порядок=5
       текст: Hug the warden as if he were your best friend
       ответ: You put your hand around the warden's shoulder and said:  / - We are truly on friendly terms here. See, the warden is everyone's best friend, really... / Everyo…
       условия: P7(Authorities' attitude) 0..59
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P4(Health) = {[p4]-[3..7]}
  -> Path407 => Loc162  вер=1 порядок=5
       текст: Hug the warden as if he were your best friend
       ответ: You put you hand around the warden in a friendly way and said:  / - We have very friendly relations. The warden here is like our own father. Very fair and just.…
       условия: P7(Authorities' attitude) 50..100
       эффект: P7(Authorities' attitude) = {[p7]+[5..15]}
       эффект: P9(Reputation) = {[p9]-[5..15]}
  -> Path563 => Loc161  вер=1 порядок=5
       текст: Pretend to be a mute
       эффект: P6(Intellect) +5

### Loc121 [обычная]
    Loc121-1: - Hello, <Ranger>! - a voice came from around the corner. - We want to talk to you. Seems like you are affording yourself too much and pay no respect to the jai…
  -> Path404 => Loc23  вер=1 порядок=6
       текст: Run away
       ответ: Looks like you were in for trouble. Time to get the hell out of here you thought, and rushed down the empty corridor.  The extorters ran after you, but already …
       эффект: P9(Reputation) = {[p9]-[10..15]}
       эффект: P8(Guards' attitude) = {[p8]+[1..3]}
  -> Path405 => Loc23  вер=1 порядок=4
       текст: Pay 500 cr
       ответ: You gave {500} cr to the extorters - that was certainly a blow on your budget. Well, at least they did not beat you up! Seriously, these guys could even go as f…
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P28(Money) -500
  -> Path406 => Loc23  вер=1 порядок=5
       текст: Fight
       ответ: The first blow landed right onto your opponent's head. You jabbed the Maloq right in the eye, he did not expect it and couldn't block the punch. The Maloq's fri…
       условия: P5(Strength) 0..80
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P9(Reputation) = {[p9]-[0..2]}
  -> Path408 => Loc23  вер=1 порядок=5
       текст: Fight
       ответ: Indeed going to the gym was a wise decision. Now the force of your punch would put a battering ram to shame! You hit the Peleng who was standing up front and di…
       условия: P5(Strength) 70..100
       эффект: P4(Health) = {[p4]-[1..3]}
       эффект: P9(Reputation) = {[p9]+[5..10]}

### Loc124 [пустая]
  -> Path418 => Loc91  вер=1 порядок=5

### Loc126 [обычная]
    выбор описания: {[p35]}
    Loc126-1: <clr>The Medical station<clrEnd> - is an excellent place to get one's health fixed and ogle at the good-looking nurses. This is the place to be, until they star…
    Loc126-2: - I see you got some health problems. I'd suggest stimulant {245}. There it is by that device over there.  /  / You approached the device distributing the medic…
    Loc126-3: - Right, same one different day! They all say that, when they come to the station you know. And you actually expect me to believe, what you are saying? Although…
    Loc126-4: - Hold your horses, <Ranger>, and do not forget who you are! If you want to be treated right, don't try to hit on me, alright? Some folks who did not keep their…
    Loc126-5: You were ogling at the good-looking nurse, who was yawning and eyeing you indifferently.  / "What are those red stains on her coat, I wonder?" - you thought to …
    Loc126-6: - Do I look like I am with the Army of Salvation? I don't have money, to treat you lot for free. Come back when you have the money!
    Loc126-7: <clr>The Medical station<clrEnd> - is an excellent place to get one's health fixed and ogle at the good-looking nurses. This is the place to be, until they star…
    Loc126-8: - Payment in advance, please! What? Ain't got it? You pay - you get the alcohol, and if you try to take it without paying, our jail dentist will examine you for…
    Loc126-9: You took the cold bottle of alcohol, and felt the warmth flow in your soul! You were already anticipating the bash you were going to throw in the canteen with y…
    Loc126-10: - If you ain't got it then you haven't got it! Why ask then? Get lost now, before I called the guards. Some people; no money - no conscience.
  -> Path360 => Loc111  вер=1 порядок=8
       текст: I want to pay for a professional massager (250 cr)
       условия: P13(pp 2) ∈[0, 2]; P28(Money) 250..1000000000
       эффект: P28(Money) = {[p28]-250}
  -> Path428 => Loc127  вер=1 порядок=1
       текст: I need to be fixed a little
       условия: P4(Health) 1..69; P13(pp 2) 0..1; P28(Money) 20..1000000000; P35(x) ∉[3]
       эффект: P4(Health) = {[p4]+[8..18]}
       эффект: P13(pp 2) +2
       эффект: P28(Money) -20
       эффект: P35(x) = {2}
  -> Path431 => Loc127  вер=1 порядок=2
       текст: Back on the freeside the doctor prescribed me to take 40% spirit solution from  all illnesses
       условия: P13(pp 2) ∈[0, 2]; P31(Alcohol) ∉[1]
       эффект: P13(pp 2) +1
       эффект: P35(x) = {3}
  -> Path432 => Loc127  вер=1 проходов<=1 порядок=7
       текст: Do you have any plans for tonight?
       условия: P13(pp 2) ∈[0, 2]
       эффект: P35(x) = {4}
  -> Path433 => Loc28  вер=1 порядок=9
       текст: I think I will go back to the cell.
       условия: P13(pp 2) ∈[0, 2]
  -> Path434 => Loc128  вер=1
       текст: I'll take it
       условия: P28(Money) 800..1000000000; P35(x) 3..3
       эффект: P28(Money) -800
       эффект: P35(x) = {9}
       эффект: P31(Alcohol) = {1} [показ]
       показ: P26
  -> Path435 => Loc128  вер=1 порядок=1
       текст: No, that's a bit too steep
       условия: P35(x) 3..3
       эффект: P35(x) = {10}
  -> Path439 => Loc128  вер=1
       текст: I'll take it
       условия: P28(Money) 0..799; P35(x) 3..3
       эффект: P35(x) = {8}
  -> Path478 => Loc127  вер=1 порядок=1
       текст: I need to be fixed a little
       условия: P4(Health) 1..69; P13(pp 2) 0..1; P28(Money) 0..19; P35(x) ∉[3]
       эффект: P35(x) = {6}

### Loc127 [пустая]
  -> Path429 => Loc126  вер=1 порядок=5

### Loc128 [пустая]
  -> Path436 => Loc126  вер=1 порядок=5
       условия: P35(x) ∉[10]
       эффект: P13(pp 2) = {0}
  -> Path440 => Loc126  вер=1 порядок=5
       условия: P35(x) 10..10
       эффект: P35(x) = {5}
       эффект: P13(pp 2) = {0}

### Loc130 [обычная]
    выбор описания: {[p13]}
    Loc130-1: Two Maloqs approached you.  /  / - Listen, <Ranger>, - one of them winked at you with conspiracy. - Wanna earn some quick cred? We need your help. We know a pla…
    Loc130-2: You followed the Maloqs. The lead you to the toilet, went into one of the cubicles and said: /  / - The cache is somewhere in this wall. Take the pipe-cleaner a…
    Loc130-3: - What makes you think I am going to believe you? <clr>Rachekhan<clrEnd> had never been in this prison, and even if he had, the banknotes that are three hundred…
  -> Path442 => Loc131  вер=1 порядок=6
       текст: Refuse
       условия: P13(pp 2) 0..1
       эффект: P13(pp 2) = {3}
       эффект: P9(Reputation) = {[p9]+[2..5]}
  -> Path444 => Loc131  вер=1 порядок=5
       текст: Agree
       условия: P13(pp 2) 0..1
       эффект: P13(pp 2) = {2}
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P5(Strength) = {[p5]-[2..5]}
       эффект: P6(Intellect) = {[p6]+[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}
  -> Path445 => Loc23  вер=1 порядок=5
       текст: Go back to the cell
       условия: P13(pp 2) 2..3
       эффект: P13(pp 2) = {0}

### Loc131 [пустая]
  -> Path443 => Loc130  вер=1 порядок=5

### Loc138 [обычная]
    выбор описания: {[p12]}
    Loc138-1: You dug slowly but steadily all through the day. Excellent job, the sap has become slightly deeper!
    Loc138-2: Being in good athletic shape you made quite some progress. It looked like an excellent tunnel.
    Loc138-3: Climbing into the far dark corner which could not be seen from outside the cell, you got down to work - digging the sap. You spent half a day digging, and reste…
    Loc138-4: Today your spirits were high and that helped you dig the sap. The spoon and fork were flashing in your hands, and the digging brought you a lot of moral satisfa…
    Loc138-5: Your trips to the gym were proving to be 100% useful. Even the Maloq experts of digging and backfilling the trenches, would have grown envious had they seen you…
    Loc138-6: Today everyone went off about their respective businesses quite quickly, and you started digging. From the very start you took such a pace, that it even made yo…
    Loc138-7: Digging was hard, but not impossible. The sap was growing bigger very slowly. Must be lack of vitamins or bad physical shape. Maybe it's time you started taking…
    Loc138-8: Digging a tunnel is not painting a fence, this requires strength. You were running out of strength, but kept digging. The tunnel was gradually growing longer, b…
    Loc138-9: You were hardly holding the fork and the spoon, so you quickly ran out of breath, practically not having dug anything. You spent the entire day regaining your s…
    Loc138-10: You have very little strength, you are so weak, that you only managed to pick at the dirt with the fork and spoon a couple of times, and then hardly made it to …
    показ: P25
  -> Path542 => Loc23  вер=1 порядок=5
       текст: Go to sleep
       условия: P25(Sap) 0..89
  -> Path546 => Loc157  вер=1 порядок=5
       условия: P25(Sap) 90..100
       эффект: P12(pp 3) = {1}
       эффект: P26(dimensions) = {[1..3]}

### Loc140 [обычная]
    Loc140-1: The Gaalians, as usual, were discussing global issues, taking turns at the blackboard and drawing some abstract diagrams, which somehow caused associations with…
  -> Path479 => Loc141  вер=1 порядок=2
       текст: Draw something unusual
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
       эффект: P34(next) = {1}
  -> Path492 => Loc142  вер=1 порядок=9
       текст: Go back to the corridor with five doors
       эффект: P34(next) = {0}
  -> Path502 => Loc141  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Contemplate the harmony of colours
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P34(next) = {2}
  -> Path503 => Loc141  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Play a pipe
       условия: P32(Pipe) 1..1
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P7(Authorities' attitude) = {[p7]-[2..5]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}
       эффект: P34(next) = {3}
  -> Path526 => Loc141  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Use a tape recorder
       условия: P29(tape recorder) 2..2
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P34(next) = {4}
  -> Path533 => Loc141  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Show the cube-puzzle
       условия: P33(cube) 1..1
       эффект: P9(Reputation) = {[p9]-[4..9]}
       эффект: P6(Intellect) = {[p6]+[2..5]}
       эффект: P34(next) = {5}
  -> Path554 => Loc141  вер=1 порядок=7
       текст: Watch the performance
       эффект: P4(Health) = {[p4]+[1..3]}
       эффект: P6(Intellect) = {[p6]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}
       эффект: P34(next) = {6}

### Loc141 [обычная]
    выбор описания: {[p34]}
    Loc141-1: You decided that tricking the Gaalians would be quite easy, and started drawing all sorts of nonsense on the blackboard remembering some things you'd seen on Hu…
    Loc141-2: You wanted to throw in some topic for discussion, but you could hardly think of anything - harmony and contemplation were not you cup of tea. Then again, painti…
    Loc141-3: You waited for the speaker to finish, and then stepped forward and blew the wooden pipe. The melody that sounded, was so beautiful;, that it felt as if a flower…
    Loc141-4: The tapes for the recorded contained lots of different music, and this time too you managed to find something suitable. You turned on the wails of some late 20t…
    Loc141-5: No matter how hard you tried to explain to the Gaalians that the cube-puzzle was an ancient symbol of connection with a supreme being and ideal incarnation of h…
    Loc141-6: It was a rare occasion that you could observe the philosophical speculations of a whole group of Gaalians, and you decided to listen to a couple of speeches.  /…
  -> Path508 => Loc151  вер=1 порядок=5
       текст: Go back to the cell

### Loc142 [обычная]
    Loc142-1: Due to frequent frights and brawls the prison authorities provided {5} large cells for amateur's nights to be held separately by each race. You entered a grey c…
    Loc142-2: You stood in front of the five halls intended for the prison shows for different races. The new posters certainly appealed to the eye. Looks like the prison her…
    Loc142-3: You entered the hall with entrances to the cells for mass entertainment. These doors always had something to offer! When one was here one could easily forget th…
  -> Path480 => Loc143  вер=1 порядок=1
       текст: Go to the Maloq competition
  -> Path481 => Loc144  вер=1 порядок=2
       текст: Go to the hall of the cunning Pelengs
  -> Path482 => Loc145  вер=1 порядок=3
       текст: Go see the amateur's night at the Humans'
  -> Path483 => Loc146  вер=1 порядок=4
       текст: Go to the egg-headed Faeyans
  -> Path484 => Loc140  вер=1 порядок=5
       текст: Visit the Gaalian feast of the spirit
       эффект: P34(next) = {5}

### Loc143 [обычная]
    Loc143-1: The Maloq hall was large. In its centre there was a huge arena with a numerous audience standing and sitting around it. The Maloqs cheered loudly for the guy in…
  -> Path486 => Loc147  вер=1 порядок=2
       текст: Fight the cyborg
       условия: P5(Strength) 0..39
       эффект: P5(Strength) = {[p5]-[1..3]}
       эффект: P4(Health) = {[p4]-[15..25]}
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P34(next) = {3}
  -> Path487 => Loc147  вер=1 порядок=1
       текст: Use the Peleng's offer
       условия: P28(Money) 500..1000000000
       эффект: P28(Money) -500
       эффект: P9(Reputation) = {[p9]+[15..20]}
       эффект: P34(next) = {1}
  -> Path488 => Loc142  вер=1 порядок=9
       текст: Go back to the corridor with five doors
       эффект: P34(next) = {0}
  -> Path522 => Loc147  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Use a tape recorder here
       условия: P29(tape recorder) 2..2
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P34(next) = {4}
  -> Path531 => Loc147  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Play a pipe
       условия: P32(Pipe) 1..1
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P34(next) = {5}
  -> Path535 => Loc147  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Show the cube-puzzle
       условия: P33(cube) 1..1
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]-[4..9]}
       эффект: P34(next) = {6}
  -> Path539 => Loc147  вер=1 порядок=2
       текст: Fight the cyborg
       условия: P5(Strength) 30..69
       эффект: P5(Strength) = {[p5]-[1..3]}
       эффект: P4(Health) = {[p4]-[5..12]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P34(next) = {9}
  -> Path540 => Loc147  вер=1 порядок=2
       текст: Fight the cyborg
       условия: P5(Strength) 60..100
       эффект: P5(Strength) = {[p5]-[1..3]}
       эффект: P4(Health) = {[p4]-[2..6]}
       эффект: P9(Reputation) = {[p9]+[10..15]}
       эффект: P34(next) = {10}
  -> Path550 => Loc147  вер=1 порядок=7
       текст: Watch the performance
       эффект: P4(Health) = {[p4]+[3..7]}
       эффект: P6(Intellect) = {[p6]-[1..3]}
       эффект: P34(next) = {2}

### Loc144 [обычная]
    Loc144-1: A huge Peleng was delivering some rigorous speech from the tribune in the Peleng hall. He gesticulated violently decorating his speech with colourful gestures u…
  -> Path489 => Loc142  вер=1 порядок=9
       текст: Go back to the corridor with five doors
       эффект: P34(next) = {0}
  -> Path493 => Loc148  вер=1 порядок=1
       текст: Tell a false story
       условия: P6(Intellect) 0..59
       эффект: P6(Intellect) = {[p6]+[1..3]}
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P34(next) = {7}
  -> Path494 => Loc148  вер=1 проходов<=1 порядок=2
       текст: Tell a true story
       эффект: P9(Reputation) = {[p9]-[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..5]}
       эффект: P34(next) = {2}
  -> Path523 => Loc148  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Use a tape recorder
       условия: P29(tape recorder) 2..2
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P34(next) = {3}
  -> Path530 => Loc148  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Play a pipe
       условия: P32(Pipe) 1..1
       эффект: P4(Health) = {[p4]-[3..7]}
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P34(next) = {4}
  -> Path534 => Loc148  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Show the cube-puzzle
       условия: P33(cube) 1..1
       эффект: P9(Reputation) = {[p9]-[2..6]}
       эффект: P34(next) = {5}
  -> Path551 => Loc148  вер=1 порядок=7
       текст: Watch the performance
       эффект: P9(Reputation) = {[p9]-[0..1]}
       эффект: P6(Intellect) = {[p6]+[0..2]}
       эффект: P8(Guards' attitude) = {[p8]-[0..2]}
       эффект: P34(next) = {6}
  -> Path600 => Loc148  вер=1 порядок=1
       текст: Tell a false story
       условия: P6(Intellect) 50..100
       эффект: P9(Reputation) = {[p9]+[7..13]}
       эффект: P7(Authorities' attitude) = {[p7]-[4..8]}
       эффект: P34(next) = {1}

### Loc145 [обычная]
    Loc145-1: The master of ceremony in the Human hall was calling out more and more participants to the scene where they demonstrated how they could sing, drink, paint and d…
  -> Path490 => Loc142  вер=1 порядок=9
       текст: Go back to the corridor with five doors
       эффект: P34(next) = {0}
  -> Path495 => Loc149  вер=1 порядок=3
       текст: Sing
       эффект: P34(next) = {1}
  -> Path496 => Loc149  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Show the cube-puzzle
       условия: P33(cube) 1..1
       эффект: P9(Reputation) = {[p9]+[4..9]}
       эффект: P6(Intellect) = {[p6]+[1..3]}
       эффект: P34(next) = {2}
  -> Path497 => Loc149  вер=1 порядок=2
       текст: Recite a poem
       условия: P6(Intellect) 0..59
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}
       эффект: P34(next) = {3}
  -> Path498 => Loc149  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Play with your spoon and fork
       условия: P30(Fork and spoon) 1..1
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P5(Strength) = {[p5]-[0..2]}
       эффект: P6(Intellect) = {[p6]-[0..2]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
       эффект: P34(next) = {4}
  -> Path524 => Loc149  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Use a tape recorder
       условия: P29(tape recorder) 2..2
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P34(next) = {5}
  -> Path529 => Loc149  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Play a pipe
       условия: P32(Pipe) 1..1
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]-[0..2]}
       эффект: P34(next) = {6}
  -> Path547 => Loc149  вер=1 порядок=2
       текст: Recite a poem
       условия: P6(Intellect) 40..100
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P34(next) = {7}
  -> Path552 => Loc149  вер=1 порядок=7
       текст: Watch the performance
       эффект: P4(Health) = {[p4]+[2..5]}
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P34(next) = 8

### Loc146 [обычная]
    Loc146-1: On the scene there was a tribune, like the ones they put in universities. Behind the tribune a thin Faeyan was mumbling something complete unintelligible. At ti…
  -> Path491 => Loc142  вер=1 порядок=9
       текст: Go back to the corridor with five doors
       эффект: P34(next) = {0}
  -> Path499 => Loc150  вер=1 [всегда видна] порядок=2
       текст: Deliver a lecture in Physics
       условия: P6(Intellect) 50..100
       эффект: P4(Health) = {[p4]-[2..6]}
       эффект: P9(Reputation) = {[p9]+[1..5]}
       эффект: P34(next) = {1}
  -> Path500 => Loc150  вер=1 порядок=3
       текст: Deliver a lecture on the Dominators
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P5(Strength) = {[p5]-[0..1]}
       эффект: P6(Intellect) = {[p6]-[0..1]}
       эффект: P7(Authorities' attitude) = {([p7]+[2..5])*([p7]<80)+79*([p7]>=80)}
       эффект: P34(next) = {2}
  -> Path501 => Loc150  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Show the cube-puzzle
       условия: P33(cube) 1..1
       эффект: P9(Reputation) = {[p9]+[10..15]}
       эффект: P7(Authorities' attitude) = {[p7]-[5..10]}
       эффект: P34(next) = {3}
  -> Path525 => Loc150  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Use a tape recorder
       условия: P29(tape recorder) 2..2
       эффект: P9(Reputation) = {[p9]+[7..12]}
       эффект: P34(next) = {4}
  -> Path528 => Loc150  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Play a pipe
       условия: P32(Pipe) 1..1
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P34(next) = {5}
  -> Path553 => Loc150  вер=1 порядок=7
       текст: Watch the performance
       эффект: P4(Health) = {[p4]-[2..5]}
       эффект: P6(Intellect) = {[p6]+[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..3]}
       эффект: P34(next) = {6}

### Loc147 [обычная]
    выбор описания: {[p34]}
    Loc147-1: You told the master of ceremony that you wanted to participate. With a sceptical smile he announced your appearance and gave you the floor. The spectators caugh…
    Loc147-2: You sat down between two Maloqs. A Maloq fighter stepped on the ring. He was of mid-height, but very muscled. The crowd roar was so intense that a couple of lam…
    Loc147-3: and gave you the floor. The spectators caught their breaths although you could still hear occasional laughs. A huge combat android walked The spectators laughed…
    Loc147-4: You turned the tape-recorder on, and some sort of a march broke out from the speakers. You started marching across the scene, stomping your feet. The upbeat, rh…
    Loc147-5: As soon as the first notes flew into the hall, it became very clear that the Maloqs did not expect anything like that from you. They stomped their feet and star…
    Loc147-6: Showing a puzzle to a Maloq, is pretty much the same as giving a Dominator a bunch of flowers to sniff. The Maloq audience roared at the only sound of the word …
    Loc147-9: You told the master of ceremony that you wanted to participate. With a sceptical smile he announced your appearance and gave you the floor. The spectators caugh…
    Loc147-10: You went into the arena, and showing off your muscles, proceeded into your corner of the ring. A combat cyborg was already stepping onto the arena. The folks wh…
  -> Path504 => Loc151  вер=1 порядок=5
       текст: Go back to the cell

### Loc148 [обычная]
    выбор описания: {[p34]}
    Loc148-1: You told everyone a fresh story, the one you'd just come up with yourself. The story was about the times when you were still at large and blew up the embassy of…
    Loc148-2: You told them a true story about once landing onto this uninhabited planet, where no one actually lived. You went to the right and there was not a soul, you tur…
    Loc148-3: You turned on the tape-recorder and the hall was filled with the sounds of the swamps. Ragobam bullfrogs started croaking, the water gurgled, and the voices of …
    Loc148-4: The Pelengs thought that this thing in your hands was a spitting-pipe and that you wanted to spit at them from the scene. The Pelengs themselves would only spit…
    Loc148-5: The Pelengs did not like the cube, mainly because its shape was not ergonomic enough - a quality that was immensely valued by the race that itself came from wat…
    Loc148-6: The large Peleng finished his number, and two other thin Pelengs, one of them green and the other one green as well climbed onto the scene. They took the mikes …
    Loc148-7: You came up with this story about how much of a tough rapscallion you were. Or rather - you tried to come up with it, but your audience knew better than that. T…
  -> Path505 => Loc151  вер=1 порядок=5
       текст: Go back to the cell

### Loc149 [обычная]
    выбор описания: {[p34]}
    Loc149-1: While the master of ceremony was announcing your entrance, you rushed to come up with something to sing. Knowing who the audience was, some gansgta-rap would re…
    Loc149-2: You took out the cube. The Humans recognised it instantly, this was one of the most popular games ever to be invented by this race. You demonstrated your skills…
    Loc149-3: Excellent choice, <Ranger>! But now you have to recall some poem. You remembered the one that you tried to memorise back at school. They ushered you into the mi…
    Loc149-4: You produced a fork and a spoon from your pockets, put them between your thumb, index- and middle finger and started drumming on your knees, sides, and palms, k…
    Loc149-5: You used the tape recorder as a DJ console and started up a ripping dance-party. The folks instantly hit the dance floor having fun 100%. The prison hasn't seen…
    Loc149-6: The people want something with more guts to it, like a dance party, but for that one needs a tape recorder at least! The audience shooed you away from the scene…
    Loc149-7: Excellent choice, <Ranger>! But now you have to recall some poem. You remembered the one that you tried to memorise back at school. They ushered you into the mi…
    Loc149-8: You took a free seat and started watching the performance. The anchorman announced the participant loudly: / - Number nine in our concert today is a songwriter …
  -> Path506 => Loc151  вер=1 порядок=5
       текст: Go back to the cell
       условия: P34(next) ∉[1]
  -> Path510 => Loc152  вер=1 порядок=1
       текст: Sing some gangsta-rap
       ответ: You remembered a famous gangsta-rap song, which your cellmates liked to sing: /  / - Been spending most our lives, in the heaven of gangsta's paradise!  /  / Th…
       условия: P34(next) 1..1
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
  -> Path511 => Loc152  вер=1 порядок=2
       текст: Sing a lullaby
       ответ: As soon as you started singing the hall started yawning and shooed you off the stage, upstaging your singing with their shouts. In shame you went away.
       условия: P34(next) 1..1
       эффект: P9(Reputation) = {[p9]-[4..9]}
  -> Path512 => Loc152  вер=1
       текст: Sing a merry song
       ответ: You had this excellent merry song just at the tip of your tongue. You sang it twice, cheering up the inmates and even the guards - indeed laughter extends life.…
       условия: P34(next) 1..1
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
  -> Path513 => Loc152  вер=1 порядок=3
       текст: Sing some reggae
       ответ: You started singing the reggae but since you did not know the words, you simply sang about what you saw around you. The inmates, the guards, the hard life witho…
       условия: P34(next) 1..1
       эффект: P9(Reputation) = {[p9]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[2..5]}

### Loc150 [обычная]
    выбор описания: {[p34]}
    Loc150-1: You remembered that the piece of cardboard that you usually put under your behinds in order not to sit on anything too dirty originally used to be school notepa…
    Loc150-2: You tried to recollect all of your combat experience against the Dominators, and not only yours - after all, these nights in spaceport pubs, spent in the compan…
    Loc150-3: You told them about the knowledge that was transcended from one generation to another and showed the Faeyans the cube-puzzle. The puzzle was met with much enthu…
    Loc150-4: You turned the tape-recorder on and played a lecture called "The Whole Truth about Black Holes", which you'd found on one of the tapes. The Faeyans listened wit…
    Loc150-5: You produced a pipe and started blowing. Despite the music being rather pleasing to the ear, the listeners did not really appreciate it - the Faeyans were more …
    Loc150-6: You decided to take a look on what the Faeyans were talking about here. One of the participants of the conference stepped behind the tribune: /  / - Dear collea…
  -> Path507 => Loc151  вер=1 порядок=5
       текст: Go back to the cell

### Loc151 [пустая]
  -> Path509 => Loc28  вер=1 порядок=5

### Loc152 [пустая]
  -> Path514 => Loc151  вер=1 порядок=5
       текст: Go back to the cell

### Loc154 [обычная]
    Loc154-1: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - You know who are one of the most popular folks in prison? T…
    Loc154-2: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Argh... If only you knew how much I miss alcohol! I am abso…
    Loc154-3: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Only the strongest and the most reputable criminals can rac…
    Loc154-4: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - If you really do not feel well, better go and visit the med…
    Loc154-5: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - A Peleng once told me, that our local pop-star has gained h…
    Loc154-6: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - The word around the campus is that this prison is not as so…
    Loc154-7: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Nothing can impress the Faeyans more, than some weird mecha…
    Loc154-8: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - The inmates do not like egg-heads, but a lot of them could …
  -> Path519 => Loc155  вер=1 порядок=5
       текст: Throw another 5 cr to the blind man
       эффект: P28(Money) -5
  -> Path521 => Loc28  вер=1 порядок=5
       текст: Go back to the cell

### Loc155 [пустая]
  -> Path520 => Loc154  вер=1 порядок=5
  -> Path604 => Loc55  вер=1 порядок=5

### Loc156 [ПРОВАЛ]
    Loc156-1: You climbed through the hole and found yourself in the nearest sewage system. You made a long way underground and were now far away from the prison having safel…

### Loc157 [обычная]
    выбор описания: {[p26]}
    Loc157-1: Finally you saw the light in the end of the tunnel. The sup was complete. You crawled back into the cell to take a look at your sorry cot and the no less sorry …
    Loc157-2: Finally you saw the light in the end of the tunnel. The sup was complete. You crawled back into the cell to take a look at your sorry cot and the no less sorry …
    Loc157-3: Suddenly the light and the smell of freedom broke into the tunnel. The sap was finished, and judging by the familiar smell your way to freedom went through sewa…
  -> Path476 => Loc171  вер=1 порядок=5
       текст: Alright, go for it!
       ответ: You let the Human go instead of you, he shook you hand, shoved all his money into it and rushed down the tunnel. Suddenly you heard steps in the corridor. A rou…
       условия: P26(dimensions) 2..2
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P25(Sap) = 0
       эффект: P28(Money) +450
  -> Path477 => Loc156  вер=1 порядок=3
       текст: Escape through the tunnel
       условия: P25(Sap) 90..100
  -> Path541 => Loc171  вер=1 порядок=6
       текст: Set up the witness
       ответ: You broke away from the cell and ran to the warden. He was in his office, busy with piles of paper, and did not want to see anyone, but you insisted. You told h…
       условия: P25(Sap) 90..100; P26(dimensions) 1..1
       эффект: P25(Sap) = {0}
       эффект: P9(Reputation) -50%
       эффект: P7(Authorities' attitude) = {[p7]+[7..12]}
       эффект: P8(Guards' attitude) = {[p8]+[7..12]}
  -> Path548 => Loc171  вер=1 порядок=5
       текст: I finished the tunnel, run!
       ответ: - Thank you, <Ranger>! You helped me big time here. I will not forget this. Here, take this {300} cr, I think this is a decent payment for you helping me to esc…
       условия: P26(dimensions) 1..1
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P25(Sap) = 0
       эффект: P28(Money) +300
  -> Path549 => Loc171  вер=1 порядок=5
       текст: No need to get so worked up about this! Run, no problem!
       ответ: - Oh, <Ranger>, looks like you are a cool guy after all. Thanks, - the Maloq grabbed your hand and squeezed it painfully. - Here, take this {140} cr, I am sure …
       условия: P26(dimensions) 3..3
       эффект: P9(Reputation) = {[p9]+[10..20]}
       эффект: P25(Sap) = 0
       эффект: P28(Money) +140
  -> Path561 => Loc171  вер=1 порядок=6
       текст: Set up the witness
       ответ: You told the Human to pack for the road, and excusing yourself for a minute, rushed back to the warden. The guard at his office asked you what you wanted and le…
       условия: P25(Sap) 90..100; P26(dimensions) 2..2
       эффект: P25(Sap) = {0}
       эффект: P9(Reputation) -50%
       эффект: P7(Authorities' attitude) = {[p7]+[7..12]}
       эффект: P8(Guards' attitude) = {[p8]+[7..12]}
  -> Path562 => Loc171  вер=1 порядок=6
       текст: Set up the witness
       ответ: Without a word you left the cell. Unnoticed you carefully sneaked through to the warden's office and reported that there was a Maloq locked up in your cell doin…
       условия: P25(Sap) 90..100; P26(dimensions) 3..3
       эффект: P9(Reputation) -50%
       эффект: P7(Authorities' attitude) = {[p7]+[7..12]}
       эффект: P8(Guards' attitude) = {[p8]+[7..12]}

### Loc159 [обычная]
    Loc159-1: A Peleng-inmate went over to your cot.  /  / - Listen, <Ranger>, - he said, - somehow it seems to me, that you are interested in them amateur's nights. No? Well…
  -> Path558 => Loc172  вер=1 [всегда видна] порядок=5
       текст: Buy
       условия: логика {[p28]>=[p36]}
       эффект: P28(Money) = {[p28]-[p36]}
       эффект: P29(tape recorder) = {2} [показ]
  -> Path560 => Loc172  вер=1 порядок=9
       текст: Refuse

### Loc160 [обычная]
    Loc160-1: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - If you don't want to do any hard work, make frie…
    Loc160-2: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Good food will help you improve your health, but…
    Loc160-3: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - They say that the last fist-fighting champion, Bite-Punch, …
    Loc160-4: You tossed {5} cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - A cellmate read it to me from some newspaper that according…
    Loc160-5: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Cockroach races are a traditional entertainment …
    Loc160-6: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - The jail gym has excellent equipment and by work…
    Loc160-7: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - They say, that fools are always lucky, but I wou…
    Loc160-8: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - Try not to lose your cellmates' respect! They do…
    Loc160-9: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom:  / - During the weekends the real criminals like to …
    Loc160-10: You tossed <clr>5<clrEnd> cr into the blind-man's hat and he introduced you to the treasury of jail wisdom: / - On Sundays the prison authorities become a nice …
  -> Path249 => Loc23  вер=1 проходов<=1 порядок=5
       текст: Head back to your cell
  -> Path250 => Loc88  вер=1 [всегда видна] порядок=5
       текст: Throw another 5 cr to the blind man
       условия: P28(Money) 5..1000000000
       эффект: P28(Money) -5

### Loc161 [обычная]
    Loc161-1: It occurred to you that the best way out of this situation would be passing off as a mute - he who cannot speak, cannot blabber anything out. / - Mmmmm... - you…
  -> Path564 => Loc162  вер=1 порядок=5
       текст: Yes!
       ответ: - Yes - what? - the warden asked. / - I mean, "yes", it's all these guards - they are beating me up everyday, and on weekends and holidays, the beat me twice a …
       эффект: P4(Health) = {[p4]-[3..8]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P6(Intellect) = {[p6]-[1..5]}
       эффект: P7(Authorities' attitude) = {[p7]-[3..7]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}
  -> Path566 => Loc162  вер=1 порядок=5
       текст: Mmm... (shake your head in negation)
       ответ: - You mean to say, that the guards have nothing to do with this? - she wouldn't let you go. / - Uhm, - you nodded affirmatively and tried to explain in sign lan…
       эффект: P9(Reputation) = {[p9]-[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[7..12]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
  -> Path567 => Loc162  вер=1 порядок=5
       текст: Mmmmm (nod in affirmation)
       ответ: - So, you mean to say that the guards are beating you up violently? - she would not let it go. / - Mhm, - you nodded again and tried to explain in sign-language…
       условия: P33(cube) ∈[0]
       эффект: P33(cube) +1 [показ]
       эффект: P9(Reputation) = {[p9]+[-3..3]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..5]}
       эффект: P8(Guards' attitude) = {[p8]-[1..5]}
  -> Path569 => Loc162  вер=1 порядок=5
       текст: No...
       ответ: - No - what? - the warden asked. / - I mean "no", I had been a mute already before I got here. And the local OG's are constantly beating me up, and it made a fo…
       эффект: P9(Reputation) = {[p9]-[8..12]}
       эффект: P7(Authorities' attitude) = {[p7]-[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[5..10]}
  -> Path570 => Loc162  вер=1 порядок=5
       текст: Mmmmm (nod in affirmation)
       ответ: - So, you mean to say that the guards are beating you up violently? - she would not let it go. / - Mhm, - you nodded again and tried to explain in sign-language…
       условия: P33(cube) ∈[1]
       эффект: P4(Health) = {[p4]+[0..2]}
       эффект: P9(Reputation) = {[p9]+[-3..3]}
       эффект: P7(Authorities' attitude) = {[p7]-[1..5]}
       эффект: P8(Guards' attitude) = {[p8]-[1..5]}

### Loc162 [пустая]
  -> Path568 => Loc23  вер=1 порядок=5

### Loc163 [обычная] визитов<=1
    Loc163-1: You approached the door of the med-station when you heard some noise and loud voices coming from the inside. Stepping forward carefully, you pressed your ear ag…
  -> Path573 => Loc28  вер=1 проходов<=1 порядок=5
       текст: Quietly walk away, before they noticed you.
       ответ: "Looks like today the medical station is closed today ", - you thought to yourself on the way back to the cell.
  -> Path574 => Loc166  вер=1 проходов<=1 порядок=5
       текст: Knock and ask any help was needed
       эффект: P35(x) = {2}
  -> Path575 => Loc166  вер=1 проходов<=1 порядок=5
       текст: Take a deep breath and break in
       эффект: P9(Reputation) = {[p9]+[0..1]}
       эффект: P35(x) = {1}

### Loc165 [пустая] визитов<=1
  -> Path572 => Loc126  вер=1 проходов<=1 порядок=5
       эффект: P13(pp 2) = 0
       эффект: P35(x) = {7}

### Loc166 [обычная] визитов<=10
    выбор описания: {[p35]}
    Loc166-1: You kicked the door in and broke into the room. You saw the huge Maloq wrestle with the nurse trying bring her down on the couch, and his tattooed Peleng partne…
    Loc166-2: - No, homey, we are doing a good job ourselves, y'know, - the rough Maloq voice said. / - Say, big man, I'll go see who the hell is there... - with these words …
  -> Path576 => Loc28  вер=1 проходов<=1 порядок=9
       текст: Sorry I was just passing by (run away)
       ответ: Deciding not to mess with these hoodlums you, you turned away and rushed off like there was no tomorrow. Stopping round the corner to catch your breath you list…
       эффект: P9(Reputation) = {[p9]-[5..10]}
       эффект: P8(Guards' attitude) = {[p8]-[3..7]}
  -> Path578 => Loc167  вер=1 проходов<=1 порядок=4
       текст: Alright, you scumbags, prepare to die! (attack them)
       ответ: - Hey, Sis, I hope you got a couple of them bodybags somewhere in the back? - you said with a wicked grin and jumped onto the Maloq. / - Hey, punk, wassup with …
       условия: P5(Strength) 50..100
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P35(x) = {6}
  -> Path579 => Loc167  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: I suggest that we settle this peacefully - I am going to give you {500} cr, and you leave the girl alone
       ответ: - Err, dude, you actually like mean it? - the Maloq scratched the back of his head. / - Hey, man, who does this punk think he is - the tatted Peleng shrieked hi…
       условия: P9(Reputation) 30..69; P28(Money) 500..1000000000
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P28(Money) = {[p28]-500}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
       эффект: P35(x) = {1}
  -> Path580 => Loc167  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: I suggest that we settle this peacefully - I am going to give you {500} cr, and you leave the girl alone
       ответ: - Err, dude, you actually like mean it? - the Maloq scratched the back of his head. / - Hey, man, who does this punk think he is - the tatted Peleng shrieked hi…
       условия: P9(Reputation) 70..99; P28(Money) 500..1000000000
       эффект: P9(Reputation) = {[p9]-[2..5]}
       эффект: P28(Money) = {[p28]-250}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
       эффект: P35(x) = {2}
  -> Path581 => Loc168  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: I suggest that we settle this peacefully - I am going to give you {500} cr, and you leave the girl alone
       условия: P5(Strength) 0..69; P9(Reputation) 0..39; P28(Money) 500..1000000000
       эффект: P9(Reputation) = {[p9]-[1..4]}
       эффект: P28(Money) = {[p28]-500}
       эффект: P4(Health) = {[p4]-[10..15]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[1..4]}
       эффект: P35(x) = {1}
  -> Path582 => Loc167  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Hey, yo! Isn't it time for you girls to go home? Yeah, you...
       ответ: - Hey, punk, wassup with that? - the Maloq was outraged. - When exactly was it that some rotten scum started as much as to even talk back to us? / - Get'im, get…
       условия: P5(Strength) 50..100; P9(Reputation) 0..69
       эффект: P9(Reputation) = {[p9]+[2..5]}
       эффект: P4(Health) = {[p4]-[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]+[2..5]}
       эффект: P8(Guards' attitude) = {[p8]+[2..5]}
       эффект: P35(x) = {4}
  -> Path584 => Loc167  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: I suggest that we settle this peacefully - I am going to give you {500} cr, and you leave the girl alone
       ответ: - Hey, punk, wassup with that? - the Maloq was outraged. - When exactly was it that some rotten scum started offering any deals to us? / - Who does this scum th…
       условия: P5(Strength) 70..100; P9(Reputation) 0..39; P28(Money) 500..1000000000
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P28(Money) = {[p28]+100}
       эффект: P4(Health) = {[p4]-[5..10]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[5..10]}
       эффект: P35(x) = {3}
  -> Path585 => Loc167  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Hey, yo! Isn't it time for you girls to go home? Yeah, you...
       ответ: - Hey, punk, wassup with that? - the Peleng was in proper fury. - When exactly was it that some rotten scum started as much as to even talk back to us? / - Shut…
       условия: P9(Reputation) 70..99
       эффект: P9(Reputation) = {[p9]+[1..3]}
       эффект: P7(Authorities' attitude) = {[p7]+[0..2]}
       эффект: P8(Guards' attitude) = {[p8]+[1..3]}
       эффект: P35(x) = {5}
  -> Path586 => Loc168  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Hey, yo! Isn't it time for you girls to go home? Yeah, you...
       условия: P5(Strength) 0..69; P9(Reputation) 0..69
       эффект: P9(Reputation) = {[p9]-[1..3]}
       эффект: P4(Health) = {[p4]-[10..15]}
       эффект: P7(Authorities' attitude) = {[p7]+[3..7]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P35(x) = {2}
  -> Path587 => Loc168  вер=1 проходов<=1 порядок=4
       текст: Alright, you scumbags, prepare to die! (attack them)
       условия: P5(Strength) 0..69
       эффект: P5(Strength) = {[p5]-[3..7]}
       эффект: P4(Health) = {[p4]-[15..20]}
       эффект: P9(Reputation) = {[p9]+[5..10]}
       эффект: P6(Intellect) = {[p6]-[3..7]}
       эффект: P7(Authorities' attitude) = {[p7]+[5..8]}
       эффект: P8(Guards' attitude) = {[p8]+[3..7]}
       эффект: P35(x) = {3}

### Loc167 [пустая] визитов<=2
  -> Path589 => Loc169  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: I think I could use some spirit...
       условия: P31(Alcohol) 0..0
       эффект: P31(Alcohol) +1
       эффект: P35(x) = {9}
  -> Path591 => Loc169  вер=1 проходов<=1 порядок=5
       текст: Yes, I don't really feel well - so I could use some professional assistance
       ответ: - So I noticed, - she smiled. - Looks like conventional methods are not going to help here, but don't you worry, hero. /  / With these words she produced a syri…
       эффект: P4(Health) = {100}
       эффект: P35(x) = {7}

### Loc168 [обычная] визитов<=1
    выбор описания: {[p35]}
    Loc168-1: - Hey, punk, wassup with that? - the Maloq was outraged. - When exactly was it that some rotten scum started offering any deals to us? / - Who does this scum th…
    Loc168-2: - Hey, punk, wassup with that? - the Maloq was outraged. - When exactly was it that some rotten scum started as much as to even talk back to us? / - Get'im, get…
    Loc168-3: - Hey, Sis, I hope you've got a couple of those bodybags somewhere in the back? - you said with a wicked grin and jumped onto the Maloq. / - Hey, punk, wassup w…
  -> Path583 => Loc165  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc169 [пустая] визитов<=1
  -> Path588 => Loc126  вер=1 проходов<=1 порядок=5

### Loc170 [пустая]
  -> Path592 => Loc23  вер=1 порядок=5

### Loc171 [пустая]
  -> Path593 => Loc23  вер=1 порядок=5

### Loc172 [пустая]
  -> Path598 => Loc91  вер=1 порядок=5

## Анализ
- стартовых: [1]
- концовки: {19: 'ПРОВАЛ', 21: 'СМЕРТЬ', 37: 'УСПЕХ', 105: 'УСПЕХ', 156: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
