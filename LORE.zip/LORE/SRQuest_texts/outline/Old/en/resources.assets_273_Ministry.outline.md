# Квест (формат 1111111126)
Сложность 20; стартовая локация: [121]; путей по умолчанию: 1

## Параметры
- P1 'Clothes' [0..4] тип=провал
    старт: [4]
    [0..0] You have nothing on
    [1..1] All you have on are underpants with hearts on them
    [2..2] You have underpants and boots on
    [3..3] You do not carry a ranger badge
    [4..4] You are dressed casually
    критическое: After you lost all your clothes, you could not proceed with the important mission. You quickly ran t…
- P2 'Garrison cap' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You have a garrison cap on
    критическое: Сообщение достижения критического значения параметром 11
- P3 'Your money' [0..100000] тип=обычный деньги
    старт: [50]
    [0..100000] You've got <> cr
    критическое: Сообщение достижения критического значения параметром 1
- P5 'Inventory (inscription)' [0..1] тип=обычный
    старт: [0]
    [0..1] Other things:
    критическое: Сообщение достижения критического значения параметром 3
- P7 "Secretary's things" [0..2] тип=обычный
    старт: [2]
    [0..0] 
    [1..1] Watch
    [2..2] Watch and glasses
    критическое: Сообщение достижения критического значения параметром 5
- P8 'Fishing rod (and related)' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Fishing rod
    [2..2] Fishing rod with a bait
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Crowbar' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Crowbar
    критическое: Сообщение достижения критического значения параметром 9
- P10 'To play cards' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 7
- P11 'Papers' [0..3] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Papers (not stamped)
    [2..2] Papers (not stamped)
    [3..3] Papers (stamped)
    критическое: Сообщение достижения критического значения параметром 12
- P12 'Fish' [0..1] тип=обычный
    старт: [1]
    [0..0] 
    [1..1] Three-eye fish
    критическое: Сообщение достижения критического значения параметром 6
- P13 'Your glasses' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Hand: {<> mod 100} pt.
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Hearts+Diamonds (F1)' [0..20000000] тип=обычный
    старт: [0]
    [0..20000000] Parameter 14: <>
    критическое: Сообщение достижения критического значения параметром 14
- P15 "Opponent's points" [0..1000] тип=обычный
    старт: [0]
    [0..1] Your bet: 10 cr
    [2..2] Your bet: 25 cr
    [3..3] Your bet: 40 cr
    [4..4] Your bet: 55 cr
    [5..1000] Your bet: 70 cr
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Clubs+Spades (F2)' [0..20000000] тип=обычный
    старт: [0]
    [0..20000000] Parameter 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Value generator' [0..50] тип=обычный
    старт: [0]
    [0..50] Parameter 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P19 'Game process' [0..5] тип=обычный
    старт: [0]
    [0..5] 
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Stayed in the basement (bool)' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Played cards (bool)' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Test points' [0..10000] тип=обычный
    старт: [0]
    [0..10000] Current win: <> cr
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Parameter 23' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 23
- P25 'x' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 25

## Локации и переходы

### Loc98 [обычная]
    выбор описания: {[p25]}
    Loc98-1: - So are we playing or not? - the secretary asked rudely while riffling the pack.
    Loc98-2: - It's not the right time to explain it completely. Alright. To put it short. Each player takes cards in turns. At first - by two cards. If it's not enough, the…
    Loc98-3: You already lost your worn out dirty <clr>boots<clrEnd>. Why would anyone need them except you? But judging from the happy face of your opponent, she needs your…
    Loc98-4: You took off the <clr>overalls<clrEnd>, and passed it over to the secretary. It looks like you gradually turn from a space hero into a space bum... Well, you sh…
    Loc98-5: Reluctantly you took of the <clr>ranger badge<clrEnd>. /  / - A nice thingy. Shiny, like the housemaster's bold head! - the secretary said.
    Loc98-6: You did not enjoy your victory long. After a few sighs you returned <clr>the watch<clrEnd> to the secretary.
    Loc98-7: - What do I give you? Alright, here is my <clr>watch<clrEnd>, - mumbled the secretary sadly, took off her watch and handed it over to you. / - What time is it? …
    Loc98-8: Here comes your <clr>overall<clrEnd> back. How pleasant it is to return into this synthetic wonder. Ah, I can hardly describe it...
    Loc98-9: Here come the <clr>boots<clrEnd> back. Worn out, dirty ones, anyway, they are yours. With pride you took them on your precious feet.
    Loc98-10: Hurray! You made it! You won back your pride - the <clr>ranger badge<clrEnd>. Satisfied, you pinned it to your overalls. All galaxy girls are yours again!
    эффект: P10(To play cards) = 0
    эффект: P13(Your glasses) = 0
    эффект: P14(Hearts+Diamonds (F1)) = {0}
    эффект: P15(Opponent's points) = {0}
    эффект: P16(Clubs+Spades (F2)) = {0}
    скрыт: P4,P6
  -> Path602 => Loc116  вер=1 порядок=6
       текст: Could you remind the rules please?
       эффект: P25(x) = 2
  -> Path641 => Loc101  вер=1 порядок=5
       текст: Deal faster
       эффект: P10(To play cards) = 0
       эффект: P13(Your glasses) = 0 [показ]
       эффект: P14(Hearts+Diamonds (F1)) = 0
       эффект: P15(Opponent's points) = 0
       эффект: P16(Clubs+Spades (F2)) = 0
  -> Path642 => Loc129  вер=1 порядок=9
       текст: Rather no than yes. I'd rather say definitely no. I mean no, period!
       эффект: P25(x) = 1

### Loc99 [пустая]
  -> Path539 => Loc108  вер=1 порядок=5

### Loc101 [пустая]
  -> Path451 => Loc102  вер=1 порядок=5
       условия: логика {([p14] mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+1}
       эффект: P15(Opponent's points) = {[p15]+6}
       эффект: P17(Value generator) = 19
  -> Path452 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 131072) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+11}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+131072}
       эффект: P17(Value generator) = 18
  -> Path453 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 2) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+2}
       эффект: P15(Opponent's points) = {[p15]+7}
       эффект: P17(Value generator) = 20
  -> Path454 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 65536) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+4}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+65536}
       эффект: P17(Value generator) = 17
  -> Path455 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 4) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+4}
       эффект: P15(Opponent's points) = {[p15]+8}
       эффект: P17(Value generator) = 21
  -> Path456 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 32768) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+3}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+32768}
       эффект: P17(Value generator) = 16
  -> Path457 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 8) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+8}
       эффект: P15(Opponent's points) = {[p15]+9}
       эффект: P17(Value generator) = 22
  -> Path458 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 16384) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+2}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+16384}
       эффект: P17(Value generator) = 15
  -> Path459 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 16) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+16}
       эффект: P15(Opponent's points) = {[p15]+10}
       эффект: P17(Value generator) = 23
  -> Path460 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 8192) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+10}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+8192}
       эффект: P17(Value generator) = 14
  -> Path461 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 32) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+32}
       эффект: P15(Opponent's points) = {[p15]+2}
       эффект: P17(Value generator) = 24
  -> Path462 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 4096) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+9}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+4096}
       эффект: P17(Value generator) = 13
  -> Path463 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 64) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+64}
       эффект: P15(Opponent's points) = {[p15]+3}
       эффект: P17(Value generator) = 25
  -> Path464 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 2048) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+8}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+2048}
       эффект: P17(Value generator) = 12
  -> Path465 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 128) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+128}
       эффект: P15(Opponent's points) = {[p15]+4}
       эффект: P17(Value generator) = 26
  -> Path466 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 1024) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+7}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+1024}
       эффект: P17(Value generator) = 11
  -> Path467 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 256) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+256}
       эффект: P15(Opponent's points) = {[p15]+11}
       эффект: P17(Value generator) = 27
  -> Path468 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 512) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+6}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+512}
       эффект: P17(Value generator) = 10
  -> Path469 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 512) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+512}
       эффект: P15(Opponent's points) = {[p15]+6}
       эффект: P17(Value generator) = 28
  -> Path470 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 256) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+11}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+256}
       эффект: P17(Value generator) = 9
  -> Path471 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 1024) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+1024}
       эффект: P15(Opponent's points) = {[p15]+7}
       эффект: P17(Value generator) = 29
  -> Path472 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 128) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+4}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+128}
       эффект: P17(Value generator) = 8
  -> Path473 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 2048) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+2048}
       эффект: P15(Opponent's points) = {[p15]+8}
       эффект: P17(Value generator) = 30
  -> Path474 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 64) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+3}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+64}
       эффект: P17(Value generator) = 7
  -> Path475 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 4096) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+4096}
       эффект: P15(Opponent's points) = {[p15]+9}
       эффект: P17(Value generator) = 31
  -> Path476 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 32) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+2}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+32}
       эффект: P17(Value generator) = 6
  -> Path477 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 8192) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+8192}
       эффект: P15(Opponent's points) = {[p15]+10}
       эффект: P17(Value generator) = 32
  -> Path478 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 16) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+10}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+16}
       эффект: P17(Value generator) = 5
  -> Path479 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 16384) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+16384}
       эффект: P15(Opponent's points) = {[p15]+2}
       эффект: P17(Value generator) = 33
  -> Path480 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 8) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+9}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+8}
       эффект: P17(Value generator) = 4
  -> Path481 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 32768) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+32768}
       эффект: P15(Opponent's points) = {[p15]+3}
       эффект: P17(Value generator) = 34
  -> Path482 => Loc102  вер=1 порядок=5
       условия: логика {(([p16] div 4) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+8}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+4}
       эффект: P17(Value generator) = 3
  -> Path484 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 65536) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+65536}
       эффект: P15(Opponent's points) = {[p15]+4}
       эффект: P17(Value generator) = 35
  -> Path486 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 2) mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+7}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+2}
       эффект: P17(Value generator) = 2
  -> Path562 => Loc102  вер=1 порядок=5
       условия: логика {(([p14] div 131072) mod 2)=0}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+131072}
       эффект: P15(Opponent's points) = {[p15]+11}
       эффект: P17(Value generator) = 36
  -> Path599 => Loc102  вер=1 порядок=5
       условия: логика {([p14] mod 2)=0}
       эффект: P15(Opponent's points) = {[p15]+6}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+1}
       эффект: P17(Value generator) = 1

### Loc102 [пустая]
  -> Path525 => Loc105  вер=1 порядок=5

### Loc103 [обычная]
    выбор описания: {([p15]>100)+1}
    Loc103-1: With a serious expression on her face, the secretary took a card from the top of the pack.  / Then she took another card from the pack and handed it to you with…
    Loc103-2: With a grin, the secretary took a card from the pack and handed it to you. Looks like she does not wish you victory. By the way, you don't wish it to her either…
  -> Path563 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Six of diamonds.
       условия: логика {([p14] mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+6}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+1}
       эффект: P17(Value generator) = 19
  -> Path564 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ace of clubs.
       условия: логика {(([p16] div 131072) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+11}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+131072}
       эффект: P17(Value generator) = 18
  -> Path565 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Seven of diamonds.
       условия: логика {(([p14] div 2) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+7}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+2}
       эффект: P17(Value generator) = 20
  -> Path566 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: King of clubs.
       условия: логика {(([p16] div 65536) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+4}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+65536}
       эффект: P17(Value generator) = 17
  -> Path567 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Eight of diamonds.
       условия: логика {(([p14] div 4) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+8}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+4}
       эффект: P17(Value generator) = 21
  -> Path568 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Queen of clubs.
       условия: логика {(([p16] div 32768) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+3}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+32768}
       эффект: P17(Value generator) = 16
  -> Path569 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Nine of diamonds.
       условия: логика {(([p14] div 8) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+9}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+8}
       эффект: P17(Value generator) = 22
  -> Path570 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Jack of clubs.
       условия: логика {(([p16] div 16384) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+2}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+16384}
       эффект: P17(Value generator) = 15
  -> Path571 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ten of diamonds.
       условия: логика {(([p14] div 16) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+10}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+16}
       эффект: P17(Value generator) = 23
  -> Path572 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ten of clubs.
       условия: логика {(([p16] div 8192) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+10}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+8192}
       эффект: P17(Value generator) = 14
  -> Path573 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Jack of diamonds.
       условия: логика {(([p14] div 32) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+2}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+32}
       эффект: P17(Value generator) = 24
  -> Path574 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Nine of clubs.
       условия: логика {(([p16] div 4096) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+9}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+4096}
       эффект: P17(Value generator) = 13
  -> Path575 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Queen of diamonds.
       условия: логика {(([p14] div 64) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+3}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+64}
       эффект: P17(Value generator) = 25
  -> Path576 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Eight if clubs.
       условия: логика {(([p16] div 2048) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+8}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+2048}
       эффект: P17(Value generator) = 12
  -> Path577 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: King of diamonds.
       условия: логика {(([p14] div 128) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+4}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+128}
       эффект: P17(Value generator) = 26
  -> Path578 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Seven of clubs.
       условия: логика {(([p16] div 1024) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+7}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+1024}
       эффект: P17(Value generator) = 11
  -> Path579 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ace of diamonds.
       условия: логика {(([p14] div 256) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+11}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+256}
       эффект: P17(Value generator) = 27
  -> Path580 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Six of clubs.
       условия: логика {(([p16] div 512) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+6}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+512}
       эффект: P17(Value generator) = 10
  -> Path581 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Six of hearts.
       условия: логика {(([p14] div 512) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+6}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+512}
       эффект: P17(Value generator) = 28
  -> Path582 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ace of spades.
       условия: логика {(([p16] div 256) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+11}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+256}
       эффект: P17(Value generator) = 9
  -> Path583 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Seven of hearts.
       условия: логика {(([p14] div 1024) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+7}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+1024}
       эффект: P17(Value generator) = 29
  -> Path584 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: King of spades.
       условия: логика {(([p16] div 128) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+4}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+128}
       эффект: P17(Value generator) = 8
  -> Path585 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Eight of hearts.
       условия: логика {(([p14] div 2048) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+8}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+2048}
       эффект: P17(Value generator) = 30
  -> Path586 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Queen of spades.
       условия: логика {(([p16] div 64) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+3}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+64}
       эффект: P17(Value generator) = 7
  -> Path587 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Nine of hearts.
       условия: логика {(([p14] div 4096) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+9}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+4096}
       эффект: P17(Value generator) = 31
  -> Path588 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Jack of spades.
       условия: логика {(([p16] div 32) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+2}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+32}
       эффект: P17(Value generator) = 6
  -> Path589 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ten of hearts.
       условия: логика {(([p14] div 8192) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+10}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+8192}
       эффект: P17(Value generator) = 32
  -> Path590 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ten of spades.
       условия: логика {(([p16] div 16) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+10}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+16}
       эффект: P17(Value generator) = 5
  -> Path591 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Jack of hearts.
       условия: логика {(([p14] div 16384) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+2}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+16384}
       эффект: P17(Value generator) = 33
  -> Path592 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Nine of spades.
       условия: логика {(([p16] div 8) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+9}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+8}
       эффект: P17(Value generator) = 4
  -> Path593 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Queen of hearts.
       условия: логика {(([p14] div 32768) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+3}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+32768}
       эффект: P17(Value generator) = 34
  -> Path594 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Eight of spades.
       условия: логика {(([p16] div 4) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+8}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+4}
       эффект: P17(Value generator) = 3
  -> Path595 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: King of hearts.
       условия: логика {(([p14] div 65536) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+4}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+65536}
       эффект: P17(Value generator) = 35
  -> Path596 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Seven of spades.
       условия: логика {(([p16] div 2) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+7}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+2}
       эффект: P17(Value generator) = 2
  -> Path597 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Ace of hearts.
       условия: логика {(([p14] div 131072) mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+11}
       эффект: P14(Hearts+Diamonds (F1)) = {[p14]+131072}
       эффект: P17(Value generator) = 36
  -> Path598 => Loc99  вер=1 порядок=5
       текст: Take the card and look at it
       ответ: Six of spades.
       условия: логика {([p16] mod 2)=0}
       эффект: P13(Your glasses) = {[p13]+6}
       эффект: P16(Clubs+Spades (F2)) = {[p16]+1}
       эффект: P17(Value generator) = 1

### Loc105 [пустая]
  -> Path526 => Loc106  вер=0.5 порядок=5
       условия: P15(Opponent's points) 18..18
  -> Path527 => Loc106  вер=0.7 порядок=5
       условия: P15(Opponent's points) 17..17
  -> Path528 => Loc106  вер=0.25 порядок=5
       условия: P15(Opponent's points) 19..19
  -> Path530 => Loc106  вер=1 порядок=5
       условия: P15(Opponent's points) 15..16
  -> Path531 => Loc106  вер=2 порядок=5
       ответ: With a serious grin, the secretary took a card from the top of the pack.  / - I think I stop at this one - the secretary said calmly.
       условия: логика {[p15]>=15}
       эффект: P15(Opponent's points) = {[p15]+100}
  -> Path556 => Loc134  вер=1000 порядок=5
       условия: логика {([p15]=21) and ([p10]=1)}
       эффект: P25(x) = 2
       скрыт: P5
  -> Path560 => Loc103  вер=1000 порядок=5
       условия: логика {[p10]=0}
  -> Path601 => Loc106  вер=1 порядок=5
       условия: P15(Opponent's points) 0..14

### Loc106 [пустая]
  -> Path532 => Loc101  вер=1 порядок=5
       условия: логика {([p13]>100) and ([p15]<100) and ([p10]<6)}
       эффект: P10(To play cards) +1
  -> Path533 => Loc103  вер=1 порядок=5
       условия: логика {[p13]<100}
  -> Path534 => Loc107  вер=1 порядок=5
       условия: логика {([p13]>100) and ([p15]>100)}
  -> Path540 => Loc107  вер=1000 порядок=5
       ответ: - Seven rounds are over. The game is over according to the rules, - the secretary declared.
       условия: логика {([p15]>100) and ([p10]=6)}

### Loc107 [пустая]
    эффект: P13(Your glasses) = {[p13] mod 100} [скрыт]
    эффект: P15(Opponent's points) = {[p15] mod 100}
  -> Path547 => Loc110  вер=1000 порядок=5
       условия: логика {([p13]=[p15]) and ([p13]<=21) and ([p15]<=21)}
  -> Path548 => Loc134  вер=1 порядок=5
       условия: логика {(([p15]>[p13]) and ([p15]<=21)) or (([p15]<=21) and ([p13]>21))}
       эффект: P25(x) = 1
  -> Path549 => Loc113  вер=1000 порядок=5
       условия: логика {([p13]>21) and ([p15]>21)}
  -> Path550 => Loc139  вер=1 порядок=5
       условия: логика {(([p13]>[p15]) and ([p13]<=21)) or (([p13]<=21) and ([p15]>21))}
       эффект: P25(x) = 1

### Loc108 [пустая]
  -> Path541 => Loc107  вер=1 порядок=5
       ответ: - Seven rounds are over. The game is over according to the rules, - the secretary declared.
       условия: логика {[p10]=6}
  -> Path542 => Loc109  вер=1 порядок=5
       условия: логика {[p10]<6}
  -> Path558 => Loc139  вер=1000 порядок=5
       условия: логика {([p13]=21) and ([p10]=1)}
       эффект: P25(x) = 2
  -> Path561 => Loc101  вер=1000 порядок=5
       условия: логика {[p10]=0}
       эффект: P10(To play cards) +1

### Loc109 [обычная]
    Loc109-1: - Another one, pilot? Or is that enough? - she said with a blow of smoke into your face.
  -> Path543 => Loc101  вер=1 порядок=2
       текст: Enough
       условия: логика {[p15]<100}
       эффект: P10(To play cards) +1
       эффект: P13(Your glasses) = {[p13]+100}
  -> Path544 => Loc101  вер=1 [всегда видна] порядок=1
       текст: More
       условия: логика {([p15]<100) and ([p13]<20)}
       эффект: P10(To play cards) +1
  -> Path545 => Loc103  вер=1 [всегда видна] порядок=1
       текст: More
       условия: логика {([p15]>=100) and ([p13]<20)}
       эффект: P10(To play cards) +1
  -> Path546 => Loc107  вер=1 порядок=2
       текст: Enough
       условия: логика {[p15]>=100}

### Loc110 [обычная]
    Loc110-1: - Alright, what have you got? - Rachehanovna said casually.  / You opened your cards slowly - you've got [p13]. The tension rose. After looking at your cards, t…
  -> Path600 => Loc98  вер=1 порядок=5
       текст: Next
       эффект: P25(x) = 1

### Loc113 [обычная]
    Loc113-1: - Alright, what have you got? - the secretary said seriously.  / You slowly turned your cards one by one - you've got [p13]. Overshoot. Then the secretary opene…
  -> Path551 => Loc98  вер=1 порядок=5
       текст: Next
       эффект: P25(x) = 1

### Loc116 [пустая]
  -> Path603 => Loc98  вер=1 порядок=5

### Loc117 [обычная]
    выбор описания: {1+([p2]=1)}
    Loc117-1: You stand in a hall with pink speckled wallpaper.  /  / To the left the commandant stands, frowning and wagging his finger at you.  / In front of you - the corr…
    Loc117-2: You stand in a hall with pink speckled wallpaper.  /  / To the left of you the commandant stands. He smiles at you.  / In front of you - the corridor. / To the …
  -> Path604 => Loc118  вер=10000 проходов<=1 порядок=3
       текст: Go down the stairs
       ответ: After you cheerfully went down the stairs, you found yourself in the basement and suddenly stepped on your shoelace. The brave ranger sprawled out on the floor …
       эффект: P25(x) = 1
  -> Path605 => Loc118  вер=1 порядок=3
       текст: Go down the stairs
       эффект: P25(x) = 1
  -> Path612 => Loc122  вер=1 порядок=1
       текст: Talk to the commandant
       условия: логика {[p2]=0}
  -> Path616 => Loc124  вер=1 порядок=2
       текст: Go to the corridor
  -> Path704 => Loc153  вер=1 порядок=1
       текст: Talk to the commandant
       ответ: "Commandant, sorry to disturb you, but..." - you started. / "I can see you are wearing the garrison cap of the resistance, soldier. Just let me know what you ne…
       условия: логика {[p2]=1}
       эффект: P25(x) = 1
  -> Path778 => Loc176  вер=1 порядок=4
       текст: Go outside
       эффект: P25(x) = 1

### Loc118 [обычная]
    выбор описания: {[p25]}
    Loc118-1: A gloomy ragged basement. Torn wallpaper hangs from the walls. The floor is scratched, it looks like somebody was moving a lot of heavy furniture. But the most …
    Loc118-2: "Wait, - you said to yourself, - its not over yet. You're only going to have a bruise on the forehead..." /  / A gloomy ragged basement. Torn wallpaper hangs fr…
    Loc118-3: You cast the line in the hole with water, but nothing happened. You were going to take out the bait when the fishing line tightened. Out of surprise you pulled …
    Loc118-4: You cast the line in the hole with water, but nothing happened.
    Loc118-5: You carefully hooked the door with a crowbar and finally opened it. There was a lot of dust inside ... and a small envelope. You opened it and found <clr>100 cr…
    Loc118-6: "Splash", - and the crowbar vanished in deep waters like a cargo ship in hyperspace. Nothing else happened. What could happen anyway?
    Loc118-7: You carefully inspected the wallpaper, crumpled it and even tasted a small piece. This looks like ordinary wallpaper - nothing special. You decided against taki…
    Loc118-8: You carefully looked into the hole. Something moved there. You assumed the worse - it was Babai! But can it be just ripple on the water? Anyway you should bette…
    эффект: P20(Stayed in the basement (bool)) = 1
  -> Path606 => Loc119  вер=1 проходов<=1 порядок=1
       текст: Approach the door and try to open it
       условия: P23(Parameter 23) 0..0
  -> Path608 => Loc120  вер=1 проходов<=1 порядок=5
       текст: Peek into the hole
       эффект: P25(x) = 8
  -> Path609 => Loc120  вер=1 проходов<=1 порядок=6
       текст: Inspect wallpaper
       эффект: P25(x) = 7
  -> Path620 => Loc117  вер=1 порядок=9
       текст: Back to the lobby
  -> Path675 => Loc120  вер=1 проходов<=1 порядок=4
       текст: Break the door with the crowbar
       условия: логика {[p9]=1}
       эффект: P3(Your money) = {[p3]+100}
       эффект: P23(Parameter 23) = 1
       эффект: P25(x) = 5
  -> Path676 => Loc120  вер=1 порядок=7
       текст: Toss the crowbar in the hole with water
       условия: логика {[p9]=1}
       эффект: P9(Crowbar) = 0
       эффект: P25(x) = 6
  -> Path792 => Loc120  вер=1
       текст: Cast the line into the hole with water
       условия: логика {[p8]=1}
       эффект: P25(x) = 4
  -> Path796 => Loc120  вер=1
       текст: Cast the line into the hole with water
       условия: логика {[p8]=2}
       эффект: P8(Fishing rod (and related)) = 0
       эффект: P12(Fish) = 1
       эффект: P25(x) = 3

### Loc119 [обычная] визитов<=1
    Loc119-1: You bravely came up to the door and pulled the handle. The door did not open. You pulled harder; the handle came off, slipped from your hand and hit you right i…
  -> Path607 => Loc118  вер=1 проходов<=1 порядок=5
       текст: Game over
       эффект: P25(x) = 2

### Loc120 [пустая]
  -> Path610 => Loc118  вер=1 порядок=5

### Loc121 [СТАРТ]
    Loc121-1: After you graciously landed, you stepped down on to Rectal Island and into a cowpat. A nice start indeed... Shaking the dirty foot you jumped to the administrat…
    эффект: P7(Secretary's things) = 0
    эффект: P12(Fish) = 0
    эффект: P23(Parameter 23) = 0 [скрыт]
    показ: P1,P3,P5,P11
    скрыт: P10,P13,P14,P15,P16,P17,P19,P20,P21,P22
  -> Path611 => Loc117  вер=1 порядок=5
       текст: Look around

### Loc122 [обычная]
    Loc122-1: "Commandant, sorry to disturb you, but..." - you began. / "How you dare to speak with me, punk? When I fought enemies of the galaxy, you were in pinafores..."
  -> Path613 => Loc123  вер=1 проходов<=1 порядок=5
       текст: Hit the watchman's booth with a fist
       ответ: You hauled off and hit the booth glass. "Bang" - a pleasant sound flew across the lobby. But the glass was not broken. You looked at the commandant, and he only…
  -> Path615 => Loc117  вер=1 порядок=5
       текст: Leave the commandant alone with his memories
  -> Path697 => Loc150  вер=1 порядок=5
       текст: Hit the booth with the crowbar
       условия: логика {[p9]=1}

### Loc123 [пустая] визитов<=1
  -> Path614 => Loc117  вер=1 проходов<=1 порядок=5
       текст: Leave the commandant alone with his memories

### Loc124 [обычная]
    Loc124-1: A clean and tidy corridor, bright with the light from the window in the end. There are doors and doors on both sides. There are plates on every door.  /  / "Hou…
  -> Path621 => Loc117  вер=1 порядок=7
       текст: Back to the lobby
  -> Path622 => Loc152  вер=1 порядок=3
       текст: Go see head of the transportation shop
       условия: логика {[p19]<4}
  -> Path623 => Loc128  вер=1 порядок=1
       текст: Go to the housemaster
       ответ: As soon as you entered the room, a thick bass hit your ears: / - Is it reserved for you? - asked a man sitting in a luxurious armchair at a carved table.  / - W…
       условия: логика {[p19]<>3}
  -> Path625 => Loc125  вер=1 порядок=6
       текст: Come up to the window
       эффект: P25(x) = 1
  -> Path627 => Loc131  вер=1 порядок=2
       текст: To the Secretariat
       условия: P7(Secretary's things) 0..1
  -> Path664 => Loc141  вер=1000 проходов<=1 порядок=4
       текст: See the brushes manager
       ответ: The manager's office was some kind of a depot, filled with rubbish. A hairy dude in greasy overalls sat in the middle on a paint jar. / - Wanna drink? - said th…
       эффект: P25(x) = 1
  -> Path665 => Loc141  вер=1 порядок=4
       текст: See the brushes manager
       эффект: P25(x) = 1
  -> Path677 => Loc144  вер=1 порядок=5
       текст: To WC
       эффект: P25(x) = 1
  -> Path733 => Loc162  вер=1 порядок=1
       текст: Go to the housemaster
       условия: логика {[p19]=3}
  -> Path773 => Loc128  вер=1 порядок=3
       текст: Go see head of the transportation shop
       ответ: As soon as you entered, a heated person ran up to you. / - Fish samples. Have you brought them?  / - What fish? / - I ain't doing anything before I have the sam…
       условия: логика {[p19]>=4}
       эффект: P19(Game process) = 5
  -> Path798 => Loc180  вер=1000 порядок=3
       текст: Go see head of the transportation shop
       условия: логика {[p12]=1}
  -> Path816 => Loc131  вер=1 порядок=2
       текст: To the Secretariat
       условия: P7(Secretary's things) 2..2

### Loc125 [обычная]
    выбор описания: {[p25]}
    Loc125-1: You stand at a dirty window looking outside. Silly thoughts come to your mind: "Who am I?" "What is my purpose?" Exactly! "Why I was responsible for catching fl…
    Loc125-2: It's peace and quiet outside. It's so good!
    Loc125-3: The window is dirty by the way. Why don't you wash it? There is something written on it: "The housemaster is bounder! What a bounder! He hasn't paid my salary f…
  -> Path617 => Loc126  вер=1 проходов<=1 порядок=5
       текст: Look outside through the window
       эффект: P25(x) = 2
  -> Path618 => Loc126  вер=1 проходов<=1 порядок=3
       текст: Look at the window
       эффект: P25(x) = 3
  -> Path626 => Loc124  вер=1 порядок=9
       текст: Back

### Loc126 [пустая]
  -> Path619 => Loc125  вер=1 порядок=5

### Loc127 [обычная]
    выбор описания: {[p25]}
    Loc127-1: You stand on a beach of a swamped lake. A warm wind blows into your pink-cheeked face, the rush moves with waves. It's beautiful alright!
    Loc127-2: "Splash!" - you have obviously lost your tool forever.
    Loc127-3: You cast the line and waited. For nothing. You just made sure that you can't get fish without a bait.
    Loc127-4: You cast the line and waited. Fish just won't bite. Looks like there are no fish in the lake.
    Loc127-5: You began walking out of the water and a bloodsucker bit you by the leg and you dropped this little monster in the lake.  /  / You stand on a beach of a swamped…
    Loc127-6: There was no hook with the fishing rod and you just wrapped the bloodsucker with the line. It won't come off this time!
  -> Path784 => Loc176  вер=1 порядок=9
       текст: Go back to the entrance of the ministry
       эффект: P25(x) = 1
  -> Path785 => Loc178  вер=1 порядок=5
       текст: Get into the lake and look for something on the bottom
  -> Path789 => Loc179  вер=1 порядок=2
       текст: Cast the line
       условия: логика {[p8]=1}
       эффект: P25(x) = 3
  -> Path790 => Loc179  вер=1 порядок=2
       текст: Cast the line
       условия: логика {[p8]=2}
       эффект: P25(x) = 4
  -> Path795 => Loc179  вер=1 порядок=7
       текст: Toss the crowbar into the lake
       условия: логика {[p9]=1}
       эффект: P9(Crowbar) = 0
       эффект: P25(x) = 2

### Loc128 [пустая]
  -> Path624 => Loc124  вер=1 порядок=9
       текст: Back to the corridor

### Loc129 [обычная]
    выбор описания: {[p25]}
    Loc129-1: The secretary is staring at the table. She is obviously not busy and you can ask her about something.
    Loc129-2: - As you wish, - the secretary said.
    Loc129-3: - Fish? Auh! Disgusting! Fish makes me fat.  / Well, it's not fish, but the fact that you eat seven times a day.
    Loc129-4: - Thank you. What a kind ranger. Would you like me to kiss you for your kindness? - gabbled Rachehanovna sweetly. / - No thanks. / - As you wish.
    Loc129-5: - What do you mean no? Have you checked the right basement? Go to the lobby and then downstairs, - she said. / - I did go down the stairs, the Registry was not …
    Loc129-6: "Rules? Alright, - the secretary replied. - It is played with a 36 card pack. Players are dealt by two cards and then they count points. Counting is easy: six i…
    Loc129-7: "In the lobby, take the stairs down - and you are there", - she replied.
    Loc129-8: - Obtain the papers from the Registry and come back here. I will stamp them. Then you will have to go to the housemaster. He will review the application, define…
    Loc129-9: - Alright. Here are the <clr>glasses<clrEnd>, - the secretary said. / - Thanks a lot. / - Hey, wait! I can hardly see without them. Give them back at once!  / -…
  -> Path628 => Loc130  вер=1 проходов<=1
       текст: Could you tell me where the Registry is? It is not in the basement...
       условия: логика {[p20]=1 and [p19]=1}
       эффект: P25(x) = 5
  -> Path629 => Loc130  вер=1 проходов<=1
       текст: Can you tell me please how do I find the Registry?
       условия: логика {[p20]=0 and [p19]=1}
       эффект: P25(x) = 7
  -> Path632 => Loc130  вер=1
       текст: A came here on a mission from the government of <FromPlanet>. I have to perfect documents for lease of Hillside. How can I do that?
       условия: логика {[p19]=0}
       эффект: P19(Game process) = 1
       эффект: P25(x) = 8
  -> Path633 => Loc131  вер=1 порядок=9
       текст: Step away from the secretary
  -> Path634 => Loc132  вер=1 проходов<=1 порядок=1
       текст: Can I ask you, what is your name?
  -> Path636 => Loc130  вер=1 порядок=4
       текст: Could you please explain me the rules of 21?
       условия: P2(Garrison cap) 0..0; логика {[p21]=1}
       эффект: P25(x) = 6
  -> Path644 => Loc98  вер=1 порядок=5
       текст: Why don't we play some cards?
       условия: логика {([p21]=1) and ([p7]<2) and ([p2]=0)}
  -> Path663 => Loc130  вер=1 порядок=5
       текст: Why don't we play some cards?
       ответ: - Do you want to undress me naked? - cried the secretary. / - Yes! / - You won't make it! / - Mmkey.
       условия: логика {([p21]=1) and ([p7]=2) and ([p2]=0)}
  -> Path703 => Loc130  вер=1 порядок=6
       текст: Take your clothes. I don't really need them
       условия: логика {[p7]>0}
       эффект: P7(Secretary's things) = 0
       эффект: P25(x) = 4
  -> Path709 => Loc130  вер=1 порядок=5
       текст: Why don't we play some cards?
       ответ: - I don't want to play cards, they make me sick, - the secretary said.
       условия: логика {[p2]=1}
  -> Path728 => Loc130  вер=1 порядок=3
       текст: Could you please stamp my papers?
       ответ: - Alright, give it to me, - the secretary said. - But wait. I can't find my stamp. Where is it?  / - Let me help you to find it. / - You wish! Stay away from my…
       условия: логика {([p7]=2) and (([p11]=1) or ([p11]=2))}
       эффект: P11(Papers) = 2
  -> Path729 => Loc130  вер=1 проходов<=1 порядок=3
       текст: Could you please stamp my papers?
       ответ: - Err. Wait! Where is the stamp? Ah, here it is - under the table. - the secretary took the papers from you and stamped every of them. Even where they were not …
       условия: логика {([p7]<=1) and (([p11]=1) or ([p11]=2))}
       эффект: P11(Papers) = 3
       эффект: P19(Game process) = 3
  -> Path776 => Loc130  вер=1 проходов<=1 порядок=2
       текст: Don't you have a fish by any chance?
       условия: логика {[p19]=5}
       эффект: P25(x) = 3

### Loc130 [пустая]
  -> Path630 => Loc129  вер=1 порядок=5

### Loc131 [обычная]
    выбор описания: {1+([p7]=2)}
    Loc131-1: You stand in the middle of a square room, illuminated with a green chandelier. Light flares around the room prevent you from focusing.  / A secretary of a consi…
    Loc131-2: The setting is usual. A chandelier, trash can, secretary at a table. Only <clr>she does not have glasses on<clrEnd>.
  -> Path631 => Loc129  вер=1
       текст: Approach the secretary
       эффект: P25(x) = 1
  -> Path639 => Loc124  вер=1 порядок=9
       текст: Go out to the corridor
  -> Path691 => Loc149  вер=1 порядок=7
       текст: Rock on the chandelier
       ответ: That's your nature. You can not live without flying. Even in such a primitive form. The secretary did not understand your fine nature and prevented you from cat…
       условия: логика {[p7]<2}
  -> Path693 => Loc149  вер=1 порядок=2
       текст: Rummage in the trash can
       ответ: - Hey, what are you doing with the trash can? - the secretary shouted. / - I'm just looking for some buts, - you tried to justify yourself. / - Find yourself an…
       условия: логика {([p7]<2)}
  -> Path694 => Loc149  вер=1 порядок=7
       текст: Rock on the chandelier
       ответ: As long as the secretary had no glasses on, you grabbed the chandelier and started to rock. Whitewashing falls on your head, the chandelier squeaks disgustingly…
       условия: логика {[p7]=2}
  -> Path695 => Loc149  вер=1 порядок=2
       текст: Rummage in the trash can
       ответ: You quietly came up to the small trash can and put your hand inside. Looks like there is nothing inside but torn papers and useless garbage. Wait! There is some…
       условия: логика {([p7]=2) and ([p2]=0)}
       эффект: P2(Garrison cap) +1
  -> Path696 => Loc149  вер=1 порядок=2
       текст: Rummage in the trash can
       ответ: You quietly came up to the small trash can and put your hand inside. Looks like there is nothing inside but torn papers and useless garbage. Indeed. Nothing els…
       условия: логика {([p7]=2) and ([p2]=1)}

### Loc132 [обычная] визитов<=1
    Loc132-1: - Dunia Rachehanovna! - uttered the heavyset secretary. / - What a beautiful name. / - You were right you did not try another comment. I'd break your head like …
    эффект: P21(Played cards (bool)) = 1
  -> Path635 => Loc129  вер=1 порядок=9
       текст: Probably some other time
       эффект: P25(x) = 2
  -> Path637 => Loc133  вер=1 порядок=5
       текст: 21? Never heard of it. Can you tell me the rules...
  -> Path643 => Loc98  вер=1 порядок=5
       текст: I love cards, let's play a game or two
       эффект: P25(x) = 1

### Loc133 [обычная]
    Loc133-1: "Rules? Alright, - the secretary replied. - It is played with a 36 card pack. Players are dealt by two cards and then they count points. Counting is easy: six i…
  -> Path638 => Loc129  вер=1 порядок=7
       текст: No, I'm not in the right mood
       эффект: P25(x) = 1
  -> Path640 => Loc98  вер=1 порядок=5
       текст: Alright! I love cards!
       эффект: P25(x) = 1

### Loc134 [обычная]
    выбор описания: {1+(([p13] div 22)>0)*([p25]=1)+2*([p25]=2)}
    Loc134-1: - Alright, what have you got? - Rachehanovna said casually.  / You opened your cards slowly - you've got [p13]. The secretary smiled and opened hers - she had […
    Loc134-2: - Alright, what have you got? - Rachehanovna said casually. / You opened your cards slowly - you've got [p13] - overshoot. The secretary smiled and opened hers …
    Loc134-3: - You have lost, birdie. I have 21 with two cards! - the secretary exclaimed and showed her cards.  /  / - Once you loose - you give something away. I mean your…
  -> Path645 => Loc136  вер=2 [всегда видна] порядок=1
       текст: Can you take money instead? Is 100 cr enough?
       условия: логика {([p3]>=100) and ([p7]=0)}
  -> Path647 => Loc135  вер=1 [всегда видна] порядок=1
       текст: Can you take money instead? Is 100 cr enough?
       условия: логика {[p3]>=100}
  -> Path648 => Loc137  вер=1 порядок=5
       текст: Yeah, you wish! I'm not giving away my stuff!
  -> Path656 => Loc138  вер=1 порядок=2
       текст: Alright, here is "something" for you

### Loc135 [обычная]
    Loc135-1: "Shouldn't I fry some nails for you instead? Give me the clothes!" - the secretary was in a decisive mood. /  / Looks like you will have to give away your dear …
  -> Path649 => Loc137  вер=1 порядок=5
       текст: You want to leave me naked? No way!
  -> Path653 => Loc138  вер=1 порядок=1
       текст: Give away the clothes

### Loc136 [обычная]
    Loc136-1: - Fine, give it to me, - she replied.
    эффект: P3(Your money) = {[p3]-100}
  -> Path646 => Loc98  вер=1 порядок=5
       текст: Next
       эффект: P25(x) = 1

### Loc137 [ПРОВАЛ]
    Loc137-1: She reacted to your careless answer in a flash - the secretary jumped up from her chair, hopped over the table and brought you down on the floor with a powerful…

### Loc138 [пустая]
  -> Path650 => Loc98  вер=1 порядок=5
       условия: логика {([p7]=0) and ([p1]=4)}
       эффект: P1(Clothes) -1
       эффект: P25(x) = 5
  -> Path651 => Loc98  вер=1 порядок=5
       условия: логика {([p7]=0) and ([p1]=3)}
       эффект: P1(Clothes) -1
       эффект: P25(x) = 4
  -> Path652 => Loc98  вер=1 порядок=5
       условия: логика {([p7]=0) and ([p1]=2)}
       эффект: P1(Clothes) -1
       эффект: P25(x) = 3
  -> Path654 => Loc98  вер=1 порядок=5
       ответ: You took off the last piece of clothes and gave THAT to the secretary. Rachehanovna only cackled (or was she laughing?). Anyway there was nothing funny for you.…
       условия: логика {([p7]=0) and ([p1]=1)}
       эффект: P1(Clothes) -1
  -> Path655 => Loc98  вер=1 порядок=5
       условия: логика {[p7]=1}
       эффект: P7(Secretary's things) -1
       эффект: P25(x) = 6

### Loc139 [обычная]
    выбор описания: {1+(([p15] div 22)>0)*([p25]=1)+2*([p25]=2)}
    Loc139-1: - Come on, what have you got? - the secretary said seriously.  / You opened your cards slowly - you've got [p13]. The hurt secretary dropped her cards on the ta…
    Loc139-2: - Come on, what have you got? - the secretary said seriously.  / You opened your cards slowly - you've got [p13]. The hurt secretary dropped her cards on the ta…
    Loc139-3: - 21 points with two cards! Rangers begin and win! - you cried cheerfully and showed your cards. /  / - Alright, alright. I lost and will give you something. Ru…
  -> Path658 => Loc140  вер=1 порядок=5
       текст: Take the thing
       условия: логика {([p1]=1) and ([p7]=0)}
       эффект: P1(Clothes) +1
       эффект: P25(x) = 9
  -> Path659 => Loc140  вер=1 порядок=5
       текст: Take the thing
       условия: логика {([p1]=2) and ([p7]=0)}
       эффект: P1(Clothes) +1
       эффект: P25(x) = 8
  -> Path660 => Loc140  вер=1 порядок=5
       текст: Take the thing
       условия: логика {([p1]=3) and ([p7]=0)}
       эффект: P1(Clothes) +1
       эффект: P25(x) = 10
  -> Path661 => Loc140  вер=1 порядок=5
       текст: Take the thing
       условия: логика {([p1]=4) and ([p7]=0)}
       эффект: P7(Secretary's things) +1
       эффект: P25(x) = 7
  -> Path662 => Loc129  вер=1 порядок=5
       текст: Take the thing
       условия: логика {([p1]=4) and ([p7]=1)}
       эффект: P7(Secretary's things) +1
       эффект: P25(x) = 9

### Loc140 [пустая]
  -> Path657 => Loc98  вер=1 порядок=5

### Loc141 [обычная]
    выбор описания: {[p25]}
    Loc141-1: You stand in the middle of a room, full of rubbish. In the centre, a heavyset fellow sat and smiled cunningly. This must be the hammers manager.
    Loc141-2: - Do I look like a pen-pusher, huh? I've no crappy stamp. Even if I had it, I would not give it to you, go it?
    Loc141-3: - You don't bumble me. The Secretarial deals with papers, damn you.
    Loc141-4: - Don't you also want to get inside my pants, dude? - he replied.
    Loc141-5: - Why am I supposed to know, huh? We're ain't no info booth here. We paint the crappy paint and drink alky here.
    Loc141-6: - What rod? Do I look like a fisherman? I like fish with beer, cool that.
    Loc141-7: - Ah. Good crows that, - the fellow said taking the box away.
    Loc141-8: - Great crow! Drop by if you need more. / - I don't think so, - you replied taking your purchase.
    Loc141-9: - Alright, alright, - the fellow began raking about in the box searching for a crowbar (he obviously tried to find the worst one, but it was stupid of him, beca…
  -> Path667 => Loc142  вер=1 проходов<=1 порядок=8
       текст: Can I borrow something here? Anything from the shelves?
       эффект: P25(x) = 4
  -> Path668 => Loc143  вер=1
       текст: Look, can you sell me anything? You've got a lot of stuff here.
  -> Path671 => Loc142  вер=1 проходов<=1 порядок=1
       текст: A came here on a mission from the government of <FromPlanet>. I have to perfect documents for lease of Hillside. How can I do that?
       условия: логика {[p19]=0}
       эффект: P25(x) = 3
  -> Path672 => Loc142  вер=1 проходов<=1 порядок=2
       текст: Can you tell me please how do I find the Registry?
       условия: логика {[p19]=1}
       эффект: P25(x) = 5
  -> Path673 => Loc124  вер=1 порядок=9
       текст: Go out to the corridor
  -> Path731 => Loc142  вер=1 проходов<=1 порядок=3
       текст: Don't you have a stamp?
       условия: логика {[p11]=2}
       эффект: P25(x) = 2
  -> Path774 => Loc142  вер=1 проходов<=1 порядок=5
       текст: Don't you have a fish or a fishing rod?
       условия: логика {[p19]=5}
       эффект: P25(x) = 6

### Loc142 [пустая]
  -> Path666 => Loc141  вер=1 порядок=5

### Loc143 [обычная]
    Loc143-1: - Here, - said the fellow, taking out a dirty box, - great crows, only 50 cr. Take that?  / - Anything else? / - Nothing else like, got it?  / - Sure, bloody go…
  -> Path669 => Loc141  вер=1 [всегда видна] порядок=3
       текст: Fine, I take one for 50 cr
       условия: логика {([p9]=0) and ([p3]>=50)}
       эффект: P3(Your money) = {[p3]-50}
       эффект: P9(Crowbar) +1
       эффект: P25(x) = 8
  -> Path670 => Loc151  вер=1 [всегда видна] порядок=5
       текст: 50? But this crowbar is hardly worth 20!
       условия: логика {([p9]=0) and ([p3]>=20)}
  -> Path674 => Loc141  вер=1 порядок=9
       текст: Thank you for the offer, but I don't need it
       эффект: P25(x) = 7

### Loc144 [обычная]
    выбор описания: {[p25]}
    Loc144-1: You stand in the middle of a WC. It does not look so dirty. Anyway you saw much worse toilets. On the left you see two cubicles. The floor is tiled. Wow you can…
    Loc144-2: - Taken, - you heard from inside.
    Loc144-3: You inspected the toiled inch by inch. No hidings, no buts, no papers. It's a pity.
    Loc144-4: As soon as you went out of the cubicle, the clerk closed the door behind you with a latch. /  / You stand in the middle of a WC. It does not look so dirty. Anyw…
  -> Path680 => Loc146  вер=1 порядок=1
       текст: Enter the first cubicle
       эффект: P25(x) = 1
  -> Path686 => Loc148  вер=1 порядок=2
       текст: Enter the second cubicle
       условия: логика {[p19]<=1}
       эффект: P25(x) = 2
  -> Path688 => Loc148  вер=1 проходов<=1 порядок=3
       текст: Look around the toilet more carefully
       эффект: P25(x) = 3
  -> Path690 => Loc124  вер=1 порядок=9
       текст: To the corridor
  -> Path710 => Loc155  вер=1 порядок=2
       текст: Enter the second cubicle
       условия: логика {[p19]>1}
       эффект: P25(x) = 1

### Loc145 [обычная] визитов<=10
    Loc145-1: "The secretary is a damned fool!"
    Loc145-2: "Robby + starship = death to pirates".
    Loc145-3: "x^4 + Ln(x) + exp(x) = 10. I can't solve it, help me!!!"
    Loc145-4: "I feel so bad. July 12, 2987, Ga-Notsri  / PS: Kids, don't mix ekup with dill".
    Loc145-5: "Those who haven't been to the crap-house - haven't seen the beauty".
    Loc145-6: "Don't flatter yourself - come closer".
    Loc145-7: "Let this crap-house be the rampart in our righteous fight for peace!"
    Loc145-8: "Robby with the spaceship - we will get ya! The free corsairs"
    Loc145-9: "Anton "Ragnar" Mikhailov. Kaliningrad. Russia. 3003"
    Loc145-10: You inspected the walls but did not find any new writing. Looks like you'll have to develop your intelligence in some other place.
  -> Path679 => Loc146  вер=1 проходов<=10 порядок=5
       текст: Back
       эффект: P25(x) = 1

### Loc146 [обычная]
    выбор описания: {[p25]}
    Loc146-1: You stand in a VERY tiny room. Right in front of you there is a lavatory with a water tank. A chain with a handle hangs to the right. Every wall and the ceiling…
    Loc146-2: The lavatory chunked, but soon became silent. You flushed water, that's all. Did you expect a secret passage to open? So silly of you!
    Loc146-3: You cast the line into the lavatory. Nothing happened. Only the bait died. You had to untie it.
    Loc146-4: For some obscure reason, you cast the line into the lavatory. Probably, out of desperation. You feared than someone may notice you and put away your fishing gea…
    Loc146-5: You have finished your sloppy business.
    Loc146-6: You failed! Partitions between the cubicles reach the ceiling.
  -> Path678 => Loc145  вер=1 проходов<=10 порядок=8
       текст: Read writings on the walls
  -> Path682 => Loc147  вер=1 порядок=4
       текст: Push the handle
       эффект: P25(x) = 2
  -> Path684 => Loc147  вер=1 порядок=6
       текст: Take a leak
       эффект: P25(x) = 5
  -> Path685 => Loc147  вер=1 проходов<=1 порядок=2
       текст: Look what's going on in the nearby cubicle
       эффект: P25(x) = 6
  -> Path689 => Loc144  вер=1 порядок=9
       текст: Leave the cubicle
       эффект: P25(x) = 1
  -> Path793 => Loc147  вер=1 порядок=1
       текст: Cast the line in the lavatory
       условия: логика {[p8]=1}
       эффект: P25(x) = 4
  -> Path794 => Loc147  вер=1 порядок=1
       текст: Cast the line in the lavatory
       условия: логика {[p8]=2}
       эффект: P8(Fishing rod (and related)) = 1
       эффект: P25(x) = 3

### Loc147 [пустая]
  -> Path683 => Loc146  вер=1 порядок=5

### Loc148 [пустая]
  -> Path687 => Loc144  вер=1 порядок=5

### Loc149 [пустая]
  -> Path692 => Loc131  вер=1 порядок=5

### Loc150 [ПРОВАЛ]
    Loc150-1: You hauled off and hit the booth with the crowbar. Nothing happened. There was not even a crack. Only the commandant is beaming. It looks like he is happy with …

### Loc151 [обычная]
    Loc151-1: Looks like your swearing was not convincing enough for the fellow.  / - 20? What the? It's worth 60!
  -> Path698 => Loc141  вер=1 порядок=4
       текст: As you wish. I'm not giving you more than 20
       эффект: P3(Your money) = {[p3]-20}
       эффект: P9(Crowbar) +1
       эффект: P25(x) = 9
  -> Path699 => Loc141  вер=1 порядок=9
       текст: 60 or 20, I don't care. I don't need your crowbars anyway
       эффект: P25(x) = 7
  -> Path700 => Loc141  вер=1 [всегда видна] порядок=5
       текст: Fine, here is 50 cr
       условия: логика {([p9]=0) and ([p3]>=50)}
       эффект: P3(Your money) = {[p3]-50}
       эффект: P9(Crowbar) +1
       эффект: P25(x) = 8

### Loc152 [обычная]
    Loc152-1: You tried to open the door, turned the handle but it did not work. You knocked, picked in the keyhole with your nail, and even tromped your feet, all for nothin…
  -> Path701 => Loc124  вер=1 порядок=9
       текст: Back to the corridor
  -> Path702 => Loc124  вер=1 порядок=5
       текст: Break the door with a crowbar
       ответ: You desperately tried to open the door, but the crowbar was useless with such a massive door. What a pity.
       условия: логика {[p9]=1}

### Loc153 [обычная]
    выбор описания: {[p25]}
    Loc153-1: The commandant looks at you with his wide open surprised eyes. He must be waiting for you to say something.
    Loc153-2: - Fish? I tried fishing in the lake nearby, but got nothing. I can give you a fishing rod if you like. Probably you will have more luck. / - Sure, - you replied…
    Loc153-3: - The Registry? - responded the watchman - It used to be in the basement. But the floor crumbled there and they moved to the toilet. Second cubicle. There was n…
    Loc153-4: - Oh come on. Deadly dullness! - the commandant replied. - I remember we hit a truck with guanawa when I was in a guerilla force. We... / He set off. Bum Bam. S…
    Loc153-5: - I will do anything for the revolution, my forest brother. But I am of no help in this business of yours. I don't have the stamp. But according to intelligence…
    Loc153-6: - Regarding all the paper issues go to the Secretariat, bro, - commandant Ge Chevara replied to you.
  -> Path705 => Loc117  вер=1 порядок=9
       текст: Was a pleasure talking to you. No passaran! We will win!
  -> Path706 => Loc154  вер=1 порядок=6
       текст: And how is it working here? Good?
       эффект: P25(x) = 4
  -> Path708 => Loc154  вер=1 проходов<=1 порядок=2
       текст: Commandant, where is the Registry?
       условия: логика {[p19]=1}
       эффект: P19(Game process) = 2
       эффект: P25(x) = 3
  -> Path732 => Loc154  вер=1 проходов<=1 порядок=4
       текст: Comandante, the stamp is required for the revolution. Urgently.
       условия: логика {[p11]=2}
       эффект: P25(x) = 5
  -> Path777 => Loc154  вер=1 проходов<=1 порядок=5
       текст: Listen comandante, where do I find some fish here?
       условия: логика {[p19]=5}
       эффект: P8(Fishing rod (and related)) = 1
       эффект: P25(x) = 2
  -> Path800 => Loc154  вер=1 проходов<=1
       текст: A came here on a mission from the government of <FromPlanet>. I have to perfect documents for lease of Hillside. How can I do that?
       условия: логика {[p19]=0}
       эффект: P25(x) = 6

### Loc154 [пустая]
  -> Path707 => Loc153  вер=1 порядок=5

### Loc155 [обычная]
    выбор описания: {[p25]}
    Loc155-1: - Interesting, - you heard a voice from inside. / - I am on a very important government assignment! / - The first cubicle is also vacant by the way. / - Not tha…
    Loc155-3: - I am a minority peoples expert, not a fishing industry expert. So please excuse me.
    Loc155-4: - No. I don't have the stamp. I have paper, but no stamp.
    Loc155-5: - Do you have anything else? - the clerk asked.
  -> Path713 => Loc157  вер=1 проходов<=1
       текст: I need to perfect documents for the lease of Hillside
  -> Path727 => Loc144  вер=1 порядок=9
       текст: Leave the Registry
       эффект: P25(x) = 4
  -> Path730 => Loc156  вер=1 проходов<=1 порядок=4
       текст: Don't you have the stamp by any chance?
       условия: логика {[p11]=2}
       эффект: P25(x) = 4
  -> Path775 => Loc156  вер=1 проходов<=1 порядок=2
       текст: I need fish. Don't you have some?
       условия: логика {[p19]=5}
       эффект: P25(x) = 3

### Loc156 [пустая]
  -> Path712 => Loc155  вер=1 порядок=5

### Loc157 [обычная] визитов<=1
    Loc157-1: - No problem. We're going to perfect it perfectly, the clerk said and inserted a new blank. - Here we go, field 1 - Sex.
  -> Path714 => Loc158  вер=1 порядок=3
       текст: Tiled
  -> Path715 => Loc158  вер=1 порядок=1
       текст: Masculine
  -> Path716 => Loc158  вер=1 порядок=2
       текст: Feminine

### Loc158 [обычная]
    Loc158-1: - I see. That's what I fill in, - his fingers hit the keys. - Now field 2: nationality.
  -> Path717 => Loc159  вер=1 порядок=1
       текст: I am the citizen of the whole galaxy
  -> Path718 => Loc159  вер=1 порядок=2
       текст: I'm from the Rurick family
  -> Path719 => Loc159  вер=1 порядок=3
       текст: I have no nationality because of ideology reasons

### Loc159 [обычная]
    Loc159-1: - Absolutely clear. Filled in. Fields 3, 4 and 5 are to be filled in by the official. Field 6: for what purposes the land will be used.
  -> Path720 => Loc160  вер=1 порядок=3
       текст: Establishing of training camps to prepare forces for capturing of planet <ToPlanet>
  -> Path721 => Loc160  вер=1 порядок=2
       текст: Building of a resort for members of government of planet <FromPlanet>
  -> Path722 => Loc160  вер=1 порядок=1
       текст: Establishing of a resort and its use for the primary purpose

### Loc160 [обычная]
    Loc160-1: - Alright. Name of company or individual that will be the lessee of the Hillside.
  -> Path723 => Loc161  вер=1 порядок=2
       текст: At the name of <Ranger>, of course
  -> Path724 => Loc161  вер=1 порядок=3
       текст: At the name of Frecken-Bock - my grandmother is from Urupinsk
  -> Path725 => Loc161  вер=1 порядок=1
       текст: Perfect them in the name of the government of <FromPlanet>

### Loc161 [обычная]
    Loc161-1: - Ready, - the clerk said joyfully, taking out the paper from the typewriter and handing it over to you. / Now you have the lending papers for Hillside. At leas…
    эффект: P11(Papers) = 1
  -> Path726 => Loc155  вер=1 порядок=5
       текст: Thank you!
       эффект: P25(x) = 5

### Loc162 [обычная]
    Loc162-1: As soon as you entered the room, a thick bass hit your ears: / - Is it reserved for you? - asked a man sitting in a luxurious armchair at a carved table.  / - O…
  -> Path734 => Loc163  вер=1 порядок=8
       текст: I'm not answering your questions. Just make the papers!
  -> Path735 => Loc164  вер=1 порядок=5
       текст: Alright, go ahead with your questions
       эффект: P22(Test points) = 0

### Loc163 [ПРОВАЛ]
    Loc163-1: - I guess we misunderstood each other. Leave the premises and never come back here! Do you hear me - never, NEVER!!! - shouted the housemaster. /  / After you l…

### Loc164 [обычная]
    Loc164-1: - OK... Here we go, - the housemaster said and took out a notebook with a pencil.  / <clr>What is required to start a starship?<clrEnd>
  -> Path737 => Loc166  вер=1 порядок=2
       текст: Spit at the control board, cross yourself and break the key in the ignition lock
  -> Path738 => Loc166  вер=1 порядок=3
       текст: Sitting in the pilot chair, sigh at the desperate situation, forget about it and go looking for a pilot to start this damned starship
       эффект: P22(Test points) = {[p22]+4}
  -> Path739 => Loc166  вер=1 порядок=4
       текст: Get out of the starship, come to its front, insert a steel handle into the hole and rotate it quickly until the starship starts.
       эффект: P22(Test points) = {[p22]+1}
  -> Path740 => Loc166  вер=1 порядок=1
       текст: Cross yourself, spit over the left shoulder and turn the ignition key
       эффект: P22(Test points) = {[p22]+3}
  -> Path801 => Loc166  вер=1 порядок=5
       текст: Turn on the vector, energy and navigation systems, check all parameters and start the engines
       эффект: P22(Test points) = {[p22]+5}

### Loc166 [обычная]
    Loc166-1: Are you sure about that? I will inform the authorities that issued you the permission for space travel. No way, you can't change your answer!!! /  / Alright. Ne…
  -> Path745 => Loc167  вер=1 порядок=2
       текст: Alive, scorching it skilfully
       эффект: P22(Test points) = {[p22]+3}
  -> Path746 => Loc167  вер=1 порядок=3
       текст: The recipe is simple: toss it into the nozzle of the starship, turn it on and in a couple of minutes - ready! Penchekryak in gasoline sauce with acetates
       эффект: P22(Test points) = {[p22]+1}
  -> Path748 => Loc167  вер=1 порядок=4
       текст: Penchekryak meat is too rough for frying. It can only be cooked
       эффект: P22(Test points) = {[p22]+5}
  -> Path803 => Loc167  вер=1 порядок=5
       текст: Who told you penchekryaks can be fried at all? I always eat them fresh...
       эффект: P22(Test points) = {[p22]+1}
  -> Path814 => Loc167  вер=1 порядок=1
       текст: Dead, turning slowly.
       эффект: P22(Test points) = {[p22]+4}

### Loc167 [обычная]
    Loc167-1: What do you say? A Faeyan told me that penchekryaks are not suitable for eating in any form. One has to eat mineral fertilisers and drink ekup! But the authors …
  -> Path749 => Loc168  вер=1 порядок=2
       текст: Wife
  -> Path750 => Loc168  вер=1 порядок=3
       текст: Lock
  -> Path751 => Loc168  вер=1 порядок=4
       текст: Code lock
  -> Path752 => Loc168  вер=1 порядок=1
       текст: Toothless and numb dog
  -> Path805 => Loc168  вер=1 порядок=5
       текст: I have no idea

### Loc168 [обычная]
    Loc168-1: Ah, damn it, I ticked off in a wrong column! Does not matter... /  / The fourth question: / <clr>Finish the phrase: "All politicians are..."<clrEnd>
    эффект: P22(Test points) = {[p22]+[1..5]}
  -> Path754 => Loc169  вер=1 порядок=3
       текст: Live at the people's expense
       эффект: P22(Test points) = {[p22]+5}
  -> Path755 => Loc169  вер=1 порядок=5
       текст: Bastards!
       эффект: P22(Test points) = {[p22]+4}
  -> Path756 => Loc169  вер=1 порядок=1
       текст: Take bribes
       эффект: P22(Test points) = {[p22]+2}
  -> Path804 => Loc169  вер=1 порядок=4
       текст: Associated with the mafia
       эффект: P22(Test points) = {[p22]+2}
  -> Path815 => Loc169  вер=1 порядок=2
       текст: Swearing
       эффект: P22(Test points) = {[p22]+1}

### Loc169 [обычная]
    Loc169-1: By the way, I would like to warn you that all conversations in this room are constantly recorded by the secret service of the government of <ToPlanet>. But it d…
  -> Path761 => Loc171  вер=1 порядок=4
       текст: Sit on a traditional Maloq stool and discuss the meaning of life
  -> Path762 => Loc171  вер=1 порядок=5
       текст: Dish out a nuisance
       эффект: P22(Test points) = {[p22]+4}
  -> Path763 => Loc171  вер=1 порядок=2
       текст: Smash this Faeyan/Gaalian/Human face
       эффект: P22(Test points) = {[p22]+4}
  -> Path764 => Loc171  вер=1 порядок=3
       текст: Get hit in the face
       эффект: P22(Test points) = {[p22]+1}
  -> Path807 => Loc171  вер=1 порядок=1
       текст: Expensive weapon
       эффект: P22(Test points) = {[p22]+5}

### Loc171 [пустая]
  -> Path765 => Loc172  вер=1 порядок=5
       ответ: - You result is [p22], and, according to the tables, you are quite a trustworthy ranger, - concluded the housemaster.
       условия: логика {[p22]>=20}
  -> Path767 => Loc173  вер=1 порядок=5
       условия: логика {[p22]<20}

### Loc172 [обычная]
    Loc172-1: - Fine, so you have passed the test, - Bobchinsky went on. / - And now, are your going to sign the lease documents for Hillside? - you asked. / - No. / - What d…
    эффект: P11(Papers) = 0
  -> Path766 => Loc124  вер=1 порядок=9
       текст: Go out to the corridor
       эффект: P19(Game process) = 4

### Loc173 [обычная]
    Loc173-1: - So, hmmm. You've got [p22]. Bad, really bad. According to the tables, you are not a trustworthy member of the galactic society. I am very sorry, but any furth…
  -> Path768 => Loc174  вер=1 порядок=5
       текст: Well, this test obliterated all your efforts. It is time to fly away from this island, drowned in bureaucratic delays.
  -> Path769 => Loc175  вер=1 порядок=5
       текст: But maybe there is something else to be done?

### Loc174 [ПРОВАЛ]
    Loc174-1: Hopeless to obtain the Hillside lease papers, you returned to your ship, sadly started the engines and flew away from Rectal Island.  /  / You mission is failed…

### Loc175 [обычная]
    Loc175-1: - Well, only out of respect for you, I rather have a look at some papers, - Bobchinsky took out a large pack of documents and began searching them. / After seve…
  -> Path770 => Loc174  вер=1 порядок=5
       текст: Are you kidding? I am not retard!!! I am not paying this stupid fee
       ответ: - You can say whatever you want, but we prefer to trust in tests. And not in you, - Bobchinsky said.  / After you said everything you thought about the test, th…
  -> Path771 => Loc174  вер=1 порядок=5
       текст: I do not thing that the amount you mentioned is suitable for me. A can not pay it
       ответ: - I am sorry then. We can not help you, - Bobchinsky said. - Please leave the office.
  -> Path772 => Loc172  вер=1 [всегда видна] порядок=5
       текст: Alright, here is the money
       условия: логика {[p3]>=((20-[p22])*12)}
       эффект: P3(Your money) = {[p3]-(20-[p22])*12}
  -> Path808 => Loc182  вер=1 порядок=5
       текст: I am processing papers for the government of planet <FromPlanet>. They are the ones to pay the official compensations
       ответ: - Alright, I will make a call, - Bobchinsky took the handset, pressed several keys and began speaking with somebody. After a few minutes he replaced the handset…
       условия: логика {[p3]>=((20-[p22])*12)}
  -> Path809 => Loc182  вер=1 порядок=5
       текст: I am processing papers for the government of planet <FromPlanet>. They are the ones to pay the official compensations
       ответ: - Alright, I will make a call, - Bobchinsky took the handset, pressed several keys and began speaking with somebody. After a few minutes he replaced the handset…
       условия: логика {[p3]<((20-[p22])*12)}
  -> Path810 => Loc172  вер=1 порядок=5
       текст: I am processing papers for the government of planet <FromPlanet>. They are the ones to pay the official compensations
       ответ: - Alright, I will make a call, - Bobchinsky took the handset, pressed several keys and began speaking with somebody. After a few minutes he replaced the handset…
       условия: логика {[p3]=0}

### Loc176 [обычная]
    выбор описания: {[p25]}
    Loc176-1: You stand outside at the entrance to the pink building. There is a plate above the doors: "Ministry for various affairs of Rectal Island". To the North there is…
    Loc176-2: You slowly moved around the building. You found nothing interesting on your way. Except for the windows. But they were all too high to have a look inside or cli…
    Loc176-3: You roamed about the ship, but haven't found anything useful or at least anything that could be carried in your hands.
  -> Path779 => Loc117  вер=1 порядок=2
       текст: Enter the ministry
  -> Path780 => Loc177  вер=1 проходов<=1 порядок=6
       текст: Walk around the building
       эффект: P25(x) = 2
  -> Path782 => Loc177  вер=1 проходов<=1 порядок=7
       текст: Look for something useful in the starship
       эффект: P25(x) = 3
  -> Path783 => Loc127  вер=1 порядок=4
       текст: Go to the lake
       эффект: P25(x) = 1
  -> Path799 => Loc181  вер=1 порядок=9
       текст: I am sick of this stupid mission. Time to leave the island

### Loc177 [пустая]
  -> Path781 => Loc176  вер=1 порядок=5

### Loc178 [обычная]
    Loc178-1: You got knee-deep into the water, but could not extract anything but mud from the bottom. Wait! Something is moving in your hands. It is a small <clr> bloodsuck…
  -> Path786 => Loc127  вер=1 порядок=5
       текст: Throw away the bloodsucker and get back to the beach
       эффект: P25(x) = 1
  -> Path787 => Loc127  вер=1 порядок=3
       текст: Go back to the beach with the bloodsucker
       эффект: P25(x) = 5
  -> Path788 => Loc127  вер=1 порядок=1
       текст: Attach the bloodsucker to the line and go to the beach
       условия: логика {[p8]=1}
       эффект: P8(Fishing rod (and related)) = 2
       эффект: P25(x) = 6

### Loc179 [обычная]
  -> Path791 => Loc127  вер=1 порядок=5

### Loc180 [УСПЕХ]
    Loc180-1: As soon as you entered, a heated person ran up to you. / - Fish samples. Have you brought them?  / - Sure. Here they are, - You handed your three-eyed trophy to…

### Loc181 [ПРОВАЛ]
    Loc181-1: You got into your lovely starship and left Rectal Island. That was right. Meddling with papers is not appropriate for a real ranger.

### Loc182 [обычная]
    Loc182-1: The housemaster watches you carefully. He must be waiting for you to pay him.
  -> Path811 => Loc174  вер=1 порядок=5
       текст: That's a mere robbery! I'm not paying this stupid fee!
       ответ: - I am sorry then. We can not help you, - Bobchinsky said. - Please leave the office.
  -> Path812 => Loc172  вер=1 порядок=5
       текст: Pay
       условия: логика {[p3]<((20-[p22])*12)}
       эффект: P3(Your money) = 0
  -> Path813 => Loc172  вер=1 порядок=5
       текст: Pay
       условия: логика {[p3]>=((20-[p22])*12)}
       эффект: P3(Your money) = {[p3]-((20-[p22])*12)}

## Анализ
- стартовых: [121]
- концовки: {137: 'ПРОВАЛ', 150: 'ПРОВАЛ', 163: 'ПРОВАЛ', 174: 'ПРОВАЛ', 180: 'УСПЕХ', 181: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
