# Квест (формат 1111111126)
Сложность 65; стартовая локация: [41]; путей по умолчанию: 1

## Параметры
- P1 'Empty cell coordinates' [11..44] тип=обычный
    старт: [11]
    [11..44] Empty cell coordinates: <>
    критическое: Сообщение достижения критического значения параметром 1
- P2 'First row' [111..8888] тип=обычный
    старт: [111]
    [111..8888] First row: <>
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Second row' [111..8888] тип=обычный
    старт: [111]
    [111..8888] Second row: <>
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Third row' [111..8888] тип=обычный
    старт: [111]
    [111..8888] Third row: <>
    критическое: Сообщение достижения критического значения параметром 4
- P5 'Fourth row' [111..8888] тип=обычный
    старт: [111]
    [111..8888] Fourth row: <>
    критическое: Сообщение достижения критического значения параметром 5
- P6 'Side cells' [0..10000] тип=обычный
    старт: [0]
    [0..10000] Side cells: <>
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Switches remaining' [0..200] тип=провал
    старт: [1]
    [0..200] Switches remaining: <>
    критическое: The counter showing the number of remaining moves indicated zero. The safe didn't check the current …
- P8 'Puzzle version' [0..10] тип=обычный
    старт: [0]
    [0..10] Puzzle version: <>
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Text' [1..2] тип=обычный
    старт: [1]
    [1..2] Parameter 9: <>
    критическое: Сообщение достижения критического значения параметром 9

## Локации и переходы

### Loc29 [обычная]
    выбор описания: {[p6]}
    Loc29-1: Together with Ikss, you go up several floors, and enter a small room with lowered curtains and a lamp glowing brightly on a table. A dark, rectangular object wi…
    Loc29-2: "The input panel is a <clr>4x4<clrEnd> square of cells. One cell is empty, while all the others are filled with numbers from {1} to {8}. A 'switch' is a move of…
    Loc29-3: You take the piece of paper in your hand and unfold it. It has the following diagram: / <fix> /  _______________ / | {6} | {5} | {4} | {3} | / |___|___|___|___|…
  -> Path194 => Loc34  вер=1 порядок=5
       текст: Start solving
       условия: P8(Puzzle version) 1..1
       эффект: P7(Switches remaining) +24 [показ]
       эффект: P1(Empty cell coordinates) = 44
       эффект: P2(First row) = {7632}
       эффект: P3(Second row) = {5824}
       эффект: P4(Third row) = {3175}
       эффект: P5(Fourth row) = {4810}
       эффект: P6(Side cells) = {15}
  -> Path195 => Loc34  вер=1 порядок=5
       текст: Start solving
       условия: P8(Puzzle version) 2..2
       эффект: P7(Switches remaining) +28 [показ]
       эффект: P1(Empty cell coordinates) = {44}
       эффект: P2(First row) = {4631}
       эффект: P3(Second row) = {7584}
       эффект: P4(Third row) = {3152}
       эффект: P5(Fourth row) = {8270}
       эффект: P6(Side cells) = {72}
  -> Path196 => Loc34  вер=1 порядок=5
       текст: Start solving
       условия: P8(Puzzle version) 3..3
       эффект: P7(Switches remaining) +44 [показ]
       эффект: P1(Empty cell coordinates) = {44}
       эффект: P2(First row) = {5643}
       эффект: P3(Second row) = {7127}
       эффект: P4(Third row) = {4215}
       эффект: P5(Fourth row) = {3880}
       эффект: P6(Side cells) = {85}
  -> Path197 => Loc33  вер=1 порядок=5
       текст: Start solving
       условия: P8(Puzzle version) 4..4
       эффект: P7(Switches remaining) +31 [показ]
       эффект: P1(Empty cell coordinates) = {12}
       эффект: P2(First row) = {7654}
       эффект: P3(Second row) = {583}
       эффект: P4(Third row) = {3182}
       эффект: P5(Fourth row) = {4271}
       эффект: P6(Side cells) = {5307}
  -> Path202 => Loc37  вер=1 порядок=9
       текст: Decline to fulfill the mission
       эффект: P9(Text) = 1
  -> Path204 => Loc40  вер=1 проходов<=1 порядок=7
       текст: Ask for clarification about 'switches'
       эффект: P6(Side cells) = {2}
  -> Path209 => Loc40  вер=1 проходов<=1 порядок=6
       текст: Look at the piece of paper with the password
       эффект: P6(Side cells) = {3}

### Loc32 [УСПЕХ]
    Loc32-1: Something clicks inside the safe and the door opens. Ikss sighs with relief behind you. You curiously examine the maloq skull, which is resting on a small black…

### Loc33 [обычная]
    выбор описания: {4*(([p1] mod 10)=2)+([p1] div 10)}
    Loc33-1: <fix>Password                      Example /  _______________        _______________ / |   | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} | {[p2] mod 10}…
    Loc33-2: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} |   | {([p2] mod 100) div 10} | {[p2] mod 10} |      | …
    Loc33-3: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} |   | {[p2] mod 10} |      …
    Loc33-4: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc33-5: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc33-6: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc33-7: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc33-8: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
  -> Path172 => Loc35  вер=1 порядок=2
       текст: Fragment {([p6] div 10)  mod 10} to the left of the empty cell.
       условия: логика {([p1] div 10)>1}
       эффект: P1(Empty cell coordinates) = {[p1]-10}
       эффект: P2(First row) = {(([p1] mod 10)>1)*([p2])+([p1]=21)*(([p2] div 1000)*100+[p2] mod 100)+([p1]=31)*(([p2] div 1000)*1000+(([p2] div 100) mod 10)*10+[p2] mod 10)+([p1]=41)*(([p2] div 100)*100+(([p2] div 10) mod 10))}
       эффект: P3(Second row) = {(([p1] mod 10)<>2)*([p3])+([p1]=22)*(([p3] div 1000)*100+[p3] mod 100)+([p1]=32)*(([p3] div 1000)*1000+(([p3] div 100) mod 10)*10+([p3] mod 10))+([p1]=42)*(([p3] div 100)*100+(([p3] div 10) mod 10))}
  -> Path173 => Loc35  вер=1 порядок=3
       текст: Fragment {([p6] div 100)  mod 10} below the empty cell.
       условия: логика {([p1] mod 10)<4}
       эффект: P1(Empty cell coordinates) = {[p1]+1}
       эффект: P2(First row) = {[p2]+(([p1] mod 10)=1)*((([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p3] div 100) mod 10)*100*(([p1] div 10)=2)+(([p3] div 10) mod 10)*10*(([p1] div 10)=3)+(([p3] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P3(Second row) = {[p3]+(([p1] mod 10)=1)*(-(([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p3] div 100) mod 10)*100*(([p1] div 10)=2)-(([p3] div 10) mod 10)*10*(([p1] div 10)=3)-(([p3] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=2)*((([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p4] div 100) mod 10)*100*(([p1] div 10)=2)+(([p4] div 10) mod 10)*10*(([p1] div 10)=3)+(([p4] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P4(Third row) = {[p4]+(([p1] mod 10)=2)*(-(([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p4] div 100) mod 10)*100*(([p1] div 10)=2)-(([p4] div 10) mod 10)*10*(([p1] div 10)=3)-(([p4] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=3)*((([p5] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p5] div 100) mod 10)*100*(([p1] div 10)=2)+(([p5] div 10) mod 10)*10*(([p1] div 10)=3)+(([p5] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P5(Fourth row) = {[p5]+(([p1] mod 10)=3)*(-(([p5] div 10000) mod 10)*10000*(([p1] div 10)=1)-(([p5] div 1000) mod 10)*1000*(([p1] div 10)=3)-(([p5] div 100) mod 10)*100*(([p1] div 10)=3)-(([p5] div 1) mod 10)*1*(([p1] div 10)=4))}
  -> Path174 => Loc35  вер=1 порядок=1
       текст: Fragment {([p6] div 1)  mod 10} above the empty cell.
       условия: логика {([p1] mod 10)>1}
       эффект: P1(Empty cell coordinates) = {[p1]-1}
       эффект: P2(First row) = {[p2]+(([p1] mod 10)=2)*(-(([p2] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p2] div 100) mod 10)*100*(([p1] div 10)=2)-(([p2] div 10) mod 10)*10*(([p1] div 10)=3)-(([p2] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P3(Second row) = {[p3]+(([p1] mod 10)=3)*(-(([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p3] div 100) mod 10)*100*(([p1] div 10)=2)-(([p3] div 10) mod 10)*10*(([p1] div 10)=3)-(([p3] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=2)*((([p2] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p2] div 100) mod 10)*100*(([p1] div 10)=2)+(([p2] div 10) mod 10)*10*(([p1] div 10)=3)+(([p2] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P4(Third row) = {[p4]+(([p1] mod 10)=4)*(-(([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p4] div 100) mod 10)*100*(([p1] div 10)=2)-(([p4] div 10) mod 10)*10*(([p1] div 10)=3)-(([p4] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=3)*((([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p3] div 100) mod 10)*100*(([p1] div 10)=2)+(([p3] div 10) mod 10)*10*(([p1] div 10)=3)+(([p3] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P5(Fourth row) = {[p5]+(([p1] mod 10)=4)*((([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p4] div 100) mod 10)*100*(([p1] div 10)=2)+(([p4] div 10) mod 10)*10*(([p1] div 10)=3)+(([p4] div 1) mod 10)*1*(([p1] div 10)=4))}
  -> Path175 => Loc35  вер=1 порядок=4
       текст: Fragment {([p6] div 1000)  mod 10} to the right of the empty cell.
       условия: логика {([p1] div 10)<4}
       эффект: P1(Empty cell coordinates) = {[p1]+10}
       эффект: P2(First row) = {(([p1] mod 10)>1)*([p2])+([p1]=11)*(([p2] div 100)*1000+[p2] mod 100)+([p1]=21)*(([p2] div 1000)*1000+(([p2] div 10) mod 10)*100+[p2] mod 10)+([p1]=31)*(([p2] div 100)*100+([p2] mod 10)*10)}
       эффект: P3(Second row) = {(([p1] mod 10)<>2)*([p3])+([p1]=12)*(([p3] div 100)*1000+[p3] mod 100)+([p1]=22)*(([p3] div 1000)*1000+(([p3] div 10) mod 10)*100+[p3] mod 10)+([p1]=32)*(([p3] div 100)*100+([p3] mod 10)*10)}
  -> Path188 => Loc32  вер=1
       текст: The password has not been put together.
       условия: P2(First row) 6543..6543; P3(Second row) 7812..7812; P4(Third row) 2187..2187; P5(Fourth row) 3450..3450
  -> Path207 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Decline to fulfill the mission
       условия: логика {[p2]<>6543 or [p3]<>7812 or [p4]<>2187 or [p5]<>3450}
       эффект: P9(Text) = 2

### Loc34 [обычная]
    выбор описания: {4*(([p1] mod 10)=4)+([p1] div 10)}
    Loc34-1: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-2: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-3: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-4: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-5: <fix>Password                      Example /  _______________        _______________   / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10}…
    Loc34-6: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-7: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
    Loc34-8: <fix>Password                      Example /  _______________        _______________ / | {[p2] div 1000} | {([p2] mod 1000) div 100} | {([p2] mod 100) div 10} |…
  -> Path183 => Loc35  вер=1 порядок=1
       текст: Fragment {([p6] div 1)  mod 10} above the empty cell.
       условия: логика {([p1] mod 10)>1}
       эффект: P1(Empty cell coordinates) = {[p1]-1}
       эффект: P2(First row) = {[p2]+(([p1] mod 10)=2)*(-(([p2] div 10000) mod 10)*10000*(([p1] div 10)=1)-(([p2] div 1000) mod 10)*1000*(([p1] div 10)=2)-(([p2] div 100) mod 10)*100*(([p1] div 10)=3)-(([p2] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P3(Second row) = {[p3]+(([p1] mod 10)=3)*(-(([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p3] div 100) mod 10)*100*(([p1] div 10)=2)-(([p3] div 10) mod 10)*10*(([p1] div 10)=3)-(([p3] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=2)*((([p2] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p2] div 100) mod 10)*100*(([p1] div 10)=2)+(([p2] div 10) mod 10)*10*(([p1] div 10)=3)+(([p2] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P4(Third row) = {[p4]+(([p1] mod 10)=4)*(-(([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p4] div 100) mod 10)*100*(([p1] div 10)=2)-(([p4] div 10) mod 10)*10*(([p1] div 10)=3)-(([p4] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=3)*((([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p3] div 100) mod 10)*100*(([p1] div 10)=2)+(([p3] div 10) mod 10)*10*(([p1] div 10)=3)+(([p3] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P5(Fourth row) = {[p5]+(([p1] mod 10)=4)*((([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p4] div 100) mod 10)*100*(([p1] div 10)=2)+(([p4] div 10) mod 10)*10*(([p1] div 10)=3)+(([p4] div 1) mod 10)*1*(([p1] div 10)=4))}
  -> Path184 => Loc35  вер=1 порядок=3
       текст: Fragment {([p6] div 100)  mod 10} below the empty cell.
       условия: логика {([p1] mod 10)<4}
       эффект: P1(Empty cell coordinates) = {[p1]+1}
       эффект: P2(First row) = {[p2]+(([p1] mod 10)=1)*((([p3] div 10000) mod 10)*10000*(([p1] div 10)=1)+(([p3] div 1000) mod 10)*1000*(([p1] div 10)=2)+(([p3] div 100) mod 10)*100*(([p1] div 10)=3)+(([p3] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P3(Second row) = {[p3]+(([p1] mod 10)=1)*(-(([p3] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p3] div 100) mod 10)*100*(([p1] div 10)=2)-(([p3] div 10) mod 10)*10*(([p1] div 10)=3)-(([p3] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=2)*((([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p4] div 100) mod 10)*100*(([p1] div 10)=2)+(([p4] div 10) mod 10)*10*(([p1] div 10)=3)+(([p4] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P4(Third row) = {[p4]+(([p1] mod 10)=2)*(-(([p4] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p4] div 100) mod 10)*100*(([p1] div 10)=2)-(([p4] div 10) mod 10)*10*(([p1] div 10)=3)-(([p4] div 1) mod 10)*1*(([p1] div 10)=4))+(([p1] mod 10)=3)*((([p5] div 1000) mod 10)*1000*(([p1] div 10)=1)+(([p5] div 100) mod 10)*100*(([p1] div 10)=2)+(([p5] div 10) mod 10)*10*(([p1] div 10)=3)+(([p5] div 1) mod 10)*1*(([p1] div 10)=4))}
       эффект: P5(Fourth row) = {[p5]+(([p1] mod 10)=3)*(-(([p5] div 1000) mod 10)*1000*(([p1] div 10)=1)-(([p5] div 100) mod 10)*100*(([p1] div 10)=2)-(([p5] div 10) mod 10)*10*(([p1] div 10)=3)-(([p5] div 1) mod 10)*1*(([p1] div 10)=4))}
  -> Path185 => Loc35  вер=1 порядок=2
       текст: Fragment {([p6] div 10)  mod 10} to the left of the empty cell.
       условия: логика {([p1] div 10)>1}
       эффект: P1(Empty cell coordinates) = {[p1]-10}
       эффект: P4(Third row) = {(([p1] mod 10)<>3)*([p4])+([p1]=23)*(([p4] div 1000)*100+[p4] mod 100)+([p1]=33)*(([p4] div 1000)*1000+(([p4] div 100) mod 10)*10+[p4] mod 10)+([p1]=43)*(([p4] div 100)*100+(([p4] div 10) mod 10))}
       эффект: P5(Fourth row) = {(([p1] mod 10)<>4)*([p5])+([p1]=24)*(([p5] div 1000)*100+[p5] mod 100)+([p1]=34)*(([p5] div 1000)*1000+(([p5] div 100) mod 10)*10+[p5] mod 10)+([p1]=44)*(([p5] div 100)*100+(([p5] div 10) mod 10))}
  -> Path186 => Loc35  вер=1 порядок=4
       текст: Fragment {([p6] div 1000)  mod 10} to the right of the empty cell.
       условия: логика {([p1] div 10)<4}
       эффект: P1(Empty cell coordinates) = {[p1]+10}
       эффект: P4(Third row) = {(([p1] mod 10)<>3)*([p4])+([p1]=13)*(([p4] div 100)*1000+[p4] mod 100)+([p1]=23)*(([p4] div 1000)*1000+(([p4] div 10) mod 10)*100+[p4] mod 10)+([p1]=33)*(([p4] div 100)*100+([p4] mod 10)*10)}
       эффект: P5(Fourth row) = {(([p1] mod 10)<>4)*([p5])+([p1]=14)*(([p5] div 100)*1000+[p5] mod 100)+([p1]=24)*(([p5] div 1000)*1000+(([p5] div 10) mod 10)*100+[p5] mod 10)+([p1]=34)*(([p5] div 100)*100+([p5] mod 10)*10)}
  -> Path187 => Loc32  вер=1
       текст: The password has not been put together.
       условия: P2(First row) 6543..6543; P3(Second row) 7812..7812; P4(Third row) 2187..2187; P5(Fourth row) 3450..3450
  -> Path208 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Decline to fulfill the mission
       условия: логика {[p2]<>6543 or [p3]<>7812 or [p4]<>2187 or [p5]<>3450}
       эффект: P9(Text) = 2

### Loc35 [пустая]
    эффект: P6(Side cells) = {0}
  -> Path180 => Loc36  вер=1 порядок=5
       условия: логика {([p1] mod 10)=3}
       эффект: P6(Side cells) = {[p6]+(([p1] div 10)=1)*(1*([p3] div 1000)+10*0+100*([p5] div 1000)+1000*(([p4] div 100) mod 10))+(([p1] div 10)=2)*(1*(([p3] div 100) mod 10)+10*(([p4] div 1000) mod 10)+100*(([p5] div 100) mod 10)+1000*(([p4] div 10) mod 10))+(([p1] div 10)=3)*(1*(([p3] div 10) mod 10)+10*(([p4] div 100) mod 10)+100*(([p5] div 10) mod 10)+1000*(([p4] div 1) mod 10))+(([p1] div 10)=4)*(1*(([p3] div 1) mod 10)+10*(([p4] div 10) mod 10)+100*(([p5] div 1) mod 10)+1000*0)}
  -> Path189 => Loc36  вер=1 порядок=5
       условия: логика {([p1] mod 10)=4}
       эффект: P6(Side cells) = {[p6]+(([p1] div 10)=1)*(1*([p4] div 1000)+10*0+1000*(([p5] div 100) mod 10))+(([p1] div 10)=2)*(1*(([p4] div 100) mod 10)+10*(([p5] div 1000) mod 10)+1000*(([p5] div 10) mod 10))+(([p1] div 10)=3)*(1*(([p4] div 10) mod 10)+10*(([p5] div 100) mod 10)+1000*(([p5] div 1) mod 10))+(([p1] div 10)=4)*(1*(([p4] div 1) mod 10)+10*(([p5] div 10) mod 10)+1000*0)}
  -> Path190 => Loc36  вер=1 порядок=5
       условия: логика {([p1] mod 10)=1}
       эффект: P6(Side cells) = {[p6]+(([p1] div 10)=1)*(10*0+100*([p3] div 1000)+1000*(([p2] div 100) mod 10))+(([p1] div 10)=2)*(10*(([p2] div 1000) mod 10)+100*(([p3] div 100) mod 10)+1000*(([p2] div 10) mod 10))+(([p1] div 10)=3)*(10*(([p2] div 100) mod 10)+100*(([p3] div 10) mod 10)+1000*(([p2] div 1) mod 10))+(([p1] div 10)=4)*(10*(([p2] div 10) mod 10)+100*([p3] mod 10)+1000*0)}
  -> Path191 => Loc36  вер=1 порядок=5
       условия: логика {([p1] mod 10)=2}
       эффект: P6(Side cells) = {[p6]+(([p1] div 10)=1)*(1*([p2] div 1000)+10*0+100*([p4] div 1000)+1000*(([p3] div 100) mod 10))+(([p1] div 10)=2)*(1*(([p2] div 100) mod 10)+10*(([p3] div 1000) mod 10)+100*(([p4] div 100) mod 10)+1000*(([p3] div 10) mod 10))+(([p1] div 10)=3)*(1*(([p2] div 10) mod 10)+10*(([p3] div 100) mod 10)+100*(([p4] div 10) mod 10)+1000*(([p3] div 1) mod 10))+(([p1] div 10)=4)*(1*(([p2] div 1) mod 10)+10*(([p3] div 10) mod 10)+100*(([p4] div 1) mod 10)+1000*0)}

### Loc36 [пустая]
  -> Path181 => Loc33  вер=1 порядок=5
       условия: логика {([p1] mod 10)<3}
       эффект: P7(Switches remaining) -1
  -> Path182 => Loc34  вер=1 порядок=5
       условия: логика {([p1] mod 10)>2}
       эффект: P7(Switches remaining) -1

### Loc37 [ПРОВАЛ]
    выбор описания: {[p9]}
    Loc37-1: "I might not be able to handle it," you confess. "I'm not that good at safecracking." /  / "Well, thanks anyway for 'fessing up," Ikss said. "We'll have a chanc…
    Loc37-2: "I might not be able to handle it," you confess. "I just won't be able to get it done in the time remaining." /  / "Unfortunately, <Ranger>. You haven't proven …
    скрыт: P7

### Loc40 [пустая]
  -> Path205 => Loc29  вер=1 порядок=5

### Loc41 [СТАРТ]
    Loc41-1: At the spaceport on planet <ToPlanet> you were greeted by deafeningly loud music and colorful confetti twirling through the air. This is the celebratory atmosph…
    эффект: P1(Empty cell coordinates) = 11 [скрыт]
    эффект: P2(First row) = {111} [скрыт]
    эффект: P3(Second row) = {111} [скрыт]
    эффект: P4(Third row) = {111} [скрыт]
    эффект: P5(Fourth row) = {111} [скрыт]
    эффект: P6(Side cells) = {1} [скрыт]
    эффект: P7(Switches remaining) = {35} [скрыт]
    эффект: P8(Puzzle version) = {[1..4]} [скрыт]
    скрыт: P9
  -> Path206 => Loc29  вер=1 порядок=5
       текст: Go up to the safe

## Анализ
- стартовых: [41]
- концовки: {32: 'УСПЕХ', 37: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
