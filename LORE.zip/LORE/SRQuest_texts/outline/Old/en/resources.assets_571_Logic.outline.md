# Квест (формат 1111111126)
Сложность 30; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Line 1' [0..2] тип=обычный
    старт: [0]
    [0..0] <fix>    [ ]    </fix>
    [1..1] <fix>    [0]    </fix>
    [2..2] <fix>    [+]    </fix>
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Line 2 (blank)' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[ ]-[ ]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[ ]</fix>
    [2..2] <fix>[ ]-[0]-[ ]</fix>
    [3..3] <fix>[ ]-[ ]-[0]</fix>
    [4..4] <fix>[+]-[ ]-[ ]</fix>
    [5..5] <fix>[ ]-[+]-[ ]</fix>
    [6..6] <fix>[ ]-[ ]-[+]</fix>
    [7..7] <fix>[+]-[+]-[ ]</fix>
    [8..8] <fix>[ ]-[+]-[+]</fix>
    [9..9] <fix>[+]-[ ]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Line 2 (half)' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[0]-[+]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[+]</fix>
    [2..2] <fix>[0]-[+]-[+]</fix>
    [3..3] <fix>[+]-[0]-[ ]</fix>
    [4..4] <fix>[ ]-[0]-[+]</fix>
    [5..5] <fix>[+]-[0]-[+]</fix>
    [6..6] <fix>[+]-[ ]-[0]</fix>
    [7..7] <fix>[ ]-[+]-[0]</fix>
    [8..8] <fix>[+]-[+]-[0]</fix>
    [9..9] <fix>[+]-[+]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Line 3 (blank).' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[ ]-[ ]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[ ]</fix>
    [2..2] <fix>[ ]-[0]-[ ]</fix>
    [3..3] <fix>[ ]-[ ]-[0]</fix>
    [4..4] <fix>[+]-[ ]-[ ]</fix>
    [5..5] <fix>[ ]-[+]-[ ]</fix>
    [6..6] <fix>[ ]-[ ]-[+]</fix>
    [7..7] <fix>[+]-[+]-[ ]</fix>
    [8..8] <fix>[ ]-[+]-[+]</fix>
    [9..9] <fix>[+]-[ ]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 4
- P5 'Line 3 (half).' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[0]-[+]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[+]</fix>
    [2..2] <fix>[0]-[+]-[+]</fix>
    [3..3] <fix>[+]-[0]-[ ]</fix>
    [4..4] <fix>[ ]-[0]-[+]</fix>
    [5..5] <fix>[+]-[0]-[+]</fix>
    [6..6] <fix>[+]-[ ]-[0]</fix>
    [7..7] <fix>[ ]-[+]-[0]</fix>
    [8..8] <fix>[+]-[+]-[0]</fix>
    [9..9] <fix>[+]-[+]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 12
- P6 'Line 4 (blank).' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[ ]-[ ]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[ ]</fix>
    [2..2] <fix>[ ]-[0]-[ ]</fix>
    [3..3] <fix>[ ]-[ ]-[0]</fix>
    [4..4] <fix>[+]-[ ]-[ ]</fix>
    [5..5] <fix>[ ]-[+]-[ ]</fix>
    [6..6] <fix>[ ]-[ ]-[+]</fix>
    [7..7] <fix>[+]-[+]-[ ]</fix>
    [8..8] <fix>[ ]-[+]-[+]</fix>
    [9..9] <fix>[+]-[ ]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Line 4 (half).' [0..9] тип=обычный
    старт: [0]
    [0..0] <fix>[0]-[+]-[ ]</fix>
    [1..1] <fix>[0]-[ ]-[+]</fix>
    [2..2] <fix>[0]-[+]-[+]</fix>
    [3..3] <fix>[+]-[0]-[ ]</fix>
    [4..4] <fix>[ ]-[0]-[+]</fix>
    [5..5] <fix>[+]-[0]-[+]</fix>
    [6..6] <fix>[+]-[ ]-[0]</fix>
    [7..7] <fix>[ ]-[+]-[0]</fix>
    [8..8] <fix>[+]-[+]-[0]</fix>
    [9..9] <fix>[+]-[+]-[+]</fix>
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Line 5.' [0..2] тип=обычный
    старт: [0]
    [0..0] <fix>    [ ]    </fix>
    [1..1] <fix>    [0]    </fix>
    [2..2] <fix>    [+]    </fix>
    критическое: Сообщение достижения критического значения параметром 5
- P9 "Player's position." [0..99] тип=обычный
    старт: [23]
    [0..99] <br>Player: X:{<> div 10} Y:{<> mod 10}
    критическое: Сообщение достижения критического значения параметром 8
- P10 "Computer's position 1." [0..99] тип=обычный
    старт: [14]
    [0..99] 1: X:{<> div 10} Y:{<> mod 10}
    критическое: Сообщение достижения критического значения параметром 9
- P11 "Computer's position 2." [0..99] тип=обычный
    старт: [25]
    [0..99] 2: X:{<> div 10} Y:{<> mod 10}
    критическое: Сообщение достижения критического значения параметром 10
- P12 "Computer's position 3." [0..99] тип=обычный
    старт: [34]
    [0..99] 3: X:{<> div 10} Y:{<> mod 10}
    критическое: Сообщение достижения критического значения параметром 11
- P46 'Player.' [0..1] тип=обычный
    старт: [0]
    [0..1] <br>"0" - Player's piece.
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Penchekryaks.' [0..1] тип=обычный
    старт: [0]
    [0..1] "+" - Enemy's pieces.
    критическое: Сообщение достижения критического значения параметром 47
- P48 'Text.' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter 48: <>.
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: Following the instructions received on planet <ToPlanet>, you find the entertainment complex where the championship is to be held. You struggle through the crow…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P46,P47,P48
  -> Path81 => Loc24  вер=1 порядок=5
       текст: Nobody told me the rules of Barabum. Can anybody help?
  -> Path123 => Loc25  вер=1 порядок=4
       текст: You said something about the ancient history of the game... I'd like to hear it.
  -> Path127 => Loc2  вер=1
       текст: What are we waiting for then? Forward, to victory! Just show me this Ubaran...

### Loc2 [обычная]
    Loc2-1: "Not Ubaran, but Uralban," said the maloq with a grin. If you are ready, please come with me..." / You leave the office, pass by a number of corridors, and ente…
    эффект: P1(Line 1) = {0} [показ]
    эффект: P2(Line 2 (blank)) = {0} [показ]
    эффект: P4(Line 3 (blank).) = {2} [показ]
    эффект: P6(Line 4 (blank).) = {9} [показ]
    эффект: P8(Line 5.) = {2} [показ]
    показ: P46,P47
  -> Path82 => Loc11  вер=1 порядок=5
       текст: Well, let's begin!
       эффект: P1(Line 1) = {0} [показ]
       эффект: P2(Line 2 (blank)) = {0} [показ]
       эффект: P4(Line 3 (blank).) = {2} [показ]
       эффект: P6(Line 4 (blank).) = {9} [показ]
       эффект: P8(Line 5.) = {2} [показ]

### Loc3 [обычная]
    выбор описания: {[p48]}
    Loc3-1: The maloq doesn't even think about his first move. He immediately pushes the button. One of the penchekryaks gets going and takes some steps forward.	 / "What a…
    Loc3-2: After mustering up your courage, you push the button and a maloq figure moves on the screen. / "Well, that's an okay move. Personally, I have no doubt that Ural…
    Loc3-3: After thinking over your move, you at last push one of the buttons. To your surprise, the commentator says nothing - it was a good move. However, your opponent …
    Loc3-4: After moving Drakar into one of the cells, you look up triumphantly at Uralban. Your move confuses him. He scratches his head and another important part of his …
    Loc3-5: You decide the move will be clever enough given your current situation. You move Gromiko into one of the cells. / "Ah, <Ranger> is using the famous Dirty Schnap…
    Loc3-6: You decisively push the button and look confidently at your opponent. "Surely, he won't be able to answer this", you think. As it turns out, you were wrong. See…
  -> Path2 => Loc4  вер=1 порядок=8
       текст: Down.
       условия: логика {(([p9]+1)<>[p10]) and (([p9]+1)<>[p11]) and (([p9]+1)<>[p12]) and [p9]<>25 and [p9]<>14 and [p9]<>34}
       эффект: P9(Player's position.) = {[p9]+1}
  -> Path3 => Loc4  вер=1 порядок=1
       текст: Up.
       условия: логика {(([p9]-1)<>[p10]) and (([p9]-1)<>[p11]) and (([p9]-1)<>[p12]) and [p9]<>21 and [p9]<>12 and [p9]<>32}
       эффект: P9(Player's position.) = {[p9]-1}
  -> Path4 => Loc4  вер=1 порядок=4
       текст: Left.
       условия: логика {(([p9]-10)<>[p10]) and (([p9]-10)<>[p11]) and (([p9]-10)<>[p12]) and (([p9]-10)>10) and [p9]<>25 and [p9]<>21}
       эффект: P9(Player's position.) = {[p9]-10}
  -> Path5 => Loc4  вер=1 порядок=5
       текст: Right.
       условия: логика {(([p9]+10)<>[p10]) and (([p9]+10)<>[p11]) and (([p9]+10)<>[p12]) and (([p9]+10)<40) and [p9]<>25 and [p9]<>21}
       эффект: P9(Player's position.) = {[p9]+10}
  -> Path75 => Loc4  вер=1 порядок=5
       текст: Down and right.
       условия: логика {[p9]=21 and [p10]<>32 and [p12]<>32 and [p12]<>32}
       эффект: P9(Player's position.) = {32}
  -> Path76 => Loc4  вер=1 порядок=4
       текст: Down and left.
       условия: логика {[p9]=21 and [p10]<>12 and [p12]<>12 and [p12]<>12}
       эффект: P9(Player's position.) = {12}
  -> Path77 => Loc4  вер=1 порядок=4
       текст: Up and left.
       условия: логика {[p9]=25 and [p10]<>14 and [p12]<>14 and [p12]<>14}
       эффект: P9(Player's position.) = {14}
  -> Path78 => Loc4  вер=1 порядок=5
       текст: Up and right.
       условия: логика {[p9]=25 and [p10]<>34 and [p12]<>34 and [p12]<>34}
       эффект: P9(Player's position.) = {34}
  -> Path79 => Loc4  вер=1 порядок=8
       текст: Down.
       условия: логика {([p9]=14 or [p9]=34) and ([p10]<>25 and [p11]<>25 and [p12]<>25)}
       эффект: P9(Player's position.) = {25}
  -> Path80 => Loc4  вер=1 порядок=1
       текст: Up.
       условия: логика {([p9]=12 or [p9]=32) and ([p10]<>21 and [p11]<>21 and [p12]<>21)}
       эффект: P9(Player's position.) = {21}
  -> Path114 => Loc23  вер=1 порядок=9
       текст: That's it. I give up.
       эффект: P48(Text.) = {1}
  -> Path136 => Loc23  вер=100 порядок=5

### Loc4 [пустая]
  -> Path83 => Loc13  вер=1 порядок=5
       условия: логика {[p9]<>25}
  -> Path118 => Loc5  вер=1 порядок=5
       условия: логика {[p9]=25}

### Loc5 [пустая]
    скрыт: P2,P3,P4,P5,P6,P7
  -> Path8 => Loc6  вер=1 порядок=5
       условия: логика {[p10]=21 or [p11]=21 or [p12]=21}
       эффект: P1(Line 1) = {2}
  -> Path9 => Loc6  вер=1 порядок=5
       условия: логика {[p9]<>21 and [p10]<>21 and [p11]<>21 and [p12]<>21}
       эффект: P1(Line 1) = {0}
  -> Path10 => Loc6  вер=1 порядок=5
       условия: логика {[p9]=21}
       эффект: P1(Line 1) = {1}

### Loc6 [пустая]
  -> Path11 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=12 and (([p10]=22 and [p11]=32) or ([p11]=22 and [p12]=32) or ([p12]=22 and [p10]=32) or ([p10]=22 and [p12]=32) or ([p12]=22 and [p11]=32))}
       эффект: P3(Line 2 (half)) = {2} [показ]
  -> Path16 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=32 and (([p10]=22 and [p11]<>12 and [p12]<>12) or ([p11]=22 and [p10]<>12 and [p12]<>12) or ([p12]=22 and [p10]<>12 and [p11]<>12))}
       эффект: P3(Line 2 (half)) = {7} [показ]
  -> Path17 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=22 and (([p10]=12 and [p11]=32) or ([p11]=12 and [p12]=32) or ([p12]=12 and [p10]=32) or ([p10]=12 and [p12]=32) or ([p12]=12 and [p11]=32))}
       эффект: P3(Line 2 (half)) = {5} [показ]
  -> Path18 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=32 and (([p10]=12 and [p11]<>22 and [p12]<>22) or ([p11]=12 and [p10]<>22 and [p12]<>22) or ([p12]=12 and [p10]<>22 and [p11]<>22))}
       эффект: P3(Line 2 (half)) = {6} [показ]
  -> Path19 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=32 and (([p10]=12 and [p11]=22) or ([p11]=12 and [p12]=22) or ([p12]=12 and [p10]=22) or ([p10]=12 and [p12]=22) or ([p12]=12 and [p11]=22))}
       эффект: P3(Line 2 (half)) = {8} [показ]
  -> Path20 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=22 and (([p10]=32 and [p11]<>12 and [p12]<>12) or ([p11]=32 and [p10]<>12 and [p12]<>12) or ([p12]=32 and [p10]<>12 and [p11]<>12))}
       эффект: P3(Line 2 (half)) = {4} [показ]
  -> Path21 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (([p10]=12 and [p11] mod 10<>2 and [p12] mod 10<>2) or ([p11]=12 and [p10] mod 10<>2 and [p12] mod 10<>2) or ([p12]=12 and [p10] mod 10<>2 and [p11] mod 10<>2))}
       эффект: P2(Line 2 (blank)) = {4} [показ]
  -> Path22 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=22 and (([p10]=12 and [p11]<>32 and [p12]<>32) or ([p11]=12 and [p10]<>32 and [p12]<>32) or ([p12]=12 and [p10]<>32 and [p11]<>32))}
       эффект: P3(Line 2 (half)) = {3} [показ]
  -> Path23 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (([p10]=22 and [p11] mod 10<>2 and [p12] mod 10<>2) or ([p11]=22 and [p10] mod 10<>2 and [p12] mod 10<>2) or ([p12]=22 and [p10] mod 10<>2 and [p11] mod 10<>2))}
       эффект: P2(Line 2 (blank)) = {5} [показ]
  -> Path24 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=12 and (([p10]=32 and [p11]<>22 and [p12]<>22) or ([p11]=32 and [p10]<>22 and [p12]<>22) or ([p12]=32 and [p10]<>22 and [p11]<>22))}
       эффект: P3(Line 2 (half)) = {1} [показ]
  -> Path25 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (([p10]=32 and [p11] mod 10<>2 and [p12] mod 10<>2) or ([p11]=32 and [p10] mod 10<>2 and [p12] mod 10<>2) or ([p12]=32 and [p10] mod 10<>2 and [p11] mod 10<>2))}
       эффект: P2(Line 2 (blank)) = {6} [показ]
  -> Path26 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=12 and (([p10]=22 and [p11]<>32 and [p12]<>32) or ([p11]=22 and [p10]<>32 and [p12]<>32) or ([p12]=22 and [p10]<>32 and [p11]<>32))}
       эффект: P3(Line 2 (half)) = {0} [показ]
  -> Path27 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (((([p10]=12 and [p11]=22) or ([p10]=22 and [p11]=12)) and [p12]<>32) or ((([p10]=12 and [p12]=22) or ([p10]=22 and [p12]=12)) and [p11]<>32) or ((([p11]=12 and [p12]=22) or ([p11]=22 and [p12]=12)) and [p10]<>32))}
       эффект: P2(Line 2 (blank)) = {7} [показ]
  -> Path28 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=32 and [p10] mod 10<>2 and [p11] mod 10<>2 and [p12] mod 10<>2}
       эффект: P2(Line 2 (blank)) = {3} [показ]
  -> Path29 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (((([p10]=32 and [p11]=22) or ([p10]=22 and [p11]=32)) and [p12]<>22) or ((([p10]=32 and [p12]=22) or ([p12]=32 and [p10]=22)) and [p11]<>12) or ((([p11]=32 and [p12]=22) or ([p11]=22 and [p12]=32)) and [p10]<>12))}
       эффект: P2(Line 2 (blank)) = {8} [показ]
  -> Path30 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=22 and [p10] mod 10<>2 and [p11] mod 10<>2 and [p12] mod 10<>2}
       эффект: P2(Line 2 (blank)) = {2} [показ]
  -> Path31 => Loc7  вер=1 порядок=5
       условия: логика {[p9] mod 10<>2 and (((([p10]=12 and [p11]=32) or ([p10]=32 and [p11]=12)) and [p12]<>22) or ((([p10]=12 and [p12]=32) or ([p12]=32 and [p10]=12)) and [p11]<>22) or ((([p11]=12 and [p12]=32) or ([p11]=32 and [p12]=12)) and [p10]<>22))}
       эффект: P2(Line 2 (blank)) = {9} [показ]
  -> Path32 => Loc7  вер=1 порядок=5
       условия: логика {[p9]=12 and [p10] mod 10<>2 and [p11] mod 10<>2 and [p12] mod 10<>2}
       эффект: P2(Line 2 (blank)) = {1} [показ]
  -> Path33 => Loc7  вер=1 порядок=5
       условия: логика {[p10] mod 10=2 and [p11] mod 10=2 and [p12] mod 10=2}
       эффект: P3(Line 2 (half)) = {9} [показ]
  -> Path34 => Loc7  вер=1 порядок=5
       условия: логика {([p9] mod 10<>2) and ([p10] mod 10<>2) and ([p11] mod 10<>2) and ([p12] mod 10<>2)}
       эффект: P2(Line 2 (blank)) = {0} [показ]

### Loc7 [пустая]
  -> Path12 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=13 and (([p10]=23 and [p11]=33) or ([p11]=23 and [p12]=33) or ([p12]=23 and [p10]=33) or ([p10]=23 and [p12]=33) or ([p12]=23 and [p11]=32))}
       эффект: P5(Line 3 (half).) = {2} [показ]
  -> Path37 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=33 and (([p10]=23 and [p11]<>13 and [p12]<>13) or ([p11]=23 and [p10]<>13 and [p12]<>13) or ([p12]=23 and [p10]<>13 and [p11]<>13))}
       эффект: P5(Line 3 (half).) = {7} [показ]
  -> Path38 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=23 and (([p10]=13 and [p11]=33) or ([p11]=13 and [p12]=33) or ([p12]=13 and [p10]=33) or ([p10]=13 and [p12]=33) or ([p12]=13 and [p11]=33))}
       эффект: P5(Line 3 (half).) = {5} [показ]
  -> Path39 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=33 and (([p10]=13 and [p11]<>23 and [p12]<>23) or ([p11]=13 and [p10]<>23 and [p12]<>23) or ([p12]=13 and [p10]<>23 and [p11]<>23))}
       эффект: P5(Line 3 (half).) = {6} [показ]
  -> Path40 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=33 and (([p10]=13 and [p11]=23) or ([p11]=13 and [p12]=23) or ([p12]=13 and [p10]=23) or ([p10]=13 and [p12]=23) or ([p12]=13 and [p11]=23))}
       эффект: P5(Line 3 (half).) = {8} [показ]
  -> Path41 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=23 and (([p10]=33 and [p11]<>13 and [p12]<>13) or ([p11]=33 and [p10]<>13 and [p12]<>13) or ([p12]=33 and [p10]<>13 and [p11]<>13))}
       эффект: P5(Line 3 (half).) = {4} [показ]
  -> Path42 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (([p10]=13 and [p11] mod 10<>3 and [p12] mod 10<>3) or ([p11]=13 and [p10] mod 10<>3 and [p12] mod 10<>3) or ([p12]=13 and [p10] mod 10<>3 and [p11] mod 10<>3))}
       эффект: P4(Line 3 (blank).) = {4} [показ]
  -> Path43 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=23 and (([p10]=13 and [p11]<>33 and [p12]<>33) or ([p11]=13 and [p10]<>33 and [p12]<>33) or ([p12]=13 and [p10]<>33 and [p11]<>33))}
       эффект: P5(Line 3 (half).) = {3} [показ]
  -> Path44 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (([p10]=23 and [p11] mod 10<>3 and [p12] mod 10<>3) or ([p11]=23 and [p10] mod 10<>3 and [p12] mod 10<>3) or ([p12]=23 and [p10] mod 10<>3 and [p11] mod 10<>3))}
       эффект: P4(Line 3 (blank).) = {5} [показ]
  -> Path45 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=13 and (([p10]=33 and [p11]<>23 and [p12]<>23) or ([p11]=33 and [p10]<>23 and [p12]<>23) or ([p12]=33 and [p10]<>23 and [p11]<>23))}
       эффект: P5(Line 3 (half).) = {1} [показ]
  -> Path46 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (([p10]=33 and [p11] mod 10<>3 and [p12] mod 10<>3) or ([p11]=33 and [p10] mod 10<>3 and [p12] mod 10<>3) or ([p12]=33 and [p10] mod 10<>3 and [p11] mod 10<>3))}
       эффект: P4(Line 3 (blank).) = {6} [показ]
  -> Path47 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=13 and (([p10]=23 and [p11]<>33 and [p12]<>33) or ([p11]=23 and [p10]<>33 and [p12]<>33) or ([p12]=23 and [p10]<>33 and [p11]<>33))}
       эффект: P5(Line 3 (half).) = {0} [показ]
  -> Path48 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (((([p10]=13 and [p11]=23) or ([p10]=23 and [p11]=13)) and [p12]<>33) or ((([p10]=13 and [p12]=23) or ([p10]=23 and [p12]=13)) and [p11]<>33) or ((([p11]=13 and [p12]=23) or ([p11]=23 and [p12]=13)) and [p10]<>33))}
       эффект: P4(Line 3 (blank).) = {7} [показ]
  -> Path49 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=33 and [p10] mod 10<>3 and [p11] mod 10<>3 and [p12] mod 10<>3}
       эффект: P4(Line 3 (blank).) = {3} [показ]
  -> Path50 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (((([p10]=33 and [p11]=23) or ([p10]=23 and [p11]=33)) and [p12]<>23) or ((([p10]=33 and [p12]=23) or ([p12]=33 and [p10]=23)) and [p11]<>13) or ((([p11]=33 and [p12]=23) or ([p11]=23 and [p12]=33)) and [p10]<>13))}
       эффект: P4(Line 3 (blank).) = {8} [показ]
  -> Path51 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=23 and [p10] mod 10<>3 and [p11] mod 10<>3 and [p12] mod 10<>3}
       эффект: P4(Line 3 (blank).) = {2} [показ]
  -> Path52 => Loc8  вер=1 порядок=5
       условия: логика {[p9] mod 10<>3 and (((([p10]=13 and [p11]=33) or ([p10]=33 and [p11]=13)) and [p12]<>23) or ((([p10]=13 and [p12]=33) or ([p12]=33 and [p10]=13)) and [p11]<>23) or ((([p11]=13 and [p12]=33) or ([p11]=33 and [p12]=13)) and [p10]<>23))}
       эффект: P4(Line 3 (blank).) = {9} [показ]
  -> Path53 => Loc8  вер=1 порядок=5
       условия: логика {[p9]=13 and [p10] mod 10<>3 and [p11] mod 10<>3 and [p12] mod 10<>3}
       эффект: P4(Line 3 (blank).) = {1} [показ]
  -> Path54 => Loc8  вер=1 порядок=5
       условия: логика {[p10] mod 10=3 and [p11] mod 10=3 and [p12] mod 10=3}
       эффект: P5(Line 3 (half).) = {9} [показ]
  -> Path55 => Loc8  вер=1 порядок=5
       условия: логика {([p9] mod 10<>3) and ([p10] mod 10<>3) and ([p11] mod 10<>3) and ([p12] mod 10<>3)}
       эффект: P4(Line 3 (blank).) = {0} [показ]

### Loc8 [пустая]
  -> Path13 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=14 and (([p10]=24 and [p11]=34) or ([p11]=24 and [p12]=34) or ([p12]=24 and [p10]=34) or ([p10]=24 and [p12]=34) or ([p12]=24 and [p11]=34))}
       эффект: P7(Line 4 (half).) = {2} [показ]
  -> Path56 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=34 and (([p10]=24 and [p11]<>14 and [p12]<>14) or ([p11]=24 and [p10]<>14 and [p12]<>14) or ([p12]=24 and [p10]<>14 and [p11]<>14))}
       эффект: P7(Line 4 (half).) = {7} [показ]
  -> Path57 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=24 and (([p10]=14 and [p11]=34) or ([p11]=14 and [p12]=34) or ([p12]=14 and [p10]=34) or ([p10]=14 and [p12]=34) or ([p12]=14 and [p11]=34))}
       эффект: P7(Line 4 (half).) = {5} [показ]
  -> Path58 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=34 and (([p10]=14 and [p11]<>24 and [p12]<>24) or ([p11]=14 and [p10]<>24 and [p12]<>24) or ([p12]=14 and [p10]<>24 and [p11]<>24))}
       эффект: P7(Line 4 (half).) = {6} [показ]
  -> Path59 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=34 and (([p10]=14 and [p11]=24) or ([p11]=14 and [p12]=24) or ([p12]=14 and [p10]=24) or ([p10]=14 and [p12]=24) or ([p12]=14 and [p11]=24))}
       эффект: P7(Line 4 (half).) = {8} [показ]
  -> Path60 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=24 and (([p10]=34 and [p11]<>14 and [p12]<>14) or ([p11]=34 and [p10]<>14 and [p12]<>14) or ([p12]=34 and [p10]<>14 and [p11]<>14))}
       эффект: P7(Line 4 (half).) = {4} [показ]
  -> Path61 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (([p10]=14 and [p11] mod 10<>4 and [p12] mod 10<>4) or ([p11]=14 and [p10] mod 10<>4 and [p12] mod 10<>4) or ([p12]=14 and [p10] mod 10<>4 and [p11] mod 10<>4))}
       эффект: P6(Line 4 (blank).) = {4} [показ]
  -> Path62 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=24 and (([p10]=14 and [p11]<>34 and [p12]<>34) or ([p11]=14 and [p10]<>34 and [p12]<>34) or ([p12]=14 and [p10]<>34 and [p11]<>34))}
       эффект: P7(Line 4 (half).) = {3} [показ]
  -> Path63 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (([p10]=24 and [p11] mod 10<>4 and [p12] mod 10<>4) or ([p11]=24 and [p10] mod 10<>4 and [p12] mod 10<>4) or ([p12]=24 and [p10] mod 10<>4 and [p11] mod 10<>4))}
       эффект: P6(Line 4 (blank).) = {5} [показ]
  -> Path64 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=14 and (([p10]=34 and [p11]<>24 and [p12]<>24) or ([p11]=34 and [p10]<>24 and [p12]<>24) or ([p12]=34 and [p10]<>24 and [p11]<>24))}
       эффект: P7(Line 4 (half).) = {1} [показ]
  -> Path65 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (([p10]=34 and [p11] mod 10<>4 and [p12] mod 10<>4) or ([p11]=34 and [p10] mod 10<>4 and [p12] mod 10<>4) or ([p12]=34 and [p10] mod 10<>4 and [p11] mod 10<>4))}
       эффект: P6(Line 4 (blank).) = {6} [показ]
  -> Path66 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=14 and (([p10]=24 and [p11]<>34 and [p12]<>34) or ([p11]=24 and [p10]<>34 and [p12]<>34) or ([p12]=24 and [p10]<>34 and [p11]<>34))}
       эффект: P7(Line 4 (half).) = {0} [показ]
  -> Path67 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (((([p10]=14 and [p11]=24) or ([p10]=24 and [p11]=14)) and [p12]<>34) or ((([p10]=14 and [p12]=24) or ([p10]=24 and [p12]=14)) and [p11]<>34) or ((([p11]=14 and [p12]=24) or ([p11]=24 and [p12]=14)) and [p10]<>34))}
       эффект: P6(Line 4 (blank).) = {7} [показ]
  -> Path68 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=34 and [p10] mod 10<>4 and [p11] mod 10<>4 and [p12] mod 10<>4}
       эффект: P6(Line 4 (blank).) = {3} [показ]
  -> Path69 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (((([p10]=34 and [p11]=24) or ([p10]=24 and [p11]=34)) and [p12]<>24) or ((([p10]=34 and [p12]=24) or ([p12]=34 and [p10]=24)) and [p11]<>14) or ((([p11]=34 and [p12]=24) or ([p11]=24 and [p12]=34)) and [p10]<>14))}
       эффект: P6(Line 4 (blank).) = {8} [показ]
  -> Path70 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=24 and [p10] mod 10<>4 and [p11] mod 10<>4 and [p12] mod 10<>4}
       эффект: P6(Line 4 (blank).) = {2} [показ]
  -> Path71 => Loc9  вер=1 порядок=5
       условия: логика {[p9] mod 10<>4 and (((([p10]=14 and [p11]=34) or ([p10]=34 and [p11]=14)) and [p12]<>24) or ((([p10]=14 and [p12]=34) or ([p12]=34 and [p10]=14)) and [p11]<>24) or ((([p11]=14 and [p12]=34) or ([p11]=34 and [p12]=14)) and [p10]<>24))}
       эффект: P6(Line 4 (blank).) = {9} [показ]
  -> Path72 => Loc9  вер=1 порядок=5
       условия: логика {[p9]=14 and [p10] mod 10<>4 and [p11] mod 10<>4 and [p12] mod 10<>4}
       эффект: P6(Line 4 (blank).) = {1} [показ]
  -> Path73 => Loc9  вер=1 порядок=5
       условия: логика {[p10] mod 10=4 and [p11] mod 10=4 and [p12] mod 10=4}
       эффект: P7(Line 4 (half).) = {9} [показ]
  -> Path74 => Loc9  вер=1 порядок=5
       условия: логика {([p9] mod 10<>4) and ([p10] mod 10<>4) and ([p11] mod 10<>4) and ([p12] mod 10<>4)}
       эффект: P6(Line 4 (blank).) = {0} [показ]

### Loc9 [пустая]
  -> Path14 => Loc10  вер=1 порядок=5
       условия: логика {[p10]=25 or [p11]=25 or [p12]=25}
       эффект: P8(Line 5.) = {2}
  -> Path35 => Loc10  вер=1 порядок=5
       условия: логика {[p9]<>25 and [p10]<>25 and [p11]<>25 and [p12]<>25}
       эффект: P8(Line 5.) = {0}
  -> Path36 => Loc10  вер=1 порядок=5
       условия: логика {[p9]=25}
       эффект: P8(Line 5.) = {1}

### Loc10 [пустая]
  -> Path15 => Loc3  вер=1 порядок=5
       условия: логика {[p9]<>25}
       эффект: P48(Text.) = {[2..6]}
  -> Path120 => Loc3  вер=100 проходов<=1 порядок=5
       условия: логика {[p9]<>25}
       эффект: P48(Text.) = {1}
  -> Path121 => Loc17  вер=1 порядок=5
       условия: логика {[p9]=25}
       эффект: P48(Text.) = {1}
  -> Path122 => Loc23  вер=100000 порядок=5
       условия: логика {[p9]=21 and [p10]=12 and [p11]=22 and [p12]=32}
       эффект: P48(Text.) = {2}
  -> Path133 => Loc17  вер=1e+06 порядок=5
       условия: логика {([p9] mod 10)>([p10] mod 10) and ([p9] mod 10)>([p11] mod 10) and ([p9] mod 10)>([p12] mod 10)}
       эффект: P48(Text.) = {3}
  -> Path143 => Loc23  вер=100000 порядок=5
       условия: логика {[p9]=12 and [p10]=13 and [p11]=22 and [p12]=21}
       эффект: P48(Text.) = {2}
  -> Path144 => Loc23  вер=100000 порядок=5
       условия: логика {[p9]=32 and [p10]=21 and [p11]=22 and [p12]=33}
       эффект: P48(Text.) = {2}

### Loc11 [пустая]
  -> Path89 => Loc5  вер=5 порядок=5
       эффект: P11(Computer's position 2.) -1

### Loc12 [пустая]
  -> Path7 => Loc5  вер=1 порядок=5

### Loc13 [пустая]
  -> Path84 => Loc14  вер=100 [всегда видна] порядок=5
       условия: логика {([p9]=13 or [p9]=33) and [p11]=24 and [p10]<>23 and [p12]<>23}
       эффект: P11(Computer's position 2.) = {23}
  -> Path85 => Loc16  вер=1 [всегда видна] порядок=5
  -> Path109 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=33 and [p11]=23 and [p10]=13}
       эффект: P10(Computer's position 1.) = {12}
  -> Path112 => Loc14  вер=100 порядок=5
       условия: логика {([p9]=12 or [p9]=32) and [p11]=23 and [p10]<>13 and [p10]<>33 and [p10]<>21 and [p10]<>12}
       эффект: P10(Computer's position 1.) = {[p10]-1}
  -> Path113 => Loc14  вер=100 порядок=5
       условия: логика {([p9]=12 or [p9]=32) and [p11]=23 and [p12]<>33 and [p12]<>13 and [p12]<>21 and [p12]<>32}
       эффект: P12(Computer's position 3.) = {[p12]-1}
  -> Path115 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=13 and [p11]=23 and [p12]=33 and [p10]<>32}
       эффект: P12(Computer's position 3.) = {32}
  -> Path116 => Loc14  вер=100 порядок=5
       условия: логика {[p12]=22 and [p10]=13 and [p9]=12 and [p12]=33}
       эффект: P12(Computer's position 3.) = {23}
  -> Path117 => Loc14  вер=100 порядок=5
       условия: логика {[p11]=22 and [p10]=13 and [p9]=32 and [p12]=33}
       эффект: P10(Computer's position 1.) = {12}
  -> Path128 => Loc14  вер=40 порядок=5
       условия: логика {[p9]=32 and [p12]=33 and [p11]=22 and [p10]=12}
       эффект: P10(Computer's position 1.) = {21}
  -> Path129 => Loc14  вер=40 порядок=5
       условия: логика {[p9]=12 and [p12]=32 and [p11]=22 and [p10]=13}
       эффект: P12(Computer's position 3.) = {21}
  -> Path130 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=13 and [p11]=24 and [p12]=33}
       эффект: P11(Computer's position 2.) = {23}
  -> Path131 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=23 and [p10]=14 and [p11]=24 and [p12]=33}
       эффект: P10(Computer's position 1.) = {13}
  -> Path132 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=23 and [p10]=13 and [p11]=24 and [p12]=34}
       эффект: P12(Computer's position 3.) = {33}
  -> Path134 => Loc14  вер=100 порядок=5
       условия: логика {[p12]=32 and [p10]=14 and [p11]=24 and [p9]<>23}
       эффект: P11(Computer's position 2.) = {23}
  -> Path135 => Loc14  вер=100 порядок=5
       условия: логика {[p12]=34 and [p10]=12 and [p11]=24 and [p9]<>23}
       эффект: P11(Computer's position 2.) = {23}
  -> Path137 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=13 and [p11]=23 and [p12]=32}
       эффект: P10(Computer's position 1.) = {12}
  -> Path138 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=12 and [p11]=23 and [p12]=33}
       эффект: P12(Computer's position 3.) = {32}
  -> Path139 => Loc14  вер=100 порядок=5
       условия: логика {[p10]=14 and [p11]=22 and [p12]=32 and [p9]<>13}
       эффект: P10(Computer's position 1.) = {13}
  -> Path140 => Loc14  вер=100 порядок=5
       условия: логика {[p10]=12 and [p11]=22 and [p12]=34 and [p9]<>33}
       эффект: P12(Computer's position 3.) = {33}
  -> Path141 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=12 and [p11]=23 and [p12]=34}
       эффект: P12(Computer's position 3.) = {33}
  -> Path142 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=14 and [p11]=23 and [p12]=32}
       эффект: P10(Computer's position 1.) = {13}
  -> Path145 => Loc14  вер=100 порядок=5
       условия: логика {[p9]=22 and [p10]=12 and [p11]=23 and [p12]=32}
       эффект: P10(Computer's position 1.) = {21}
  -> Path146 => Loc14  вер=100 порядок=5
       условия: логика {(([p9]=12 and [p10]=13 and [p12]=32) or ([p9]=32 and [p10]=12 and [p12]=33)) and [p11]=24}
       эффект: P11(Computer's position 2.) = {23}

### Loc14 [пустая]
  -> Path111 => Loc5  вер=1 порядок=5

### Loc16 [пустая]
  -> Path94 => Loc19  вер=1 порядок=5
       условия: логика {[p10]+10<>[p11] and [p10]+10<>[p12] and [p10]+10<>[p9] and [p10]+10<40 and [p10]<>21}
       эффект: P10(Computer's position 1.) = {[p10]+10}
  -> Path95 => Loc19  вер=1 порядок=5
       условия: логика {[p10]-10<>[p11] and [p10]-10<>[p12] and [p10]-10<>[p9] and [p10]-10>10 and [p10]<>21}
       эффект: P10(Computer's position 1.) = {[p10]-10}
  -> Path97 => Loc19  вер=100 порядок=5
       условия: логика {[p10]-1<>[p11] and [p10]-1<>[p12] and [p10]-1<>[p9] and [p10]<>12 and [p10]<>32 and [p10]<>21}
       эффект: P10(Computer's position 1.) = {[p10]-1}
  -> Path98 => Loc19  вер=5 порядок=5
       условия: логика {([p10]=12 and [p11]<>21 and [p12]<>21 and [p9]<>21) or ([p10]=32 and [p11]<>21 and [p12]<>21 and [p9]<>21)}
       эффект: P10(Computer's position 1.) = {21}
  -> Path99 => Loc20  вер=1 порядок=5
       условия: логика {[p11]+10<>[p10] and [p11]+10<>[p12] and [p11]+10<>[p9] and [p11]+10<40 and [p11]<>21}
       эффект: P11(Computer's position 2.) = {[p11]+10}
  -> Path100 => Loc20  вер=1 порядок=5
       условия: логика {[p11]-10<>[p10] and [p11]-10<>[p12] and [p11]-10<>[p9] and [p11]-10>10 and [p11]<>21}
       эффект: P11(Computer's position 2.) = {[p11]-10}
  -> Path102 => Loc20  вер=100 порядок=5
       условия: логика {[p11]-1<>[p10] and [p11]-1<>[p12] and [p11]-1<>[p9] and [p11]<>12 and [p11]<>32 and [p11]<>21}
       эффект: P11(Computer's position 2.) = {[p11]-1}
  -> Path103 => Loc20  вер=5 порядок=5
       условия: логика {([p11]=12 and [p10]<>21 and [p12]<>21 and [p9]<>21) or ([p11]=32 and [p10]<>21 and [p12]<>21 and [p9]<>21)}
       эффект: P12(Computer's position 3.) = {21}
  -> Path104 => Loc21  вер=1 порядок=5
       условия: логика {[p12]+10<>[p10] and [p12]+10<>[p11] and [p12]+10<>[p9] and [p12]+10<40 and [p12]<>21}
       эффект: P12(Computer's position 3.) = {[p12]+10}
  -> Path105 => Loc21  вер=1 порядок=5
       условия: логика {[p12]-10<>[p10] and [p12]-10<>[p11] and [p12]-10<>[p9] and [p12]-10>10 and [p12]<>21}
       эффект: P12(Computer's position 3.) = {[p12]-10}
  -> Path107 => Loc21  вер=100 порядок=5
       условия: логика {[p12]-1<>[p10] and [p12]-1<>[p11] and [p12]-1<>[p9] and [p12]<>12 and [p12]<>32 and [p12]<>21}
       эффект: P12(Computer's position 3.) = {[p12]-1}
  -> Path108 => Loc21  вер=5 порядок=5
       условия: логика {([p12]=12 and [p10]<>21 and [p11]<>21 and [p9]<>21) or ([p12]=32 and [p10]<>21 and [p11]<>21 and [p9]<>21)}
       эффект: P12(Computer's position 3.) = {21}

### Loc17 [УСПЕХ]
    выбор описания: {[p48]}
    Loc17-1: Already tasting victory, you make your last move. Drakar Gromiko runs into the enemy camp, while the penchekryaks are left out in the cold. / "It can't be!!! Fo…
    Loc17-3: You look proudly at Uralban and make your final move. <clr>Leaving all the penchekryaks behind<clrEnd>, Drakar Gromiko runs delightedly into the enemy camp. The…

### Loc19 [пустая]
  -> Path90 => Loc12  вер=1 порядок=5

### Loc20 [пустая]
  -> Path91 => Loc12  вер=1 порядок=5

### Loc21 [пустая]
  -> Path92 => Loc12  вер=1 порядок=5

### Loc23 [ПРОВАЛ]
    выбор описания: {[p48]}
    Loc23-1: You don't wish to play any further, so you push the big red button. The game piece representing you on the screen won't tolerate such an action. It draws a big …
    Loc23-2: Fearing defeat, you make a final move. Having assessed the current situation, your opponent pushes a button right away. His screaming penchekryaks lash out at t…

### Loc24 [обычная]
    Loc24-1: "Rules?" the maloq says with a smirk. "Well, okay. There will be a field with a particular layout in front of you. The first player has one piece that can move …
  -> Path119 => Loc2  вер=1
       текст: Enough talking - I can't wait any longer. I want to defeat this Ubaran!
  -> Path124 => Loc25  вер=1 порядок=5
       текст: I'd also like to hear the story behind the game.

### Loc25 [обычная]
    Loc25-1: "This game dates back to ancient times when, just like today, it was played to develop military minds. The idea was borrowed from an ancient maloq legend. Accor…
  -> Path125 => Loc24  вер=1 порядок=5
       текст: Now I'd like hear the rules of the game.
  -> Path126 => Loc2  вер=1
       текст: Enough talking - I can't wait any longer. I want to defeat this Ubaran!

## Анализ
- стартовых: [1]
- концовки: {17: 'УСПЕХ', 23: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
