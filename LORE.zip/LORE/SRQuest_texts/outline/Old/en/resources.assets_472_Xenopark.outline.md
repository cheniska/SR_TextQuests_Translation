# Квест (формат 1111111126)
Сложность 60; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Xenomorph 1' [-2..2] тип=провал
    старт: [0]
    [-2..-2] Xenomorph in Cage {1}: got poisoned and fell
    [-1..-1] Xenomorph in Cage {1}:  is having a hiccup fit
    [0..0] Xenomorph in Cage {1}:  is starving to death
    [1..1] Xenomorph in Cage {1}: looks better
    [2..2] Xenomorph in Cage {1}: is filled
    критическое: Parameter 1 critical message
- P2 'Xenomorph 2' [-2..2] тип=провал
    старт: [0]
    [-2..-2] Xenomorph in Cage {2}:  petrified
    [-1..-1] Xenomorph in Cage {2}:  is bleeding
    [0..0] Xenomorph in Cage {2}:  is starving to death
    [1..1] Xenomorph in Cage {2}: looks better
    [2..2] Xenomorph in Cage {2}: is filled
    критическое: Parameter 2 critical message
- P3 'Xenomorph 3' [-2..2] тип=провал
    старт: [0]
    [-2..-2] Xenomorph in Cage {3}:  got poisoned and fell
    [-1..-1] Xenomorph in Cage {3}:  is sick
    [0..0] Xenomorph in Cage {3}:  is starving to death
    [1..1] Xenomorph in Cage {3}: looks better
    [2..2] Xenomorph in Cage {3}: is filled
    критическое: Parameter 3 critical message
- P4 'Xenomorph 4' [-2..2] тип=смерть
    старт: [0]
    [-2..-2] Xenomorph in Cage {4}:  mouldered
    [-1..-1] Xenomorph in Cage {4}:  the animal is convulsing
    [0..0] Xenomorph in Cage {4}: is starving to death
    [1..1] Xenomorph in Cage {4}: looks better
    [2..2] Xenomorph in Cage {4}: is filled
    критическое: Parameter 4 critical message
- P5 'Xenomorph 5' [-2..2] тип=провал
    старт: [0]
    [-2..-2] Xenomorph in Cage {5}: got poisoned and fell
    [-1..-1] Xenomorph in Cage {5}: is unwell
    [0..0] Xenomorph in Cage {5}: is starving to death
    [1..1] Xenomorph in Cage {5}: looks better
    [2..2] Xenomorph in Cage {5}: is filled
    критическое: Parameter 5 critical message
- P6 'tequila' [0..1] тип=обычный
    старт: [0]
    [0..1] Do you have the book "How to feed xenomorphs"?
    критическое: Сообщение достижения критического значения параметром 6
- P7 'tail' [0..1] тип=обычный
    старт: [0]
    [0..1] Do you have the book "Behaviour and brief description of xenomorphs "?
    критическое: Сообщение достижения критического значения параметром 7
- P8 'tongue' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 8: <>
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Cola' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter No9: <>
    критическое: Сообщение достижения критического значения параметром 9
- P10 'diamonds' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter No10: <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Did you scoff a cactus?' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter No11: <>
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Dialogue' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter No12: <>
    критическое: Сообщение достижения критического значения параметром 12

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You hardly killed your ship's engines when a rather presentable aerocar with the <clr> "Brigee Bardozze's xenopark "<clrEnd> sticker on its side drove to the sh…
    эффект: P6(tequila) = {0} [скрыт]
    эффект: P7(tail) = {0} [скрыт]
    эффект: P8(tongue) = {0} [скрыт]
    скрыт: P1,P2,P3,P4,P5,P9,P10,P11,P12
  -> Path201 => Loc4  вер=1 порядок=6
       текст: Read the books if you have some spare time...
       эффект: P12(Dialogue) = {1}
  -> Path202 => Loc4  вер=1 порядок=5
       текст: Just look in the window...
       эффект: P12(Dialogue) = {2}

### Loc4 [обычная]
    выбор описания: {[p12]}
    Loc4-1: You leafed the books the chief feeder's assistant had given to you. "Food for xenomorphs..." turned out to be something like a manual for alien animal feeding, …
    Loc4-2: You spent the rest of the flight gazing into the window though the speed was so high that you failed to see anything - <ToPlanet>'s landscapes were only a colou…
  -> Path6 => Loc5  вер=1 порядок=9
       текст: Are you mocking? I'm flying away...
  -> Path7 => Loc6  вер=1 проходов<=1 порядок=4
       текст: I know what I'm doing - bring me to the animals...
       ответ: The care-taker gleefully smiled at your words, clasped your hand with his four and opened the door. His cunning Peleng smile didn't match his rather bright gree…
  -> Path76 => Loc6  вер=1 порядок=5
       текст: It's alright - we'll figure it out on the spot (may be, books will help)
       ответ: The caretaker grew pale immediately and leaned against the wall catching his breath. He didn't say anything and just opened the door. /  / And you...you were ea…

### Loc5 [ПРОВАЛ]
    Loc5-1: You forced the books into the clerk's hands and strode to the aerocar murmuring: /  / No way! It's not just feeding these beasts but playing that damn "Nick the…

### Loc6 [обычная]
    Loc6-1: You entered a big room. There are five cages with all kinds of beasts to your left. And seven tubs with some hockey, which probably was the food for the xenomor…
    эффект: P1(Xenomorph 1) = {} [показ]
    эффект: P2(Xenomorph 2) = {} [показ]
    эффект: P3(Xenomorph 3) = {} [показ]
    эффект: P4(Xenomorph 4) = {} [показ]
    эффект: P5(Xenomorph 5) = {} [показ]
    эффект: P12(Dialogue) = {1}
  -> Path8 => Loc7  вер=1 порядок=2
       текст: Come to Cage №1 "Big habbath. Planet Taboth "
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path9 => Loc8  вер=1 порядок=3
       текст: Come to Cage №2 "Swamp phatklink. Planet Chvack "
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path10 => Loc9  вер=1 порядок=4
       текст: Come to Cage №3 "Klissan proto-shpock. The Klissans"
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path11 => Loc10  вер=1 порядок=5
       текст: Come to Cage №4 "Graceful Aishout. Planet Faeyaton "
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path12 => Loc11  вер=1 порядок=6
       текст: Come to Cage №5 "Sand Ship. Planet Mars "
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path13 => Loc12  вер=1 порядок=8
       текст: May be, the books can help you...
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path15 => Loc14  вер=1 порядок=7
       текст: Study the tubs with the food for the xenomorphs
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]<10}
  -> Path92 => Loc47  вер=1 проходов<=1
       текст: All the animals are filled! Call the caretaker
       условия: логика {[p1]+[p2]+[p3]+[p4]+[p5]=10}

### Loc7 [обычная]
    Loc7-1: You're standing at Cage №1 with the tablet <clr>"Big habbath. Planet Taboth "<clrEnd> on it.
  -> Path22 => Loc15  вер=1 порядок=7
       текст: Read " Food for xenomorphs from our Galaxy ". May be, it will give you a hint
  -> Path27 => Loc13  вер=1 порядок=6
       текст: Read " Behaviour and brief description of xenomorphs ". May be, the descriptions will help you
       эффект: P12(Dialogue) = {1}
  -> Path32 => Loc6  вер=1 порядок=9
       текст: Go away from the cage...
  -> Path37 => Loc16  вер=1 порядок=4
       текст: Try to feed the animal...
       условия: логика {[p1]<2}
       эффект: P12(Dialogue) = {1}
  -> Path47 => Loc21  вер=1 порядок=5
       текст: Examine the xenomorph

### Loc8 [обычная]
    Loc8-1: You're standing at Cage №2 with the tablet <clr>"Swamp phatklink. Planet Chvack "<clrEnd> on it.
  -> Path23 => Loc15  вер=1 порядок=7
       текст: Read " Food for xenomorphs from our Galaxy ". May be, it will give you a hint
  -> Path28 => Loc13  вер=1 порядок=6
       текст: Read " Behaviour and brief description of xenomorphs ". May be, the descriptions will help you
       эффект: P12(Dialogue) = {1}
  -> Path33 => Loc6  вер=1 порядок=9
       текст: Go away from the cage
  -> Path38 => Loc17  вер=1 порядок=4
       текст: Feed the animal...
       условия: логика {[p2]<2}
       эффект: P12(Dialogue) = {1}
  -> Path48 => Loc22  вер=1 порядок=5
       текст: Examine the xenomorph

### Loc9 [обычная]
    Loc9-1: You're standing at Cage №3 with the tablet <clr>"Klissan proto-shpock. The Klissans"<clrEnd> on it.
  -> Path24 => Loc15  вер=1 порядок=7
       текст: Read " Food for xenomorphs from our Galaxy ". May be, it will give you a hint
  -> Path29 => Loc13  вер=1 порядок=6
       текст: Read " Behaviour and brief description of xenomorphs ". May be, the descriptions will help you
       эффект: P12(Dialogue) = {1}
  -> Path34 => Loc6  вер=1 порядок=9
       текст: Go away from the cage
  -> Path39 => Loc18  вер=1 порядок=4
       текст: Feed the animal...
       условия: логика {[p3]<2}
       эффект: P12(Dialogue) = {1}
  -> Path49 => Loc23  вер=1 порядок=5
       текст: Examine the xenomorph
       ответ: Thick pseudoclouds were wreathing in the bright blue light of the sun-imitator. It was strange but the beast in the cage felt comfortless there - it quivered ch…
       условия: логика {[p8]<1}
  -> Path114 => Loc23  вер=1 порядок=5
       текст: Visit the ranger-scoffing loser...
       ответ: As soon as you came to the cage, its inhabitant lazily crawled out from the shade and stared at you. For a couple of minutes you were playing glimmers and the b…
       условия: логика {[p8]>0}

### Loc10 [обычная]
    Loc10-1: You're standing at the cage with the superscription <clr>"Graceful Aishaut. Planet Faeyaton "<clrEnd> on it.
  -> Path25 => Loc15  вер=1 порядок=7
       текст: Read " Food for xenomorphs from our Galaxy ". May be, it will give you a hint
  -> Path30 => Loc13  вер=1 порядок=6
       текст: Read " Behaviour and brief description of xenomorphs ". May be, the descriptions will help you
       эффект: P12(Dialogue) = {1}
  -> Path35 => Loc6  вер=1 порядок=9
       текст: Go away from the cage
  -> Path40 => Loc19  вер=1 порядок=4
       текст: Feed the animal...
       условия: логика {[p4]<2}
       эффект: P12(Dialogue) = {1}
  -> Path50 => Loc24  вер=1 порядок=5
       текст: Examine the xenomorph

### Loc11 [обычная]
    Loc11-1: You're standing at Cage №5 with the tablet <clr>"Sandy ship. Planet Mars "<clrEnd> on it.
  -> Path26 => Loc15  вер=1 порядок=7
       текст: Read " Food for xenomorphs from our Galaxy ". May be, it will give you a hint
  -> Path31 => Loc13  вер=1 порядок=6
       текст: Read " Behaviour and brief description of xenomorphs ". May be, the descriptions will help you
       эффект: P12(Dialogue) = {1}
  -> Path36 => Loc6  вер=1 порядок=9
       текст: Go away from the cage
  -> Path41 => Loc20  вер=1 порядок=4
       текст: Feed the animal...
       условия: логика {[p5]<2}
       эффект: P12(Dialogue) = {1}
  -> Path51 => Loc25  вер=1 порядок=5
       текст: Examine the xenomorph
       ответ: The xenomorph in the last cage turned out to look nicer than the other ones. Its long runty body with six short and bandy paws was covered with cloudy scale. Th…
       условия: логика {[p7]<1}
  -> Path113 => Loc25  вер=1 порядок=5
       текст: Check the animal that became crippled ...much thanks to your unsleeping care
       ответ: Hoo!!! It didn't waste its time on trifles. At least one third of the tail grew up again. This animal can feed so many starving Chinese... What if we cut off so…
       условия: логика {[p7]>0}

### Loc12 [обычная]
    Loc12-1: So, what book do you want to hive wisdom from?
  -> Path14 => Loc13  вер=2 порядок=4
       текст: Read "Behaviour and brief description of xenomorphs "
       эффект: P12(Dialogue) = {1}
  -> Path17 => Loc6  вер=1 порядок=9
       текст: Stick to business...
  -> Path18 => Loc15  вер=1 порядок=7
       текст: Read "Food for xenomorphs from our Galaxy"

### Loc13 [обычная]
    выбор описания: {[p12]}
    Loc13-1: You opened the book <clr>"Behaviour and brief description of xenomorphs "<clrEnd>. / There are five different chapters, each containing the description of one a…
    Loc13-2: My detachment was proud of the fact that it was its members who came across the most dangerous predator whose ferocious violence and unusual strength could be t…
    Loc13-3: Swamp phatklink is the most rare type of phatklinks and the most interesting one for historians and pelengists because there is every reason to believe that it …
    Loc13-4: It all started as usual - ranger Anton, Schulman and me surrounded that Klissan and struck simultaneously. And, cut him up to the state of [censored]. And sudde…
    Loc13-5: In the context of speculative theosophistry, Aishout is identified with a singular reservoir of coapsular bioenergetics, and this fact proves it's harmonious co…
    Loc13-6: A special necessity brought us to this red planet: these dirty looters, stinky custom rats from Venus somehow considered our excellent heroino-marihuanic cigars…
  -> Path20 => Loc6  вер=1 порядок=8
       текст: Stop reading - it's time to work
       эффект: P12(Dialogue) = {1}
  -> Path98 => Loc48  вер=1 порядок=4
       текст: Klissan proto-shpock. Alexander, ranger (3003)
       эффект: P12(Dialogue) = {4}
  -> Path99 => Loc48  вер=1 порядок=6
       текст: Swamp phatklink. Author: Klyakush Chapazzvack, archaeologist
       эффект: P12(Dialogue) = {3}
  -> Path100 => Loc48  вер=1 порядок=1
       текст: Graceful aishout. Author: Pestupohn Yer, a Gaalian ihike-bahanists
       эффект: P12(Dialogue) = {5}
  -> Path101 => Loc48  вер=1 порядок=5
       текст: Big habbath. Author: Garrakh the Strong, captain of the "Muscled Leg" detachment
       эффект: P12(Dialogue) = {2}
  -> Path102 => Loc48  вер=1 порядок=2
       текст: Sand ship. Author: Eitzkhala Snipe-It, an honest trader
       эффект: P12(Dialogue) = {6}

### Loc14 [обычная]
    Loc14-1: You approached the right wall with seven huge tubs at it, which are tightly topped. There are tablets with names on them. The local care-keeper assured you that…
  -> Path21 => Loc6  вер=1 порядок=9
       текст: Finish your look-over...
  -> Path61 => Loc36  вер=1 порядок=2
       текст: Look what "Vazze criambusine" from Tub 1 is
       эффект: P12(Dialogue) = {1}
  -> Path83 => Loc37  вер=1 порядок=2
       текст: Examine this "QUACK-TOSE rind-blooming" thing
       эффект: P12(Dialogue) = {1}
  -> Path107 => Loc49  вер=1 порядок=4
       текст: Look what the "Khahapt globules" are
       эффект: P12(Dialogue) = {1}
  -> Path115 => Loc51  вер=1 порядок=5
       текст: Study "Granulated sparklings"
       эффект: P12(Dialogue) = {1}
  -> Path125 => Loc55  вер=1 порядок=6
       текст: Examine "Glandulous Noohoo-Dle"
       эффект: P12(Dialogue) = {1}
  -> Path131 => Loc57  вер=1 порядок=7
       текст: Look at the elementary photons
       эффект: P12(Dialogue) = {1}
  -> Path133 => Loc60  вер=1 порядок=8
       текст: Examine the content of the tub with the tablet "hydrocarbon tincture"
       эффект: P12(Dialogue) = {1}

### Loc15 [обычная]
    Loc15-1: You opened the book <clr>"Food for xenomorphs of our Galaxy"<clrEnd>, rather, it was not a book but a number of separate files containing the following informat…
  -> Path19 => Loc6  вер=1 порядок=7
       текст: Put the book aside...
       эффект: P12(Dialogue) = {1}

### Loc16 [обычная]
    выбор описания: {[p12]}
    Loc16-1: Before the beasts got off the hooks starving, you should hurry up and decide what feed will go where. The hell of the thing is that you can't make mistakes. You…
    Loc16-2: You took a bunch of Noohoo-Dle and put it in the manger. The animal <clr>ignored <clrEnd> your true attempts to save its life.
    Loc16-3: The animal tremulously flicked out its mug to the drinking bowl and started lapping it. You were about to sigh with relief but suddenly it started desperately h…
    Loc16-4: You took a handful of sparkling small crystals and emptied it into the manger. You could as well have made a striptease show - <clr>no heed<clrEnd> to either yo…
    Loc16-5: You threw the lid open and dipped up some of the criambusine with a trowel. Then you carefully approached the cage, tipped the half-liquid mass into the manger,…
    Loc16-6: You tipped a handful of globules from Tub 3 and handed it to the beast. The animal nosed the feed lazily and <clr>and indifferently turned away <clrEnd>. Failur…
  -> Path42 => Loc7  вер=1 порядок=8
       текст: No, you better drag your heels and think it over properly
  -> Path57 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Feed it with the Vazze criambusine from Tub 1
       эффект: P12(Dialogue) = {5}
  -> Path94 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Try to feed the animal with the Khahapt globules
       эффект: P12(Dialogue) = {6}
  -> Path95 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Give a couple of quack-tose sprigs to the beast
       ответ: You took several more grips of that plant choosing the thorniest ones and handed them to the animal. It looked at you with some suspicion, then took one grip wi…
       эффект: P1(Xenomorph 1) = {2}
  -> Path97 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Pour in the granulated sparklings to him
       эффект: P12(Dialogue) = {4}
  -> Path104 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Feed it with the hydrocarbon tincture
       эффект: P1(Xenomorph 1) = {-1}
       эффект: P12(Dialogue) = {3}
  -> Path105 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Let the xenomorph have some Noohoo-Dle
       эффект: P12(Dialogue) = {2}
  -> Path106 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Feed it with some elementary photons
       ответ: It took you a lot of effort to pick a piece from the photon pile. You thrust it into the beast's mug. The animal skewed at you, then timidly licked the piece on…
       эффект: P1(Xenomorph 1) = {-2} «- Oh, dear!!! - you shouted. / - Oh, dear, - an unknown Pele…»
       эффект: P12(Dialogue) = {2}

### Loc17 [обычная]
    выбор описания: {[p12]}
    Loc17-1: Before the beasts got off the hooks starving, you should hurry up and decide what feed will go where. The hell of the thing is that you can't make mistakes. You…
    Loc17-2: You put a prickly sprig near the creature. It bent its head over the "rind-blooming" and stood motionless. Than the wide paws started raking out the soil under …
    Loc17-3: You threw several globules at the animal that caught them speedily. It chewed up the farinose feed and even got a little bit lighter. <clr>There appeared some c…
    Loc17-4: You poured some of that bubbled liquid into a bowl and put it near the beast. It bent over the bowl <clr>showing some interest<clrEnd> and stared expectantly at…
    Loc17-5: You threw several globules at the animal that caught them speedily. It chewed up the farinose feed and even got a little bit lighter. There appeared some conten…
    Loc17-6: The creature in the cage <clr>ignored<clrEnd> the long stems or what-ever-it-was.
    Loc17-7: You took a sparkling and threw it to the monster. Its thin neck curved and the animal adroitly caught the sparkling with its chaps. But some time after it spat …
    Loc17-8: It took you much effort to pick out a piece of "photons", which you threw into the cage. The animal flustered as if you had thrown a burning sprig there - it pu…
  -> Path43 => Loc8  вер=1 порядок=8
       текст: No, you better drag your heels and think it over properly
  -> Path151 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Feed it with the vazze criambusine
       ответ: You plunked a couple of handfuls near the creature. It slightly bent over the pile, then stuck its pulpi down into it and glued to the spot. You remained motion…
       эффект: P2(Xenomorph 2) = {-2} «The faces of the care-takers who came at alarm betokened no …»
  -> Path152 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Feed it with the granulated sparklings
       эффект: P2(Xenomorph 2) = {-1}
       эффект: P12(Dialogue) = {7}
  -> Path153 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Pour in some Noohoo-Dle
       эффект: P12(Dialogue) = {6}
  -> Path154 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Give Khahapt globules
       условия: логика {[p2]<0 and [p9]=0}
       эффект: P2(Xenomorph 2) = {1}
       эффект: P12(Dialogue) = {5}
  -> Path155 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Treat the beast with the elementary photons
       эффект: P12(Dialogue) = {8}
  -> Path156 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Pour in some of the hydrocarbon tincture
       условия: логика {[p2]<1}
       эффект: P9(Cola) = {1}
       эффект: P12(Dialogue) = {4}
  -> Path157 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Give Khahapt globules
       условия: логика {[p2]=0 and [p9]=0}
       эффект: P2(Xenomorph 2) = {1}
       эффект: P12(Dialogue) = {3}
  -> Path158 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Give Khahapt globules
       ответ: You threw several globules at the animal that caught them speedily. It chewed up the farinose feed crisping and even became a little bit lighter. There appeared…
       условия: логика {[p2]=0 and [p9]>0}
       эффект: P2(Xenomorph 2) = {2}
  -> Path159 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Give Khahapt globules
       ответ: You threw several globules at the animal that caught them speedily. It chewed up the farinose feed crisping and even became a little bit lighter. There appeared…
       условия: логика {[p2]<0 and [p9]>0}
       эффект: P2(Xenomorph 2) = {2}
  -> Path160 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Break off a sprig of quack-tose
       эффект: P11(Did you scoff a cactus?) = {1}
       эффект: P12(Dialogue) = {2}
  -> Path169 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Pour in some hydrocarbons
       ответ: The creature crawled up to the bowl with the "tincture" - you could hear distinct rash of its either roots, or pulpi - and gladly deepened its wide paws, or, as…
       условия: логика {[p2]>0}
       эффект: P2(Xenomorph 2) = {2}

### Loc18 [обычная]
    выбор описания: {[p12]}
    Loc18-1: Before the beasts got off the hooks starving, you should hurry up and decide what feed will go where. The hell of the thing is that you can't make mistakes. You…
    Loc18-2: You put some globules into the manger. The creature reached a couple of them with its tongue but <clr>spat them out<clrEnd> immediately.
    Loc18-3: You put some globules into the manger. The creature reached a couple of them with its tongue but <clr>spat them out<clrEnd> immediately. Well, at least it didn'…
    Loc18-4: Glittering granular sparklings impressed the creature <clr>only from the esthetical point of view <clrEnd>.
    Loc18-5: You threw the stem (or whatever it was) of Noohoo-Dle in front of the animal. It <clr>nosed it lazily and crawled aside <clrEnd>.
    Loc18-6: It looks like the poor animal <clr>is completely sick <clrEnd> after your treatment. Well, it didn't look much better before the feeding either.
  -> Path44 => Loc9  вер=1 порядок=8
       текст: No, you better drag your heels and think it over properly
  -> Path161 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Give some quack-tose sprigs to the beast
       ответ: You emptied about a dozen of thorny sprigs in front of the hungry beast. It stuck out its tongue and started palpating the feed. It shouldn't have done it. The …
       эффект: P3(Xenomorph 3) = {[p3]-1} «If the poor animal felt unwell before the accident, now it w…»
       эффект: P12(Dialogue) = {6}
  -> Path162 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Plunk a bit of criambusine for it
       ответ: You put the criambusine in the manger and stepped aside. The beast crawled out of the shade and approached the manger. Its long tongue palpated the feed; the cr…
       эффект: P3(Xenomorph 3) = {2}
  -> Path163 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Feed the beast with the Noohoo-Dle
       эффект: P12(Dialogue) = {5}
  -> Path164 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Pour in some sparklings
       эффект: P12(Dialogue) = {4}
  -> Path165 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Pour some hydrocarbon tincture
       ответ: The creature accepted the bubbling of the dark-brown liquid with joy and started lapping it with its long tongue. But in a couple of minutes it crawled aside. I…
       эффект: P3(Xenomorph 3) = {[p3]-1} «Damn it, it was the last straw and the sick animal looked mu…»
       эффект: P12(Dialogue) = {6}
  -> Path166 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Treat the ranger-eater with the Khahapt globules
       условия: логика {[p8]>0}
       эффект: P12(Dialogue) = {2}
  -> Path167 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Treat it with the Khahapt globules
       условия: логика {[p8]=0}
       эффект: P12(Dialogue) = {3}
  -> Path168 => Loc62  вер=1 проходов<=1 порядок=5
       текст: Threw the elementary photons at it
       ответ: A piece of the elementary photons fell with a spat near the creature. Well, the photons were not as elementary as they promised - as soon as the creature touche…
       эффект: P3(Xenomorph 3) = {-2} «You decided to belt off from the xenopark out of harm's way …»

### Loc19 [обычная]
    выбор описания: {[p12]}
    Loc19-1: Before the beasts got off the hooks starving, you should hurry up and decide what feed will go where. The hell of the thing is that you can't make mistakes. You…
    Loc19-2: You will never understand these creatures - you hardly held your hand out when the animal rolled to you and grasped the Noohoo-Dle with its either trunk, or pal…
    Loc19-3: You hardly went away from the cage when the creature rolled up to the scattering of sparklings and scrambled it up in a pile with its either trunk, or palpus th…
    Loc19-4: You are good at throwing and the creature is a good sleeper and <clr>is completely ignoring <clrEnd> the crisp globules. Your attempt to feed it failed.
    Loc19-5: The animal <clr>paid no attention <clrEnd> to the whole bunch of appetising thorny branches.
    Loc19-6: It took you a lot of effort to pick out a piece, which the creature just <clr>ignored<clrEnd> as if it had been elementary photons... What a pity!
    Loc19-7: The only thing you managed to do was <clr>dirtying the beast's light-blue skin <clrEnd>.
  -> Path45 => Loc10  вер=1 порядок=9
       текст: No, you better drag your heels and think it over properly
  -> Path170 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Pour in some granulated sparklings
       условия: логика {[p4]<1}
       эффект: P10(diamonds) = {1}
       эффект: P12(Dialogue) = {3}
  -> Path171 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Pour in some granulated sparklings
       ответ: You hardly went away from the cage when the creature rolled up to the scattering of sparklings and scrambled it up in a pile with its either trunk, or palpus th…
       условия: логика {[p4]>0}
       эффект: P4(Xenomorph 4) = {2}
  -> Path172 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Feed it with the quack-tose.
       эффект: P12(Dialogue) = {5}
  -> Path173 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Share a piece of photons with the xenomorph
       эффект: P12(Dialogue) = {6}
  -> Path175 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Thrust a bunch of Noohoo-Dle to the xenomorph
       условия: логика {[p10]<1}
       эффект: P4(Xenomorph 4) = {1}
       эффект: P12(Dialogue) = {2}
  -> Path176 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Thrust a bunch of Noohoo-Dle to the xenomorph
       ответ: You will never understand these creatures - you hardly stretched out your hand when the animal rolled up to you and grabbed the Noohoo-Dle with its either trunk…
       условия: логика {[p10]>0}
       эффект: P4(Xenomorph 4) = {2}
  -> Path177 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Throw several Khahapt globules to the beast
       эффект: P12(Dialogue) = {4}
  -> Path178 => Loc63  вер=1 проходов<=1 порядок=5
       текст: Treat the animal with the criambusine
       эффект: P12(Dialogue) = {7}
  -> Path179 => Loc65  вер=1 проходов<=1 порядок=5
       текст: Pour some hydrocarbon tincture

### Loc20 [обычная]
    выбор описания: {[p12]}
    Loc20-1: Before the beasts got off the hooks starving, you should hurry up and decide what feed will go where. The hell of the thing is that you can't make mistakes. You…
    Loc20-2: You were prickling and crying but the animal was stubborn and refused to scoff that thorny plant. But you only needed to go away from the cage and the animal sl…
    Loc20-3: All for nothing - the animal <clr>didn't even pay any attention <clrEnd> to the feeding.
    Loc20-4: The animal <clr>glanced indifferently<clrEnd> at the pile of crystals. Failure.
    Loc20-5: You hardly put the criambusine on the floor when the six-legged beast ran up to the feeding pile left by you and sent the sticky mass flying at one of the lamps…
  -> Path46 => Loc11  вер=1 порядок=8
       текст: No, you better drag your heels and think it over properly
  -> Path188 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Feed the animal with the criambusine
       эффект: P5(Xenomorph 5) = {1}
       эффект: P12(Dialogue) = {5}
  -> Path189 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Feed the xenomorph with the hydrocarbon tincture
       ответ: The beast approached the drinking-bowl and started greedily lapping the liquid with its forked tongue. Suddenly it quivered and... <clr>gave, turning into a pil…
       эффект: P5(Xenomorph 5) = {-2} «You hardly left the room trying to escape when the caretaker…»
       эффект: P12(Dialogue) = 6
  -> Path190 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Pour in the Khahamp globules into the manger
       ответ: The beast approached the manger and took several globules. Suddenly it quivered and... <clr>gave, turning into a pile of brown stinking slime <clrEnd>.
       эффект: P5(Xenomorph 5) = {-2} «You hardly left the room trying to escape when the caretaker…»
  -> Path191 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Treat the pangolin with the Noohoo-Dle
       эффект: P12(Dialogue) = {3}
  -> Path192 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Feed the xenomorph with the sparklings
       эффект: P12(Dialogue) = {4}
  -> Path193 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Put some sprigs of the Quack-Tose into the cage
       эффект: P5(Xenomorph 5) = {-1}
       эффект: P12(Dialogue) = {2}
  -> Path194 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Pick off a piece of food with high content of photons
       ответ: The disgusting clot of the substance hardly reached the floor when the beast darted to it and scoffed in one swallow. Its appearance changed immediately - slime…
       эффект: P5(Xenomorph 5) = {2}

### Loc21 [обычная]
    Loc21-1: You came closer to the cage and started watching the creature in it.  /  / What you saw was huge - at least, it was the biggest animal you had met there. About …
  -> Path52 => Loc7  вер=1 порядок=5
       текст: We are proud too. Turn away with your head high

### Loc22 [обычная]
    Loc22-1: A strange purple creature was sitting in the dreadful shade of the cage. Its big head on an extremely long and thin neck, which ran into the body almost with no…
  -> Path53 => Loc8  вер=1 порядок=5
       текст: Stop staring - it's time to work

### Loc23 [пустая]
    эффект: P8(tongue) = {1}
  -> Path54 => Loc9  вер=1 порядок=5
       текст: To hell with the beast - it's evil
  -> Path197 => Loc69  вер=1 порядок=5
       текст: Look about once again
       ответ: Thick pseudoclouds were wreathing in the bright blue light of the sun-imitator. It was strange but the beast in the cage felt comfortless there - it quivered ch…
       условия: логика {[p8]>0}

### Loc24 [обычная]
    Loc24-1: You came closer to the cage. There was a strange, completely motionless creature in it. It looked very much like a granite blue mass, half of you in height. Lar…
  -> Path55 => Loc10  вер=1 порядок=5
       текст: What a bore! It's time to work

### Loc25 [пустая]
    эффект: P7(tail) = {1}
  -> Path56 => Loc11  вер=1 порядок=5
       текст: Live the poor animal alone
  -> Path199 => Loc70  вер=1 порядок=5
       текст: Examine the cage inhabitant once again
       ответ: The xenomorph in the last cage turned out to look nicer than the other ones. Its long runty body with six short and bandy paws was covered by cloudy scale. The …
       условия: логика {[p7]>0}

### Loc26 [пустая]
  -> Path93 => Loc7  вер=1 порядок=5
       условия: P1(Xenomorph 1) 2..2
  -> Path146 => Loc16  вер=1 порядок=5
       условия: логика {[p1]<2}

### Loc34 [пустая]
  -> Path68 => Loc36  вер=1 порядок=5

### Loc35 [ПРОВАЛ]
    Loc35-1: You shut your eyes tight, dipped up a handful of criambusine and shoved it into your mouth. You tried to chew it but your teeth agglutinated and sand crisped on…

### Loc36 [обычная]
    выбор описания: {[p12]}
    Loc36-1: There is the following superscription on Tub №1:  / <clr>VAZZE CRIAMBUSINE <clrEnd> /  / This criambusine looks very unappetising. Actually... like excrements. …
    Loc36-2: You recollected your courage and licked your finger. Then you tried to chew that mass but when you felt sand on your teeth, you decided to better swallow it. It…
    Loc36-3: You slightly licked your fingertip feeling insecure. A slightly warm mass tasted like... paraffin? Samaldock niuphtiuline? It was not enough to figure out. Howe…
  -> Path62 => Loc14  вер=1 порядок=5
       текст: Back there...
  -> Path67 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Lick the fingertip with the stuck "criambusine" slightly
       эффект: P12(Dialogue) = {3}
  -> Path69 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Lick the messy finger
       эффект: P12(Dialogue) = {2}
  -> Path71 => Loc35  вер=1 порядок=5
       текст: Eat a handful of "criambusine"

### Loc37 [обычная]
    выбор описания: {[p12]}
    Loc37-1: There is the following superscription on Tub №2: / <clr>Quack-Tose Rind-blooming<clrEnd> /  / These Quacks are obviously plants and look very much like mercipan…
    Loc37-2: You took a small sprig without thorns on it and chewed it. Memories rushed upon you. Of course! You knew that taste very well! Now you knew for sure how the pla…
    Loc37-3: You broke off a small sprig and licked it... / Dear me!!! What a pain! A sharp long thorn stuck in your tongue, which immediately got puffed. /  / When the pain…
  -> Path84 => Loc14  вер=1 порядок=5
       текст: Back there.
  -> Path85 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Try that sprig...the thornless one
       эффект: P12(Dialogue) = {2}
  -> Path87 => Loc46  вер=1 порядок=5
       текст: Have some more
       условия: логика {[p6]<1}
  -> Path89 => Loc45  вер=1 проходов<=1 порядок=5
       текст: Treat yourself with that prodigy of nature
       условия: логика {[p6]>0}
  -> Path90 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Lick a small sprig...
       эффект: P12(Dialogue) = {3}

### Loc43 [пустая]
  -> Path91 => Loc37  вер=1 порядок=5

### Loc45 [ПРОВАЛ]
    Loc45-1: Feeling happy after you chanced upon such a nice attribute of that plant, you lit into it playing a good knife and fork. In the beginning of the process you too…

### Loc46 [обычная]
    Loc46-1: You grabbed several sprigs of the plant, carefully unthorned them and took a dollop. Thick slightly sour and acerb juice flushed into your mouth. /   / Damn it!…
  -> Path88 => Loc45  вер=1 порядок=5
       текст: Go on...

### Loc47 [обычная] визитов<=1
    Loc47-1: You pushed the emergency button and the care-taker together with an unknown Peleng in the expensive suit immediately entered the room. /  / - Let me introduce t…
  -> Path180 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Go to the aerocar
       эффект: P12(Dialogue) = {1}

### Loc48 [пустая]
  -> Path103 => Loc13  вер=1 порядок=5

### Loc49 [обычная]
    выбор описания: {[p12]}
    Loc49-1: There was a tablet with the superscription <clr> "Khahapt globules"<clrEnd> on Tub № 3. /  / There turned out to be a back full of globules under the lid. Thoug…
    Loc49-2: You ate a bellyful of the globules that turned out to be your favourite Pop-feed. Full stomach makes the brains work better - see what the food with high conten…
    Loc49-3: You took one globule and licked it carefully. It felt like its luscious taste brought you back to your calf-time but you failed to figure out what memories were…
    Loc49-4: You took several globules and put them on your tongue. Then you chewed them with a slight crisp and laughed: good for the Gaalians! Who in the entire Galaxy wou…
  -> Path108 => Loc14  вер=1 порядок=9
       текст: Back there...
  -> Path109 => Loc50  вер=1 проходов<=1 порядок=4
       текст: Lick a globule...
       эффект: P12(Dialogue) = {3}
  -> Path111 => Loc50  вер=1 проходов<=1 порядок=5
       текст: Eat a couple of globules
       эффект: P12(Dialogue) = {4}
  -> Path112 => Loc50  вер=1 проходов<=1 порядок=6
       текст: Make a meal of the globules...
       эффект: P12(Dialogue) = {2}

### Loc50 [пустая]
  -> Path110 => Loc49  вер=1 порядок=5

### Loc51 [обычная]
    выбор описания: {[p12]}
    Loc51-1: The tablet on Tub №4 said: / <clr>Granulated sparklings <clrEnd> /  / There turned out to be a lot of limpid small crystals. They were really sparkling in the l…
    Loc51-2: You took a small crystal and threw it into your mouth. /  / There - and doctor Svaikoff guaranteed that this filling would stay forever. Though he didn't cram  …
    Loc51-3: You took a crystal carefully and licked it. Neither taste, not smell, just your cut tongue...
  -> Path116 => Loc14  вер=1 порядок=9
       текст: Back there...
  -> Path117 => Loc52  вер=1 проходов<=1 порядок=6
       текст: Eat a handful of sparklings
  -> Path118 => Loc53  вер=1 проходов<=1 порядок=4
       текст: Lick one of the crystals
       эффект: P12(Dialogue) = {3}
  -> Path119 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Eat one sparkling
       эффект: P12(Dialogue) = {2}

### Loc52 [СМЕРТЬ] визитов<=1
    Loc52-1: You grabbed a handful of sparklings and threw them in your mouth. The diamond-hard feed cost several broken teeth already but suddenly the door admitting to the…

### Loc53 [пустая]
  -> Path120 => Loc51  вер=1 порядок=5

### Loc54 [пустая]
  -> Path142 => Loc8  вер=1 порядок=5
       условия: P2(Xenomorph 2) 2..2
  -> Path147 => Loc17  вер=1 порядок=5
       условия: логика {[p2]<2}

### Loc55 [обычная]
    выбор описания: {[p12]}
    Loc55-1: <clr>"Glandulous Noohoo-Dle"<clrEnd> was on Tub №5. /  / In that tub there were a lot of long thin rods looking like cords of different colours. Their surface o…
    Loc55-2: You took the smoothest and brightest sprig (or whatever it was) and carefully licked it. The silken rind insoluble in your saliva savoured of either plastic, or…
    Loc55-3: You put a couple of rods in the mouth and chewed. At last, when you managed to tear the rind with your teeth, they grated on the pith. It was soft but strong, t…
    Loc55-4: The first attempt was enough to realise that you better stay your hand - the pleasure seemed to be very doubtful.
  -> Path121 => Loc56  вер=1 проходов<=1 порядок=4
       текст: Lick a sprig
       эффект: P12(Dialogue) = {2}
  -> Path122 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Eat a tiny bit
       эффект: P12(Dialogue) = {3}
  -> Path123 => Loc56  вер=1 проходов<=1 порядок=6
       текст: Eat two scores
       эффект: P12(Dialogue) = {4}
  -> Path126 => Loc14  вер=1 порядок=9
       текст: Finish your look-over...

### Loc56 [пустая]
  -> Path124 => Loc55  вер=1 порядок=5

### Loc57 [обычная]
    выбор описания: {[p12]}
    Loc57-1: There are <clr>"Elementary Photons"<clrEnd> in Tub 6. /  / It is a huge piece of... a substance that stinks a lot. May be, it "has a high content of photons" as…
    Loc57-2: You bent carefully over the tub and licked the mass. Suddenly it moved and started producing such fetidity that tears appeared in your eyes. But in a couple of …
  -> Path127 => Loc59  вер=1 проходов<=1 порядок=4
       текст: Lick the photons
       эффект: P12(Dialogue) = {2}
  -> Path128 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Try a tiny bit...
  -> Path129 => Loc58  вер=1 проходов<=1 порядок=6
       текст: Scoff a piece of the photons
  -> Path132 => Loc14  вер=1 порядок=9
       текст: Back there.

### Loc58 [СМЕРТЬ]
    Loc58-1: You picked a small piece of elementary photons and put it in the mouth... /  / The ranger's death was instantaneous and painless.

### Loc59 [пустая] визитов<=1
  -> Path130 => Loc57  вер=1 проходов<=1 порядок=5

### Loc60 [обычная]
    выбор описания: {[p12]}
    Loc60-1: You threw open the lid of the last tub with <clr>Hydrocarbon tincture <clrEnd>.  /  / There turned out to be a bubbly dark-brown liquid with nice smell. A lot o…
    Loc60-2: You dipped up some of the liquid and drank it. Nice tickling of the bubbles made you cough but you realised that it was no hydrocarbon tincture at all but ordin…
    Loc60-3: You wet your finger with the liquid and dripped a couple of drops on your tongue. It fizzed up a little, but didn't burn the tongue, just tickled it. What a fam…
  -> Path134 => Loc14  вер=1 порядок=9
       текст: Back there...
  -> Path136 => Loc61  вер=1 проходов<=1 порядок=5
       текст: Drip some on the tongue
       эффект: P12(Dialogue) = {3}
  -> Path137 => Loc61  вер=1 проходов<=1 порядок=6
       текст: Drink some tincture
       эффект: P12(Dialogue) = {2}

### Loc61 [пустая]
  -> Path135 => Loc60  вер=1 порядок=5

### Loc62 [пустая]
  -> Path145 => Loc9  вер=1 порядок=5
       условия: P3(Xenomorph 3) 2..2
  -> Path148 => Loc18  вер=1 порядок=5
       условия: логика {[p3]<2}

### Loc63 [пустая]
  -> Path144 => Loc10  вер=1 порядок=5
       условия: P4(Xenomorph 4) 2..2
  -> Path149 => Loc19  вер=1 порядок=5
       условия: логика {[p4]<2}

### Loc64 [пустая]
  -> Path143 => Loc11  вер=1 порядок=5
       условия: P5(Xenomorph 5) 2..2
  -> Path150 => Loc20  вер=1 порядок=5
       условия: логика {[p5]<2}

### Loc65 [СМЕРТЬ] визитов<=1
    Loc65-1: The creature was ignoring the bubbly drink for some time, then it grew bolder and sucked it up with its trunk.. The result was instantaneous  - the xenomorph st…
    эффект: P4(Xenomorph 4) = {-2} «Maloq stared at the handful of blue dust that had been wheez…»

### Loc66 [пустая]
  -> Path195 => Loc68  вер=1 порядок=5

### Loc67 [УСПЕХ] визитов<=1
    Loc67-1: Soon the bender of xenopark disappeared beyond the horizon and the spaceport appeared ahead of you. Only then you awoke to the fact that all nightmares were ove…

### Loc68 [обычная] визитов<=7
    выбор описания: {[p12]}
    Loc68-1: In the street you came across Rabby Terezze - the chief feeder of the xenopark. /  / - Ah, <Ranger>, happy to see you in good health. Judging from you appearanc…
    Loc68-2: - It was the Aishout, a rather interesting plant. Completely brainless, whatever the ihike-bahanists may say, but able to shift. It absorbs amylum from starchy …
    Loc68-3: - It was the Aishout, a rather interesting plant. Completely brainless, whatever the ihike-bahanists may say, but able to shift. It absorbs amylum from starchy …
    Loc68-4: - Oh, that was a phatklink. They feed on curayaba, swamp heather, straining it out of the swamp. The mass that contains this heather is called criambusine. / - …
    Loc68-5: - Judging from your description, it was the Klissan proto-shpock. It passed into our hands from the Klissan Galaxy...I think. An extremely unpleasant creature! …
    Loc68-6: - That was a Sand Ship, they were brought to Mars from Earth. The Martian sands turned out to be suitable for them. They call them "camels" or "dessert ships" t…
    Loc68-7: - Judging from you description, that was the "dreadful habbath", the symbol of the Maloq courage. If it had been killed, a whole bunch of those tough guys would…
  -> Path181 => Loc67  вер=1 проходов<=1 порядок=8
       текст: Thank you, I have already straightened out the whole thing
  -> Path182 => Loc66  вер=1 проходов<=1 порядок=2
       текст: Ask about the Cage №1 inhabitant
       эффект: P12(Dialogue) = {6}
  -> Path183 => Loc66  вер=1 проходов<=1 порядок=3
       текст: Ask about the Cage №2 inhabitant
       условия: логика {[p11]>0}
       эффект: P12(Dialogue) = {3}
  -> Path184 => Loc66  вер=1 проходов<=1 порядок=4
       текст: Ask about the Cage №3 inhabitant
       эффект: P12(Dialogue) = {4}
  -> Path185 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Ask about the Cage №4 inhabitant
       эффект: P12(Dialogue) = {7}
  -> Path186 => Loc66  вер=1 проходов<=1 порядок=6
       текст: Ask about the Cage №5 inhabitant
       эффект: P12(Dialogue) = {5}
  -> Path203 => Loc66  вер=1 проходов<=1 порядок=3
       текст: Ask about the Cage №2 inhabitant
       условия: логика {[p11]<1}
       эффект: P12(Dialogue) = {2}

### Loc69 [пустая]
  -> Path198 => Loc9  вер=1 порядок=5
       текст: Leave the baleful xenomorph alone
       условия: логика {[p8]>0}

### Loc70 [пустая]
  -> Path200 => Loc11  вер=1 порядок=5
       текст: Don't stare and confuse the animal
       условия: логика {[p7]>0}

## Анализ
- стартовых: [1]
- концовки: {5: 'ПРОВАЛ', 35: 'ПРОВАЛ', 45: 'ПРОВАЛ', 52: 'СМЕРТЬ', 58: 'СМЕРТЬ', 65: 'СМЕРТЬ', 67: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
