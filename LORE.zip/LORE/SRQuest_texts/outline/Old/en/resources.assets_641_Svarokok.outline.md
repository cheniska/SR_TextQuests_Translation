# Квест (формат 1111111126)
Сложность 40; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Health' [0..100] тип=смерть
    старт: [100]
    [0..100] Health: <>%
    критическое: Your health was deeply exhausted. Suddenly you felt sharp pain, fell down and can't even move your f…
- P2 'Strength' [5..100] тип=обычный
    старт: [80]
    [5..100] Strength: <>%
    критическое: К сожалению, силы Вас полностью оставили. Вы могли только ползти, создавая много шума. Сварококи быс…
- P3 'Skill' [0..100] тип=обычный
    старт: [80]
    [0..100] Skill: <>%
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Concealment' [0..100] тип=обычный
    старт: [80]
    [0..100] Concealment: <>%
    критическое: Сообщение достижения критического значения параметром 5
- P5 'Swarokox' [0..10] тип=успех
    старт: [0]
    [0..10] Paws collected: <><br>
    критическое: At last, having collected <clr>10<clrEnd> paws, you went out of the gloomy forest feeling great reli…
- P6 'Knife' [0..8] тип=обычный
    старт: [0]
    [0..0] Your weapon :<br>No knife
    [1..1] Your weapon:<br>Nearly broken knife
    [2..2] Your weapon:<br>Barbed knife
    [3..3] Your weapon:<br>Twisted knife
    [4..4] Your weapon:<br>Dull knife
    [5..5] Your weapon:<br> Common knife
    [6..6] Your weapon:<br>Rather sharp knife
    [7..7] Your weapon:<br>Good knife
    [8..8] Your weapon:<br>Excellent knife
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Club' [0..5] тип=обычный
    старт: [0]
    [0..0] No club
    [1..1] Nearly broken club
    [2..2] Cracked club
    [3..3] Normal club
    [4..4] Good club
    [5..5] Tough club
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Time' [0..1440] тип=провал
    старт: [420]
    [0..1440] Current time: {[p8]div60} h {[p8]mod60} min.<br>
    критическое: Unfortunately, you failed to collect 10 paws before midnight and meet the test terms. You've got not…
- P9 'Health flower' [0..10] тип=обычный
    старт: [0]
    [0..10] Health flowers: <>
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Unknown flower' [0..5] тип=обычный
    старт: [0]
    [0..5] Unknown flowers: <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Knash' [0..100] тип=обычный
    старт: [0]
    [0..100] Knashes: <>
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Distance' [0..300] тип=обычный
    старт: [200..300]
    [0..300] Grags to Swarokok: <>
    критическое: Сообщение достижения критического значения параметром 12
- P13 "Swarokok's speed" [0..60] тип=обычный
    старт: [6]
    [0..60] Swarokok's speed: <> gr./min.
    критическое: Сообщение достижения критического значения параметром 16
- P15 'Possibility' [0..200] тип=обычный
    старт: [0]
    [0..200] 
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Ok' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 13
- P17 'Difficulty (d)' [0..200] тип=обычный
    старт: [130]
    [0..200] Difficulty
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Difficulty (n)' [0..200] тип=обычный
    старт: [140]
    [0..200] 
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Difficulty (k)' [0..200] тип=обычный
    старт: [110]
    [0..200] 
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Dt' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 20

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You were quick to find the Swarokox production facility office on <ToPlanet>. To your major surprise, it occupied a modest wooden house in the bosom of the fore…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17
  -> Path4 => Loc5  вер=1 порядок=5
       текст: Ask to tell you about the hunting
  -> Path137 => Loc8  вер=1 порядок=3
       текст: Stop reading the instructions and go hunting
       эффект: P6(Knife) = 8 [показ]
       эффект: P16(Ok) = 1
  -> Path147 => Loc66  вер=1 порядок=9
       текст: This mission is too dangerous! You better get back to the spaceport

### Loc5 [обычная]
    Loc5-1: In the first place, you can entrap a swarokok with a net. Small curious animals, <clr>knashes<clrEnd>, appear to be the best lure for this. They can be caught i…
    эффект: P14(ЗнаниеОхоты) +1
  -> Path8 => Loc8  вер=1 порядок=5
       текст: Go hunting
       эффект: P6(Knife) = 8 [показ]
       эффект: P16(Ok) = 1
       показ: P1,P8,P2,P3,P4,P7,P9,P10,P11

### Loc8 [обычная]
    выбор описания: {[p16]}
    Loc8-1: You entered the bosom of the forest surrounding the Bargagra's house. There is a lot of unknown trees, bushes and other plants all around you. Strange noises sh…
    Loc8-2: You approached the nearest tree, found a suitable limb, took out your knife and started making a <clr>club <clrEnd>. The job was rather painstaking and took muc…
    Loc8-3: You looked about you. The first thing that attracted your attention, was <clr>a red flower<clrEnd> with oval petal. Very quickly you put it in your pocket. But …
    Loc8-4: You've spent a lot of time racketing about the forest and catching knashes. The progress is obvious: now there are [p11] knashes in your bag. Next?
    Loc8-5: After telling yourself off for a rash decision, you refused the idea of untimely hunting. /  / So what are you going to do?
    показ: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11
  -> Path19 => Loc12  вер=1 проходов<=1 порядок=4
       текст: Make a club out of the tree
       эффект: P8(Time) = {[p8]+[40..50]}
       эффект: P6(Knife) = {[p6]-[1..2]}
       эффект: P7(Club) = 5 [показ]
       эффект: P16(Ok) = 2
  -> Path34 => Loc20  вер=1 порядок=9
       текст: Start hunting
       эффект: P12(Distance) = {[200..250]} [показ]
       эффект: P13(Swarokok's speed) = {[4..7]} [показ]
       эффект: P16(Ok) = 1
  -> Path121 => Loc57  вер=101 проходов<=1 порядок=9
       текст: Start hunting
       условия: логика {([p7]=0) or ([p11]=0)}
       эффект: P16(Ok) = 5
  -> Path124 => Loc58  вер=1 проходов<=1 порядок=6
       текст: Slip off a couple of flowers
       эффект: P8(Time) = {[p8]+[5..15]}
       эффект: P16(Ok) = 3
  -> Path126 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Try to catch a couple of knashes
       эффект: P8(Time) = {[p8]+[15..30]}
       эффект: P16(Ok) = 4

### Loc12 [пустая] визитов<=1
  -> Path107 => Loc8  вер=1 проходов<=1 порядок=5

### Loc20 [обычная]
    выбор описания: {[p16]}
    Loc20-1: You are standing in the middle of the gloomy forest surrounded by age-long trees stocks.  /  / What are you going to do?
    Loc20-2: You opened the brochure and found the following short rules there: /  / -------------------- / - The better your <clr>skill<clrEnd> is, the more effective your …
    Loc20-3: It took you rather long to make a club. Pluses: you made it. Minuses: your knife became dull and the swarokok came closer. Next?
    Loc20-4: While you lay doing nothing, the swarokok was coming closer and closer. But your health and strength notably increased!
    эффект: P15(Possibility) = {[1..100]}
  -> Path35 => Loc25  вер=1 порядок=4
       текст: Eat something
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 1
  -> Path36 => Loc21  вер=1 порядок=1
       текст: Bait with a knash
       условия: логика {([p11]>0) and ([p12]>=200)}
       эффект: P20(Dt) = {([p12]-[20..30])/[p13]}
  -> Path37 => Loc22  вер=1 порядок=1
       текст: Prepare to fight a swarokok with a club in your hands
       условия: логика {([p7]>0) and ([p12]<=100)}
       эффект: P8(Time) = {[p8]+([p12]-1)/[p13]}
  -> Path38 => Loc23  вер=1 порядок=2
       текст: Take your knife and wait for the swarokok
       условия: логика {([p6]>0) and ([p12]<=100)}
       эффект: P8(Time) = {[p8]+([p12]-1)/[p13]}
  -> Path39 => Loc24  вер=1 порядок=2
       текст: Train a little
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 0
  -> Path89 => Loc45  вер=1 порядок=9
       текст: Stop hunting, change your mind and return to the Bargagra's house
       условия: логика {[p5]<10}
  -> Path97 => Loc49  вер=1 порядок=3
       текст: Face the swarokok with no weapon
       условия: логика {(([p6]=0) and ([p7]=0)) and ([p12]<=100)}
       эффект: P8(Time) = {[p8]+([p12]-1)/[p13]}
  -> Path110 => Loc54  вер=1 порядок=4
       текст: Try to catch a couple of knashes
       условия: логика {([p12]>220) and ([p15]>([p3]+30))}
       эффект: P16(Ok) = 0
  -> Path111 => Loc54  вер=1 порядок=4
       текст: Try to catch a couple of knashes
       условия: логика {([p12]>220) and ([p15]<=(2*[p3]/3))}
       эффект: P11(Knash) +2
       эффект: P16(Ok) = 2
  -> Path112 => Loc54  вер=1 порядок=4
       текст: Try to catch a couple of knashes
       условия: логика {(([p12]>220) and ([p15]<=([p3]+30))) and ([p15]>(2*[p3]/3))}
       эффект: P11(Knash) +1
       эффект: P16(Ok) = 1
  -> Path118 => Loc56  вер=1 порядок=6
       текст: Read the Bargagra's brochure
       условия: логика {[p12]>100}
  -> Path128 => Loc60  вер=1 порядок=5
       текст: Make a new club
       условия: логика {([p7]<=1) and ([p6]>2) and ([p12]>220)}
  -> Path131 => Loc61  вер=1 порядок=3
       текст: Lie down and have a rest waiting for the swarokok
       условия: логика {[p12]>100}
       эффект: P15(Possibility) = {[50..99]}
       эффект: P16(Ok) = 1
  -> Path138 => Loc63  вер=1 порядок=4
       текст: Try to hide in the forest and let the swarokok pass.
       условия: логика {[p12]<=100}
       эффект: P8(Time) = {[p8]+([p12]-1)/[p13]}
       эффект: P15(Possibility) = {[1..100]}

### Loc21 [обычная]
    Loc21-1: It took you rather long to make a net trap for a swarokok. The process turned out to be very time-consuming. Now you need to put a knash into the trap and wait.
    эффект: P2(Strength) = {[p2]-[1..10]}
    эффект: P8(Time) = {[p8]+[p20]}
    эффект: P12(Distance) = {[p12]-[p20]*[p13]}
    эффект: P15(Possibility) = {1 to [p19]}
  -> Path62 => Loc35  вер=1 порядок=5
       текст: Put a knash into the trap, lie up, and wait
       условия: логика {[p15]<=([p4]+10)}
  -> Path63 => Loc36  вер=1 порядок=5
       текст: Put a knash into the trap, lie up, and wait
       условия: логика {[p15]>([p4]+10)}

### Loc22 [обычная]
    Loc22-1: You grasped the club and prepared for a single fight with a swarokok. The beast was so close that you could almost feel its breath on your face.
    эффект: P12(Distance) = 1
    эффект: P15(Possibility) = {1 to [p17]}
  -> Path72 => Loc41  вер=1 порядок=5
       текст: Haul off and struck the swarokok on the head with your club when it charges at you.
       условия: логика {[p15]<=[p2]}
       эффект: P7(Club) -1
  -> Path74 => Loc42  вер=1 порядок=5
       текст: Haul off and struck the swarokok on the head with your club when it charges at you.
       условия: логика {[p15]>[p2]}
       эффект: P7(Club) -1
  -> Path77 => Loc23  вер=1 проходов<=2 порядок=7
       текст: Change your tactics and meet the swarokok with the knife.
       условия: логика {[p6]>0}
  -> Path78 => Loc37  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)>(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}
  -> Path79 => Loc40  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)<=(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}

### Loc23 [обычная]
    Loc23-1: You looked into a swarokok's fiery eyes, clutching your knife. Next?
    эффект: P12(Distance) = 1
    эффект: P15(Possibility) = {1 to [p18]}
  -> Path81 => Loc43  вер=1 порядок=5
       текст: Wait until the swarokok jumps at you and then slash its throat.
       условия: логика {[p15]<=[p3]}
       эффект: P6(Knife) -1
  -> Path82 => Loc22  вер=1 проходов<=2 порядок=7
       текст: Be quick and change your tactics taking the club in your hands
       условия: логика {[p7]>0}
  -> Path83 => Loc44  вер=1 порядок=5
       текст: Wait until the swarokok jumps at you and then slash its throat.
       условия: логика {[p15]>[p3]}
       эффект: P6(Knife) -1
  -> Path86 => Loc37  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)>(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}
  -> Path87 => Loc40  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)<=(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}

### Loc24 [обычная]
    выбор описания: {([p16]*3-[0..2])*([p16]>0)+1}
    Loc24-1: Looking about you, you found several things that could be used as gymnasium pieces. A tree similar to cartenga with ripe fruits, a huge log on the ground and ha…
    Loc24-2: You approached the huge log and tried to lift it. Suddenly a mad thought rushed through your mind "Why the hell am I doing it?". But then you quickly gathered y…
    Loc24-3: After several lifts of the biggest in the neighbourhood log, your muscles began engorging with simply Maloq <clr>strength<clrEnd>. You were becoming stronger an…
    Loc24-4: After log lifting you felt as <clr>strong<clrEnd>, as to screw a swarokok's neck with your bare hands! However, a club is still better...
    Loc24-5: You shook the tree stock, and the fruits rained down upon you. You were doing your best to escape them and in the end of the training you became so skilful in i…
    Loc24-6: In the beginning you were just successfully escaping the falling fruits, but then you learned to peel them on the run, and in the end you were as skilful as to …
    Loc24-7: You have trained with cartenga fruits to your heart's content. After this you felt that your <clr>skill<clrEnd> let you try and compete with Drevochan, the main…
    Loc24-8: Entering the crumpius bushes, you tried to move without touching any branch or prickle there. It took you rather long to train but in the end you felt that famo…
    Loc24-9: Crumpius branches gave you much pain lashing across your face. Though there were more and more scratches appearing on it, you started producing less and less no…
    Loc24-10: After your training in the crumpius scrubs you noted with satisfaction that if knashes had been as skilled in <clr>concealment<clrEnd> as you were, nobody would…
  -> Path52 => Loc33  вер=1 порядок=6
       текст: Go to the crumpius scrubs.
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 3
       эффект: P20(Dt) = {[9..14]}
  -> Path54 => Loc32  вер=1 порядок=5
       текст: Come to the cartenga and shake its stock
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 2
       эффект: P20(Dt) = {[9..14]}
  -> Path56 => Loc31  вер=1 порядок=4
       текст: Come to the huge log
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 1
       эффект: P20(Dt) = {[9..14]}
  -> Path58 => Loc20  вер=1 порядок=8
       текст: Get back to hunting
       условия: логика {[p12]>100}
       эффект: P16(Ok) = 1
  -> Path59 => Loc20  вер=1 порядок=8
       текст: No time for training, the enemy is near! Kill swarokoks!
       условия: логика {[p12]<=100}
       эффект: P16(Ok) = 1

### Loc25 [обычная]
    выбор описания: {[p16]}
    Loc25-1: There are many unknown fruits hanging around you and most of them look rather unpalatable. Will you try any of them?
    Loc25-2: You tried an unknown fruit. Some changes are obvious. /  / Will you try anything else?
    Loc25-3: You ate a health flower and felt that all your wounds were healing. You wondered why the <FromPlanet> government needed just "Swarokox"? They should have sent y…
    Loc25-4: You ate a strange flower and tried to trace any changes in you... Yes, something changed for sure...  /  / Will you try anything else?
  -> Path42 => Loc28  вер=1 [всегда видна] порядок=3
       текст: Eat a red flower with oval petals
       условия: логика {([p9]>0) and ([p12]>100)}
       эффект: P1(Health) = 100
       эффект: P9(Health flower) -1
       эффект: P16(Ok) = 3
  -> Path44 => Loc28  вер=1 [всегда видна] порядок=5
       текст: Eat an unknown flower
       условия: логика {([p10]>0) and ([p12]>100)}
       эффект: P1(Health) = {[p1]+[-5..30]}
       эффект: P10(Unknown flower) -1
       эффект: P16(Ok) = 4
  -> Path45 => Loc28  вер=1 [всегда видна] порядок=5
       текст: Eat an unknown flower
       условия: логика {([p10]>0) and ([p12]>100)}
       эффект: P2(Strength) = {[p2]+[-5..30]}
       эффект: P10(Unknown flower) -1
       эффект: P16(Ok) = 4
  -> Path46 => Loc28  вер=1 [всегда видна] порядок=5
       текст: Eat an unknown flower
       условия: логика {([p10]>0) and ([p12]>100)}
       эффект: P3(Skill) = {[p3]+[-5..30]}
       эффект: P10(Unknown flower) -1
       эффект: P16(Ok) = 4
  -> Path47 => Loc28  вер=1 [всегда видна] порядок=5
       текст: Eat an unknown flower
       условия: логика {([p10]>0) and ([p12]>100)}
       эффект: P4(Concealment) = {[p4]+[-5..30]}
       эффект: P10(Unknown flower) -1
       эффект: P16(Ok) = 4
  -> Path49 => Loc28  вер=1 порядок=6
       текст: Eat an unknown fruit
       условия: логика {[p12]>100}
       эффект: P1(Health) = {[p1]+[-10..20]}
       эффект: P2(Strength) = {[p2]+[-10..20]}
       эффект: P3(Skill) = {[p3]+[-10..20]}
       эффект: P4(Concealment) = {[p4]+[-10..20]}
       эффект: P16(Ok) = 2
  -> Path51 => Loc20  вер=1 порядок=9
       текст: The enemy is in the game, get back to hunting!
       эффект: P16(Ok) = 1

### Loc28 [пустая]
    эффект: P20(Dt) = {[3..5]}
  -> Path43 => Loc25  вер=1 порядок=5
       эффект: P8(Time) = {[p8]+[p20]}
       эффект: P12(Distance) = {[p12]-[p13]*[p20]}

### Loc31 [пустая]
    эффект: P2(Strength) = {[p2]+[20..25]}
    эффект: P3(Skill) = {[p3]-[2..5]}
    эффект: P4(Concealment) = {[p4]-[1..3]}
    эффект: P8(Time) = {[p8]+[p20]}
    эффект: P12(Distance) = {[p12]-[p20]*[p13]}
  -> Path57 => Loc24  вер=1 порядок=5

### Loc32 [пустая]
    эффект: P2(Strength) = {[p2]-[1..3]}
    эффект: P3(Skill) = {[p3]+[10..20]}
    эффект: P4(Concealment) = {[p4]-[2..5]}
    эффект: P8(Time) = {[p8]+[p20]}
    эффект: P12(Distance) = {[p12]-[p20]*[p13]}
  -> Path55 => Loc24  вер=1 порядок=5

### Loc33 [пустая]
    эффект: P2(Strength) = {[p2]-[2..5]}
    эффект: P3(Skill) = {[p3]-[1..3]}
    эффект: P4(Concealment) = {[p4]+[10..20]}
    эффект: P8(Time) = {[p8]+[p20]}
    эффект: P12(Distance) = {[p12]-[p20]*[p13]}
  -> Path53 => Loc24  вер=1 порядок=5

### Loc35 [обычная]
    выбор описания: {[1..3]}
    Loc35-1: You didn't have to wait for a swarokok long. It appeared soon, nosed out a knash and jumped after it with complete abandon. Naturally, it got entrapped in the n…
    Loc35-2: A swarokok jumped from nowhere and charged at the poor knash. There were heard a menacing roar and contented champs. You securely left your shelter and when the…
    Loc35-3: The swarokok approached the trap snuffing and looking about itself. It took the beast quite a while before it turned its head for the last time and charged at t…
    эффект: P2(Strength) = {[p2]-[1..3]}
    эффект: P4(Concealment) = {[p4]-[5..15]}
    эффект: P5(Swarokox) +1
    эффект: P8(Time) +5
    эффект: P11(Knash) -1
    эффект: P12(Distance) = 1
  -> Path64 => Loc53  вер=1 порядок=5
       текст: Get back to hunting

### Loc36 [обычная]
    выбор описания: {[1..2]}
    Loc36-1: Unfortunately, <clr>the swarokok noticed you<clrEnd> before it charged at the knash into the trap. Now it stands just a meter away from you roaring menacingly w…
    Loc36-2: The swarokok approached the trap snuffing and looking about itself. It took the beast quite a while before it turned its head for the last time. It even seemed …
    эффект: P4(Concealment) = {[p4]-[5..15]}
    эффект: P11(Knash) -1
    эффект: P12(Distance) = 1
    эффект: P15(Possibility) = {[1..100]}
  -> Path65 => Loc40  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)<=(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}
  -> Path66 => Loc39  вер=1 порядок=6
       текст: Try to be as invisible as possible
       условия: логика {[p15]<(((100-[p4])/2)+[p4])}
  -> Path67 => Loc38  вер=1 порядок=6
       текст: Try to be as invisible as possible
       условия: логика {[p15]>=(((100-[p4])/2)+[p4])}
  -> Path69 => Loc37  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/1.5)>(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}
  -> Path73 => Loc22  вер=1 порядок=1
       текст: Take your club and get ready for the swarokok's attack
       условия: логика {[p7]>0}
  -> Path76 => Loc23  вер=1 порядок=2
       текст: Hunt a swarokok with a knife in your hands.
       условия: логика {[p6]>0}
  -> Path98 => Loc49  вер=1 порядок=5
       текст: Fight the swarokok with no weapon
       условия: логика {([p6]=0) and ([p7]=0)}

### Loc37 [обычная]
    Loc37-1: You decided to desert the battlefield. Well, that wasn't a bad decision either. However, you didn't have enough health and strength to compete with the swarokok…
    эффект: P1(Health) = {[p1]-[25..40]}
    эффект: P2(Strength) = {[p2]-[10..15]}
    эффект: P3(Skill) = {[p3]-[5..10]}
    эффект: P4(Concealment) = {[p4]-[5..10]}
  -> Path71 => Loc52  вер=1 порядок=5
       текст: Get back to hunting

### Loc38 [СМЕРТЬ]
    Loc38-1: Unfortunately, the swarokok didn't believe your simulation. It approached you, sniffed at you several times and jumped. You were bound to lose.
    эффект: P1(Health) = 0

### Loc39 [обычная]
    Loc39-1: Well, it looked like you were extremely lucky. Either the swarokok was dull or your <clr>concealment<clrEnd> skills were highly developed. The beast approached …
  -> Path68 => Loc53  вер=1 порядок=5
       текст: Get back to hunting
       эффект: P3(Skill) = {[p3]-[5..10]}

### Loc40 [обычная]
    Loc40-1: You had been competing with the swarokok in race for a long time and still remained very strong. So at last the beast got tired and ran away with its tongue out…
    эффект: P2(Strength) = {[p2]-[5..15]}
  -> Path70 => Loc53  вер=1 порядок=5
       текст: Get back to hunting

### Loc41 [обычная]
    выбор описания: {[1..3]}
    Loc41-1: After you let the swarokok jump at you, you gave it a deadly blow on the head with your club. Fortunately, the latter turned out to be harder than the swarokok'…
    Loc41-2: It took you rather long punching yourself in the chest and roaring before the swarokok got furious enough and jumped at you. But you met it with your club and d…
    Loc41-3: You remained motionless playing with your club while the swarokok was lashing its tail on the ground. Finally, you had enough of it - the beast was not going to…
    эффект: P2(Strength) = {[p2]-[5..15]}
    эффект: P5(Swarokox) +1
  -> Path75 => Loc53  вер=1 порядок=5
       текст: Get back to hunting
       условия: логика {[p7]>0}
  -> Path92 => Loc53  вер=1 порядок=5
       текст: Get back to hunting
       ответ: Unfortunately, your <clr>club has staved to splinters <clrEnd> during the last fight. You'll have to use something else...
       условия: логика {[p7]=0}
       скрыт: P7

### Loc42 [обычная]
    выбор описания: {[1..2]}
    Loc42-1: After you let the swarokok jump at you, you recollected all your strength and gave it a blow on the head with your club. Unfortunately, the blow was not strong …
    Loc42-2: You looked into the swarokok's eyes and realised that it wasn't just playing games. Suddenly the swarokok jumped. You met it with your club dabbing right betwee…
    эффект: P1(Health) = {[p1]-[10..30]}
    эффект: P2(Strength) = {[p2]-[5..15]}
    эффект: P3(Skill) = {[p3]-[5..15]}
    эффект: P4(Concealment) = {[p4]-[5..15]}
  -> Path80 => Loc52  вер=1 порядок=5
       текст: Get back to hunting
       условия: логика {[p7]>0}
  -> Path135 => Loc52  вер=1 порядок=5
       текст: Get back to hunting
       ответ: Unfortunately, your <clr>club has staved to splinters <clrEnd> during the last fight. You'll have to use something else...
       условия: логика {[p7]=0}

### Loc43 [обычная]
    выбор описания: {[1..3]}
    Loc43-1: You waited until the swarokok jumped at you, then you suddenly rolled away and slashed it on the throat with your knife. The beast was agonising while you went …
    Loc43-2: You and the swarokok were moving in a round looking in each other's eyes. At last the swarokok's nerves snapped and it jumped at you. And you'd been expecting i…
    Loc43-3: As long as the swarokok refused to jump at you, you decided to attack yourself. In the beginning it seemed to you that you had made a wrong decision - the beast…
    эффект: P3(Skill) = {[p3]-[5..15]}
    эффект: P5(Swarokox) +1
  -> Path84 => Loc53  вер=1 порядок=5
       текст: Get back to hunting
       условия: логика {[p6]>0}
  -> Path93 => Loc53  вер=1 порядок=5
       текст: Get back to hunting
       ответ: Unfortunately, your knife broke completely during the last fight. If you want to get your blaster back and simultaneously not to lose your honour completely, <c…
       условия: логика {[p6]=0}
       скрыт: P6

### Loc44 [обычная]
    выбор описания: {[1..2]}
    Loc44-1: You tried to escape the swarokok's attack but failed - it caught you with its paw and stroke you down to the ground. It was going to pull you to pieces. But you…
    Loc44-2: At last when the swarokok jumped, you momentarily fell on your back and tried to throw the beast over you. But it divined your manoeuvre and wouldn't let you. L…
    эффект: P1(Health) = {[p1]-[10..30]}
    эффект: P2(Strength) = {[p2]-[5..15]}
    эффект: P3(Skill) = {[p3]-[5..15]}
    эффект: P4(Concealment) = {[p4]-[5..15]}
  -> Path85 => Loc52  вер=1 порядок=5
       текст: Try to recollect your breath after the swarokok's mad attack as soon as possible and get back to hunting
       условия: логика {[p6]>0}
  -> Path136 => Loc52  вер=1 порядок=5
       текст: Try to recollect your breath after the swarokok's mad attack as soon as possible and get back to hunting
       ответ: Unfortunately, your knife broke completely during the last fight. If you want to get your blaster back and simultaneously not to lose your honour completely, <c…
       условия: логика {[p6]=0}

### Loc45 [ПРОВАЛ]
    Loc45-1: You were sick and tired of swarokoks, knashes, knives and the rest of the stuff. You came back to the Bargagra's house and demanded your blaster back. The maste…

### Loc47 [обычная]
    выбор описания: {[1..2]}
    Loc47-1: You recollected all the remains of your strength and stood against the swarokok barehanded. However, your <clr>strength, skill and concealment <clrEnd> were not…
    Loc47-2: It was clear from the very beginning that you shouldn't have behaved like that. The swarokok didn't even have to jump or roar, it just easily approached you and…
  -> Path99 => Loc52  вер=1 порядок=5
       текст: Get back to hunting

### Loc48 [обычная]
    выбор описания: {[1..2]}
    Loc48-1: Recollecting all the remains of your strength, you decided to fight the swarokok barehanded. Weird forces must have helped you - your onset killed the swarokok …
    Loc48-2: Standing in front of the swarokok completely barehanded, all you could remember of was the ancient martial art <clr>kara-heh<clrEnd>, the main idea of which was…
    эффект: P2(Strength) = {[p2]-[10..15]}
    эффект: P3(Skill) = {[p3]-[10..15]}
    эффект: P4(Concealment) = {[p4]-[10..15]}
    эффект: P5(Swarokox) +1
  -> Path100 => Loc53  вер=1 порядок=5
       текст: Get back to hunting

### Loc49 [обычная]
    Loc49-1: The swarokok stands right in front of you screwing up its eyes and staring at you. What are you going to do?
    эффект: P12(Distance) = 1
    эффект: P15(Possibility) = {[1..200]}
  -> Path95 => Loc47  вер=1 порядок=5
       текст: Go fighting barehanded
       условия: логика {[p15]>(([p2]+[p3]+[p4])/3)}
  -> Path96 => Loc48  вер=1 порядок=5
       текст: Go fighting barehanded
       условия: логика {[p15]<=(([p2]+[p3]+[p4])/3)}
  -> Path114 => Loc37  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/2)>(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}
  -> Path115 => Loc40  вер=1 порядок=9
       текст: Run away
       условия: логика {([p15]/2)<=(((100-(([p2]+[p1])/2))/2)+((([p2]+[p1])/2)))}

### Loc52 [пустая]
    эффект: P8(Time) = {[p8]+5}
    эффект: P12(Distance) = {[200..300]}
  -> Path108 => Loc20  вер=1 порядок=5
       эффект: P13(Swarokok's speed) = {[4..7]}
       эффект: P16(Ok) = 1

### Loc53 [пустая]
    эффект: P8(Time) +5
    эффект: P12(Distance) = {[200..300]}
  -> Path109 => Loc20  вер=1 порядок=5
       эффект: P13(Swarokok's speed) = {[4..7]}
       эффект: P16(Ok) = 1

### Loc54 [обычная]
    выбор описания: {[p16]+1}
    Loc54-1: While you tried to catch knashes producing much noise, the swarokok got quite close at you. Unfortunately, you just wasted your time - <clr>not a single knash<c…
    Loc54-2: While you tried to catch knashes producing much noise, the swarokok got quite close at you. You managed to catch just <clr>one<clrEnd> knash. You lack either <c…
    Loc54-3: While you tried to catch knashes producing much noise, the swarokok got quite close at you. But then you caught as much as <clr>two<clrEnd> knashes! Time for hu…
    эффект: P4(Concealment) = {[p4]-[5..10]}
    эффект: P20(Dt) = {([p12]-[10..20])/[p13]}
  -> Path113 => Loc20  вер=1 порядок=5
       текст: Get back to hunting - the enemy is too close to catch knashes now!
       эффект: P8(Time) = {[p8]+[p20]}
       эффект: P12(Distance) = {[p12]-[p20]*[p13]}
       эффект: P16(Ok) = 1

### Loc56 [пустая]
    эффект: P20(Dt) = {[3..5]}
  -> Path119 => Loc20  вер=1 порядок=5
       эффект: P8(Time) = {[p8]+[p20]}
       эффект: P12(Distance) = {[p12]-[p20]*[p13]}
       эффект: P16(Ok) = 2

### Loc57 [обычная] визитов<=1
    Loc57-1: According to the Maloq archival manuscripts, running against a swarokok without a good club and a couple of knashes in the pocket is equal to fighting with thre…
  -> Path122 => Loc20  вер=1 порядок=6
       текст: Chroniclers hardly knew anything about new methods of knash catching. Go hunting
       эффект: P12(Distance) = {[200..250]} [показ]
       эффект: P13(Swarokok's speed) = {[4..7]} [показ]
       эффект: P16(Ok) = 1
  -> Path123 => Loc8  вер=1 порядок=5
       текст: Good idea. Reconsider your decision
       эффект: P8(Time) +1

### Loc58 [пустая] визитов<=1
    эффект: P9(Health flower) = 1 [показ]
    эффект: P10(Unknown flower) = 2 [показ]
  -> Path125 => Loc8  вер=1 проходов<=1 порядок=5

### Loc59 [пустая] визитов<=1
    эффект: P11(Knash) = {[2..3]} [показ]
  -> Path127 => Loc8  вер=1 проходов<=1 порядок=5

### Loc60 [пустая]
    эффект: P2(Strength) = {[p2]-[5..10]}
    эффект: P6(Knife) = {[p6]-[1..2]}
    эффект: P7(Club) = {[4..5]} [показ]
    эффект: P20(Dt) = {([p12]-[10..20])/[p13]}
  -> Path148 => Loc20  вер=1 порядок=5
       эффект: P8(Time) = {[p8]+[p20]}
       эффект: P12(Distance) = {[p12]-[p20]*[p13]}
       эффект: P16(Ok) = 3

### Loc61 [пустая]
    эффект: P20(Dt) = {([p12]-[10..20])/[p13]}
  -> Path149 => Loc20  вер=1 порядок=5
       эффект: P1(Health) = {[p1]+[p20]/[4..6]}
       эффект: P8(Time) = {[p8]+[p20]}
       эффект: P2(Strength) = {[p2]+[p20]/[10..20]}
       эффект: P3(Skill) = {[p3]+[p20]/[10..20]}
       эффект: P4(Concealment) = {[p4]+[p20]/[10..20]}
       эффект: P12(Distance) = {[p12]-[p20]*[p13]}
       эффект: P16(Ok) = 4

### Loc63 [обычная]
    выбор описания: {(([p3]+2*[p4])/3>=[p15])+1}
    Loc63-1: You dodged in the forest and laid up waiting for the swarokok. At last it appeared. Its fiery eyes were seen through the depths of the forest and its nose moved…
    Loc63-2: You dodged in the forest and laid up waiting for the swarokok. At last it appeared. Its fiery eyes were seen through the depths of the forest and its nose moved…
    эффект: P12(Distance) = 1
  -> Path140 => Loc53  вер=1 порядок=6
       текст: Go further
       условия: логика {([p3]+2*[p4])/3>=[p15]}
  -> Path141 => Loc22  вер=1 порядок=1
       текст: Fight with a club
       условия: логика {([p7]>0) and (([p3]+2*[p4])/3<[p15])}
  -> Path142 => Loc23  вер=1 порядок=2
       текст: Take a knife
       условия: логика {([p6]>0) and (([p3]+2*[p4])/3<[p15])}
  -> Path143 => Loc49  вер=1 порядок=5
       текст: Fight barehanded
       условия: логика {([p7]=0) and ([p6]=0) and (([p3]+2*[p4])/3<[p15])}
  -> Path144 => Loc65  вер=1 порядок=7
       текст: Run away
       условия: логика {([p7]=0) and ([p6]=0) and (([p3]+2*[p4])/3<[p15])}

### Loc65 [пустая]
    эффект: P15(Possibility) = {[1..100]}
  -> Path145 => Loc37  вер=1 порядок=5
       условия: логика {[p15]>(50+([p2]+[p1])/4)}
  -> Path146 => Loc40  вер=1 порядок=5
       условия: логика {[p15]<=(50+([p2]+[p1])/4)}

### Loc66 [ПРОВАЛ]
    Loc66-1: - It seems to me that I forgot my happy amulet in the spaceship! - you hawed and dashed out of the Bargagra's house. The Maloq yager's Homeric laughter was foll…

## Анализ
- стартовых: [1]
- концовки: {38: 'СМЕРТЬ', 45: 'ПРОВАЛ', 66: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: [18, 19]
