# Квест (формат 1111111126)
Сложность 60; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'ROUND' [1..4] тип=обычный
    старт: [1]
    [1..4] ROUND: <>
    критическое: Сообщение достижения критического значения параметром 1
- P2 'ERRORS' [0..4] тип=обычный
    старт: [0]
    [0..4] ERRORS: <>
- P3 'Current number' [4..11] тип=обычный
    старт: [4]
    [4..11] Figures left: {11-[p3]}
    критическое: Сообщение достижения критического значения параметром 14
- P4 'RULE' [0..50] тип=обычный
    старт: [0]
    [0..50] ORDER OF FIGURES:
    критическое: Сообщение достижения критического значения параметром 3
- P5 'The first' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 4
- P6 'The second' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 5
- P7 'The third' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 6
- P8 'The forth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 7
- P9 'The fifth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 8
- P10 'The sixth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 9
- P11 'The seventh' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 10
- P12 'The eighth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 11
- P13 'The ninth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 12
- P14 'The tenth' [0..8] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [2..2] <fix><format=left,8>Big</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [3..3] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [4..4] <fix><format=left,8>Big</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix>
    [5..5] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Circle</format></fix>
    [6..6] <fix><format=left,8>Small</format><format=left,7>Blue</format><format=left,5>Lozenge</format></fix>
    [7..7] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Circle</format></fix>
    [8..8] <fix><format=left,8>Small</format><format=left,7>Yellow</format><format=left,5>Lozenge</format></fix…
    критическое: Сообщение достижения критического значения параметром 13
- P15 'Truth table' [0..100000000] тип=обычный
    старт: [0]
    [0..100000000] Parameter No 15: <>
    критическое: Сообщение достижения критического значения параметром 15
- P16 'The_first_incorrect' [0..100000000] тип=обычный
    старт: [0]
    [0..100000000] Parameter No 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P17 'The_second_incorrect' [0..100000000] тип=обычный
    старт: [0]
    [0..100000000] Parameter 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Correct variant' [0..8] тип=обычный
    старт: [0]
    [0..8] Parameter No 18: <>
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Incorrect_variant_one' [0..8] тип=обычный
    старт: [0]
    [0..8] Parameter No 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Incorrect_variant_two' [0..8] тип=обычный
    старт: [0]
    [0..8] Parameter No 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Variant' [0..100] тип=обычный
    старт: [0]
    [0..100] Parameter No 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Degree' [1..100000000] тип=обычный
    старт: [1]
    [1..100000000] Parameter No 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 "Player's place" [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Money' [0..10000000] тип=обычный деньги
    старт: [0]
    [0..10000000] 
    критическое: Сообщение достижения критического значения параметром 24
- P25 "O'Nyke" [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Eo' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Loon' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 27
- P28 'Ellinar' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 28
- P29 'Crocus' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 29
- P30 'Mocus' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Phocus' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Bliuk' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 32
- P33 'Gliuk' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Agaric' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Clod' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 35
- P36 'Player' [0..999] тип=обычный
    старт: [0]
    [0..999] 
    критическое: Сообщение достижения критического значения параметром 36
- P37 "O'Nyke+" [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Eo+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Loon+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 39
- P40 'Ellinar+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Crocus+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 41
- P42 'Mocus+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 42
- P43 'Phocus+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 43
- P44 'Bliuk+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Gliuk+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 45
- P46 'Agaric+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Clod+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 47
- P48 'Player+' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: The tournament aroused a great boom in spite of the fact that <clr>Elus<clrEnd> was not so very popular among other races except for the Faeyans. You checked in…
    скрыт: P1,P2,P3,P4,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24
  -> Path2 => Loc2  вер=1 проходов<=1 порядок=5
       текст: Go to the bar
       ответ: You came down to the bar and were deciding what to order when somebody called you by name. You turned around and saw a man of average height with dark hair and …
       скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23
  -> Path3 => Loc3  вер=1 проходов<=1
       текст: Just have a rest

### Loc2 [обычная] визитов<=1
    Loc2-1: From the further conversation with Max you found out the following information: / - 8 figures are used in Elus game. They differ in <clr>colour<clrEnd> (blue an…
    скрыт: P1,P2,P3,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23
  -> Path4 => Loc40  вер=1 проходов<=1 порядок=5
       текст: Ask to give you examples of the rules
       скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23
  -> Path250 => Loc3  вер=1 проходов<=1 порядок=9
       текст: Say good-bye to Max and have a rest

### Loc3 [обычная]
    Loc3-1: In the morning you came to the championship place and went quickly through the checking procedure the aim of which was to detect electronic devices that could i…
    показ: P1,P2,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14
    скрыт: P3,P15,P16,P17,P18,P19,P20,P21,P22,P23
  -> Path5 => Loc4  вер=1 порядок=5
       текст: Start the game

### Loc4 [пустая]
    эффект: P3(Current number) = {4}
    эффект: P22(Degree) = {1000000}
  -> Path6 => Loc6  вер=1 порядок=5
       условия: P1(ROUND) ∈[1]
  -> Path7 => Loc7  вер=1 порядок=5
       условия: P1(ROUND) ∈[2]
  -> Path8 => Loc5  вер=1 порядок=5
       условия: P1(ROUND) ∈[3]

### Loc5 [пустая]
  -> Path212 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {14}
       эффект: P5(The first) = {3}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {6}
       эффект: P15(Truth table) = {2137873}
       эффект: P16(The_first_incorrect) = {4248156}
       эффект: P17(The_second_incorrect) = {8486261}
  -> Path226 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {15}
       эффект: P5(The first) = {3}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {7}
       эффект: P15(Truth table) = {1268215}
       эффект: P16(The_first_incorrect) = {4731343}
       эффект: P17(The_second_incorrect) = {8845778}
  -> Path227 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {16}
       эффект: P5(The first) = {3}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {7}
       эффект: P15(Truth table) = {2685412}
       эффект: P16(The_first_incorrect) = {4714573}
       эффект: P17(The_second_incorrect) = {8827684}
  -> Path228 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {17}
       эффект: P5(The first) = {5}
       эффект: P6(The second) = {3}
       эффект: P7(The third) = {4}
       эффект: P15(Truth table) = {7614136}
       эффект: P16(The_first_incorrect) = {2357875}
       эффект: P17(The_second_incorrect) = {4568657}
  -> Path232 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {18}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {4}
       эффект: P7(The third) = {8}
       эффект: P15(Truth table) = {4724768}
       эффект: P16(The_first_incorrect) = {1512177}
       эффект: P17(The_second_incorrect) = {5136253}
  -> Path233 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {19}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {4}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {4751473}
       эффект: P16(The_first_incorrect) = {7445724}
       эффект: P17(The_second_incorrect) = {8826862}
  -> Path234 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {20}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {4}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {4574685}
       эффект: P16(The_first_incorrect) = {5121342}
       эффект: P17(The_second_incorrect) = {6252421}

### Loc6 [пустая]
  -> Path195 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {1}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {7}
       эффект: P7(The third) = {2}
       эффект: P15(Truth table) = {8354716}
       эффект: P16(The_first_incorrect) = {1537182}
       эффект: P17(The_second_incorrect) = {2628354}
  -> Path200 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {2}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {7}
       эффект: P7(The third) = {2}
       эффект: P15(Truth table) = {8145824}
       эффект: P16(The_first_incorrect) = {1327632}
       эффект: P17(The_second_incorrect) = {2458175}
  -> Path202 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {3}
       эффект: P5(The first) = {2}
       эффект: P6(The second) = {3}
       эффект: P7(The third) = {2}
       эффект: P15(Truth table) = {3678123}
       эффект: P16(The_first_incorrect) = {6161852}
       эффект: P17(The_second_incorrect) = {8383278}
  -> Path204 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {4}
       эффект: P5(The first) = {2}
       эффект: P6(The second) = {3}
       эффект: P7(The third) = {2}
       эффект: P15(Truth table) = {3231431}
       эффект: P16(The_first_incorrect) = {6776875}
       эффект: P17(The_second_incorrect) = {8568758}
  -> Path206 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {5}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {2}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {6152612}
       эффект: P16(The_first_incorrect) = {3473783}
       эффект: P17(The_second_incorrect) = {7784834}
  -> Path208 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {6}
       эффект: P5(The first) = {2}
       эффект: P6(The second) = {4}
       эффект: P7(The third) = {2}
       эффект: P15(Truth table) = {8626842}
       эффект: P16(The_first_incorrect) = {3715135}
       эффект: P17(The_second_incorrect) = {1571371}

### Loc7 [пустая]
  -> Path210 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {7}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {7}
       эффект: P15(Truth table) = {8457326}
       эффект: P16(The_first_incorrect) = {5231537}
       эффект: P17(The_second_incorrect) = {6645278}
  -> Path214 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {8}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {7}
       эффект: P15(Truth table) = {8465346}
       эффект: P16(The_first_incorrect) = {3154837}
       эффект: P17(The_second_incorrect) = {7576271}
  -> Path216 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {9}
       эффект: P5(The first) = {1}
       эффект: P6(The second) = {5}
       эффект: P7(The third) = {7}
       эффект: P15(Truth table) = {8436237}
       эффект: P16(The_first_incorrect) = {4561583}
       эффект: P17(The_second_incorrect) = {1782872}
  -> Path218 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {10}
       эффект: P5(The first) = {4}
       эффект: P6(The second) = {7}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {1862385}
       эффект: P16(The_first_incorrect) = {4537213}
       эффект: P17(The_second_incorrect) = {7648154}
  -> Path220 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {11}
       эффект: P5(The first) = {4}
       эффект: P6(The second) = {7}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {4162837}
       эффект: P16(The_first_incorrect) = {1871362}
       эффект: P17(The_second_incorrect) = {7613524}
  -> Path222 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {12}
       эффект: P5(The first) = {4}
       эффект: P6(The second) = {7}
       эффект: P7(The third) = {5}
       эффект: P15(Truth table) = {6316727}
       эффект: P16(The_first_incorrect) = {3638135}
       эффект: P17(The_second_incorrect) = {4187246}
  -> Path223 => Loc8  вер=1 порядок=5
       эффект: P4(RULE) = {13}
       эффект: P5(The first) = {5}
       эффект: P6(The second) = {2}
       эффект: P7(The third) = {3}
       эффект: P15(Truth table) = {5476823}
       эффект: P16(The_first_incorrect) = {6527158}
       эффект: P17(The_second_incorrect) = {8745372}

### Loc8 [пустая]
  -> Path199 => Loc26  вер=1 порядок=5
       эффект: P18(Correct variant) = {[p15] div 1000000}
       эффект: P19(Incorrect_variant_one) = {[p16] div 1000000}
       эффект: P20(Incorrect_variant_two) = {[p17] div 1000000}

### Loc19 [обычная]
    выбор описания: {[p1]-1+([p47]=10)+2*([p45]=10)}
    Loc19-1: The score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |          E…
    Loc19-2: The score table appeared on the screen: / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |          ERRO…
    Loc19-3: The score table appeared on the screen: / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |          ERRO…
    Loc19-4: The score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |          E…
    Loc19-5: The score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |          E…
    эффект: P1(ROUND) +1
    эффект: P2(ERRORS) = {0}
    эффект: P5(The first) = {0}
    эффект: P6(The second) = {0}
    эффект: P7(The third) = {0}
    эффект: P8(The forth) = {0}
    эффект: P9(The fifth) = {0}
    эффект: P10(The sixth) = {0}
    эффект: P11(The seventh) = {0}
    эффект: P12(The eighth) = {0}
    эффект: P13(The ninth) = {0}
    эффект: P14(The tenth) = {0}
    эффект: P18(Correct variant) = {0}
    эффект: P19(Incorrect_variant_one) = {0}
    эффект: P20(Incorrect_variant_two) = {0}
    эффект: P21(Variant) = {0}
  -> Path153 => Loc4  вер=1 порядок=5
       текст: Go to play in the next round
       ответ: After you went through the electronic devices checking procedure again, you sat at your table and waited till the referee came and inserted the new disk into th…

### Loc21 [ПРОВАЛ]
    Loc21-1: When you returned to your ship, you wrote in your diary:  / "It's just not my day today. My luck was out but this is not the reason to get upset! I got through …

### Loc22 [УСПЕХ]
    выбор описания: {[p21]}
    Loc22-1: You approached O'Nyke and said: /  / - My congratulations, elunie O'Nyke!  You were at your best. Good for you. /  / Saying this you gripped his hand so hard th…
    Loc22-2: You shared the first place with the other participants! According to the old Faeyan tradition, the sportsmen were equally rewarded if they demonstrated the same…
    Loc22-3: You not only took the premier place but also made fewer errors than any other participant! / It hadn't happened in the history of Elus game for a long time alre…

### Loc26 [обычная]
    Loc26-1: There is a line of figures in front of you. There is a number of figures in the lower part of the screen including those you need to choose. Which figure will y…
  -> Path108 => Loc27  вер=1 порядок=5
       текст: Big blue circle
       условия: логика {([p18]=1) or ([p19]=1) or ([p20]=1)}
       эффект: P21(Variant) = {1}
  -> Path109 => Loc27  вер=1 порядок=5
       текст: Big blue lozenge
       условия: логика {([p18]=2) or ([p19]=2) or ([p20]=2)}
       эффект: P21(Variant) = {2}
  -> Path110 => Loc27  вер=1 порядок=5
       текст: Small blue circle
       условия: логика {([p18]=5) or ([p19]=5) or ([p20]=5)}
       эффект: P21(Variant) = {5}
  -> Path111 => Loc27  вер=1 порядок=5
       текст: Big yellow circle
       условия: логика {([p18]=3) or ([p19]=3) or ([p20]=3)}
       эффект: P21(Variant) = {3}
  -> Path112 => Loc27  вер=1 порядок=5
       текст: Big yellow lozenge
       условия: логика {([p18]=4) or ([p19]=4) or ([p20]=4)}
       эффект: P21(Variant) = {4}
  -> Path113 => Loc27  вер=1 порядок=5
       текст: Small blue lozenge
       условия: логика {([p18]=6) or ([p19]=6) or ([p20]=6)}
       эффект: P21(Variant) = {6}
  -> Path114 => Loc27  вер=1 порядок=5
       текст: Small yellow circle
       условия: логика {([p18]=7) or ([p19]=7) or ([p20]=7)}
       эффект: P21(Variant) = {7}
  -> Path115 => Loc27  вер=1 порядок=5
       текст: Small yellow lozenge
       условия: логика {([p18]=8) or ([p19]=8) or ([p20]=8)}
       эффект: P21(Variant) = {8}

### Loc27 [пустая]
  -> Path116 => Loc28  вер=1 порядок=5
       условия: логика {[p21]=[p18]}
  -> Path117 => Loc29  вер=1 порядок=5
       условия: логика {[p21]<>[p18]}

### Loc28 [пустая]
  -> Path118 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=6}
       эффект: P10(The sixth) = {[p21]}
  -> Path119 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=7}
       эффект: P11(The seventh) = {[p21]}
  -> Path120 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=8}
       эффект: P12(The eighth) = {[p21]}
  -> Path121 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=9}
       эффект: P13(The ninth) = {[p21]}
  -> Path122 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=10}
       эффект: P14(The tenth) = {[p21]}
  -> Path123 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=4}
       эффект: P8(The forth) = {[p21]}
  -> Path124 => Loc30  вер=1 порядок=5
       условия: логика {[p3]=5}
       эффект: P9(The fifth) = {[p21]}

### Loc29 [обычная]
    выбор описания: {[p2]}
    Loc29-1: - THIS IS YOUR <clr>FIRST<clrEnd> ERROR IN THIS ROUND! - the computer announced.
    Loc29-2: - THIS IS YOUR <clr>SECOND <clrEnd> ERROR IN THIS ROUND! - the computer announced.
    Loc29-3: - THIS IS YOUR <clr>THIRD<clrEnd> ERROR IN THIS ROUND! - the computer announced. - ANY MORE ERRORS AND YOU WILL BE DISQUALIFIED.
    Loc29-4: - THIS IS YOUR <clr>FORTH<clrEnd> ERROR! - the computer announced.  /  / The referee approached you and said: / - This is your forth error in the round! Accordi…
    эффект: P2(ERRORS) +1
  -> Path127 => Loc26  вер=1 порядок=5
       текст: Resume the game
       условия: P2(ERRORS) 0..3; логика {[p21]=[p19]}
       эффект: P19(Incorrect_variant_one) = {0}
  -> Path197 => Loc26  вер=1 порядок=5
       текст: Resume the game
       условия: P2(ERRORS) 0..3; логика {[p21]=[p20]}
       эффект: P20(Incorrect_variant_two) = {0}
  -> Path257 => Loc33  вер=1 проходов<=1 порядок=5
       текст: At least tell me what the rule was
       условия: P2(ERRORS) 4..4

### Loc30 [обычная]
    Loc30-1: You made the right choice and the figure moved to the end of the line.  /  / "What is next, I wonder?" - you thought.
    эффект: P3(Current number) +1
    эффект: P22(Degree) = {[p22]/10}
  -> Path125 => Loc26  вер=1 порядок=5
       условия: логика {[p3]<9}
       эффект: P18(Correct variant) = {([p15] div [p22])-(([p15] div ([p22]*10))*10)}
       эффект: P19(Incorrect_variant_one) = {([p16] div [p22])-(([p16] div ([p22]*10))*10)}
       эффект: P20(Incorrect_variant_two) = {([p17] div [p22])-(([p17] div ([p22]*10))*10)}
  -> Path196 => Loc39  вер=1 порядок=5
       условия: логика {[p3]=9}

### Loc32 [ПРОВАЛ]
    Loc32-1: On the way to the ship, all your thoughts were concentrated on two things. The first thing was that you should have paid more attention to your intellectual dev…

### Loc33 [пустая]
  -> Path198 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the other size <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[1]
  -> Path201 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the other colour <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[2]
  -> Path203 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the other type <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[3]
  -> Path205 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the same size <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[4]
  -> Path207 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the same colour <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[5]
  -> Path209 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>Choose a figure of the same type <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[6]
  -> Path211 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a blue one; if not, choose a yellow one <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[7]
  -> Path213 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a circle, if not, choose a figure of the same colour <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[14]
  -> Path215 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is blue, choose a circle; if not, choose a lozenge<clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[8]
  -> Path217 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is a circle, choose a small figure; if not, choose a big one <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[9]
  -> Path219 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a yellow figure; if not, choose a blue one <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[10]
  -> Path221 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is yellow, choose a circle; if not, choose a lozenge <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[11]
  -> Path224 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is a circle, choose a blue figure; if not, choose a yellow one <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[12]
  -> Path225 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a circle; if not, choose a lozenge<clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[13]
  -> Path229 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a blue figure; if not, choose a figure of the same type <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[15]
  -> Path230 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a blue figure; if not, choose a figure of different colour <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[16]
  -> Path231 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is blue, choose a big figure; if not, choose a figure of different type <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[17]
  -> Path235 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is big, choose a yellow figure; if not, choose a lozenge<clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[18]
  -> Path236 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is blue, choose a big figure; if not, choose a circle <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[19]
  -> Path237 => Loc34  вер=1 порядок=5
       ответ: - The rule said: "<clr>If the last figure is circle, choose a yellow figure; if not, choose a small one <clrEnd>", - the computer announced.
       условия: P4(RULE) ∈[20]

### Loc34 [пустая]
  -> Path238 => Loc41  вер=1 порядок=5
       условия: P2(ERRORS) 0..3; логика {[p1]=2}
       эффект: P25(O'Nyke) = {[p25]+10*[-2..1]}
       эффект: P26(Eo) = {[p26]+10*[0..2]}
       эффект: P27(Loon) = {[p27]+10*[0..2]}
       эффект: P28(Ellinar) = {[p28]+10*[0..2]}
       эффект: P29(Crocus) = {[p29]+10*[0..3]}
       эффект: P30(Mocus) = {[p30]+10*[0..3]}
       эффект: P31(Phocus) = {[p31]+10*[0..3]}
       эффект: P32(Bliuk) = {[p32]+10*[0..3]}
       эффект: P33(Gliuk) = {[p33]+10*[1..3]}
       эффект: P34(Agaric) = {[p34]+10*[1..3]}
       эффект: P35(Clod) = {[p35]+10*[1..3]}
       эффект: P36(Player) = {[p36]+10*[p2]}
  -> Path252 => Loc41  вер=1 порядок=5
       условия: P2(ERRORS) 0..3; логика {[p1]=1}
       эффект: P26(Eo) = {[p26]+100*[-3..1]}
       эффект: P27(Loon) = {[p27]+100*[-2..1]}
       эффект: P28(Ellinar) = {[p28]+100*[-2..1]}
       эффект: P29(Crocus) = {[p29]+100*[-1..1]}
       эффект: P30(Mocus) = {[p30]+100*[-1..1]}
       эффект: P31(Phocus) = {[p31]+100*[-1..1]}
       эффект: P32(Bliuk) = {[p32]+100*[0..1]}
       эффект: P33(Gliuk) = {[p33]+100*[0..1]}
       эффект: P34(Agaric) = {[p34]+100*[0..1]}
       эффект: P35(Clod) = {[p35]+100*[0..2]}
       эффект: P36(Player) = {[p36]+100*[p2]}
  -> Path255 => Loc41  вер=1 порядок=5
       условия: P2(ERRORS) 0..3; логика {[p1]=3}
       эффект: P25(O'Nyke) = {[p25]+[0..1]}
       эффект: P26(Eo) = {[p26]+[0..3]}
       эффект: P27(Loon) = {[p27]+[0..3]}
       эффект: P28(Ellinar) = {[p28]+[0..3]}
       эффект: P29(Crocus) = {[p29]+[0..3]}
       эффект: P30(Mocus) = {[p30]+[0..3]}
       эффект: P31(Phocus) = {[p31]+[1..3]}
       эффект: P32(Bliuk) = {[p32]+[1..3]}
       эффект: P33(Gliuk) = {[p33]+[1..3]}
       эффект: P34(Agaric) = {[p34]+[1..3]}
       эффект: P35(Clod) = {[p35]+[2..3]}
       эффект: P36(Player) = {[p36]+[p2]}
  -> Path258 => Loc32  вер=1 порядок=5
       условия: P2(ERRORS) 4..4

### Loc38 [обычная]
    выбор описания: {1+([p47]=10)+2*([p45]=10)+4*([p46]=10)}
    Loc38-1: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-2: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-3: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-4: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-5: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-6: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-7: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
    Loc38-8: The final score table appeared on the screen: /  / <fix> / ----------------------------------------------------- / <format=left,17>PARTICIPANTS</format>  |     …
  -> Path168 => Loc21  вер=1 порядок=6
       текст: You lost! Return to the spaceport
       условия: P23(Player's place) 2..10
  -> Path169 => Loc22  вер=1 порядок=5
       текст: Elunie O'Nyke is a sole winner!!! Congratulate him
       условия: логика {([p23]=2) and ([p37]<[p38]) and ([p37]<[p39]) and ([p37]<[p40]) and ([p37]<[p41]) and ([p37]<[p42]) and ([p37]<[p43]) and ([p37]<[p44]) and ([p37]<[p45]) and ([p37]<[p46]) and ([p37]<[p47])}
       эффект: P21(Variant) = 1
  -> Path248 => Loc22  вер=1000 порядок=5
       текст: You won!!!
       условия: логика {([p23]=1) and ([p48]<[p38]) and ([p48]<[p39]) and ([p48]<[p40]) and ([p48]<[p41]) and ([p48]<[p42]) and ([p48]<[p43]) and ([p48]<[p44]) and ([p48]<[p45]) and ([p48]<[p46]) and ([p48]<[p47]) and ([p48]<[p37])}
       эффект: P21(Variant) = 3
       эффект: P24(Money) = {[p24]+1000}
  -> Path256 => Loc22  вер=1 порядок=5
       текст: You won!!!
       условия: логика {[p23]=1}
       эффект: P21(Variant) = 2

### Loc39 [обычная]
    Loc39-1: - No more place in the line, - the computer announced.
  -> Path194 => Loc33  вер=1 порядок=5
       текст: Excellent! And what was the rule?

### Loc40 [обычная] визитов<=1
    Loc40-1: - No problem, - Max said. - "Choose a figure of the same colour as the last one in the line", "Choose a figure of a different colour ", "If the last figure is y…
  -> Path251 => Loc3  вер=1 проходов<=1 порядок=9
       текст: Say good-bye to Max and have a rest

### Loc41 [пустая]
    эффект: P37(O'Nyke+) = {([p25] div 100)+(([p25] div 10) mod 10)+([p25] mod 10)}
    эффект: P38(Eo+) = {([p26] div 100)+(([p26] div 10) mod 10)+([p26] mod 10)}
    эффект: P39(Loon+) = {([p27] div 100)+(([p27] div 10) mod 10)+([p27] mod 10)}
    эффект: P40(Ellinar+) = {([p28] div 100)+(([p28] div 10) mod 10)+([p28] mod 10)}
    эффект: P41(Crocus+) = {([p29] div 100)+(([p29] div 10) mod 10)+([p29] mod 10)}
    эффект: P42(Mocus+) = {([p30] div 100)+(([p30] div 10) mod 10)+([p30] mod 10)}
    эффект: P43(Phocus+) = {([p31] div 100)+(([p31] div 10) mod 10)+([p31] mod 10)}
    эффект: P44(Bliuk+) = {([p32] div 100)+(([p32] div 10) mod 10)+([p32] mod 10)}
    эффект: P45(Gliuk+) = {([p33] div 100)+(([p33] div 10) mod 10)+([p33] mod 10)+10*[0..1]*([p1]>1)+10*([p45]=10)}
    эффект: P46(Agaric+) = {([p34] div 100)+(([p34] div 10) mod 10)+([p34] mod 10)+10*[0..1]*([p1]=3)}
    эффект: P47(Clod+) = {([p35] div 100)+(([p35] div 10) mod 10)+([p35] mod 10)+10*[0..1]*([p1]>1)+10*([p47]=10)}
    эффект: P48(Player+) = {([p36] div 100)+(([p36] div 10) mod 10)+([p36] mod 10)}
  -> Path247 => Loc38  вер=1 порядок=5
       условия: P1(ROUND) 3..4
       эффект: P23(Player's place) = {1+([p48]>[p47])+([p48]>[p46])+([p48]>[p45])+([p48]>[p44])+([p48]>[p43])+([p48]>[p42])+([p48]>[p41])+([p48]>[p40])+([p48]>[p39])+([p48]>[p38])+([p48]>[p37])}
  -> Path253 => Loc19  вер=1 порядок=5
       условия: P1(ROUND) 1..2
       эффект: P23(Player's place) = {1+([p48]>[p47])+([p48]>[p46])+([p48]>[p45])+([p48]>[p44])+([p48]>[p43])+([p48]>[p42])+([p48]>[p41])+([p48]>[p40])+([p48]>[p39])+([p48]>[p38])+([p48]>[p37])}

## Анализ
- стартовых: [1]
- концовки: {21: 'ПРОВАЛ', 22: 'УСПЕХ', 32: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
