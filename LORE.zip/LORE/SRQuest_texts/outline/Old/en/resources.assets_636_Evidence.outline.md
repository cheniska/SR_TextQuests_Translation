# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Time' [0..80] тип=провал
    старт: [0]
    [0..80] Time remaining: <> min.
    критическое: You were so deeply engrossed in fulfilling your secret mission that you didn't notice that you excee…
- P2 'Money' [0..10001] тип=обычный деньги
    старт: [0]
    [0..10001] Your savings: <> cr.
    критическое: Сообщение достижения критического значения параметром 4
- P3 'Narcotics' [0..5] тип=обычный
    старт: [0]
    [0..0] Planted <> out of 5 packages
    [1..1] Planted <> out of 5 packages
    [2..5] Planted <> out of 5 packages
    критическое: Сообщение достижения критического значения параметром 2
- P4 'Separator' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 5
- P5 'You have' [0..1] тип=обычный
    старт: [0]
    [0..1] Inventory:
    критическое: Сообщение достижения критического значения параметром 3
- P6 'Magazine' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Girly magazine
    [2..2] 
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Towel' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Dirty towel
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Glue' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Tube of glue
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Screwdriver' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Screwdriver
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Key' [0..1] тип=обычный
    старт: [0]
    [0..0] Key to entrance door
    [1..1] 
    критическое: Сообщение достижения критического значения параметром 47
- P11 'Knock down the door with your shoulder' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 11
- P12 'tmp' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 12
- P20 'Writing on the wall' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Painting on the wall' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Room-by-room results' [0..100] тип=обычный
    старт: [0]
    [0..100] total <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'The grate is broken' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Took a dip' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Alcohol' [0..4] тип=провал
    старт: [0]
    [0..4] 
    критическое: You were so enthralled with testing the narcotics that you lost control and overdosed.  / Then you w…
- P26 'Buried in a vase' [0..2] тип=обычный
    старт: [0]
    [0..2] 
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Take the money' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 27
- P30 'Code 1' [0..9999] тип=обычный
    старт: [0]
    [0..9999] First code: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Code 2' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Second code: <>
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Code 3' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Third code: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'Broken boot' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Puddle by the aquarium' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 35
- P35 'Too difficult' [0..30] тип=обычный
    старт: [0]
    [0..30] 
    критическое: Сообщение достижения критического значения параметром 34
- P36 'Too simple' [0..30] тип=обычный
    старт: [0]
    [0..30] 
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Critical damage' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Evidence in the stereovision' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Turned the TV on' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 39
- P42 'gloves' [0..1] тип=обычный
    старт: [0]
    [0..0] The gloves are on
    [1..1] The gloves are not on
    критическое: Сообщение достижения критического значения параметром 42
- P43 'shoe booties' [0..1] тип=обычный
    старт: [0]
    [0..0] The shoe booties are on
    [1..1] The shoe booties are not on
    критическое: Сообщение достижения критического значения параметром 43
- P44 'Number of attempts at unlocking' [0..5] тип=обычный
    старт: [0]
    [0..5] 
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Code number sequence' [0..5] тип=обычный
    старт: [0]
    [0..5] 
    критическое: Сообщение достижения критического значения параметром 45
- P46 'Correct code' [0..9999] тип=обычный
    старт: [0]
    [0..9999] 
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Range of possible codes' [0..3] тип=обычный
    старт: [0]
    [0..3] Option number <>
    критическое: Сообщение достижения критического значения параметром 10
- P48 'Lock location' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You landed at the spaceport of the planet's moon, in the very center of an enormous gigopolis made of plastic and concrete. Gigantic skyscrapers rise above your…
    эффект: P1(Time) = 70 [скрыт]
    эффект: P10(Key) = 1 [скрыт]
    эффект: P12(tmp) = 0 [скрыт]
    эффект: P28(Правильный код стола (не нужен)) = 0 [скрыт]
    эффект: P29(Правильный код спальни (не нужен)) = {0}
    эффект: P30(Code 1) = 3282 [скрыт]
    эффект: P31(Code 2) = 1234 [скрыт]
    эффект: P32(Code 3) = 5555 [скрыт]
    эффект: P42(gloves) = 1 [скрыт]
    эффект: P43(shoe booties) = 1 [скрыт]
    эффект: P46(Correct code) = 0 [скрыт]
    скрыт: P2,P3,P4,P5,P11,P20,P21,P22,P23,P24,P25,P26,P27,P33,P34,P35,P36,P37,P38,P39,P40,P44,P45,P47,P48
  -> Path2 => Loc2  вер=1 порядок=5
       текст: Go meet the politician

### Loc2 [обычная]
    выбор описания: {[p12]+1}
    Loc2-1: You got out of the taxi when it brought you to the address which your employer had given you. An intermediary should meet you here somewhere. / "Are you <Ranger…
    Loc2-2: The fae silently raised his hand and his sleeve dropped to reveal an intricate electronic bracelet. / "If I get within a hundred meters of him or his apartment,…
    эффект: P10(Key) = 0
    показ: P5,P30,P31,P32,P46
  -> Path3 => Loc3  вер=1 порядок=5
       текст: I can handle it!
  -> Path4 => Loc136  вер=1 проходов<=1 порядок=5
       текст: If you're so well trained, why don't you do it yourself?
       эффект: P12(tmp) = 1
  -> Path78 => Loc31  вер=1 порядок=5
       текст: You know something? I've changed my mind. I don't like all this. I think I'll decline to fulfill the mission.

### Loc3 [обычная]
    Loc3-1: You took the elevator up to the required floor and, trying to look natural, peered out. Directly in front of you was a small hallway with an impressive door on …
    Loc3-2: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-3: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-4: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-5: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-6: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-7: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-8: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-9: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    Loc3-10: You are standing in front of the closed door. It would be great to open it, so you can go inside.
    показ: P1,P2,P4,P5,P10,P42
  -> Path5 => Loc5  вер=1 проходов<=1 порядок=9
       текст: Break down the door with your shoulder
       условия: P11(Knock down the door with your shoulder) 0..0
       эффект: P1(Time) -5
       эффект: P11(Knock down the door with your shoulder) = 1
  -> Path6 => Loc4  вер=1
       текст: Use the key
       эффект: P10(Key) = 1 [скрыт]
  -> Path95 => Loc36  вер=1 порядок=5
       текст: Put on the gloves
       условия: P42(gloves) 1..1
       эффект: P42(gloves) = 0

### Loc4 [обычная]
    Loc4-1: You put the key the intermediary gave you into the keyhole and turned it once, and then once again. Something clicked inside and the combination lock's screen i…
  -> Path8 => Loc131  вер=1 порядок=5
       текст: Enter the code to open the door
       эффект: P47(Range of possible codes) = {[1..3]}
       эффект: P48(Lock location) = 1

### Loc5 [обычная]
    Loc5-1: You took a running start and plowed into the door with all your might. It stood firm, but your shoulder ached for some reason. You kicked and poked the door a b…
  -> Path7 => Loc4  вер=1 проходов<=1 порядок=5
       текст: Use the key
       эффект: P10(Key) = 0 [скрыт]
  -> Path351 => Loc36  вер=1 порядок=5
       текст: Put on the gloves
       условия: P42(gloves) 1..1
       эффект: P42(gloves) = 0

### Loc12 [обычная]
    Loc12-1: "Problems?" asked the fae, looking at you. "I didn't say anything about problems. I'm surprised how clean you were. Most of the things were in their places, acc…
  -> Path305 => Loc125  вер=1 порядок=5
       текст: What about the evidence?
       условия: P35(Too difficult) 0..4; P36(Too simple) 0..4
  -> Path311 => Loc128  вер=1 порядок=5
       текст: What about the evidence?
       условия: P35(Too difficult) 5..30
  -> Path314 => Loc129  вер=1 порядок=5
       текст: What about the evidence?
       условия: P36(Too simple) 5..30

### Loc13 [обычная]
    выбор описания: {1*([p42] in [0] and [p43] in [0])+2*([p42] in [1] and [p43] in [0])+3*([p42] in [0] and [p43] in [1])+4*([p42] in [1] and [p43] in [1])}
    Loc13-1: Of course, you didn't forget to remove the gloves and stuff them in the pocket of your ranger uniform and take the booties off of your shoes, although you only …
    Loc13-2: Of course, you didn't forget to remove the booties from your feet - but you didn't do it right away either. /  / Now you have to wait a couple of hours until th…
    Loc13-3: Of course, you didn't forget to take the gloves off and stuff them into the pocket of your ranger uniform. /  / Now you have to wait a couple of hours until the…
    Loc13-4: Now you have to wait a couple of hours until the forces of law and order strike the apartment and discover your illegal handiwork. /  / You strolled to the near…
    эффект: P22(Room-by-room results) = {[p6]+[p7]+[p8]+[p9]+[p20]+[p21]+[p23]+[p26]+[p27]+[p33]+[p34]+[p39]}
  -> Path301 => Loc111  вер=1 порядок=5
       текст: Were there problems?
       условия: логика {[p42]=1 or [p43]=1 or [p10]=1}
  -> Path302 => Loc109  вер=1 порядок=5
       текст: Were there problems?
       условия: P22(Room-by-room results) 3..4; логика {[p42]=0 and [p43]=0 and [p10]=0}
  -> Path303 => Loc108  вер=1 порядок=5
       текст: Were there problems?
       условия: P22(Room-by-room results) 5..100; логика {[p42]=0 and [p43]=0 and [p10]=0}
  -> Path304 => Loc12  вер=1 порядок=5
       текст: Were there problems?
       условия: P22(Room-by-room results) 0..2

### Loc15 [обычная]
    Loc15-1: You tested the door, pulling it toward yourself, and - miracle of miracles - it opened! The way into the apartment is clear!
    эффект: P28(Правильный код стола (не нужен)) = 0
    эффект: P29(Правильный код спальни (не нужен)) = 0
    эффект: P44(Number of attempts at unlocking) = 0
    эффект: P45(Code number sequence) = 0
    эффект: P46(Correct code) = 0
    эффект: P48(Lock location) = 0
    показ: P3,P43
  -> Path65 => Loc19  вер=1 порядок=4
       текст: Go into the apartment
       эффект: P1(Time) -2
       скрыт: P30,P31,P32
  -> Path97 => Loc37  вер=1 порядок=5
       текст: Put on the booties
       эффект: P43(shoe booties) = 0
       скрыт: P30,P31,P32

### Loc16 [обычная]
    Loc16-1: Unfortunately, the lock didn't open and your efforts were in vain. Clearly, you entered the wrong code. / You need to enter a different code.
    эффект: P1(Time) -3
  -> Path64 => Loc18  вер=1 порядок=5
       текст: Try again
       условия: P44(Number of attempts at unlocking) 3..5
  -> Path336 => Loc131  вер=1 порядок=5
       текст: Try a different code
       условия: P44(Number of attempts at unlocking) 0..2
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
  -> Path349 => Loc47  вер=1 порядок=5
       текст: Leave the lock alone
       условия: P48(Lock location) 2..2
       эффект: P48(Lock location) = 0
       эффект: P44(Number of attempts at unlocking) = 0
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
       скрыт: P30,P31,P32
  -> Path350 => Loc23  вер=1 порядок=5
       текст: Leave the lock alone
       условия: P48(Lock location) 3..3
       эффект: P48(Lock location) = 0
       эффект: P44(Number of attempts at unlocking) = 0
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
       скрыт: P30,P31,P32

### Loc18 [ПРОВАЛ]
    выбор описания: {1+1*([p48]=2)+2*([p48]=3)}
    Loc18-1: Unfortunately, after the third incorrect attempt an alarm built into the lock was activated, and after a minute your loneliness in the hallway was brightened by…
    Loc18-2: Unfortunately, after the third incorrect attempt an alarm built into the safe was secretly activated, and after a minute your loneliness in the living room was …
    Loc18-3: Unfortunately, after the third incorrect attempt an alarm built into the lock on the wall was secretly activated, and after a minute your loneliness in the bedr…
    скрыт: P1,P3

### Loc19 [обычная]
    выбор описания: {1*([p3]<5 and [p12]<3)+2*([p3] in [5] and [p12]<3)+3*([p12]=3)}
    Loc19-1: You are in the hallway of a small - galactically speaking - apartment. The bathroom door adjoins the hallway nearby. A bit farther, on the opposite side, is a d…
    Loc19-2: You are in the hallway of a small - galactically speaking - apartment. The bathroom door adjoins the hallway nearby. A bit farther, on the opposite side, is a d…
    Loc19-3: Unfortunately, your saliva didn't have a miraculous effect on the boot and the heel didn't stick. Then you carefully put the shoes in their place and closed the…
  -> Path66 => Loc20  вер=1
       текст: Peek into the bathroom
       эффект: P1(Time) -1
       эффект: P12(tmp) = 0
  -> Path67 => Loc21  вер=1 порядок=1
       текст: Go to the kitchen
       эффект: P1(Time) -1
       эффект: P12(tmp) = 0
  -> Path68 => Loc24  вер=1 порядок=2
       текст: Go farther down the hallway
       эффект: P1(Time) -3
       эффект: P12(tmp) = 0
  -> Path94 => Loc35  вер=1 порядок=9
       текст: Leave the apartment
       условия: P3(Narcotics) 5..5
  -> Path139 => Loc58  вер=1 порядок=3
       текст: Look in the cabinet
       эффект: P1(Time) -2
       эффект: P12(tmp) = 0
  -> Path149 => Loc63  вер=1 порядок=9
       текст: Leave the apartment
       условия: P3(Narcotics) 0..4

### Loc20 [обычная]
    выбор описания: {1+1*([p23]=1)}
    Loc20-1: A special feature of the landscape in this residence is the Jacuzzi. The far side is barely visible with the naked eye, and a sign by the steps warns "No swimmi…
    Loc20-2: A special feature of the landscape in this residence is the Jacuzzi. The far side is barely visible with the naked eye, and a sign by the steps warns "No swimmi…
  -> Path73 => Loc26  вер=1
       текст: Inspect the Jacuzzi
       эффект: P1(Time) -2
  -> Path80 => Loc19  вер=1 порядок=9
       текст: Go into the hallway
       эффект: P1(Time) -1
  -> Path179 => Loc76  вер=1 порядок=1
       текст: Examine the toilet
       эффект: P1(Time) -2
  -> Path180 => Loc77  вер=1 порядок=4
       текст: Rummage through the clothing
       эффект: P1(Time) -3
  -> Path181 => Loc78  вер=1 порядок=3
       текст: Inspect the shelf with the cosmetics
       эффект: P1(Time) -3
  -> Path182 => Loc79  вер=1 порядок=5
       текст: Approach the ventilation hole
       условия: P3(Narcotics) 0..4
  -> Path183 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Throw a package on the floor
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +3

### Loc21 [обычная]
    Loc21-1: Everything in the kitchen shines with its original whiteness. There aren't any slightly burned eggs on the stove or stains from coffee that boiled over. Apparen…
  -> Path74 => Loc27  вер=1
       текст: Look at the stove
       эффект: P1(Time) -2
  -> Path79 => Loc19  вер=1 порядок=9
       текст: Go into the hallway
       эффект: P1(Time) -1
  -> Path185 => Loc81  вер=1 порядок=3
       текст: Rummage through the cabinets
       эффект: P1(Time) -3
  -> Path186 => Loc82  вер=1 порядок=2
       текст: See what's in the refrigerator
       эффект: P1(Time) -2
  -> Path187 => Loc83  вер=1 порядок=1
       текст: Play around with the food processor
       эффект: P1(Time) -1
  -> Path188 => Loc84  вер=1 проходов<=1 порядок=4
       текст: Throw a package into the kitchen
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +3

### Loc22 [обычная]
    Loc22-1: You are in the living room. The center of the room, which is the size of a hatchball field, is plainly empty. On the right is a wall unit with three sections: a…
  -> Path75 => Loc28  вер=1 порядок=3
       текст: Examine the stereovision
       эффект: P1(Time) -1
  -> Path82 => Loc24  вер=1 порядок=9
       текст: Go into the hallway
       эффект: P1(Time) -1
  -> Path115 => Loc46  вер=1
       текст: Examine the cabinets
       эффект: P1(Time) -1
  -> Path116 => Loc47  вер=1 порядок=1
       текст: Take on the work table
       эффект: P1(Time) -2
  -> Path121 => Loc49  вер=1 проходов<=1 порядок=5
       текст: Throw a package into the middle of the room
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +3

### Loc23 [обычная]
    выбор описания: {1*([p21]=0 and [p12]<3)+2*([p21]=1 and [p12]<3)+3*([p12]=3)}
    Loc23-1: You are in the bedroom. The room is almost empty, holding only a wide bed on the far wall and an aquarium - large enough to accommodate your entire ship - with …
    Loc23-2: You are in the bedroom. The room is almost empty, holding only a wide bed on the far wall and an aquarium - large enough to accommodate your entire ship - with …
    Loc23-3: You had just stepped across the threshold when some built-in machinery slammed the door shut, nearly catching your heel. The only thing that saved you was your …
  -> Path76 => Loc29  вер=1
       текст: Study the bed
       эффект: P1(Time) -2
       эффект: P12(tmp) = 0
  -> Path81 => Loc24  вер=1 порядок=9
       текст: Go into the hallway
       эффект: P1(Time) -1
       эффект: P12(tmp) = 0
  -> Path89 => Loc33  вер=1 порядок=1
       текст: Inspect aquarium
       эффект: P1(Time) -1
       эффект: P12(tmp) = 0
  -> Path92 => Loc34  вер=1 порядок=3
       текст: Walk along the perimeter
       эффект: P1(Time) -3
       эффект: P12(tmp) = 0
  -> Path104 => Loc40  вер=1 проходов<=1 порядок=4
       текст: Throw a package into the middle of the room
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P12(tmp) = 0
       эффект: P34(Puddle by the aquarium) +50
       эффект: P36(Too simple) +3
  -> Path135 => Loc56  вер=1 порядок=2
       текст: Look at the painting
       условия: P21(Painting on the wall) 0..0
       эффект: P12(tmp) = 0
  -> Path289 => Loc114  вер=1 порядок=2
       текст: Hang the painting back where it was
       условия: P21(Painting on the wall) 1..1
       эффект: P12(tmp) = 0

### Loc24 [обычная]
    выбор описания: {1+1*([p26] in [2])}
    Loc24-1: You are at the far end of the hallway. In the end wall, directly in front of you, there is an enormous panoramic window with a view of the city. In front of the…
    Loc24-2: You are at the far end of the hallway. In the end wall, directly in front of you, there is an enormous panoramic window with a view of the city. In front of the…
  -> Path69 => Loc22  вер=1
       текст: Go into the living room
       эффект: P1(Time) -1
  -> Path70 => Loc23  вер=1 порядок=1
       текст: Check on the bedroom
       эффект: P1(Time) -1
  -> Path71 => Loc19  вер=1 порядок=9
       текст: Go back to the front door
       эффект: P1(Time) -3
  -> Path77 => Loc30  вер=1 порядок=4
       текст: Inspect the vase with the plant
       эффект: P1(Time) -2
  -> Path177 => Loc75  вер=1 проходов<=1 порядок=3
       текст: Look out the window
       эффект: P1(Time) -10
  -> Path193 => Loc86  вер=1 порядок=5
       текст: Wipe the dirty floor
       условия: P7(Towel) 1..1; P26(Buried in a vase) 2..2
       эффект: P1(Time) -5

### Loc25 [обычная]
    Loc25-1: "Evidence" quest by ru_ND.  / June-July 2011 (finale: April 2012) /  / Testers: / Bret / Bercut  / Leo-san /  /  / Good luck, have fun! Kisses to all!

### Loc26 [обычная]
    Loc26-1: The far side of the Jacuzzi is hidden by a dense fog. You can hear seagulls crying shrilly and the water splashing rhythmically against the side. This is no ord…
  -> Path72 => Loc32  вер=3 проходов<=1 порядок=3
       текст: Take a bath
       условия: P24(Took a dip) 0..0
       эффект: P1(Time) -5
       эффект: P24(Took a dip) = 1
  -> Path88 => Loc20  вер=1 порядок=6
       текст: Stop looking around
  -> Path222 => Loc96  вер=1 проходов<=1 порядок=5
       текст: Take a bath
       условия: P24(Took a dip) 0..0
       эффект: P1(Time) -20
       эффект: P24(Took a dip) = 1

### Loc27 [обычная]
    Loc27-1: A solitary lamp is on inside, and there are no signs of food.
  -> Path87 => Loc21  вер=1 порядок=5
       текст: Leave the stove

### Loc28 [обычная]
    выбор описания: {1+1*([p39] in [1])}
    Loc28-1: The gray bulk of some technological wonder hangs threateningly above you. It would be best to watch tennis from a couple of kilometers away. Otherwise, it's hig…
    Loc28-2: A technological wonder hangs threateningly above you, with gigawatt speakers and the ability to display every color of the rainbow. It would be best to watch te…
  -> Path86 => Loc22  вер=1 порядок=9
       текст: Look around the room again
  -> Path124 => Loc51  вер=1 порядок=5
       текст: Turn on the stereovision
       условия: P39(Turned the TV on) 0..0
       эффект: P1(Time) -2
       эффект: P39(Turned the TV on) = 1
  -> Path131 => Loc53  вер=1 порядок=9
       текст: Turn off the stereovision
       условия: P39(Turned the TV on) 1..1
       эффект: P1(Time) -1
       эффект: P39(Turned the TV on) = 0
  -> Path132 => Loc55  вер=1 порядок=5
       текст: Hide a package in the stereovision
       ответ: Trying not to break the expensive device, you carefully pushed it a little to gain access to the rear panel. Then unfastened the latches holding the panel and m…
       условия: P3(Narcotics) 0..4; P38(Evidence in the stereovision) 0..0; P39(Turned the TV on) 0..0
       эффект: P1(Time) -10
       эффект: P3(Narcotics) +1
       эффект: P38(Evidence in the stereovision) +1
       эффект: P35(Too difficult) +1
  -> Path134 => Loc55  вер=1 порядок=5
       текст: Hide a package in the stereovision
       ответ: Trying not to break the expensive device, you carefully pushed it a little to gain access to the rear panel. Then unfastened the latches holding the panel and m…
       условия: P3(Narcotics) 0..4; P38(Evidence in the stereovision) 0..0; P39(Turned the TV on) 1..1
       эффект: P1(Time) -20
       эффект: P3(Narcotics) +1
       эффект: P38(Evidence in the stereovision) +1
       эффект: P35(Too difficult) +1

### Loc29 [обычная]
    выбор описания: {1+1*([p6] in [1])}
    Loc29-1: The politician's bed is big - no, huge - with at least a dozen pillows. If you wanted to you could arrange a party on it with thirty girls at once, but then you…
    Loc29-2: The politician's bed is big - no, huge - with at least a dozen pillows. If you wanted to you could arrange a party on it with thirty girls at once, but then you…
  -> Path85 => Loc23  вер=1 порядок=9
       текст: Look around the room again.
  -> Path106 => Loc41  вер=1 проходов<=1 порядок=5
       текст: Hide a package under the pillow
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -3
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1
  -> Path108 => Loc41  вер=1 проходов<=1 порядок=5
       текст: Stuff a package behind the head of the bed
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -3
       эффект: P3(Narcotics) +1
  -> Path109 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Lie down on the bed for a while
  -> Path240 => Loc103  вер=1 порядок=5
       текст: Examine the magazine
       условия: P6(Magazine) 0..0
  -> Path243 => Loc41  вер=1 порядок=5
       текст: Put the magazine back
       условия: P6(Magazine) 1..2
       эффект: P6(Magazine) = 0

### Loc30 [обычная]
    Loc30-1: With its sprawling plant decked out with pink, aromatic flowers , the square vase looks more like the base of some futuristic monument. The soil in the vase is …
  -> Path84 => Loc24  вер=1 порядок=9
       текст: Leave the plant alone
  -> Path190 => Loc85  вер=1 проходов<=1
       текст: Hide a package by covering it lightly with soil
       условия: P3(Narcotics) 0..4; P26(Buried in a vase) 0..0
       эффект: P1(Time) -4
       эффект: P3(Narcotics) +1
       эффект: P26(Buried in a vase) = 1
       эффект: P36(Too simple) +1
  -> Path192 => Loc130  вер=1 проходов<=1 порядок=1
       текст: Hide a package by burying it a deeply as possible
       условия: P3(Narcotics) 0..4; P26(Buried in a vase) 0..0
       эффект: P1(Time) -15
       эффект: P3(Narcotics) +1
       эффект: P26(Buried in a vase) = 2
       эффект: P35(Too difficult) +1
  -> Path210 => Loc93  вер=1 проходов<=4 порядок=3
       текст: Smell the flowers
       эффект: P1(Time) -1

### Loc31 [ПРОВАЛ]
    Loc31-1: The fae shrugged his shoulders indifferently. / "Fine, have it your way. I'm sure you don't need to be warned to keep all of this confidential." / You looked hi…

### Loc32 [обычная] визитов<=1
    Loc32-1: You quickly undressed and plopped into the warm water. True, you couldn't find where to turn on the bubbles, so you had to manage without them.
  -> Path223 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Get back to work

### Loc33 [обычная]
    выбор описания: {1+1*([p34]=1)}
    Loc33-1: An enormous mass of water is miraculously held back by a thin pane of glass. Behind the glass, water plants sway and various kinds of fish swim about. Somewhere…
    Loc33-2: An enormous mass of water is miraculously held back by a thin pane of glass. Behind the glass, water plants sway and various kinds of fish swim about. Somewhere…
  -> Path91 => Loc23  вер=1 порядок=9
       текст: Look around the room again
  -> Path111 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Knock on the glass
       эффект: P1(Time) -3
       эффект: P34(Puddle by the aquarium) = 1
  -> Path113 => Loc45  вер=1 проходов<=1 порядок=5
       текст: Throw a package into the aquarium
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P35(Too difficult) +2
  -> Path137 => Loc57  вер=1 порядок=5
       текст: Wipe the dirty floor
       условия: P7(Towel) 1..1; P34(Puddle by the aquarium) 1..1
       эффект: P1(Time) -3

### Loc34 [обычная]
    Loc34-1: You walked about the entire room, but could not find any place that rags might be stored. Blasted asceticism!
  -> Path93 => Loc23  вер=1 порядок=9
       текст: Look around the room again

### Loc35 [обычная]
    Loc35-1: Okay, all five packages with the evidence are hidden and now all you can do is hope that they are hidden well. It's time to get out of here. / You stuck your no…
  -> Path99 => Loc13  вер=1 порядок=5
       текст: Clear out quickly
  -> Path100 => Loc38  вер=1
       текст: Remove the key from the door
       эффект: P10(Key) = 0 [показ]
       эффект: P41(неактивный параметр) = 0

### Loc36 [обычная]
    Loc36-1: Remembering that forensic science had reached unprecedented heights by the thirty fourth century, you put on the gloves the fae had given you. Now you can start…
  -> Path96 => Loc4  вер=1 порядок=5
       текст: Use the key
       эффект: P10(Key) = 1 [скрыт]
  -> Path271 => Loc5  вер=1 порядок=9
       текст: Break down the door with your shoulder
       условия: P11(Knock down the door with your shoulder) 0..0
       эффект: P11(Knock down the door with your shoulder) = 1

### Loc37 [обычная]
    Loc37-1: You carefully pulled the transparent booties onto your fashionable ranger shoes in order to avoid leaving tracks in the apartment. But nobody will see you while…
  -> Path98 => Loc19  вер=1 порядок=5
       текст: Go into the apartment
       эффект: P1(Time) -2

### Loc38 [обычная]
    Loc38-1: If the key were left in the keyhole, at best it would look weird - it couldn't have just grown there, right? So you pulled it a bit farther out of harm's way an…
  -> Path101 => Loc13  вер=1 порядок=5
       текст: Clear out quickly

### Loc40 [пустая] визитов<=1
  -> Path105 => Loc23  вер=1 проходов<=1 порядок=5

### Loc41 [пустая]
  -> Path107 => Loc29  вер=1 порядок=5

### Loc42 [обычная] визитов<=1
    Loc42-1: You decided to see what it's like to lay down on such a bourgeois bed. It turned about to be not bad at all. Soft, comfy, soothing...relaxing... /  / Your sharp…
    эффект: P1(Time) -20
  -> Path110 => Loc23  вер=1 проходов<=1 порядок=9
       текст: Get back to work

### Loc43 [обычная] визитов<=1
    Loc43-1: You drummed your fingers for a while on the glass to get the fishes' attention. It would have been better if you hadn't. In response to your knocking, from some…
  -> Path112 => Loc33  вер=1 порядок=6
       текст: Step back farther, just in case
  -> Path136 => Loc57  вер=1 порядок=5
       текст: Wipe up the water on the floor
       условия: P7(Towel) 1..1
       эффект: P1(Time) -3

### Loc45 [обычная] визитов<=1
    Loc45-1: You climbed to the top on a special attached ladder, moved a small cover aside and threw a package of evidence into the dark water. You hadn't managed to climb …
  -> Path114 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Get down on the floor

### Loc46 [обычная]
    Loc46-1: A wall unit with three sections towers above you like a mountain peak and you, like a knight at a crossroads, are deciding which section to take.
  -> Path118 => Loc22  вер=1 порядок=9
       текст: Look around the room again
  -> Path174 => Loc72  вер=1
       текст: Look at the books
       эффект: P1(Time) -3
  -> Path175 => Loc73  вер=1 порядок=1
       текст: Look at the clothing
       эффект: P1(Time) -3
  -> Path176 => Loc74  вер=1 порядок=2
       текст: Examine the contents of the bar
       эффект: P1(Time) -1

### Loc47 [обычная]
    Loc47-1: An impressive lacquered table made of fake wood twinkled in the light. It was completely empty. A large, soft armchair was moved to the corner of the table so a…
  -> Path119 => Loc22  вер=1 порядок=9
       текст: Look around the room again
       эффект: P28(Правильный код стола (не нужен)) = 0
       эффект: P29(Правильный код спальни (не нужен)) = 0
       эффект: P44(Number of attempts at unlocking) = 0
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
  -> Path152 => Loc131  вер=1 порядок=5
       текст: Unlock the table's right cabinet
       эффект: P48(Lock location) = 2
       показ: P30,P31,P32
  -> Path153 => Loc66  вер=1 порядок=5
       текст: Get into the table's left cabinet
       эффект: P12(tmp) = 0

### Loc49 [пустая] визитов<=1
  -> Path122 => Loc22  вер=1 проходов<=1 порядок=5

### Loc51 [обычная]
    Loc51-1: You found a remote control on the shelf near the apparatus and pressed a big, red button. In an instant, you were assaulted by an intense blast from the sound s…
  -> Path125 => Loc28  вер=1 порядок=9
       текст: Get back to work
  -> Path126 => Loc53  вер=1 порядок=5
       текст: Turn off the stereovision
       эффект: P39(Turned the TV on) = 0
  -> Path128 => Loc52  вер=1 порядок=5
       текст: Change the channel
       эффект: P1(Time) -2

### Loc52 [обычная]
    Loc52-1: Another channel is also showing a film with a ranger in the main role, but rather than a thriller, this one is an action flick. In this one, another stupid rang…
  -> Path129 => Loc53  вер=1 порядок=5
       текст: Turn off the stereovision
       эффект: P39(Turned the TV on) = 0
  -> Path130 => Loc28  вер=1 порядок=9
       текст: Get back to work

### Loc53 [обычная]
    Loc53-1: You pressed the button on the remote control again and the cacophony subsided.
  -> Path127 => Loc28  вер=1 порядок=5
       текст: Get back to work

### Loc54 [обычная]
    Loc54-1: The fae only shrugged his shoulders. / "It's your business," he said, "but I'm not going to pay for you. And if you're ready to bungle the whole deal for a few …
  -> Path309 => Loc126  вер=1 порядок=5
       текст: Okay, fine, extortioner. I'll pay.
       эффект: P2(Money) -5000
  -> Path310 => Loc127  вер=1 порядок=5
       текст: I don't have that kind of money. And I don't pay bribes on principle anyway!

### Loc55 [пустая]
  -> Path133 => Loc28  вер=1 порядок=5

### Loc56 [обычная]
    Loc56-1: You approached the wall and with great interest began to study the painting hanging on the wall. After just a few minutes your head began to ache from the chaot…
    эффект: P1(Time) -2
  -> Path272 => Loc23  вер=1 порядок=9
       текст: Return to examining the room
  -> Path273 => Loc113  вер=1 порядок=5
       текст: Adjust the painting
       условия: P21(Painting on the wall) 0..0

### Loc57 [обычная]
    Loc57-1: It's a good thing you brought a dirty towel with you. You used it to carefully smear the water about the floor, having volunteered as a housemaid for a time. No…
  -> Path138 => Loc23  вер=1 порядок=9
       текст: Get back to work
       эффект: P34(Puddle by the aquarium) = 0

### Loc58 [обычная]
    Loc58-1: The cabinet is divided into two sections inside. One section had five identical pairs of polished boots, probably for official events. The left section had litt…
  -> Path140 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Plant some evidence in a slipper
       условия: P3(Narcotics) 0..4
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1
  -> Path141 => Loc19  вер=1 порядок=7
       текст: Leave the shoes alone
  -> Path143 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Hide evidence in a boot
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P12(tmp) = 0
       эффект: P33(Broken boot) = 1
  -> Path147 => Loc61  вер=1 порядок=5
       текст: Glue on the ripped off heel
       условия: P8(Glue) 1..1; P33(Broken boot) 1..1
       эффект: P1(Time) -2

### Loc59 [обычная] визитов<=1
    Loc59-1: You pulled out one of the slippers and, without hesitating, stuffed some evidence inside. Then you put it back where it was.
  -> Path142 => Loc19  вер=1 проходов<=1 порядок=5
       текст: Leave the shoes alone

### Loc60 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc60-1: You took a boot and thoughtfully turned it in your hands. Then you had a stroke of genius. Straining yourself, you tore the heel off the boot - just like in an …
  -> Path145 => Loc61  вер=1 порядок=5
       текст: Glue on the heel
       условия: P8(Glue) 1..1; P33(Broken boot) 1..1
       эффект: P1(Time) -2
       эффект: P35(Too difficult) +2
  -> Path148 => Loc19  вер=1 порядок=5
       текст: Spit on it and leave
       эффект: P1(Time) -1
       эффект: P12(tmp) = 3

### Loc61 [обычная]
    Loc61-1: It's a good thing you have a tube of glue on you. You immediately applied it to the sole of the shoe, and the heel stuck in place as if it had never been torn. …
  -> Path146 => Loc19  вер=1 порядок=5
       текст: Leave the shoes alone
       эффект: P33(Broken boot) = 0

### Loc63 [обычная]
    выбор описания: {1+1*([p3]=1)+2*([p3]>1)}
    Loc63-1: You retrieved the bundle from your pocket and looked at it critically. Unless your eyes are deceiving you, you haven't hid a single package yet! / If you leave …
    Loc63-2: You retrieved the bundle from your pocket and looked at it critically. Unless your eyes are deceiving you, you've only hidden [p3] packages so far. / If you lea…
    Loc63-3: You retrieved the bundle from your pocket and looked at it critically. Unless your eyes are deceiving you, you've only hidden [p3] packages so far. / If you lea…
  -> Path150 => Loc64  вер=1 порядок=5
       текст: Decline to fulfill the mission
  -> Path151 => Loc19  вер=1 порядок=3
       текст: Return to fulfilling the mission

### Loc64 [ПРОВАЛ]
    Loc64-1: You spit on the successful completion of your mission, having decided that the risk was incommensurate with the reward, or something like that. Who knows what's…

### Loc66 [обычная]
    выбор описания: {[p12]+1}
    Loc66-1: The box is open. Inside there is a small depression, inhabited by some animal you couldn't identify - kind of like a lump of slime with eyes. Staring at you wit…
    Loc66-2: You gathered your courage and poked the slug with your finger. Your finger passed through it without any resistance. That was the last thing you remembered befo…
    Loc66-3: You cautiously tossed a package inside, hoping that the creature wouldn't gobble up the important evidence. Your hopes were in vain. Apparently, the slimy pet t…
    Loc66-4: You hesitantly waved your hand and greeted the strange animal. / "Caw-purr-quack!" responded the animal decisively, and then added, "plop-splash." / "In what se…
  -> Path168 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Put a package inside
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -2
       эффект: P3(Narcotics) +1
       эффект: P12(tmp) = 2
       эффект: P35(Too difficult) +2
  -> Path170 => Loc70  вер=1 порядок=5
       текст: Poke the animal with your finger
       эффект: P1(Time) -25
       эффект: P12(tmp) = 1
  -> Path171 => Loc47  вер=1 порядок=9
       текст: Close the box
       эффект: P12(tmp) = 0
  -> Path316 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Say hello
       эффект: P1(Time) -3
       эффект: P12(tmp) = 3

### Loc67 [обычная]
    выбор описания: {1+1*([p27])}
    Loc67-1: The door is open. There are several shelves inside. Nearly all of them are empty, except for one, where a thick stack of credits lies tied with a string.
    Loc67-2: The door is open. There are several shelves inside. They're all empty.
    скрыт: P30,P31,P32
  -> Path163 => Loc69  вер=1 порядок=5
       текст: Take the money!
       условия: P27(Take the money) 0..0
       эффект: P1(Time) -1
       эффект: P27(Take the money) = 1
       эффект: P2(Money) +5000
  -> Path165 => Loc47  вер=1 порядок=9
       текст: Close the door
       эффект: P44(Number of attempts at unlocking) = 0
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
       эффект: P48(Lock location) = 0
  -> Path166 => Loc69  вер=1 порядок=5
       текст: Put the money back...
       условия: P27(Take the money) 1..1
       эффект: P1(Time) -1
       эффект: P27(Take the money) = 0
       эффект: P2(Money) -5000
  -> Path167 => Loc69  вер=1 проходов<=1 порядок=6
       текст: Put a package inside
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1

### Loc69 [пустая]
  -> Path164 => Loc67  вер=1 порядок=5

### Loc70 [пустая]
  -> Path169 => Loc66  вер=1 порядок=5

### Loc72 [обычная]
    Loc72-1: The shelves are crammed full of the most boring books in the history of the Coalition. You tried hard, but you still couldn't find a single brochure about the b…
  -> Path195 => Loc46  вер=1 порядок=9
       текст: Leave the shelf alone
  -> Path196 => Loc92  вер=1 проходов<=1 порядок=5
       текст: Hide a package in "The Basics of Legal Proceedings" by Iilkach Shletsozorg
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
  -> Path201 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Randomly open one of the books
       эффект: P1(Time) -5

### Loc73 [обычная]
    Loc73-1: The closet is filled with identical, outrageously boring, black suits. It seems like politicians are totally unaware that other clothing even exists.
    эффект: P1(Time) -3
  -> Path198 => Loc87  вер=1 проходов<=1 порядок=5
       текст: Plant evidence in the pocket of one of the suits
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1
  -> Path199 => Loc46  вер=1 порядок=9
       текст: Leave the closet alone

### Loc74 [обычная]
    Loc74-1: The bar was chock-full of all sorts of first-class drinks, everything from vtequila and ekup to totally exotic drinks in a special container, both glowing and b…
    эффект: P1(Time) -3
  -> Path200 => Loc46  вер=1 порядок=9
       текст: Leave the closet alone
  -> Path202 => Loc89  вер=1 порядок=5
       текст: Pour yourself a small glass of something strong
       эффект: P25(Alcohol) +1
  -> Path358 => Loc138  вер=1 проходов<=1 порядок=5
       текст: Hide a package behind the bottles
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -2
       эффект: P3(Narcotics) +1

### Loc75 [обычная] визитов<=1
    Loc75-1: There's a posh view of the city from the fortieth floor. Dense streams of flying vehicles bustle between the skyscrapers; the bright sun's rays reflect off of m…
  -> Path178 => Loc24  вер=1 проходов<=1 порядок=9
       текст: Get back to work

### Loc76 [обычная]
    Loc76-1: The toilet is large and shiny. It works the old fashioned way with flushing water. It's not one of the modern constructions that annihilates human waste - and s…
  -> Path233 => Loc100  вер=1 порядок=2
       текст: Use the device for its intended purpose
       эффект: P1(Time) -5
  -> Path234 => Loc20  вер=1 порядок=4
       текст: Go away
  -> Path236 => Loc101  вер=1 порядок=1
       текст: Take a seat and leaf through the requisitioned magazine
       условия: P6(Magazine) 1..2
       эффект: P1(Time) -15
  -> Path237 => Loc102  вер=1 проходов<=1 порядок=3
       текст: Hide a package in the toilet's water tank
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -3
       эффект: P3(Narcotics) +1

### Loc77 [обычная]
    Loc77-1: There are just some dirty clothes, predominately black business suits which the owner apparently hasn't taken to the dry cleaner located around the block. In ad…
  -> Path212 => Loc94  вер=1 проходов<=1 порядок=2
       текст: Throw a package in with the dirty clothes
       условия: P3(Narcotics) 0..4
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1
  -> Path213 => Loc94  вер=1 порядок=3
       текст: Take one of the dirty towels
       условия: P7(Towel) 0..0
       эффект: P7(Towel) = 1
  -> Path214 => Loc94  вер=1 порядок=3
       текст: Put the towel in its place
       условия: P7(Towel) 1..1
       эффект: P7(Towel) = 0
  -> Path216 => Loc20  вер=1 порядок=5
       текст: Step away from the container

### Loc78 [обычная]
    Loc78-1: The shelf is cracking and nearly collapsing under the weight of numerous and diverse flasks, vials, tubes, and other specialized containers. If he has to use al…
  -> Path225 => Loc20  вер=1 порядок=8
       текст: Walk away before the shelf collapses
  -> Path226 => Loc97  вер=1 проходов<=1 порядок=5
       текст: Hide a package among the cosmetics
       условия: P3(Narcotics) 0..4
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1

### Loc79 [обычная]
    выбор описания: {1+1*([p9]=1)+2*([p23]=1)}
    Loc79-1: The ventilation hole is covered by a solid grate. You could hide evidence inside, but breaking into there will be somewhat complicated. If only you had a <clr>s…
    Loc79-2: The ventilation hole is covered by a solid grate. You could hide evidence inside, but breaking into there will be somewhat complicated. Fortunately, you have a …
    Loc79-3: The grate came off of the ventilation hole along with a piece of the wall. There's no kind of screwdriver that will help this situation now.
  -> Path228 => Loc98  вер=1 проходов<=1 порядок=5
       текст: Try to pull it off anyway
       условия: P9(Screwdriver) 0..0
       эффект: P23(The grate is broken) = 1
  -> Path229 => Loc99  вер=1 проходов<=1 порядок=5
       текст: Remove the grate with a screwdriver
       условия: P9(Screwdriver) 1..1; P23(The grate is broken) 0..0
       эффект: P3(Narcotics) +1
  -> Path230 => Loc20  вер=1 порядок=6
       текст: Leave the grate alone

### Loc80 [пустая] визитов<=1
  -> Path184 => Loc20  вер=1 проходов<=1 порядок=5

### Loc81 [обычная]
    выбор описания: {1+1*([p8] in [0] and [p9] in [1])+2*([p8] in [1] and [p9] in [0])+3*([p8] in [1] and [p9] in [1])}
    Loc81-1: Almost all of the cabinets were empty. Apparently, the owner of the apartment really isn't a fan of cooking. / In one of the empty compartments there is a screw…
    Loc81-2: Almost all of the cabinets were empty. Apparently, the owner of the apartment really isn't a fan of cooking. / You found a tube of glue in one of the cabinets.
    Loc81-3: Almost all of the cabinets were empty. Apparently, the owner of the apartment really isn't a fan of cooking. / An abandoned screwdriver is lying in one of the c…
    Loc81-4: Almost all of the cabinets were empty. Apparently, the owner of the apartment really isn't a fan of cooking.
  -> Path217 => Loc95  вер=1
       текст: Take the screwdriver
       условия: P9(Screwdriver) 0..0
       эффект: P9(Screwdriver) = 1
  -> Path219 => Loc95  вер=1 порядок=2
       текст: Put the screwdriver in place
       условия: P9(Screwdriver) 1..1
       эффект: P9(Screwdriver) = 0
  -> Path220 => Loc21  вер=1 порядок=9
       текст: Leave the cabinets alone
  -> Path221 => Loc95  вер=1 проходов<=1 порядок=4
       текст: Put a package in one of the cabinets
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +2
  -> Path254 => Loc95  вер=1 порядок=1
       текст: Take the tube of glue
       условия: P8(Glue) 0..0
       эффект: P8(Glue) = 1
  -> Path255 => Loc95  вер=1 порядок=3
       текст: Put the glue back
       условия: P8(Glue) 1..1
       эффект: P8(Glue) = 0

### Loc82 [обычная]
    Loc82-1: The refrigerator is entirely empty, to your great chagrin. But maybe this is for the best, otherwise you would have lost control and scarfed something down.
  -> Path244 => Loc21  вер=1 порядок=8
       текст: Step away from the refrigerator
  -> Path245 => Loc104  вер=1 проходов<=1 порядок=5
       текст: Put a package inside
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -1
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +1

### Loc83 [обычная]
    Loc83-1: This is the latest model of one of those miraculous food processors that can do everything. They can almost compose music and fight dominators. Its surface is c…
  -> Path247 => Loc105  вер=1 проходов<=1
       текст: Hide a package inside
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -4
       эффект: P3(Narcotics) +1
       эффект: P36(Too simple) +2
  -> Path249 => Loc21  вер=1 порядок=8
       текст: Step away from the food processor
  -> Path250 => Loc106  вер=1 порядок=4
       текст: Make something to eat
       эффект: P1(Time) -3

### Loc84 [пустая] визитов<=1
  -> Path189 => Loc21  вер=1 проходов<=1 порядок=5

### Loc85 [обычная] визитов<=1
    Loc85-1: You dug a small hole, like a penchekryak preparing to relieve himself, then placed a package with evidence in the depression, delicately sprinkled it with soil,…
  -> Path191 => Loc24  вер=1 проходов<=1 порядок=9
       текст: Step away from the plant

### Loc86 [обычная]
    Loc86-1: Even though drying floors is not a ranger job, you can't stand the sight of such a mess, so you rolled up your sleeves and worked as a housemaid for a couple mi…
  -> Path194 => Loc24  вер=1 порядок=9
       текст: Get back to your immediate responsibilities
       эффект: P26(Buried in a vase) = 1

### Loc87 [пустая] визитов<=1
  -> Path197 => Loc46  вер=1 проходов<=1 порядок=5

### Loc88 [обычная] визитов<=1
    Loc88-1: Sibolusofts are very gentle and frail animals, so they must be treated with love and kindness. They are also easily frightened and can actually die from even th…
  -> Path203 => Loc90  вер=1 порядок=5
       текст: Try again
       эффект: P1(Time) -5
  -> Path204 => Loc72  вер=1 порядок=9
       текст: Stop goofing off

### Loc89 [обычная]
    Loc89-1: You grabbed a bottle, whichever one your hand fell on, and, in order to avoid smudging any glasses, you poured its contents liberally into your mouth and, partl…
    Loc89-2: The next bottle was as cold as ice, but that didn't scare you off - and you enthusiastically hit the bottle. In principle, this wouldn't have been half bad, exp…
    Loc89-3: The drink was so stung so badly that you quickly grabbed another bottle to extinguish the fire in your nasal passages. This seemed to help, since afterward you …
  -> Path209 => Loc74  вер=1 порядок=5
       текст: Put the bottle in its place

### Loc90 [обычная]
    Loc90-1: "A quest must have a beginning and an end. The quest begins when, upon the ranger landing on a planet, the player clicks 'Accomplish quest'. Upon completing the…
  -> Path205 => Loc72  вер=1 порядок=9
       текст: Stop fooling around
  -> Path206 => Loc91  вер=1 порядок=5
       текст: Again! Maybe you'll find something more worthwhile!
       эффект: P1(Time) -5

### Loc91 [обычная]
    Loc91-1: "He opened to the middle of the first book he came across and found a description of some sort of animal with an unpronounceable name starting with 'S'. He wasn…
  -> Path207 => Loc72  вер=1 порядок=5
       текст: Leave the books alone, just in case

### Loc92 [пустая] визитов<=1
  -> Path208 => Loc72  вер=1 проходов<=1 порядок=5

### Loc93 [обычная] визитов<=4
    Loc93-1: You smelled a small flower. Beautiful!
    Loc93-2: Aahhh!
    Loc93-3: Ah-chooo!
    Loc93-4: Some pollen must have gotten up your nose, because you sneezed so powerfully that you spit all over the flowers. "Well, to hell with that plant!," you decided.
  -> Path211 => Loc30  вер=1 проходов<=4 порядок=9
       текст: Stop sniffing

### Loc94 [пустая]
  -> Path215 => Loc77  вер=1 порядок=5

### Loc95 [пустая]
  -> Path218 => Loc81  вер=1 порядок=5

### Loc96 [обычная] визитов<=1
    Loc96-1: You quickly undressed and plopped into the warm water. After dipping under a couple of times to warm up, you swam with a noisy butterfly stroke toward the sunse…
  -> Path224 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Get back to work

### Loc97 [пустая] визитов<=1
  -> Path227 => Loc78  вер=1 проходов<=1 порядок=5

### Loc98 [обычная] визитов<=1
    Loc98-1: You grabbed hold of the grate and yanked hard. The builder must not have expected somebody to entertain himself this way, since he didn't make the grate vandal-…
  -> Path231 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Leave the grate alone

### Loc99 [обычная] визитов<=1
    Loc99-1: You carefully unscrewed the bolts from the grate and removed it without making a sound or any mess. Then you placed a package with evidence inside and tightened…
  -> Path232 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Continue working

### Loc100 [обычная]
    Loc100-1: You got unbuttoned, took care of your ranger needs, buttoned yourself back up, and pressed the flusher button, feeling that you had done your duty.
  -> Path235 => Loc20  вер=1 порядок=5
       текст: Return to examining the premises

### Loc101 [обычная]
    Loc101-1: You sat down on the toilet, opened to the middle of the magazine, and began to read an article about some multimillionaire who loved gorgeous heifers and hot wh…
  -> Path239 => Loc76  вер=1 порядок=5
       текст: Stop reading

### Loc102 [обычная] визитов<=1
    Loc102-1: With great effort, you moved the tank lid to the side and tossed in a package. Then you put the lid back in place. Now you can only hope that nobody flushes the…
    эффект: P35(Too difficult) +2
  -> Path238 => Loc20  вер=1 проходов<=1 порядок=5
       текст: Continue working

### Loc103 [обычная]
    Loc103-1: You pulled the magazine out from under the pillow and opened it. Inside were mostly pictures of half-dressed girls at exotic resort locations or on luxurious ya…
  -> Path241 => Loc29  вер=1 порядок=9
       текст: Put the magazine back
  -> Path242 => Loc41  вер=1 проходов<=1 порядок=5
       текст: Take the magazine with you
       эффект: P6(Magazine) = 1

### Loc104 [пустая] визитов<=1
  -> Path246 => Loc21  вер=1 проходов<=1 порядок=5

### Loc105 [обычная] визитов<=1
    Loc105-1: You crammed a package into one of the openings. To your horror, the processor took this as a call to action and started running. No one knows what processes wer…
  -> Path248 => Loc83  вер=1 проходов<=1 порядок=5
       текст: Continue

### Loc106 [обычная]
    Loc106-1: You pushed the first button you came across and waited to see what would happen next. For a long time the processor puffed, grunted, and shuddered all over. Fin…
  -> Path251 => Loc83  вер=1 порядок=9
       текст: Do nothing
  -> Path252 => Loc107  вер=1 порядок=5
       текст: Try again with the magazine
       условия: P6(Magazine) 1..1
       эффект: P1(Time) -5
       эффект: P6(Magazine) = 2

### Loc107 [обычная]
    Loc107-1: You put the magazine inside and pressed a different button. The processor again began to purr and hum. After five minutes it released what it had produced.  / O…
    скрыт: P6
  -> Path253 => Loc83  вер=1 порядок=9
       текст: Stop with the pranks

### Loc108 [ПРОВАЛ]
    Loc108-1: "The problem, <Player>, is that even a penchekryak in the museum of fine art wouldn't have left more tracks that you managed too!" / Clearly irritated, the fae …

### Loc109 [обычная]
    Loc109-1: "The problem, <Ranger>, is that you didn't do your job well enough. The police discovered some evidence of a break-in at the residence. This isn't fatal - I kno…
  -> Path307 => Loc54  вер=1 порядок=5
       текст: Yeah, right! I'm not giving you my money!
  -> Path308 => Loc126  вер=1 порядок=5
       текст: Of course, I'll pay. I don't want to go to prison!
       эффект: P2(Money) -5000

### Loc111 [ПРОВАЛ]
    выбор описания: {1+1*([p10] in [1] and [p42] in [0] and [p43] in [0])+2*([p10] in [0] and [p42] in [1] and [p43] in [0])+3*([p10] in [0] and [p42] in [0] and [p43] in [1])+4*([p10] in [1] and [p42] in [1] and [p43] in [0])+5*([p10] in [1] and [p42] in [0] and [p43] in [1])+6*([p10] in [0] and [p42] in [1] and [p43] in [1])+7*([p10] in [1] and [p42] in [1] and [p43] in [1])}
    Loc111-1: Blah, blah, blah, ranger! / (this version of the description shouldn't end up in the quest xD)
    Loc111-2: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-3: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-4: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-5: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-6: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-7: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…
    Loc111-8: Judging by his appearance, the fae was beside himself with rage. / "I always knew that rangers were stupid, but I never suspected it could be this bad! I though…

### Loc113 [обычная]
    Loc113-1: You put out your hand and tried to carefully adjust the painting, but you couldn't. You tugged on it, but the stubborn masterpiece wouldn't budge. You yanked it…
    эффект: P1(Time) -2
    эффект: P21(Painting on the wall) = 1
  -> Path274 => Loc114  вер=1 порядок=5
       текст: Hang the painting back where it was
  -> Path275 => Loc131  вер=1 порядок=5
       текст: Open the lock on the wall
       эффект: P48(Lock location) = 3
       показ: P30,P31,P32
  -> Path315 => Loc23  вер=1 порядок=5
       текст: Do something else

### Loc114 [обычная]
    Loc114-1: A bit above the combination lock you noticed the hardware for hanging the painting. Getting the painting back in place only took a second, but it refused to han…
    эффект: P1(Time) -4
    эффект: P21(Painting on the wall) = 0
  -> Path276 => Loc23  вер=1 порядок=9
       текст: Step away from the painting

### Loc120 [обычная]
    Loc120-1: As soon as you pressed the last button, a previously inconspicuous wall panel, which was actually a secret door, flipped open in your face. Thanks to your sharp…
    скрыт: P30,P31,P32
  -> Path292 => Loc121  вер=1 порядок=5
       текст: Check out the secret room

### Loc121 [обычная]
    Loc121-1: Your are in a spacious, and entirely pink, room. Directly in the middle of the room, under a pretentious pink chandelier is a huge doll house, also pink. The re…
    эффект: P1(Time) -3
  -> Path293 => Loc122  вер=1 проходов<=1
       текст: Hide some evidence in this mess
       условия: P3(Narcotics) 0..4
       эффект: P1(Time) -2
       эффект: P3(Narcotics) +1
       эффект: P35(Too difficult) +2
  -> Path294 => Loc123  вер=1 проходов<=1 порядок=2
       текст: Play with something
  -> Path295 => Loc23  вер=1 порядок=9
       текст: Leave the room
       эффект: P12(tmp) = 3
       эффект: P28(Правильный код стола (не нужен)) = 0
       эффект: P29(Правильный код спальни (не нужен)) = 0
       эффект: P44(Number of attempts at unlocking) = 0
       эффект: P45(Code number sequence) = 0
       эффект: P46(Correct code) = 0
       эффект: P48(Lock location) = 0
  -> Path298 => Loc124  вер=1 проходов<=1 порядок=4
       текст: Leave a message for the apartment's owner

### Loc122 [обычная] визитов<=1
    Loc122-1: You chose the largest mound of toys, dug down to its foundation, and then stuffed one of the packages with evidence in the crater you created. Putting the toys …
  -> Path296 => Loc121  вер=1 проходов<=1 порядок=5
       текст: Continue your mission

### Loc123 [обычная] визитов<=1
    Loc123-1: You sat on the floor, pulled a toy train closer, put dolls in each of the railcars, and rolled them around the room. The only thing you lacked to be completely …
    эффект: P1(Time) -20
  -> Path297 => Loc121  вер=1 проходов<=1 порядок=5
       текст: Get back to work

### Loc124 [обычная] визитов<=1
    Loc124-1: The look of the room made you so happy that you decided to play a prank of this poor guy who loves pink so much. To implement your idea you needed the marker th…
    эффект: P1(Time) -5
    эффект: P20(Writing on the wall) = 1
  -> Path299 => Loc121  вер=1 проходов<=1 порядок=5
       текст: Get back to work

### Loc125 [УСПЕХ]
    Loc125-1: "Amazingly, <Ranger>, you did very well! The police didn't suspect a thing when they found the evidence you had planted. I guess you have a well-developed crimi…

### Loc126 [обычная]
    Loc126-1: "So you're reasonable after all, <Ranger>," observed the fae. "I also would have paid. Although, for starters, I wouldn't have left so many tracks. / The fae fo…
  -> Path306 => Loc125  вер=1 порядок=5
       текст: What? With the evidence?
       условия: P35(Too difficult) 0..4; P36(Too simple) 0..4
  -> Path312 => Loc128  вер=1 порядок=5
       текст: What? With the evidence?
       условия: P35(Too difficult) 5..30
  -> Path313 => Loc129  вер=1 порядок=5
       текст: What? With the evidence?
       условия: P36(Too simple) 5..30

### Loc127 [ПРОВАЛ]
    Loc127-1: Well, take care then, <Ranger>." / The fae finished his drink, grinned, and left the cafe. Just minutes later, police officers burst through the same door and i…

### Loc128 [ПРОВАЛ]
    Loc128-1: "<Ranger>, you did a horrible job with that evidence. Tell me, did you actually plant any in the apartment? Or did you just swing by for a tour and keep the nar…

### Loc129 [ПРОВАЛ]
    Loc129-1: "<Ranger>, you did a horrible job with that evidence. Instead of at least trying to hide it in some way, within reason, you scattered it about in plain view. Ev…

### Loc130 [обычная] визитов<=1
    Loc130-1: You worked diligently and blasted out an enormous pit. Then you almost got tangled up in the roots of the plant growing at your excavation site. When the bottom…
  -> Path317 => Loc24  вер=1 проходов<=1 порядок=9
       текст: Step away from the plant

### Loc131 [обычная]
    выбор описания: {1+[p45]}
    Loc131-1: Number on the combination lock's screen: "<clr>****<clrEnd>" / Enter the first number.
    Loc131-2: Number on the combination lock's screen: "[p46]<clr>***<clrEnd>". / Enter the second number.
    Loc131-3: Number on the combination lock's screen: "[p46]<clr>**<clrEnd>" / Enter the third number.
    Loc131-4: Number on the combination lock's screen: "[p46]<clr>*<clrEnd>" / Enter the fourth number.
    Loc131-5: Number on the combination lock's screen: "[p46]". / Now click the confirmation button.
  -> Path59 => Loc15  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 1..1; логика {[p46]=5555}
  -> Path60 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 1..1; логика {[p46]<5555 or [p46]>5555}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path160 => Loc67  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 2..2; логика {[p46]=3282}
  -> Path291 => Loc120  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 3..3; логика {[p46]=3282}
  -> Path320 => Loc133  вер=1
       текст: Enter 1
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+1}
  -> Path321 => Loc133  вер=1 порядок=1
       текст: Enter 2
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+2}
  -> Path324 => Loc133  вер=1 порядок=2
       текст: Enter 3
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+3}
  -> Path325 => Loc133  вер=1 порядок=3
       текст: Enter 4
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+4}
  -> Path326 => Loc133  вер=1 порядок=4
       текст: Enter 5
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+5}
  -> Path327 => Loc133  вер=1 порядок=5
       текст: Enter 6
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+6}
  -> Path328 => Loc133  вер=1 порядок=6
       текст: Enter 7
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+7}
  -> Path329 => Loc133  вер=1 порядок=7
       текст: Enter 8
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+8}
  -> Path330 => Loc133  вер=1 порядок=8
       текст: Enter 9
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+9}
  -> Path331 => Loc133  вер=1 порядок=9
       текст: Enter 0
       условия: P45(Code number sequence) 0..3
       эффект: P45(Code number sequence) +1
       эффект: P46(Correct code) = {[p46]*10+0}
  -> Path332 => Loc134  вер=1 порядок=9
       текст: Clear the code you entered
       условия: P45(Code number sequence) 4..4
  -> Path334 => Loc15  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 1..1; логика {[p46]=3282}
  -> Path335 => Loc15  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 1..1; логика {[p46]=1234}
  -> Path337 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 1..1; логика {[p46]<1234 or [p46]>1234}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path338 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 1..1; логика {[p46]<3282 or [p46]>3282}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path339 => Loc67  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 2..2; логика {[p46]=5555}
  -> Path340 => Loc67  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 2..2; логика {[p46]=1234}
  -> Path341 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 2..2; логика {[p46]<1234 or [p46]>1234}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path342 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 2..2; логика {[p46]<3282 or [p46]>3282}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path343 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 2..2; логика {[p46]<5555 or [p46]>5555}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path344 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 1..1; P48(Lock location) 3..3; логика {[p46]<3282 or [p46]>3282}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path345 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 3..3; логика {[p46]<5555 or [p46]>5555}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path346 => Loc16  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 3..3; логика {[p6]<1234 or [p46]>1234}
       эффект: P44(Number of attempts at unlocking) +1
  -> Path347 => Loc120  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 2..2; P48(Lock location) 3..3; логика {[p46]=5555}
  -> Path348 => Loc120  вер=1
       текст: Press the confirmation button
       условия: P45(Code number sequence) 4..4; P47(Range of possible codes) 3..3; P48(Lock location) 3..3; логика {[p46]=1234}

### Loc133 [пустая]
  -> Path319 => Loc131  вер=1 порядок=5

### Loc134 [пустая]
    эффект: P45(Code number sequence) = 0
    эффект: P46(Correct code) = 0
  -> Path333 => Loc131  вер=1 порядок=5

### Loc135 [обычная]
    Loc135-1: Codes: /  / Option 1: 1-3, 2-2, 3-1 / Option 2: 1-2, 2-1, 3-3 / Option 3: 1-1, 2-3, 3-2

### Loc136 [пустая] визитов<=1
  -> Path352 => Loc2  вер=1 проходов<=1 порядок=5

### Loc138 [пустая] визитов<=1
  -> Path359 => Loc74  вер=1 проходов<=1 порядок=5

## Анализ
- стартовых: [1]
- концовки: {18: 'ПРОВАЛ', 31: 'ПРОВАЛ', 64: 'ПРОВАЛ', 108: 'ПРОВАЛ', 111: 'ПРОВАЛ', 125: 'УСПЕХ', 127: 'ПРОВАЛ', 128: 'ПРОВАЛ', 129: 'ПРОВАЛ'}
- недостижимые локации: [25, 135]
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
