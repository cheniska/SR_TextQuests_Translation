# Квест (формат 1111111126)
Сложность 40; стартовая локация: [19]; путей по умолчанию: 1

## Параметры
- P1 'Title' [0..1] тип=обычный
    старт: [0]
    [0..1] == Your foncer ==
    критическое: Сообщение достижения критического значения параметром 18
- P2 'Engine' [91..109] тип=обычный
    старт: [91]
    [91..93] The cheapest engine
    [94..96] The worst engine
    [97..99] Bad engine
    [100..102] Average engine
    [103..105] Good engine
    [106..108] Excellent engine
    [109..109] Super engine!!!
    критическое: Сообщение достижения критического значения параметром 7
- P3 'Protection' [0..900] тип=смерть
    старт: [300]
    [0..900] Protection: <>
    критическое: The cursor of the forcefield generator indicator almost pointed to zero and entered the red area. "B…
- P4 'Manoeuvrability details' [91..109] тип=обычный
    старт: [91]
    [91..92] Minimal manoeuvrability
    [93..96] Very bad manoeuvrability
    [97..99] Bad manoeuvrability
    [100..102] Normal manoeuvrability
    [103..105] Average manoeuvrability
    [106..109] Excellent manoeuvrability
    критическое: Сообщение достижения критического значения параметром 9
- P5 'Title' [0..1] тип=обычный
    старт: [0]
    [0..1] == Racers' time ==
    критическое: Сообщение достижения критического значения параметром 19
- P6 'YOU' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Your time: {[p6] div 600} min {([p6] mod 600)div10},{([p6] mod 600)mod10} sec
    критическое: Сообщение достижения критического значения параметром 2
- P7 'Racer 1' [0..10000] тип=обычный
    старт: [0]
    [0..10000] 
    критическое: Сообщение достижения критического значения параметром 12
- P8 'The first competitor' [1..3] тип=обычный
    старт: [1]
    [1..1] Rasgush's time: {[p7] div 600} min {([p7] mod 600)div10},{([p7] mod 600)mod10} sec
    [2..2] Gonzar's time: {[p7] div 600} min {([p7] mod 600)div10},{([p7] mod 600)mod10} sec
    [3..3] Miatra's time: {[p7] div 600} min {([p7] mod 600)div10},{([p7] mod 600)mod10} sec
    критическое: Сообщение достижения критического значения параметром 28
- P9 'The second competitor' [1..2] тип=обычный
    старт: [1]
    [1..1] Korchenitza's time: {[p7] div 600} min {([p7] mod 600)div10},{([p7] mod 600)mod10} sec
    [2..2] Shulman's time: {[p7] div 600} min {([p7] mod 600)div10},{([p7] mod 600)mod10} sec
    критическое: Сообщение достижения критического значения параметром 29
- P10 'Time difference' [0..10000] тип=обычный
    старт: [0]
    [0..499] You're in the lead!
    [500..500] Head to head
    [501..10000] You're behind...
    критическое: Сообщение достижения критического значения параметром 20
- P11 'Basic protection' [0..900] тип=обычный
    старт: [0]
    [0..900] Flows left: {10-[p16]}
    критическое: Сообщение достижения критического значения параметром 21
- P12 "Competitor's engine" [91..110] тип=обычный
    старт: [100]
    [91..110] Competitor's engine: <>
    критическое: Сообщение достижения критического значения параметром 11
- P13 "Competitor's shield" [0..1000] тип=обычный
    старт: [300]
    [0..1000] Competitor's shield: <>
    критическое: Сообщение достижения критического значения параметром 10
- P14 "Competitor's manoeuvrability" [91..110] тип=обычный
    старт: [100]
    [91..110] Competitor's manoeuvrability: <>
    критическое: Сообщение достижения критического значения параметром 16
- P15 'Title' [0..1] тип=обычный
    старт: [0]
    [0..1] == Track information ==
    критическое: Сообщение достижения критического значения параметром 25
- P16 'Meter' [0..11] тип=обычный
    старт: [1]
    [0..11] Stages over: <>
    критическое: Сообщение достижения критического значения параметром 13
- P17 'Reverse meter' [0..11] тип=обычный
    старт: [0]
    [0..11] Stages left: <>
    критическое: Сообщение достижения критического значения параметром 26
- P18 'Section length' [0..1] тип=обычный
    старт: [0]
    [0..1] == Section information ==
    критическое: Сообщение достижения критического значения параметром 27
- P19 'Passing time' [400..600] тип=обычный
    старт: [400]
    [400..466] Short
    [467..533] Middle
    [534..600] Long
    критическое: Сообщение достижения критического значения параметром 23
- P20 'Section damages' [1..100] тип=обычный
    старт: [1]
    [1..20] Minimal damages
    [21..40] Small damages
    [41..60] Middle damages
    [61..80] Big damages
    [81..100] Huge damages
    критическое: Сообщение достижения критического значения параметром 24
- P21 'Difficulty' [0..5] тип=обычный
    старт: [1]
    [0..1] Manoeuvrability: Minimal
    [2..2] Manoeuvrability: Low
    [3..3] Manoeuvrability: Average
    [4..4] Manoeuvrability: High
    [5..5] Manoeuvrability: Huge
    критическое: Сообщение достижения критического значения параметром 22
- P22 'Time' [0..14400] тип=обычный
    старт: [600]
    [0..1439] The first day: {[p22] div 60} h {[p22] mod 60} min
    [1440..2879] The second day: {([p22]-1440) div 60} h {([p22]-1440) mod 60} min
    [2880..4319] The third day: {([p22]-2880) div 60} h {([p22]-2880) mod 60} min
    [4320..5759] The forth day: {([p22]-4320) div 60} h {([p22]-4320) mod 60} min
    [5760..7199] The fifth day: {([p22]-5760) div 60} h {([p22]-5760) mod 60} min
    [7200..8639] The sixth day: {([p22]-7200) div 60} h {([p22]-7200) mod 60} min
    [8640..10079] The seventh day: {([p22]-8640) div 60} h {([p22]-8640) mod 60} min
    [10080..11519] The eighth day: {([p22]-10080) div 60} h {([p22]-10080) mod 60} min
    [11520..12959] The ninth day: {([p22]-11520) div 60} h {([p22]-11520) mod 60} min
    [12960..14400] The tenth day: {([p22]-12960) div 60} h {([p22]-12960) mod 60} min
    критическое: Сообщение достижения критического значения параметром 4
- P23 'Victory meter' [1..4] тип=обычный
    старт: [1]
    [1..4] Number 17 parameters: <>
    критическое: Сообщение достижения критического значения параметром 17
- P24 'Weariness' [0..10] тип=провал
    старт: [10]
    [0..1] You're deadly tired
    [2..3] You're tired very much
    [4..5] You're tired
    [6..10] You're alright
    критическое: You were not able to overcome your weariness and met your doom!
- P25 "Handicap's time" [0..1000] тип=обычный
    старт: [0]
    [0..1000] Section time: <>
    критическое: Сообщение достижения критического значения параметром 15
- P26 'Experience' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Experience: <>
    критическое: Сообщение достижения критического значения параметром 3
- P27 'Area type' [1..10] тип=обычный
    старт: [1]
    [1..10] Area type: <>
    критическое: Сообщение достижения критического значения параметром 14
- P28 "Player's money" [0..100000] тип=обычный деньги
    старт: [1000]
    [0..100000] Your cash: <>
    критическое: Сообщение достижения критического значения параметром 1
- P29 'Maneuver' [0..10] тип=обычный
    старт: [0]
    [0..10] Maneuver: <>
    критическое: Сообщение достижения критического значения параметром 6
- P30 'Off from the distance' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 30

## Локации и переходы

### Loc1 [обычная]
    выбор описания: {[p23]}
    Loc1-1: There are mechanics waiting in the boxes already. One of them must be the chief, he welcomes you and then recites a speech he obviously has memorized: /  / - We…
    Loc1-2: The chief mechanic congratulates you asking: / - What will you drive in the semi-final race? /  / <clr>" Hurricane "<clrEnd> is the fastest foncer with excellen…
    Loc1-3: The chief mechanic congratulates you asking:: / - What will you drive in the final race? /  / <clr>" Hurricane "<clrEnd> is the fastest foncer with excellent ma…
    эффект: P6(YOU) = 0
    эффект: P7(Racer 1) = 0
    эффект: P16(Meter) = 1
    эффект: P25(Handicap's time) = 0
  -> Path2 => Loc30  вер=1 порядок=1
       текст: Choose "Hurricane"
       эффект: P3(Protection) = {330}
       эффект: P2(Engine) = {106}
       эффект: P4(Manoeuvrability details) = {103}
  -> Path3 => Loc30  вер=1 порядок=2
       текст: Choose "Tornado"
       эффект: P3(Protection) = {330}
       эффект: P2(Engine) = {103}
       эффект: P4(Manoeuvrability details) = {106}
  -> Path4 => Loc30  вер=1 порядок=4
       текст: Choose "Breeze"
       эффект: P3(Protection) = {530}
       эффект: P2(Engine) = {97}
       эффект: P4(Manoeuvrability details) = {97}
  -> Path5 => Loc30  вер=1 порядок=3
       текст: Choose "Vortex"
       эффект: P3(Protection) = {450}
       эффект: P2(Engine) = {100}
       эффект: P4(Manoeuvrability details) = {100}
  -> Path49 => Loc23  вер=1 порядок=5
       текст: Configure your personal model
       эффект: P3(Protection) = 330
       эффект: P2(Engine) = 91
       эффект: P4(Manoeuvrability details) = 91
       эффект: P16(Meter) = 1
       показ: P11

### Loc6 [обычная]
    Loc6-1: You see only a small straight track section in front of you. After it there is stage 1 but it can't be seen because of the light mist. /  / A metallic voice sta…
    эффект: P6(YOU) = 0
    эффект: P7(Racer 1) = 0
    эффект: P10(Time difference) = 500 [показ]
    эффект: P16(Meter) = 0
    эффект: P25(Handicap's time) = 0
    показ: P5
  -> Path10 => Loc10  вер=1 порядок=5
       текст: Give full throttle
       эффект: P6(YOU) = {[p6]+200/[p2]*100}
       эффект: P7(Racer 1) = {[p7]+200/[p12]*100}

### Loc7 [обычная]
    выбор описания: {[p27]}
    Loc7-1: <clr>Horizontal section of the track.<clrEnd> The racers are almost flying over the grass like over a green sea. Artificial obstacles are comparatively rare. Us…
    Loc7-2: <clr>Canyon.<clrEnd> This is a grey corridor with stone walls. Precipitous cliffs on both sides are flitting with horrible speed.
    Loc7-3: <clr>Stone plateau<clrEnd> Red tints of boulders remind you of blood. Sharp edged rocks seem to grow up right on the racers' way. Any collision will be mortal.
  -> Path11 => Loc10  вер=1 порядок=1
       текст: Give full throttle, sacrificing protection for speed
       условия: P4(Manoeuvrability details) 91..99; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*(6-[p21])))*130}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/2.4}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..4]}
       эффект: P29(Maneuver) = 1
  -> Path12 => Loc10  вер=1 порядок=3
       текст: Move easily through the dangerous part of the track segment minding protection
       условия: P4(Manoeuvrability details) 91..99; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*(6-[p21])))*70}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/1,6}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..2]}
       эффект: P29(Maneuver) = 3
  -> Path13 => Loc10  вер=1 порядок=2
       текст: Brake slightly in the most dangerous places but mind the speed
       условия: P4(Manoeuvrability details) 91..99; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-[p20]/([p4]+([p4]-100)*2*(6-[p21]))*100}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/2}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..3]}
       эффект: P29(Maneuver) = 2
  -> Path22 => Loc15  вер=1 порядок=5
       текст: Fall back
       эффект: P26(Experience) = {[p26]+[1..5]}
  -> Path29 => Loc10  вер=1 порядок=4
       текст: Spend the power feeding your forcefield very carefully
       условия: P4(Manoeuvrability details) 100..109
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*[p21]))*20}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[0..1]}
  -> Path89 => Loc10  вер=1 порядок=2
       текст: Brake slightly in the most dangerous places but mind the speed
       условия: P4(Manoeuvrability details) 100..109; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-[p20]/([p4]+([p4]-100)*2*[p21])*100}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/2}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..3]}
       эффект: P29(Maneuver) = 2
  -> Path90 => Loc10  вер=1 порядок=4
       текст: Spend the power feeding your forcefield very carefully
       условия: P4(Manoeuvrability details) 91..99
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*(6-[p21])))*20}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[0..1]}
  -> Path91 => Loc10  вер=1 порядок=3
       текст: Move easily through the dangerous part of the track segment minding protection
       условия: P4(Manoeuvrability details) 100..109; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*[p21]))*70}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/1,6}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..2]}
       эффект: P29(Maneuver) = 3
  -> Path92 => Loc10  вер=1 порядок=1
       текст: Give full throttle, sacrificing protection for speed
       условия: P4(Manoeuvrability details) 100..109; логика {[p16]<11}
       эффект: P3(Protection) = {[p3]-([p20]/([p4]+([p4]-100)*2*[p21]))*130}
       эффект: P6(YOU) = {[p6]+([p19]/[p2]*100+[p19]/[p4]*50)/2.4}
       эффект: P16(Meter) +1
       эффект: P26(Experience) = {[p26]+[1..4]}
       эффект: P29(Maneuver) = 1

### Loc9 [обычная]
    выбор описания: {([p6]>[p7])+([p6]=[p7])*2+1+3*[p30]}
    Loc9-1: Finish!!! / Your time: {[p6] div 600} min {([p6] mod 600)div10},{([p6] mod 600)mod10} sec / Your competitor's time: {[p7] div 600} min {([p7] mod 600)div10},{([…
    Loc9-2: Finish!!! / Your time: {[p6] div 600} min {([p6] mod 600)div10},{([p6] mod 600)mod10} sec / Your competitor's time: {[p7] div 600} min {([p7] mod 600)div10},{([…
    Loc9-3: Finish!!! / Your time: {[p6] div 600} min {([p6] mod 600)div10},{([p6] mod 600)mod10} sec / Your competitor's time: {[p7] div 600} min {([p7] mod 600)div10},{([…
    Loc9-4: Finish!!! / Your time: {[p6] div 600} min {([p6] mod 600)div10},{([p6] mod 600)mod10} sec / <clr>Your competitor couldn't keep up.<clrEnd> /  / You <clr>won<clr…
    скрыт: P15,P16,P17,P18,P19,P20,P21
  -> Path35 => Loc31  вер=1 порядок=5
       условия: логика {[p6]<[p7]}
       эффект: P23(Victory meter) +1
  -> Path36 => Loc18  вер=1 порядок=5
       условия: логика {[p6]=[p7]}
  -> Path37 => Loc15  вер=1 порядок=5
       условия: логика {[p6]>[p7]}

### Loc10 [пустая]
    выбор описания: {[p16] div 11}
    Loc10-1: The last segment of the track is finished and there is only the final straight lying in front of you.
    эффект: P7(Racer 1) = {[p7]+[p25]}
    эффект: P10(Time difference) = {500+[p6]-[p7]-[p25]}
    эффект: P17(Reverse meter) = {11-[p16]} [показ]
    показ: P15,P16,P18,P19,P20,P21
  -> Path15 => Loc9  вер=1 порядок=5
       текст: Pick up the maximum speed on the final straight
       условия: логика {[p16]=11}
       эффект: P6(YOU) = {[p6]+200/[p2]*100}
       эффект: P7(Racer 1) = {[p7]+200}
       эффект: P12(Competitor's engine) = {[p12]+200/1,09}
       эффект: P26(Experience) = {[p26]+[15..20]}
  -> Path16 => Loc13  вер=1 порядок=5
       условия: логика {[p13]>2}
  -> Path17 => Loc12  вер=1 порядок=5
       условия: логика {[p13]>20}
  -> Path18 => Loc11  вер=1 порядок=5
       условия: логика {[p13]>14}
  -> Path30 => Loc13  вер=1 порядок=5
       ответ: Your competitor left the distance. Now you just need to finish!
       условия: логика {[p13]<3}
       эффект: P7(Racer 1) = 10000 [скрыт]
       эффект: P30(Off from the distance) = 1
       скрыт: P8,P9,P12,P13,P14
  -> Path31 => Loc12  вер=1 порядок=5
       ответ: Your competitor left the distance. Now you just need to finish!
       условия: логика {[p13]<21}
       эффект: P7(Racer 1) +10000 [скрыт]
       эффект: P30(Off from the distance) = 1
       скрыт: P8,P9,P12,P13,P14
  -> Path32 => Loc11  вер=1 порядок=5
       ответ: Your competitor left the distance. Now you just need to finish!
       условия: логика {[p13]<15}
       эффект: P7(Racer 1) +10000 [скрыт]
       эффект: P30(Off from the distance) = 1
       скрыт: P8,P9,P12,P13,P14

### Loc11 [пустая]
    эффект: P19(Passing time) = {[400..600]}
    эффект: P20(Section damages) = {[30..70]}
    эффект: P21(Difficulty) = {[4..5]}
    эффект: P27(Area type) = 3
  -> Path19 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (41 to 55)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*100}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2}
  -> Path25 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (56 to 70)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*70}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/1,6}
  -> Path26 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (30 to 40)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*100}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2}

### Loc12 [пустая]
    эффект: P19(Passing time) = {[400..600]}
    эффект: P20(Section damages) = {[45..100]}
    эффект: P21(Difficulty) = {[2..4]}
    эффект: P27(Area type) = 2
  -> Path20 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (61 to 80)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*70}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/1,6}
  -> Path27 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (81 to 100)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*20}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)}
  -> Path28 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (45 to 60)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*100}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2}

### Loc13 [пустая]
    эффект: P19(Passing time) = {[400..600]}
    эффект: P20(Section damages) = {[1..25]}
    эффект: P21(Difficulty) = {[1..2]}
    эффект: P27(Area type) = 1
  -> Path21 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (10 to 17)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*130}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2,4}
  -> Path23 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (1 to 9)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*130}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2,4}
  -> Path24 => Loc7  вер=1 порядок=5
       условия: логика {[p20] in (18 to 25)}
       эффект: P13(Competitor's shield) = {[p13]-[p20]/([p14]+([p14]-100)*2*[p21])*115}
       эффект: P25(Handicap's time) = {([p19]/[p12]*100+[p19]/[p14]*50)/2,2}

### Loc15 [ПРОВАЛ]
    выбор описания: {[p23]}
    Loc15-1: You showed no talent in the race and lost! You couldn't even pass  <clr>the qualifying round<clrEnd>. /  / All you can do now is go back to your spaceship and l…
    Loc15-2: You didn't win glory and lost! You couldn't even win <clr>the semi-final race<clrEnd>. /  / All you can do now is get back to your spaceship and fly away from <…
    Loc15-3: You did your best to win but failed! You lost only <clr>the final race<clrEnd>! /  / All you can do now is get back to your spaceship and fly away from <ToPlane…

### Loc16 [УСПЕХ]
    Loc16-1: Slyboots doesn't even try to hide his exultation. You won, <clr>you are the CHAMPION <clrEnd>!!! /  / The crowd of fans quickly surrounded you, cheering your na…

### Loc18 [обычная]
    выбор описания: {[p23]}
    Loc18-1: Slyboots approached your foncer. / - Very bad, tied in the qualification test! What do you expect competing with more experienced racers? / Though it could have…
    Loc18-2: Slyboots approached your foncer. / - Bad, tied in the semi-final race! What do you expect competing with a champion? Alright, we still have a chance, a tie is n…
    Loc18-3: Slyboots approached your foncer. / - Not bad, tied in the final race! Though it could have been better. No side is winning yet. Recollect your strength, <Ranger…
  -> Path38 => Loc30  вер=1 порядок=5

### Loc19 [СТАРТ]
    выбор описания: {[p16]}
    Loc19-1: You landed softly and left your spaceship quickly. Nearby you saw a huge holographic screen with changing shots of small machine races and welcoming words to al…
    Loc19-2: - The track is divided into <clr>11 segments<clrEnd> of different complexity and length. You can pass each section using different tactics. Pay special attentio…
    Loc19-3: - Actually, a foncer is a small mountable vehicle with a powerful engine. Apart from the engine itself, it also has a forcefield generator, a feeble anti-gravit…
    Loc19-4: - The final part of the tournament consists of three stages. Namely:  /  / <clr>First stage<clrEnd> - Qualification race. At this stage you may compete with an …
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29
  -> Path41 => Loc33  вер=1
       текст: Go to draw lots
       эффект: P17(Reverse meter) = 1
  -> Path42 => Loc20  вер=1 порядок=2
       текст: Ask to tell you about the race
       эффект: P16(Meter) = 4
  -> Path44 => Loc21  вер=1 порядок=1
       текст: Ask to tell you about foncers
       эффект: P16(Meter) = 3
  -> Path47 => Loc22  вер=1 порядок=3
       текст: Ask to tell you about the tournament

### Loc20 [пустая]
  -> Path46 => Loc19  вер=1 порядок=5

### Loc21 [пустая]
  -> Path45 => Loc19  вер=1 порядок=5

### Loc22 [пустая]
    эффект: P16(Meter) = 2
  -> Path48 => Loc19  вер=1 порядок=5

### Loc23 [обычная]
    Loc23-1: You are in the machine shop; the chief mechanic needs the directions on power distribution and is giving necessary explanations: /  / - The main generator's pow…
    показ: P1,P2,P3,P4
  -> Path50 => Loc24  вер=1 порядок=1
       текст: Feed power to the engine
       условия: логика {([p2]<106) and ([p16]<10)}
       эффект: P2(Engine) +3
       эффект: P16(Meter) +1
  -> Path51 => Loc25  вер=1 порядок=2
       текст: Feed power to the forcefield generator
       условия: логика {([p3]<530) and ([p16]<10)}
       эффект: P3(Protection) +40
       эффект: P16(Meter) +1
  -> Path52 => Loc26  вер=1 порядок=3
       текст: Feed power to the manoeuvring sliders
       условия: логика {([p4]<106) and ([p16]<10)}
       эффект: P4(Manoeuvrability details) +3
       эффект: P16(Meter) +1
  -> Path53 => Loc27  вер=1 порядок=4
       текст: Drop power from the engine
       условия: логика {[p2]>91}
       эффект: P2(Engine) -3
       эффект: P16(Meter) -1
  -> Path54 => Loc28  вер=1 порядок=5
       текст: Drop power from the forcefield generator
       условия: логика {[p3]>330}
       эффект: P3(Protection) -40
       эффект: P16(Meter) -1
  -> Path55 => Loc29  вер=1 порядок=6
       текст: Drop power from the manoeuvring sliders
       условия: логика {[p4]>91}
       эффект: P4(Manoeuvrability details) -3
       эффект: P16(Meter) -1
  -> Path56 => Loc30  вер=1 порядок=7
       текст: Stop configuring the foncer
       условия: логика {[p16]=10}
       скрыт: P11

### Loc24 [пустая]
  -> Path62 => Loc23  вер=1 порядок=5

### Loc25 [пустая]
  -> Path61 => Loc23  вер=1 порядок=5

### Loc26 [пустая]
  -> Path60 => Loc23  вер=1 порядок=5

### Loc27 [пустая]
  -> Path57 => Loc23  вер=1 порядок=5

### Loc28 [пустая]
  -> Path58 => Loc23  вер=1 порядок=5

### Loc29 [пустая]
  -> Path59 => Loc23  вер=1 порядок=5

### Loc30 [пустая]
    эффект: P6(YOU) = {0} [показ]
    эффект: P7(Racer 1) = {0}
    эффект: P9(The second competitor) = {[p9]*([p23]<=2)+(3-[p9])*([p23]=3)}
    эффект: P10(Time difference) = {500} [показ]
    эффект: P11(Basic protection) = {[p3]}
    эффект: P30(Off from the distance) = 0
    показ: P1,P2,P3,P4,P5
  -> Path67 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. You don the racer's outfit. The foncer is driven to the starting-post. You mount it and start the engine. The generator purrs and your …
       условия: P8(The first competitor) 3..3; логика {[p23]=1}
       эффект: P12(Competitor's engine) = 97
       эффект: P13(Competitor's shield) = 450
       эффект: P14(Competitor's manoeuvrability) = 106
       показ: P8
  -> Path68 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. The foncer is driven to the starting-post again. Habitually, you mount it and start the engine without hesitation. The generator purrs,…
       условия: P9(The second competitor) 2..2; P23(Victory meter) 3..4
       эффект: P12(Competitor's engine) = 109
       эффект: P13(Competitor's shield) = 450
       эффект: P14(Competitor's manoeuvrability) = 100
       показ: P9
  -> Path69 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. The foncer is driven to the starting-post again. You mount it habitually and start the engine. The generator is purrs, and <clr>the Sem…
       условия: P9(The second competitor) 1..1; P23(Victory meter) 2..2
       эффект: P12(Competitor's engine) = 103
       эффект: P13(Competitor's shield) = 450
       эффект: P14(Competitor's manoeuvrability) = 103
       показ: P9
  -> Path87 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. You don the racer's outfit. The foncer is driven to the starting-post. You mount it and start the engine. The generator purrs and your …
       условия: P8(The first competitor) 1..1; логика {[p23]=1}
       эффект: P12(Competitor's engine) = 103
       эффект: P13(Competitor's shield) = {330}
       эффект: P14(Competitor's manoeuvrability) = 100
       показ: P8
  -> Path88 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. You don the racer's outfit. The foncer is driven to the starting-post. You mount it and start the engine. The generator purrs and your …
       условия: P8(The first competitor) 2..2; логика {[p23]=1}
       эффект: P12(Competitor's engine) = 94
       эффект: P13(Competitor's shield) = 530
       эффект: P14(Competitor's manoeuvrability) = 100
       показ: P8
  -> Path94 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. You put the racer's outfit. The foncer is driven to the starting-post again. You sit down habitually onto it and run the engine. The ge…
       условия: P9(The second competitor) 1..1; P23(Victory meter) 3..4
       эффект: P12(Competitor's engine) = 103
       эффект: P13(Competitor's shield) = 450
       эффект: P14(Competitor's manoeuvrability) = 103
       показ: P9
  -> Path95 => Loc6  вер=1 порядок=5
       ответ: You've made your choice. You put the racer's outfit. The foncer is driven to the starting-post again. You sit down habitually onto it and automatically run the …
       условия: P9(The second competitor) 2..2; P23(Victory meter) 2..2
       эффект: P12(Competitor's engine) = 109
       эффект: P13(Competitor's shield) = 450
       эффект: P14(Competitor's manoeuvrability) = 100
       показ: P9

### Loc31 [пустая]
  -> Path71 => Loc16  вер=1 порядок=5
       условия: логика {[p23]=4}
  -> Path93 => Loc32  вер=1 порядок=5
       условия: логика {[p23]<4}

### Loc32 [обычная]
    Loc32-1: Slyboots approached your foncer: /  / - Excellent! We were right trusting in you. If you want to stay in the current foncer model, it won't take long for our me…
    эффект: P3(Protection) = {[p11]}
    скрыт: P5,P6,P7,P8,P9,P10
  -> Path72 => Loc1  вер=1 порядок=8
       текст: Change the foncer model
       скрыт: P3,P1,P2,P4
  -> Path73 => Loc30  вер=1 порядок=5
       текст: Drive the same foncer model during the next race

### Loc33 [обычная] визитов<=4
    выбор описания: {[p17]}
    Loc33-1: The decor of the hall where the draw was to be held was imposing. A huge exposition was placed along the perimeter and around the seats. Old-fashioned models of…
    Loc33-2: Peleng Rasgush answers your greeting and those sitting in the hall are applauding to this display of his respect. / In all appearances, this racer prefers <clr>…
    Loc33-3: Maloq Gonsar is roaring some dark things and a slight murmur runs through the ranks. The thing is that all the sportsmen respect competitions and their atmosphe…
    Loc33-4: Faeyan Miatra answered your greetings with delicate kindness but his words were so grandiloquent, that there were only a few individuals in the hall who were ab…
  -> Path74 => Loc35  вер=1 проходов<=1 порядок=1
       текст: Greet the Peleng
       эффект: P17(Reverse meter) = 2
  -> Path75 => Loc34  вер=1 проходов<=1 порядок=2
       текст: Greet the Maloq
       эффект: P17(Reverse meter) = 3
  -> Path76 => Loc38  вер=1 проходов<=1 порядок=3
       текст: Greet the Faeyan
       эффект: P17(Reverse meter) = 4
  -> Path77 => Loc36  вер=1 проходов<=1
       текст: Take out a lot from the basket

### Loc34 [пустая] визитов<=1
  -> Path79 => Loc33  вер=1 проходов<=1 порядок=5

### Loc35 [пустая] визитов<=1
  -> Path78 => Loc33  вер=1 проходов<=1 порядок=5

### Loc36 [пустая] визитов<=1
  -> Path81 => Loc39  вер=1 проходов<=1 порядок=5
       эффект: P8(The first competitor) = 1
  -> Path82 => Loc39  вер=1 проходов<=1 порядок=5
       эффект: P8(The first competitor) = 2
  -> Path83 => Loc39  вер=1 проходов<=1 порядок=5
       эффект: P8(The first competitor) = 3

### Loc38 [пустая] визитов<=1
  -> Path80 => Loc33  вер=1 проходов<=1 порядок=5

### Loc39 [обычная] визитов<=2
    выбор описания: {[p8]}
    Loc39-1: You take a lot out of the basket, so do the other racers. In the issue, you are going to compete with <clr>Peleng Rasgush <clrEnd>. /  / Now you know your first…
    Loc39-2: You take a lot out of the basket, so do the other racers. In the issue, you are going to compete with <clr>the Maloq - Gonzar <clrEnd>. /  / Now you know your f…
    Loc39-3: You take a lot out of the basket, so do the other racers. In the issue, you are going to compete with <clr>Faeyan Miatra <clrEnd>. /  / Now you know your first …
  -> Path84 => Loc40  вер=1 проходов<=1 порядок=5
       текст: Take one more lot
       ответ: You take one more lot from the basket. Now, if you win the Qualification, you will compete with <clr>the Earthman named Vladimir Korchenitza <clrEnd> in the Sem…
       эффект: P9(The second competitor) = 1
  -> Path85 => Loc40  вер=1 проходов<=1 порядок=5
       текст: Take one more lot
       ответ: You take one more lot from the basket. Now, if you win the Qualification, you will compete with <clr>the Earthman named Mikhael Shulman <clrEnd> in the Semi-fin…
       эффект: P9(The second competitor) = 2

### Loc40 [пустая] визитов<=1
    эффект: P17(Reverse meter) = 0
  -> Path86 => Loc1  вер=1 проходов<=1 порядок=5
       текст: The draw is over, all you need to do now is go the boxes and choose the foncer

## Анализ
- стартовых: [19]
- концовки: {15: 'ПРОВАЛ', 16: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
