# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Money' [0..1000000] тип=обычный деньги
    старт: [1000]
    [0..1000000] Your money: <> cr.
    критическое: Сообщение достижения критического значения параметром 12
- P2 'Fear' [0..100] тип=провал
    старт: [100]
    [0..19] You're panicked.
    [20..39] You're frightened.
    [40..59] You are nervous.
    [60..79] You are slightly troubled.
    [80..100] You are absolutely calm.
    критическое: You realize that you can't stand that damned house any longer and rush away. You run up to locked do…
- P3 'Stuff' [0..1] тип=обычный
    старт: [0]
    [0..1] You've got:
    критическое: Сообщение достижения критического значения параметром 1
- P4 'Bottles' [0..3] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Bottle of water
    [2..2] Bottle of alcohol
    [3..3] Bottles of water and alcohol
    критическое: Сообщение достижения критического значения параметром 2
- P5 'Food' [0..3] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Loaf of bread
    [2..2] Meat sandwich
    [3..3] Bread and a meat sandwich
    критическое: Сообщение достижения критического значения параметром 3
- P6 'Keys' [0..3] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Key card
    [2..2] Magnetic key
    [3..3] Metal key
    критическое: Сообщение достижения критического значения параметром 5
- P7 'First-aid kit' [0..10] тип=обычный
    старт: [0]
    [0..10] <> sips of elixir
    критическое: Сообщение достижения критического значения параметром 9
- P8 'Weapon' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You are armed with a shard from a broken bottle.
    [2..2] You are armed with two shards from a broken bottle.
    [3..3] You are armed with a dagger.
    [4..4] You are armed with a sledgehammer.
    критическое: Сообщение достижения критического значения параметром 4
- P9 'Dress for a peleng girl' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You've got a peleng dress.
    [2..2] You have a female peleng's body in your arms.
    критическое: Сообщение достижения критического значения параметром 6
- P10 'Your health' [0..100] тип=провал
    старт: [100]
    [0..19] Your body is bedeviled.
    [20..39] Your wounds are bleeding.
    [40..59] You are wounded.
    [60..79] You've got a couple of abrasions.
    [80..100] You are okay.
    критическое: You look at your body in horror - it’s a bloody mess. You lose your concentration and start probing …
- P11 "Enemy's life" [0..100] тип=обычный
    старт: [0]
    [0..100] Enemy's health: <>
    критическое: Сообщение достижения критического значения параметром 17
- P12 'x' [0..10] тип=обычный
    старт: [1]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 11
- P13 'First row' [0..54321] тип=обычный
    старт: [54321]
    [0..54321] First row: <>
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Second row' [0..54321] тип=обычный
    старт: [0]
    [0..54321] Second row: <>
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Third row' [0..54321] тип=обычный
    старт: [0]
    [0..54321] Third row: <>
    критическое: Сообщение достижения критического значения параметром 15
- P16 'No.' [0..5] тип=обычный
    старт: [0]
    [0..0] You have no ring in your hands.
    [1..1] The following ring is in your hands: <>
    [2..2] The following ring is in your hands: <>
    [3..3] The following ring is in your hands: <>
    [4..4] The following ring is in your hands: <>
    [5..5] The following ring is in your hands: <>
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Description marker.' [0..10] тип=обычный
    старт: [1]
    [0..10] Parameter 17: <>
    критическое: Сообщение достижения критического значения параметром 8
- P18 'Pot marker.' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter 18: <>
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Modest and Almost Useless Parameter.' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P44 'Stairs.' [0..2] тип=обычный
    старт: [1]
    [0..2] Parameter 44: <>
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Bell strike.' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 45: <>
    критическое: Сообщение достижения критического значения параметром 45
- P47 'Contents of the pot.' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 47

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You leave the ship, squinting your eyes from the bright light of the star <ToStar>. You look around for the attendants. There’s nobody on the airfield. You go t…
    скрыт: P3,P10,P11,P13,P14,P15,P16,P17,P18,P19,P44,P45,P46,P47
  -> Path2 => Loc2  вер=1 порядок=9
       текст: Forget about the <Money> cr. and fly away.
  -> Path3 => Loc3  вер=1 порядок=4
       текст: Watch the stereovision.
  -> Path4 => Loc4  вер=1 порядок=2
       текст: Chat with the bartender.
       условия: P3(Stuff) 0..0
  -> Path5 => Loc5  вер=1 порядок=1
       текст: Wander over to the spaceport to look for your escorts.
       эффект: P12(x) = 1
  -> Path183 => Loc67  вер=100 проходов<=1 порядок=1
       текст: Wander over to the spaceport to look for your escorts.
       условия: P1(Money) 0..49
       эффект: P1(Money) = {[p1]+50}
       эффект: P12(x) = 1

### Loc2 [ПРОВАЛ]
    Loc2-1: You sit at the bar for a while, but nothing happens. You voice your displeasure and stroll sadly toward your ship. The galaxy is waiting for a hero; there's no …

### Loc3 [обычная]
    выбор описания: {[p17]}
    Loc3-1: The broadcast of the hatchball game is interrupted by an ad for a new horror film. A plaintive offscreen voice prophesies of a new apocalypse and hordes of bloo…
    Loc3-2: You try to watch the hatchball game - it’s rather pitiful. The players wander around the field and the ball moves slowly from one side to the other. Ultimately,…
  -> Path14 => Loc6  вер=1 порядок=5
       эффект: P17(Description marker.) = 2

### Loc4 [обычная]
    Loc4-1: You bang your glass on the counter to attract the bartender's attention. Since no one else is in the bar, the bartender leaves his glasses and approaches you. Y…
    эффект: P3(Stuff) +1
  -> Path16 => Loc8  вер=1
       текст: Go to the specified address.
       условия: P3(Stuff) 1..1
  -> Path20 => Loc6  вер=1 порядок=5
       текст: Don't leave. Stay and wait.

### Loc5 [обычная]
    выбор описания: {[p12]}
    Loc5-1: You tear yourself away from the chair and stroll back to the spaceport to look for your escorts. Along your way, you encounter several humans, faes, and pelengs…
    Loc5-2: The bread is packed in a shrink-wrapped plastic bag. The label says that it's made using an ancient human recipe and that it's very wholesome for all races. You…
    Loc5-3: Your eyes notice a bottle of mineral water "Mineral Quaka". And according to its advertising, it's literally packed with very beneficial and extremely healthy s…
    Loc5-4: You are staring eagerly at a sandwich loaded with a mixture of herbs and exotic spices. The middle of it is crowned with a golden piece of well-done meat. After…
    Loc5-5: What would a trip be without a bottle of alcohol? It's so versatile! You can use it to treat wounds, wipe windows, or make fire! And there must be dozens of oth…
  -> Path6 => Loc6  вер=1 порядок=9
       текст: Return to the bar.
  -> Path7 => Loc7  вер=1 проходов<=1 порядок=3
       текст: Buy a loaf of bread (18 cr.).
       условия: P1(Money) 18..1000000
       эффект: P1(Money) -18
       эффект: P5(Food) +1
       эффект: P12(x) = 2
       показ: P3
  -> Path9 => Loc7  вер=1 проходов<=1 порядок=2
       текст: Buy a bottle of mineral water (15 cr.).
       условия: P1(Money) 15..1000000
       эффект: P1(Money) -15
       эффект: P4(Bottles) +1
       эффект: P12(x) = 3
       показ: P3
  -> Path10 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Buy a bottle of medicinal alcohol (50 cr.).
       условия: P1(Money) 50..1000000
       эффект: P1(Money) -50
       эффект: P4(Bottles) +2
       эффект: P12(x) = 5
       показ: P3
  -> Path11 => Loc7  вер=1 проходов<=1 порядок=4
       текст: Buy a juicy meat sandwich (20 cr.).
       условия: P1(Money) 20..1000000
       эффект: P1(Money) -20
       эффект: P5(Food) +2
       эффект: P12(x) = 4
       показ: P3
  -> Path179 => Loc8  вер=1
       текст: Go to the specified address.
       условия: P3(Stuff) 1..1

### Loc6 [обычная]
    Loc6-1: Deep in thought, you perch yourself at a bar counter. A maloq bartender is lazily wiping glasses and watching the stereovision located above the counter. There'…
  -> Path12 => Loc3  вер=1 порядок=4
       текст: Watch the stereovision.
  -> Path13 => Loc5  вер=1 порядок=1
       текст: Wander over to the spaceport to look for your escorts.
       эффект: P12(x) = 1
  -> Path15 => Loc4  вер=1 порядок=2
       текст: Chat with the bartender.
       условия: P3(Stuff) 0..0
  -> Path175 => Loc8  вер=1
       текст: Go to the specified address.
       условия: P3(Stuff) 1..1
  -> Path180 => Loc2  вер=1 порядок=9
       текст: Forget about the <Money> cr. and fly away.
  -> Path184 => Loc67  вер=100 проходов<=1 порядок=1
       текст: Wander over to the spaceport to look for your escorts.
       условия: P1(Money) 0..49
       эффект: P1(Money) = {[p1]+50}
       эффект: P12(x) = 1

### Loc7 [пустая]
  -> Path8 => Loc5  вер=1 порядок=5

### Loc8 [обычная]
    Loc8-1: You reach the nearest surface station and take the express train to Nevits & Gnik's company offices. While the train's silver body races quietly along over the …
  -> Path17 => Loc11  вер=1 порядок=5
       текст: Start looking for the company's location.
       эффект: P17(Description marker.) = 1

### Loc10 [ПРОВАЛ]
    Loc10-1: Unable to stop trembling, you turn around and start walking away - slowly at first, then faster and faster - as far away from this gloomy mansion as you can get…

### Loc11 [обычная]
    Loc11-1: You don’t have to search for long. There's a holographic banner with the company name fluttering near a majestic old mansion. Built after the manner of the huma…
    Loc11-2: You grasp the massive bronze door knocker that hangs from a rope and start rapping on the door with it. / Smash!... / Smash!... / Smash!... / Everything around …
  -> Path21 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Knock.
  -> Path23 => Loc10  вер=1 порядок=9
       текст: Run.
  -> Path24 => Loc13  вер=1 порядок=5
       текст: Enter.
       ответ: You shrug your shoulders and press the door. You assumed that it would swing open slowly with a creak, but it unexpectedly opens easily and quickly. Underestima…

### Loc12 [пустая] визитов<=1
    эффект: P2(Fear) -10
  -> Path22 => Loc11  вер=1 проходов<=1 порядок=5

### Loc13 [обычная]
    выбор описания: {[p44]}
    Loc13-1: You're in a dismal but spacious hall. At a distance, there are two semicircular stairs that lead to the second floor. There are three doors on the first floor. …
    Loc13-2: You're in a dismal but spacious hall. At a distance, there are two semicircular stairs that lead to the second floor. The stairs on the left have collapsed. A b…
  -> Path25 => Loc14  вер=100 проходов<=1 порядок=5
       текст: Go up the stairs on your right.
       ответ: You begin to ascend to the second floor on the stairs to your right. The stairs creak ominously under your feet, but they hold fast. After reaching the second f…
  -> Path34 => Loc18  вер=1 порядок=2
       текст: Enter the middle door.
       эффект: P12(x) = 1
  -> Path44 => Loc22  вер=1 порядок=1
       текст: Enter the left door.
       ответ: You approach a thick metal door which looks quite odd among the mansion's ancient furniture. You pull its handle forcefully. The door moves slightly and you can…
       условия: P44(Stairs.) 1..1
  -> Path46 => Loc23  вер=1 проходов<=1 порядок=4
       текст: Go up the left stairs.
       эффект: P44(Stairs.) +1
  -> Path67 => Loc34  вер=1 порядок=3
       текст: Enter the right door.
  -> Path135 => Loc52  вер=1 порядок=1
       текст: Enter the left door.
       условия: P44(Stairs.) 2..2
  -> Path193 => Loc14  вер=1 порядок=5
       текст: Go up the stairs on your right.

### Loc14 [обычная]
    Loc14-1: You are in an empty and dreary passage. There are stairs behind you that lead to the first floor. There are five identical doors in the passage. The second door…
  -> Path26 => Loc15  вер=1 проходов<=1 порядок=3
       текст: Enter the third door.
  -> Path31 => Loc13  вер=1 порядок=9
       текст: Go downstairs.
  -> Path43 => Loc21  вер=1 порядок=5
       текст: Enter the fifth door.
       эффект: P12(x) = 1
  -> Path52 => Loc26  вер=1 порядок=1
       текст: Enter the first door.
       условия: P6(Keys) 0..1; P9(Dress for a peleng girl) 0..0
  -> Path86 => Loc41  вер=1 порядок=1
       текст: Enter the first door.
       условия: P9(Dress for a peleng girl) 1..1
       эффект: P9(Dress for a peleng girl) = 0 [скрыт]
       эффект: P10(Your health) = 100 [показ]
       эффект: P11(Enemy's life) = 65 [показ]
       эффект: P12(x) = 1
  -> Path87 => Loc42  вер=1 порядок=1
       текст: Enter the first door.
       ответ: Trying to hold your burden more comfortably, you approach the door. It disappears into the wall immediately. The peleng girl is standing in the opening, wrapped…
       условия: P9(Dress for a peleng girl) 2..2
       эффект: P9(Dress for a peleng girl) = 0 [скрыт]
  -> Path99 => Loc44  вер=100 проходов<=1 порядок=4
       текст: Enter the fourth door.
       ответ: The fourth door has an ancient maloq style. It isn't finished, but it is made of very hard wood and reinforced with wide iron strips. Pushing the door open, you…
  -> Path158 => Loc61  вер=1 порядок=2
       текст: Enter the second door.
       условия: P45(Bell strike.) 0..0
  -> Path160 => Loc62  вер=1 порядок=2
       текст: Enter the second door.
       условия: P45(Bell strike.) 1..1
       эффект: P2(Fear) -10
       эффект: P11(Enemy's life) = 100 [показ]
       эффект: P12(x) = 1
       показ: P10
  -> Path191 => Loc44  вер=1 порядок=4
       текст: Enter the fourth door.

### Loc15 [обычная] визитов<=1
    Loc15-1: You enter and close the door tightly behind you. The furnishings in the third room were scarce. On the far wall of the narrow, rectangular room, there is a huge…
    эффект: P2(Fear) -7
  -> Path27 => Loc14  вер=1 порядок=9
       текст: Run!
       ответ: You rush toward the door, hoping that the creature exists only in the mirror world. Crashing into it with your body, you jump out into the passage and slam shut…
  -> Path28 => Loc16  вер=1 [всегда видна] порядок=5
       текст: Try to use the meat sandwich to entice the creature behind the door.
       ответ: You take the meat sandwich from your pocket, put it on the floor, and kick it toward the door. The sandwich slides along the surface of the floor and stops righ…
       условия: P5(Food) 2..3
       эффект: P2(Fear) -5
       эффект: P5(Food) -2
  -> Path29 => Loc17  вер=1 порядок=5
       текст: Kick the hand.
       ответ: You decide to see what's on the other end of the hand, so you approach the door and swing your leg so that your reflection kicks the hand. The hand rushes forwa…
       эффект: P2(Fear) -15
       эффект: P46(Знание о зазеркальной твари) +1

### Loc16 [обычная]
    Loc16-1: You are about to leave the room before the creature returns. You turn back to the mirror and see the door in the mirror swinging wide open. There it is, standin…
    эффект: P2(Fear) -5
    эффект: P46(Знание о зазеркальной твари) +1
  -> Path30 => Loc14  вер=1 порядок=5
       текст: Run!
       ответ: In an attempt to save both your reflection and yourself, you jump to the side to slip past the creature. You rush toward the door, jump out into the passage, an…
  -> Path32 => Loc17  вер=1 порядок=5
       текст: Try to kill the creature.
       ответ: You tear a massive leg from an armchair that is unexpectedly fragile and swing it around, trying to hit the creature's head. Your task is complicated by the fac…
       эффект: P2(Fear) -15

### Loc17 [обычная]
    Loc17-1: The beast tosses the gnawed leg aside and approaches the mirror, touching it with its long white fingers. Bloody fingerprints appear on the glass of the mirror.…
    эффект: P2(Fear) -15
  -> Path33 => Loc14  вер=1 порядок=5
       текст: Run!
       ответ: You swing the door wide, jump out into the passage and slam the door shut right on the creature's nose. You hear a deafening crash, a shriek, and the gnashing o…

### Loc18 [обычная]
    выбор описания: {[p12]}
    Loc18-1: You head to the middle door, stepping cautiously across the creaking floorboards. The door is quite plain, made of rough wood without any decorations. It squeak…
    Loc18-2: Wielding a heavy iron hammer, you approach the bell. Bells are made to be hit, right? Is it here for nothing? / You swing the hammer and strike the bell’s shimm…
    Loc18-3: You swing your arm and strike the bell’s shimmering surface as hard as possible with your fist. Nothing happens. The bell doesn’t ring and continues to buzz qui…
    Loc18-4: You’re in a small room, looking at a sinister semi-transparent bell. You can hear it buzzing faintly. What do you do next?
  -> Path35 => Loc13  вер=1 порядок=5
       текст: Leave the room.
  -> Path37 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Hit the bell with the bottle of alcohol.
       условия: P4(Bottles) 2..3
       эффект: P2(Fear) +2
       эффект: P4(Bottles) -2
       эффект: P12(x) = 2
  -> Path38 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Hit the bell with the bottle of water.
       условия: P4(Bottles) ∈[1, 3]
       эффект: P4(Bottles) -1
       эффект: P12(x) = 1
  -> Path41 => Loc20  вер=1 проходов<=1 порядок=3
       текст: Hit the bell with your fist.
       эффект: P12(x) = 3
  -> Path145 => Loc59  вер=1 проходов<=1 порядок=4
       текст: Hit the bell with the hammer.
       условия: P8(Weapon) 4..4
       эффект: P45(Bell strike.) +1

### Loc19 [обычная]
    выбор описания: {[p12]}
    Loc19-1: You take the bottled water from the pocket of your trusty Ranger overalls and approach the bell. Bells are made to be hit, right? Is it here for nothing? You sw…
    Loc19-2: You remove the bottle of alcohol from the pocket of your trusty Ranger overalls, take a swig for courage, and approach the bell. Bells are made to be hit, right…
  -> Path39 => Loc18  вер=1 порядок=5
       текст: Keep the sharp glass.
       условия: P8(Weapon) 0..1
       эффект: P8(Weapon) +1
       эффект: P12(x) = 4
  -> Path40 => Loc18  вер=1 порядок=5
       текст: Get rid of the sharp glass.
       эффект: P12(x) = 4

### Loc20 [пустая] визитов<=1
  -> Path42 => Loc18  вер=1 проходов<=1 порядок=5

### Loc21 [обычная]
    выбор описания: {[p12]}
    Loc21-1: You approach the fifth door. It's an automated door that senses your approach; it swings open, loudly striking the wall. You enter the room. /  / Apparently, it…
    Loc21-2: You lift the receiver from the videophone and try to call the spaceport to see if your escorts have arrived. The speaker has been ripped out, but you stare, qui…
    Loc21-3: You look at the papers on the table. They are covered with rows of figures and unfamiliar bureaucratic jargon. Trying desperately to find anything valuable on t…
    Loc21-4: You take the album from the drawer and activate it. The device starts functioning, though with a bit of interference. An idyllic scene appears in the air before…
  -> Path47 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Call somebody using the videophone.
       эффект: P2(Fear) = {[p2]-15}
       эффект: P12(x) = 2
  -> Path49 => Loc14  вер=1 порядок=9
       текст: Go out to the passage.
  -> Path50 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Search the table.
  -> Path190 => Loc24  вер=1 порядок=5
       текст: Watch the photo album.
       условия: P12(x) 3..3
       эффект: P12(x) = 4

### Loc22 [обычная]
  -> Path45 => Loc13  вер=1 порядок=5

### Loc23 [обычная] визитов<=1
    Loc23-1: You begin to go up the left stairs. After rising only a couple of steps, the stairs begin to creak ominously under your feet. There is a loud crash of rotting w…
  -> Path119 => Loc51  вер=1 проходов<=1 порядок=5
       текст: Go forward along the tunnel.

### Loc24 [пустая]
  -> Path48 => Loc21  вер=1 порядок=5

### Loc25 [пустая] визитов<=1
    эффект: P6(Keys) +1
    эффект: P12(x) = 3
    показ: P3
  -> Path51 => Loc21  вер=1 проходов<=1 порядок=5

### Loc26 [обычная]
    Loc26-1: As you approach the first door, a click sounds suddenly from deep inside and a small slot appears in its center. You look at it and even poke your finger in it,…
  -> Path53 => Loc14  вер=1 порядок=9
       текст: Step aside.
  -> Path54 => Loc27  вер=1 порядок=5
       текст: Insert the card into the slot.
       условия: P6(Keys) 1..1
       эффект: P6(Keys) -1
       эффект: P17(Description marker.) = 1

### Loc27 [обычная]
    выбор описания: {[p17]}
    Loc27-1: You bring the card to the crack and suddenly it gets sucked inside. After a loud click, the door slides silently into the wall. A short passage lies before you,…
    Loc27-2: - <Ranger>?.. No, I don't know you! Go away! I don't want to speak to you. I'm expecting a visitor soon, do you hear? Go away until after he’s gone. Quickly! / …
    Loc27-3: "That's a LIE!" The voice suddenly becomes very high and you can hear hysterical sobs. "I don't have any parents! I buried them myself! I remember...I remember …
    Loc27-4: Suddenly, the door bulges towards you, as if a furious gobsaurus had rammed into it. / "YOU VILE WENCH!!! You stole my Cesska Ritz! He was mine, you understand,…
    Loc27-5: YOU?! The speaker cracks from the female peleng’s fierce shout. You dare come here after what you did?! I've seen it...all of it! You gave that wench a slime bo…
  -> Path55 => Loc28  вер=1 проходов<=1 порядок=5
       текст: I'm Ranger <Ranger>!
  -> Path56 => Loc30  вер=1 проходов<=1 порядок=5
       текст: That's me, Cesska Ritz!
  -> Path57 => Loc33  вер=1 проходов<=1 порядок=5
       текст: It's your parents!
  -> Path58 => Loc32  вер=1 проходов<=1 порядок=5
       текст: It's Shitzka. So you remember me?
  -> Path59 => Loc29  вер=1 порядок=5
       текст: I'm the best lyakusha you know!

### Loc28 [пустая] визитов<=1
    эффект: P17(Description marker.) = 2
  -> Path62 => Loc27  вер=1 проходов<=1 порядок=5

### Loc29 [обычная]
    Loc29-1: "What?... Is that you?" The voice in the speaker becomes warmer. "Cesska Ritz?"
  -> Path60 => Loc30  вер=1 проходов<=1 порядок=5
       текст: Yes, it's me!
  -> Path61 => Loc31  вер=1 порядок=5
       текст: No, a different lyakusha!

### Loc30 [пустая]
    эффект: P2(Fear) -15
    эффект: P17(Description marker.) = 5
  -> Path65 => Loc27  вер=1 порядок=5

### Loc31 [обычная]
    Loc31-1: The speaker remains silent. You had decided that the young female peleng didn't want to speak to you when the door suddenly hit the wall, opening a typical bedr…
    эффект: P6(Keys) = 2
  -> Path66 => Loc14  вер=1 порядок=5

### Loc32 [пустая] визитов<=1
    эффект: P2(Fear) -15 «Suddenly, the door bulges towards you, as if a furious gobsa…»
    эффект: P17(Description marker.) = 4
  -> Path64 => Loc27  вер=1 проходов<=1 порядок=5

### Loc33 [пустая] визитов<=1
    эффект: P2(Fear) -15
    эффект: P17(Description marker.) = 3
  -> Path63 => Loc27  вер=1 проходов<=1 порядок=5

### Loc34 [обычная]
    Loc34-1: You approach the right door and pull on it. The door doesn’t give. Examining it carefully, you notice a small groove. It might be a slot for some sort of key.
  -> Path68 => Loc13  вер=1 порядок=9
       текст: Move away from the door.
  -> Path69 => Loc68  вер=1 порядок=5
       текст: Insert the magnetic key into the slot.
       условия: P6(Keys) 2..2
       показ: P13,P14,P15,P16

### Loc36 [обычная]
    выбор описания: {1+([p14]=54321)+([p15]=54321)}
    Loc36-1: Which ring should be removed now?
    Loc36-2: Marvelous! You collected all the rings on one pole. I wonder what will happen next.
  -> Path70 => Loc37  вер=1 порядок=1
       текст: Remove the ring from the first row.
       условия: логика {[p13]<>0 and [p15]<>54321}
       эффект: P13(First row) = {[p13] div 10}
       эффект: P16(No.) = {[p13] mod 10}
  -> Path73 => Loc38  вер=1 порядок=2
       текст: Take the ring from the second row.
       условия: логика {[p14]<>0 and [p15]<>54321}
       эффект: P14(Second row) = {[p14] div 10}
       эффект: P16(No.) = {[p14] mod 10}
  -> Path76 => Loc39  вер=1 порядок=3
       текст: Remove the ring from the third row.
       условия: логика {[p15]<>0 and [p15]<>54321}
       эффект: P15(Third row) = {[p15] div 10}
       эффект: P16(No.) = {[p15] mod 10}
  -> Path79 => Loc13  вер=1 порядок=9
       текст: Leave the room.
       ответ: You give up on the difficult puzzle and start to leave the room. An obscure grinding sound came from behind you, and when you turn around, all the rings have be…
       условия: P14(Second row) 0..54320; P15(Third row) 0..54320; логика {[p13]<>54321}
       эффект: P14(Second row) = {0} [скрыт]
       эффект: P15(Third row) = {0} [скрыт]
       эффект: P13(First row) = 54321 [скрыт]
       эффект: P16(No.) = {0} [скрыт]
  -> Path80 => Loc40  вер=1 порядок=9
       текст: Wait for the effect to kick in.
       условия: логика {([p15]=54321) or ([p14]=54321)}
       эффект: P8(Weapon) = 3
       эффект: P12(x) = 1
  -> Path182 => Loc13  вер=1 порядок=9
       текст: Leave the room.
       ответ: You give up on the difficult puzzle and start to leave the room.
       условия: P14(Second row) 0..54320; P15(Third row) 0..54320; логика {[p13]=54321}
       эффект: P14(Second row) = {0} [скрыт]
       эффект: P15(Third row) = {0} [скрыт]
       эффект: P13(First row) = 54321 [скрыт]
       эффект: P16(No.) = {0} [скрыт]
  -> Path188 => Loc40  вер=1 порядок=8
       текст: Give up on the puzzle and force the door open.
       условия: логика {([p15]<>54321) and ([p14]<>54321)}
       эффект: P2(Fear) = {[p2]-20}
       эффект: P10(Your health) -3
       эффект: P12(x) = 2

### Loc37 [обычная]
    Loc37-1: You pull a heavy stone ring from the top row. The relief images of skulls dig into your hands. Where can this heavy thing be hung?
  -> Path71 => Loc36  вер=1 порядок=2
       текст: Hang it on the second row.
       ответ: Holding the ring at chest level, you bring it to the middle pole and hang it cautiously. Now you should rearrange the other rings.
       условия: логика {[p16]<([p14] mod 10) or [p14]=0}
       эффект: P14(Second row) = {[p14]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path72 => Loc36  вер=1 порядок=3
       текст: Hang it on the third row.
       ответ: You roll the ring to the bottom pole near the floor and hang it there.
       условия: логика {[p16]<([p15] mod 10) or [p15]=0}
       эффект: P15(Third row) = {[p15]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path82 => Loc36  вер=1 порядок=7
       текст: Put it back.
       эффект: P13(First row) = {[p13]*10+[p16]}
       эффект: P16(No.) = 0

### Loc38 [обычная]
    Loc38-1: You pull a stone ring off of the middle pole and, struggling to keep it in your hands, you wonder what pole it should go on.
  -> Path74 => Loc36  вер=1 порядок=1
       текст: Hang it on the first row.
       ответ: Straining all your muscles, you lift the ring to the very top and hang it on the upper pole.
       условия: логика {[p16]<([p13] mod 10) or [p13]=0}
       эффект: P13(First row) = {[p13]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path75 => Loc36  вер=1 порядок=3
       текст: Hang it on the third row.
       ответ: You roll the ring to the bottom pole near the floor and hang it there.
       условия: логика {[p16]<([p15] mod 10) or [p15]=0}
       эффект: P15(Third row) = {[p15]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path81 => Loc36  вер=1 порядок=7
       текст: Put it back.
       эффект: P14(Second row) = {[p14]*10+[p16]}
       эффект: P16(No.) = 0

### Loc39 [обычная]
    Loc39-1: You pull a ring from the bottom row and placing it edgewise on the floor. You lean on it and look at the other poles. Which one should you hang the ring on?
  -> Path77 => Loc36  вер=1 порядок=1
       текст: Hang it on the first row.
       ответ: Straining all your muscles, you lift the ring to the very top and hang it on the upper pole.
       условия: логика {[p16]<([p13] mod 10) or [p13]=0}
       эффект: P13(First row) = {[p13]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path78 => Loc36  вер=1 порядок=2
       текст: Hang it on the second row.
       ответ: Holding the ring at chest level, you bring it to the middle pole and hang it cautiously. Now you should rearrange the other rings.
       условия: логика {[p16]<([p14] mod 10) or [p14]=0}
       эффект: P14(Second row) = {[p14]*10+[p16]}
       эффект: P16(No.) = 0
  -> Path83 => Loc36  вер=1 порядок=7
       текст: Put it back.
       эффект: P15(Third row) = {[p15]*10+[p16]}
       эффект: P16(No.) = 0

### Loc40 [обычная]
    выбор описания: {[p12]}
    Loc40-1: As soon as you step back from the poles to admire your work, they suddenly fall into the wall along with the rings. A small door swings open in the far wall, an…
    Loc40-2: You begin forcing the small door. It gives way little by little. Unexpectedly, just then the skulls on the rings started talking! /  / "Look at him!" said the h…
    скрыт: P13,P14,P15,P16
  -> Path84 => Loc13  вер=1 порядок=5
       текст: Carry the body with you.
       ответ: Deciding not to dishonor the poor peleng girl, you lift her body from the floor and, holding her in your arms, bring her out of the room. The peleng girl turns …
       эффект: P6(Keys) = 0
       эффект: P9(Dress for a peleng girl) = 2
  -> Path85 => Loc13  вер=1 порядок=5
       текст: Take off the dress.
       ответ: Damning yourself and screwing up your face from time to time, you begin taking off the dead peleng girl's dress. You feel like a total pervert. Nevertheless, so…
       эффект: P6(Keys) = 0
       эффект: P9(Dress for a peleng girl) = 1

### Loc41 [обычная]
    выбор описания: {[p12]}
    Loc41-1: Trying to hold your burden more comfortably, you approach the door. It instantly disappeared into the wall. The peleng girl is standing in the opening, wrapped …
    Loc41-2: The creature rushes forward promptly, and you have no time to jump aside as it sticks its long fangs into your neck and steps back immediately. Blood from your …
    Loc41-3: The creature rushes at you, exposing its claws. You try to evade, but it makes contact. Slanting deep gashes appear across your chest, but for some reason you f…
    Loc41-4: The creature rushes at you in an attempt to pierce you with its claws and thrash you, but you jump aside. The former peleng girl realizes that she missed and tu…
  -> Path88 => Loc43  вер=1 порядок=1
       текст: Hit the creature with your fists.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[5..30]*0,4}
       эффект: P12(x) = 2
  -> Path89 => Loc43  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Splash alcohol on the enemy.
       условия: P4(Bottles) 2..3
       эффект: P4(Bottles) -2
       эффект: P11(Enemy's life) -50
       эффект: P12(x) = 3
  -> Path90 => Loc43  вер=4 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[23..33]*0,2*[p8]}
       эффект: P12(x) = 5
  -> Path91 => Loc43  вер=3 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[35..40]*0,2*[p8]}
       эффект: P12(x) = 7
  -> Path92 => Loc43  вер=1 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 6
  -> Path93 => Loc43  вер=1 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 8
  -> Path115 => Loc43  вер=1 порядок=9
       текст: Swallow a little bit of the potion.
       условия: P7(First-aid kit) 1..10
       эффект: P7(First-aid kit) -1
       эффект: P10(Your health) = {[p10]+[30..40]}
       эффект: P12(x) = 1
  -> Path178 => Loc43  вер=1 порядок=2
       текст: Kick with your leg.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[10..26]*0,4}
       эффект: P12(x) = 4
  -> Path195 => Loc43  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Eat the sandwich.
       условия: P5(Food) 2..3
       эффект: P5(Food) -2
       эффект: P10(Your health) = {[p10]+[25..35]}
       эффект: P12(x) = 9

### Loc42 [обычная]
    Loc42-1: The bedroom was rather small - only an ancient wooden bed with curtains and a night stand. Having become quite accustomed to searching through things that aren'…
    эффект: P6(Keys) = 3
  -> Path98 => Loc14  вер=1 порядок=5

### Loc43 [обычная]
    выбор описания: {[p12]}
    Loc43-1: You jump out of the monster's way and quickly take a small sip of elixir. Some of your wounds heal right before your very eyes.
    Loc43-2: Thoroughly regretting your lack of a weapon, you strike at the creature with your fists. It doesn’t even bother to block your blow, instead receiving it and sha…
    Loc43-3: You snatch the bottle of alcohol from your pocket and hit your enemy in the face. The bottle breaks and alcohol splashes over what used to be a peleng girl. She…
    Loc43-4: You kick the creature. It shakes slightly and attacks you with a couple of its clawed hands, but misses.
    Loc43-5: You take a wide diagonal swing with your weapon, trying to hit the creature. It wasn't difficult. The creature totters. Its face and chest have new wounds, but …
    Loc43-6: You take an awkward, slanting swing with your weapon, trying to hit the creature, but it dodges safely and advances on you.
    Loc43-7: You make a sudden attack to pierce the creature. And you succeed. With a soft crunch, your weapon strikes against your enemy's flesh. Huffing and annoyed, the c…
    Loc43-8: You attempt another blow, but miss. The creature easily slips aside.
    Loc43-9: You jump back from the monster and munch on the sandwich. You immediately feel more vigorous and some of your wounds heal.
  -> Path94 => Loc41  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P12(x) = 4
  -> Path95 => Loc41  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[16..21]}
       эффект: P12(x) = 2
  -> Path96 => Loc41  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[10..16]}
       эффект: P12(x) = 3
  -> Path97 => Loc42  вер=1 порядок=5
       текст: Go on
       ответ: When you manage to hit the creature again, it suddenly falls down on the floor and lies still. A pool of blood slowly accumulates underneath it. Surprised, you …
       условия: P11(Enemy's life) 0..0
       эффект: P10(Your health) = 100 [скрыт]
       скрыт: P11

### Loc44 [обычная]
    выбор описания: {[p18]+1}
    Loc44-1: Most of the room contains wide bookcases with old, shabby books. Some hemispherical object is situated right in the middle. Its gurgling reminds you of the soun…
    Loc44-2: Most of the room contains wide bookcases with old, shabby books. The familiar pot was situated in the middle. It stank horribly from your failed experiment. The…
    Loc44-3: Most of the room contains wide bookcases with old, shabby books. The familiar pot is situated in the middle, completely empty. There is an open book lying on th…
  -> Path100 => Loc14  вер=1 порядок=9
       текст: Leave the room.
  -> Path101 => Loc45  вер=1 порядок=5
       текст: Read books from the bookcases.
  -> Path103 => Loc69  вер=1 проходов<=1 порядок=2
       текст: Examine the pot.
       условия: P18(Pot marker.) 1..2
       эффект: P12(x) = 0
  -> Path104 => Loc47  вер=1 порядок=1
       текст: Read the book lying near the pot.
  -> Path198 => Loc46  вер=1 порядок=2
       текст: Examine the pot.
       условия: P18(Pot marker.) 0..0
       эффект: P12(x) = 0

### Loc45 [обычная]
    Loc45-1: You take a book at random from the bookcase and open it. The title was very difficult to read: "Aliada Ansata". / You leaf through the book. It was written by h…
    Loc45-2: You take the first book from the shelf. Its cover is engraved with the shape of a capital letter "Z". You open the book at random and come across some incompreh…
    Loc45-3: You swipe one of the books from the bookshelf at random and open it. Curiously, the book pages are utterly empty. You thumb through the book, but there isn't an…
    Loc45-4: You run your fingers down the spines of the books and pull out one at random. The book seems to be the memoirs of some human. On one of the pages the stories co…
    Loc45-5: You swipe the next book from the shelf, but try as you might, you can't get it open. As you put it back on the shelf, you notice an inscription on the back of t…
  -> Path102 => Loc44  вер=1 порядок=5

### Loc46 [обычная]
    выбор описания: {1+[p12]}
    Loc46-1: The hemispherical object is a huge. blackened pot sitting on a plasma heater. A dark mass was heaped up in the pot. Apparently, some unknown cook had tried to m…
    Loc46-2: You notice a book lying near the pot. It says something about "dry seeds of life". Maybe it means grains of wheat? Deciding to risk it, you get a piece of hard …
    Loc46-3: You notice that the book lying near the pot says something about not enough water. Maybe alcohol would work as a substitute? You yank off the bottle's cap and p…
    Loc46-4: You notice that the book lying near the pot says something about not enough water. Praising yourself for your foresight, you take the bottle of mineral water fr…
    Loc46-5: You notice a book lying near the pot. It says something about "dry seeds of life". Maybe it means grains of wheat? Deciding to risk it, you get the juicy meat s…
  -> Path106 => Loc44  вер=1 порядок=9
       текст: Step away from the pot.
  -> Path107 => Loc48  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Add alcohol to the pot.
       условия: P4(Bottles) 2..3; P18(Pot marker.) 0..0
       эффект: P4(Bottles) -2
       эффект: P12(x) = 2
       эффект: P47(Contents of the pot.) = 5
  -> Path108 => Loc48  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Add water to the pot.
       условия: P18(Pot marker.) 0..0; логика {[p4]=1 or [p4]=3}
       эффект: P4(Bottles) -1
       эффект: P12(x) = 3
       эффект: P47(Contents of the pot.) +1
  -> Path109 => Loc48  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Throw bread in the pot.
       условия: P18(Pot marker.) 0..0; логика {[p5]=1 or [p5]=3}
       эффект: P5(Food) -1
       эффект: P12(x) = 1
       эффект: P47(Contents of the pot.) +1
  -> Path110 => Loc48  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Throw a sandwich in the pot.
       условия: P5(Food) 2..3; P18(Pot marker.) 0..0
       эффект: P5(Food) -2
       эффект: P12(x) = 4
       эффект: P47(Contents of the pot.) = 4
  -> Path112 => Loc49  вер=1 проходов<=1 порядок=8
       текст: Switch the plasma heater on.
       условия: P47(Contents of the pot.) 1..10

### Loc47 [обычная]
    Loc47-1: You pick a book up from the floor. You blow off the dust and carefully read the gray text. / "Day three. The healing potion is almost ready. I have enough ingre…
  -> Path105 => Loc44  вер=1 порядок=5

### Loc48 [пустая]
  -> Path111 => Loc46  вер=1 порядок=5

### Loc49 [обычная] визитов<=1
  -> Path113 => Loc44  вер=1 порядок=5
       ответ: You switch the plasma heater on and the contents of the pot disappear immediately behind a silver clouds of vapor. In seconds the vapor is gone. The pot is fill…
       условия: P47(Contents of the pot.) 2..2
       эффект: P7(First-aid kit) = 10
       эффект: P18(Pot marker.) = 2
  -> Path114 => Loc44  вер=1 порядок=5
       ответ: You switch the plasma heater on, and everything disappears immediately behind a puff of smoke. Coughing and sneezing, you manage to turn the heater off. The con…
       условия: логика {[p47]<>2}
       эффект: P18(Pot marker.) = 1

### Loc51 [обычная] визитов<=1
    Loc51-1: You pass through the tunnel, holding to the rough earthen wall. The slightly illuminated opening disappears around a curve of the tunnel, and you find yourself …
  -> Path120 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Distract the spider by throwing it the sandwich.
       ответ: You swing good and hard and throw the sandwich into the room. The spider waits for some time. Then, deciding that the sandwich is not a living creature, it gets…
       условия: P5(Food) 2..3
       эффект: P5(Food) -2
  -> Path121 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Distract the spider by throwing it the bread.
       ответ: You swing good and hard and throw the bread into the room. The spider notices that the bread is not a living creature, it gets down and grasps its mandible over…
       условия: логика {[p5]=1 or [p5]=3}
       эффект: P5(Food) -1
  -> Path122 => Loc53  вер=1 порядок=9
       текст: Attack the spider.
       эффект: P11(Enemy's life) = 80 [показ]
       эффект: P12(x) = 1
       показ: P10

### Loc52 [обычная]
    выбор описания: {([p8]=4)+1}
    Loc52-1: You examine the well-lit room, which has two doors. One of them is made of wood and is very thick. There is an enormous steel bolt in place, which prevents the …
    Loc52-2: You examine the well-lit room, which has two doors. One of them is made of wood and is very thick. There is an enormous steel bolt in place, which prevents the …
  -> Path134 => Loc55  вер=1 порядок=6
       текст: Go to the wooden door.
  -> Path136 => Loc13  вер=1 порядок=5
       текст: Go to the metal door.
       ответ: You remove the bolt from the door and discover that it goes right into the main hall of the mansion. It was the door on the left that you couldn't open from the…
       условия: P19(Modest and Almost Useless Parameter.) 0..0
       эффект: P19(Modest and Almost Useless Parameter.) +1
  -> Path181 => Loc13  вер=1 порядок=5
       текст: Go through the metal door.
       условия: P19(Modest and Almost Useless Parameter.) 1..1

### Loc53 [обычная]
    выбор описания: {[p12]}
    Loc53-1: You run into the middle of the room and stand motionless. The spider hesitates for a moment, but then descends and approaches you. Apparently, it thinks you are…
    Loc53-2: The spider rushes forward with incredible speed for its size. It seizes your body in its mandible. With incredible effort, you manage to liberate yourself from …
    Loc53-3: The spider strikes at you with its sharp-tipped legs, weaving and dodging you impressively. You fall backward. Narrow cuts appear on your body. But still no pai…
    Loc53-4: The spider rushes towards you. You decide to apply your military cunning and you fall flat to the ground. Unable to stop, the spider flies right over you. You c…
  -> Path123 => Loc54  вер=1 порядок=1
       текст: Hit the spider with your fists.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[10..35]*0,3}
       эффект: P12(x) = 1
  -> Path124 => Loc54  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Splash alcohol on the spider.
       условия: P4(Bottles) 2..3
       эффект: P4(Bottles) -2
       эффект: P11(Enemy's life) -50
       эффект: P12(x) = 2
  -> Path125 => Loc54  вер=4 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[23..33]*0,2*[p8]}
       эффект: P12(x) = 6
  -> Path126 => Loc54  вер=3 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[35..40]*0,2*[p8]}
       эффект: P12(x) = 5
  -> Path127 => Loc54  вер=1 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 8
  -> Path128 => Loc54  вер=1 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 7
  -> Path132 => Loc54  вер=1 порядок=9
       текст: Swallow a little bit of the potion.
       условия: P7(First-aid kit) 1..10
       эффект: P7(First-aid kit) -1
       эффект: P10(Your health) = {[p10]+[30..40]}
       эффект: P12(x) = 3
  -> Path176 => Loc54  вер=1 порядок=2
       текст: Kick with your leg.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[15..28]*0,3}
       эффект: P12(x) = 4
  -> Path194 => Loc54  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Eat the sandwich.
       условия: P5(Food) 2..3
       эффект: P5(Food) -2
       эффект: P10(Your health) = {[p10]+[25..35]}
       эффект: P12(x) = 9

### Loc54 [обычная]
    выбор описания: {[p12]}
    Loc54-1: Feeling the utter hopelessness of your plan, you swing your arms wildly and strike the spider with your fists. It shakes slightly, but you wail, shaking an inju…
    Loc54-2: You snatch the bottle of alcohol from your pocket and throw it directly on the massive spider's body. The bottle breaks, drenching the spider's shaggy trunk wit…
    Loc54-3: You jump out of the monster's way and quickly take a small sip of elixir. Some of your wounds heal right before your very eyes.
    Loc54-4: You kick the spider, trying to make contact with its vulnerable eyes. The spider hardly nips you with its jaws as you strike. It recoils back, hissing terribly.
    Loc54-5: You charge forward furiously, wounding the spider deeply with your weapon. Crunching like an eggshell, it backs off.
    Loc54-6: You wave your weapon furiously, trying to attack the spider. You succeed. The spider jumps aside, its body trembling, and bluish blood flowing from fresh wounds…
    Loc54-7: You charge forward furiously, but the spider suddenly blocks your blow with its strong mandible. Stunned, you back off.
    Loc54-8: You wave your weapon furiously, trying to attack the spider. However, it drops down on all eight legs, practically hugging the floor, and your powerful swing wh…
    Loc54-9: You jump back from the monster and munch on the sandwich. You immediately feel more vigorous and some of your wounds heal.
  -> Path129 => Loc53  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P12(x) = 4
  -> Path130 => Loc53  вер=2 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[23..28]}
       эффект: P12(x) = 2
  -> Path131 => Loc53  вер=2 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[18..22]}
       эффект: P12(x) = 3
  -> Path133 => Loc52  вер=2 порядок=5
       текст: Go on
       ответ: The spider suddenly tumbles over sideways, throwing its legs upward. You strike it cautiously, but it is indeed dead. Suddenly you notice that all your wounds h…
       условия: P11(Enemy's life) 0..0
       эффект: P10(Your health) = 100 [скрыт]
       скрыт: P11

### Loc55 [обычная]
    выбор описания: {([p8]=4)+1}
    Loc55-1: You come to the wooden door and examine the lock critically. Everything is correct. No mistake about it. This is a mechanical lock. It can be opened with a prim…
    Loc55-2: You come to the wooden door and examine the lock critically. Everything is correct. No mistake about it. This lock is mechanical and can be opened with a primit…
  -> Path137 => Loc52  вер=1 порядок=8
       текст: Move away from the door.
  -> Path138 => Loc56  вер=1 порядок=5
       текст: Open the door with the iron key.
       ответ: You insert the key into the hole and turn it. A metal click sounds and the door swings open. You remove the key and stash it in your pocket. Then you enter the …
       условия: P6(Keys) 3..3

### Loc56 [обычная]
    Loc56-1: Near the walls you notice five small statues representing something strange. Each seems to symbolize a sense. The nearest statue has no ears. An inscription in …
    эффект: P12(x) = 1
  -> Path139 => Loc52  вер=1 порядок=5
       текст: Choose the statue symbolizing sight.
       ответ: You touch the blind statue and wait for the reaction. At first, it seems that nothing will happen, but then the glass dome over the hammer opens with a click. Y…
       эффект: P6(Keys) = 0
       эффект: P8(Weapon) = 4
  -> Path140 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Choose the statue symbolizing hearing
       ответ: As soon as you touch the deaf statue it jumps from its pedestal and rushes toward you. It seems to be extremely hostile... You must have failed to solve the puz…
       эффект: P11(Enemy's life) = 65 [показ]
       показ: P10
  -> Path141 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Choose the statue symbolizing the sense of smell.
       ответ: As soon as you touch the statue without a nose, it jumps from its pedestal and rushes toward you. It seems to be extremely hostile... You must have failed to so…
       эффект: P11(Enemy's life) = 65 [показ]
       показ: P10
  -> Path142 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Choose the statue symbolizing touch.
       ответ: As soon as you touch, with disgust, the loathsome statue without any skin, it jumps from its pedestal and rushes toward you. It seems to be extremely hostile...…
       эффект: P11(Enemy's life) = 65 [показ]
       показ: P10
  -> Path143 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Choose the statue symbolizing taste.
       ответ: As soon as you touch the statue without a mouth, it jumps from its pedestal and rushes toward you. It seems to be extremely hostile... You must have failed to s…
       эффект: P11(Enemy's life) = 65 [показ]
       показ: P10
  -> Path144 => Loc52  вер=1 порядок=9
       текст: Leave the room.

### Loc58 [обычная]
    выбор описания: {[p12]}
    Loc58-1: The little statue stares at you in complete silence, having pointed its long stone claws forward. You have to fight!
    Loc58-2: Suddenly, the statue moves forward and thrusts its stone claws into your body, all the way to its wrist. Wheezing from fear, you jump back and probe the bleedin…
    Loc58-3: The statue jumps at you, pointing its stone claws forward, but you manage to block the blow and force it aside. The statue regrouped in the air and, upon landin…
    Loc58-4: The statue jumps at you, swinging wide with its claws. The stone claws are very sharp and deep cuts appear on your face and chest. Blood floods into your eyes, …
  -> Path146 => Loc60  вер=1 порядок=1
       текст: Hit the statue with your fists.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[10..35]*0,3}
       эффект: P12(x) = 2
  -> Path147 => Loc60  вер=3 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[23..33]*0,2*[p8]}
       эффект: P12(x) = 7
  -> Path148 => Loc60  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Splash alcohol on the enemy.
       условия: P4(Bottles) 2..3
       эффект: P4(Bottles) -2
       эффект: P11(Enemy's life) -50
       эффект: P12(x) = 3
  -> Path149 => Loc60  вер=1 порядок=3
       текст: Strike with your weapon at an angle.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 8
  -> Path150 => Loc60  вер=2 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P11(Enemy's life) = {[p11]-[35..40]*0,2*[p8]}
       эффект: P12(x) = 6
  -> Path152 => Loc60  вер=1 порядок=5
       текст: Attack with your weapon.
       условия: P8(Weapon) 1..4
       эффект: P12(x) = 5
  -> Path155 => Loc60  вер=1 порядок=9
       текст: Swallow a little bit of the potion.
       условия: P7(First-aid kit) 1..10
       эффект: P7(First-aid kit) -1
       эффект: P10(Your health) = {[p10]+[30..40]}
       эффект: P12(x) = 1
  -> Path177 => Loc60  вер=1 порядок=2
       текст: Kick with your leg.
       условия: P8(Weapon) 0..0
       эффект: P11(Enemy's life) = {[p11]-[15..30]*0,2}
       эффект: P12(x) = 4
  -> Path196 => Loc60  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Eat the sandwich.
       условия: P5(Food) 2..3
       эффект: P5(Food) -2
       эффект: P10(Your health) = {[p10]+[25..35]}
       эффект: P12(x) = 9

### Loc59 [пустая] визитов<=1
    эффект: P12(x) = 2
  -> Path157 => Loc18  вер=1 проходов<=1 порядок=5

### Loc60 [обычная]
    выбор описания: {[p12]}
    Loc60-1: You jump out of the monster's way and quickly take a small sip of elixir. Some of your wounds heal right before your very eyes.
    Loc60-2: Not expecting to succeed, you strike the stone statue with your fist. It is very painful, but you establish the fact that the statues are fragile; they crumble …
    Loc60-3: You snatch the bottle of alcohol and smash it against the enemy's mouth. The bottle breaks. Alcohol splashes all over the animated statue. Suddenly, the stone b…
    Loc60-4: Without having any special illusions, you strike a blow against the statue with your leg. The resulting pain helps you recall aloud some choice swear words, whi…
    Loc60-5: You rush forward, channeling all your energy into your attack. The statue steps aside slightly, just enough to evade your strike.
    Loc60-6: You rush forward, channeling all your energy into your attack. Your weapon penetrates your opponent's body, nearly punching all the way through and causing ston…
    Loc60-7: You wave the weapon with lightning speed and make contact with the statue. Stone hash rises into the air and the statue steps back.
    Loc60-8: You wave your weapon, trying to attack the statue. But it deftly evades your blow and rushes toward you.
    Loc60-9: You jump away from the statue and munch on the sandwich. You feel more vigorous at once and some of your wounds heal.
  -> Path151 => Loc58  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P12(x) = 3
  -> Path153 => Loc58  вер=5 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[15..20]}
       эффект: P12(x) = 4
  -> Path154 => Loc58  вер=5 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
       эффект: P10(Your health) = {[p10]-[18..24]}
       эффект: P12(x) = 2
  -> Path156 => Loc56  вер=1 порядок=5
       текст: Go on
       ответ: The statue couldn't withstand another blow. Suddenly, it cracks in two and sinks to the floor, covered by clouds of stone hash. When the fight ends, you notice …
       условия: P11(Enemy's life) 0..0
       эффект: P10(Your health) = 100 [скрыт]
       скрыт: P11

### Loc61 [обычная]
    Loc61-1: You come to the second door that was nailed with boards. You pull on it. It's no use. The boards hold the door in place like it was part of the wall. You try to…
  -> Path159 => Loc14  вер=1 порядок=5
       текст: Move away from the door.

### Loc62 [обычная]
    выбор описания: {[p12]}
    Loc62-1: You approach the door that is nailed over with boards, casting a disappointed look at it. You ponder how it might be opened easily. Suddenly, the door trembles,…
    Loc62-2: Your opponent swings the hammer to attack you. You try and succeed in dodging the blow. After your incredible evasive maneuver, you let the hammer fly over your…
    Loc62-3: Your opponent swings the hammer furiously to attack you. You try to evade the blow, but it was too broad for you to manage to escape the zone of devastation. Th…
    Loc62-4: The enemy rushes abruptly forward, swinging his hammer. The blow is aimed directly to your chest, but you evade it with ease.
    Loc62-5: The enemy rushes abruptly forward, swinging his hammer. You get hit hard enough to cause instant hemorrhaging. Yet, despite the serious wound, you feel no pain.
  -> Path161 => Loc63  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Splash alcohol on your twin.
       условия: P4(Bottles) 2..3
       эффект: P4(Bottles) -2
       эффект: P11(Enemy's life) -50
       эффект: P12(x) = 2
  -> Path162 => Loc63  вер=2 порядок=5
       текст: Strike from above with the hammer.
       эффект: P11(Enemy's life) = {[p11]-[35..40]*0,2*[p8]}
       эффект: P12(x) = 5
  -> Path163 => Loc63  вер=1 порядок=5
       текст: Strike from above with the hammer.
       эффект: P12(x) = 6
  -> Path164 => Loc63  вер=3 порядок=3
       текст: Strike from the side with the hammer.
       эффект: P11(Enemy's life) = {[p11]-[23..33]*0,2*[p8]}
       эффект: P12(x) = 3
  -> Path165 => Loc63  вер=1 порядок=3
       текст: Strike from the side with the hammer.
       эффект: P12(x) = 4
  -> Path166 => Loc63  вер=1 порядок=9
       текст: Swallow a little bit of the potion.
       условия: P7(First-aid kit) 1..10
       эффект: P7(First-aid kit) -1
       эффект: P10(Your health) = {[p10]+[30..40]}
       эффект: P12(x) = 1
  -> Path197 => Loc63  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Eat the sandwich.
       условия: P5(Food) 2..3
       эффект: P5(Food) -2
       эффект: P10(Your health) = {[p10]+[25..35]}
       эффект: P12(x) = 7

### Loc63 [обычная]
    выбор описания: {[p12]}
    Loc63-1: You jump back from your twin and rapidly gulp down some elixir. Some of your wounds heal.
    Loc63-2: You snatch the bottle of alcohol and throw it right in your opponent's face. The alcohol has the desired effect - your twin howls as his skin burns and falls fr…
    Loc63-3: You make a long, slanting swing with the hammer to attack your enemy with less force but more certainty. Your plan was good - your twin shudders upon receiving …
    Loc63-4: You make a long, slanting swing with the hammer to attack your enemy with less force but more certainty. But your opponent moves backward, and you, still being …
    Loc63-5: You rush forward to hit your opponent's head with the hammer. Your blow is so quick that he has no time to evade it. The hammer knocks him back with an unpleasa…
    Loc63-6: You rush forward to hit your opponent's head with the hammer. You are very fast, but the enemy anticipates your actions and blocks the blow with his own hammer.
    Loc63-7: You jump back from your twin and munch on the sandwich. You immediately feel more vigorous and some of your wounds heal.
  -> Path167 => Loc65  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
  -> Path168 => Loc64  вер=1 порядок=5
       текст: Go on
       условия: P11(Enemy's life) 1..100
  -> Path173 => Loc66  вер=1 порядок=5
       текст: Go on
       ответ: Your twin couldn't withstand your latest attack. He just falls to the ground like a sack of sand. It is very unpleasant and unusual for you to look at your own …
       условия: P11(Enemy's life) 0..0
       скрыт: P10,P11

### Loc64 [пустая]
  -> Path171 => Loc62  вер=2 порядок=5
       эффект: P10(Your health) = {[p10]-[35..40]*0,2*[p8]}
       эффект: P12(x) = 5
  -> Path172 => Loc62  вер=1 порядок=5
       эффект: P12(x) = 4

### Loc65 [пустая]
  -> Path169 => Loc62  вер=3 порядок=5
       эффект: P10(Your health) = {[p10]-[23..33]*0,2*[p8]}
       эффект: P12(x) = 3
  -> Path170 => Loc62  вер=1 порядок=5
       эффект: P12(x) = 2

### Loc66 [УСПЕХ]
    Loc66-1: Once at the gate, you notice that there's company waiting for you. But even if they are the very archdemons of hell, they can't stop you from abandoning this cu…

### Loc67 [обычная] визитов<=1
    Loc67-1: Suddenly, you notice a flat, steel disk, about the size of the palm of a hand, lying on the floor by the bar counter. Upon closer examination, the disk turns ou…
  -> Path185 => Loc5  вер=1 проходов<=1 порядок=5
       текст: Wander over the spaceport anyway and look for your escorts.

### Loc68 [обычная]
    Loc68-1: You insert the magnetic key into the slot - it fits. The magnetic locks disengage and the door finally gives way. After removing the key from of the slot, you e…
  -> Path186 => Loc40  вер=1 порядок=7
       текст: Force the door open.
       эффект: P2(Fear) = {[p2]-25}
       эффект: P10(Your health) -3
       эффект: P12(x) = 2
  -> Path187 => Loc36  вер=1 порядок=5
       текст: Try to solve the puzzle.

### Loc69 [обычная] визитов<=1
    выбор описания: {[p18]}
    Loc69-1: The lamentable results of your experiment in alchemy are smoking in the pot. The smell is disgusting. You clamp your nose and start back hastily. There's nothin…
    Loc69-2: The pot is empty. Your experiment in alchemy was a success. Now you have a prepared healing potion. There is nothing in the pot to interest you, and you can't u…
  -> Path199 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Finish the examination.

## Анализ
- стартовых: [1]
- концовки: {2: 'ПРОВАЛ', 10: 'ПРОВАЛ', 66: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
