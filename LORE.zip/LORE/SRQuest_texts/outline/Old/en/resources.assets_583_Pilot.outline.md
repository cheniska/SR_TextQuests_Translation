# Квест (формат 1111111126)
Сложность 30; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Marks' [0..5] тип=обычный
    старт: [0]
    [0..5] Marks: [p1]
    критическое: На экране монитора появилось сообщение: /  / Вы допустили ошибку. Тестирование прервано...
- P2 "Young Gaalian's bonus" [0..1] тип=обычный
    старт: [0]
    [0..1] You've got the secret code
    критическое: Сообщение достижения критического значения параметром 7
- P3 'Return' [0..10] тип=обычный
    старт: [0]
    [0..0] Nothing is taken
    [1..1] Take the first course
    [2..2] Take the second course
    [3..3] Take the first and the second course
    [4..4] Take the third course
    [5..5] Take the first and the third course
    [6..6] Take the second and the third course
    [7..7] Take all the courses now!
    [8..8] 
    [9..10] Take all the courses now!
    критическое: Сообщение достижения критического значения параметром 2
- P4 "Bugbubba's disposition" [0..100] тип=обычный
    старт: [0]
    [0..100] Bugbubba's disposition: <>%
    критическое: Сообщение достижения критического значения параметром 4
- P5 'Ticket №' [1..100] тип=обычный
    старт: [1..100]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 5
- P7 'Money' [0..1000000000] тип=обычный деньги
    старт: [1000]
    [0..1000000000] You have <> cr
    критическое: Сообщение достижения критического значения параметром 3
- P9 'Meal volume' [0..5000] тип=обычный
    старт: [0]
    [0..5000] Parameter No 9: <>
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Kcal' [0..5000] тип=обычный
    старт: [0]
    [0..5000] Parameter No 10: <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'RND' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 37
- P13 'Move' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 41
- P21 'Variant' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Missed' [0..15] тип=провал
    старт: [0]
    [0..15] Missed: <>
    критическое: The following message appeared on the monitor: "The damages are critical! Further flight impossible!…
- P23 'Shot down' [0..20] тип=обычный
    старт: [0]
    [0..20] Shot down: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Firing line' [1..5] тип=обычный
    старт: [3]
    [1..5] Firing line: [p24]
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Question' [0..10] тип=обычный
    старт: [1]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 25
- P26 'x' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Examiner' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 27
- P37 'Firing line 1' [0..99] тип=обычный
    старт: [0]
    [0..9] <fix>1 I . . . . . . . . . I</fix>
    [10..19] <fix>1 I . . . . . . . . o I</fix>
    [20..29] <fix>1 I . . . . . . . o . I</fix>
    [30..39] <fix>1 I . . . . . . o . . I</fix>
    [40..49] <fix>1 I . . . . . o . . . I</fix>
    [50..59] <fix>1 I . . . . o . . . . I</fix>
    [60..69] <fix>1 I . . . o . . . . . I</fix>
    [70..79] <fix>1 I . . o . . . . . . I</fix>
    [80..89] <fix>1 I . o . . . . . . . I</fix>
    [90..99] <fix>1 I o . . . . . . . . I</fix>
    критическое: Сообщение достижения критического значения параметром 11
- P38 'Fire 1' [0..99] тип=обычный
    старт: [0]
    [0..9] <clr><fix>1 > . . . . . . . . . I</fix><clrEnd>
    [10..19] <clr><fix>1 > . . . . . . . . o I</fix><clrEnd>
    [20..29] <clr><fix>1 > . . . . . . . o . I</fix><clrEnd>
    [30..39] <clr><fix>1 > . . . . . . o . . I</fix><clrEnd>
    [40..49] <clr><fix>1 > . . . . . o . . . I</fix><clrEnd>
    [50..59] <clr><fix>1 > . . . . o . . . . I</fix><clrEnd>
    [60..69] <clr><fix>1 > . . . o . . . . . I</fix><clrEnd>
    [70..79] <clr><fix>1 > . . o . . . . . . I</fix><clrEnd>
    [80..89] <clr><fix>1 > . o . . . . . . . I</fix><clrEnd>
    [90..99] <clr><fix>1 > o . . . . . . . . I</fix><clrEnd>
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Firing line 2' [0..99] тип=обычный
    старт: [0]
    [0..9] <fix>2 I . . . . . . . . . I</fix>
    [10..19] <fix>2 I . . . . . . . . o I</fix>
    [20..29] <fix>2 I . . . . . . . o . I</fix>
    [30..39] <fix>2 I . . . . . . o . . I</fix>
    [40..49] <fix>2 I . . . . . o . . . I</fix>
    [50..59] <fix>2 I . . . . o . . . . I</fix>
    [60..69] <fix>2 I . . . o . . . . . I</fix>
    [70..79] <fix>2 I . . o . . . . . . I</fix>
    [80..89] <fix>2 I . o . . . . . . . I</fix>
    [90..99] <fix>2 I o . . . . . . . . I</fix>
    критическое: Сообщение достижения критического значения параметром 12
- P40 'Fire 2' [0..99] тип=обычный
    старт: [0]
    [0..9] <clr><fix>2 > . . . . . . . . . I</fix><clrEnd>
    [10..19] <clr><fix>2 > . . . . . . . . o I</fix><clrEnd>
    [20..29] <clr><fix>2 > . . . . . . . o . I</fix><clrEnd>
    [30..39] <clr><fix>2 > . . . . . . o . . I</fix><clrEnd>
    [40..49] <clr><fix>2 > . . . . . o . . . I</fix><clrEnd>
    [50..59] <clr><fix>2 > . . . . o . . . . I</fix><clrEnd>
    [60..69] <clr><fix>2 > . . . o . . . . . I</fix><clrEnd>
    [70..79] <clr><fix>2 > . . o . . . . . . I</fix><clrEnd>
    [80..89] <clr><fix>2 > . o . . . . . . . I</fix><clrEnd>
    [90..99] <clr><fix>2 > o . . . . . . . . I</fix><clrEnd>
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Firing line 3' [0..99] тип=обычный
    старт: [0]
    [0..9] <fix>3 I . . . . . . . . . I</fix>
    [10..19] <fix>3 I . . . . . . . . o I</fix>
    [20..29] <fix>3 I . . . . . . . o . I</fix>
    [30..39] <fix>3 I . . . . . . o . . I</fix>
    [40..49] <fix>3 I . . . . . o . . . I</fix>
    [50..59] <fix>3 I . . . . o . . . . I</fix>
    [60..69] <fix>3 I . . . o . . . . . I</fix>
    [70..79] <fix>3 I . . o . . . . . . I</fix>
    [80..89] <fix>3 I . o . . . . . . . I</fix>
    [90..99] <fix>3 I o . . . . . . . . I</fix>
    критическое: Сообщение достижения критического значения параметром 13
- P42 'Fire 3' [0..99] тип=обычный
    старт: [0]
    [0..9] <clr><fix>3 > . . . . . . . . . I</fix><clrEnd>
    [10..19] <clr><fix>3 > . . . . . . . . o I</fix><clrEnd>
    [20..29] <clr><fix>3 > . . . . . . . o . I</fix><clrEnd>
    [30..39] <clr><fix>3 > . . . . . . o . . I</fix><clrEnd>
    [40..49] <clr><fix>3 > . . . . . o . . . I</fix><clrEnd>
    [50..59] <clr><fix>3 > . . . . o . . . . I</fix><clrEnd>
    [60..69] <clr><fix>3 > . . . o . . . . . I</fix><clrEnd>
    [70..79] <clr><fix>3 > . . o . . . . . . I</fix><clrEnd>
    [80..89] <clr><fix>3 > . o . . . . . . . I</fix><clrEnd>
    [90..99] <clr><fix>3 > o . . . . . . . . I</fix><clrEnd>
    критическое: Сообщение достижения критического значения параметром 42
- P43 'Fire line 4' [0..99] тип=обычный
    старт: [0]
    [0..9] <fix>4 I . . . . . . . . . I</fix>
    [10..19] <fix>4 I . . . . . . . . o I</fix>
    [20..29] <fix>4 I . . . . . . . o . I</fix>
    [30..39] <fix>4 I . . . . . . o . . I</fix>
    [40..49] <fix>4 I . . . . . o . . . I</fix>
    [50..59] <fix>4 I . . . . o . . . . I</fix>
    [60..69] <fix>4 I . . . o . . . . . I</fix>
    [70..79] <fix>4 I . . o . . . . . . I</fix>
    [80..89] <fix>4 I . o . . . . . . . I</fix>
    [90..99] <fix>4 I o . . . . . . . . I</fix>
    критическое: Сообщение достижения критического значения параметром 14
- P44 'Fire 4' [0..99] тип=обычный
    старт: [0]
    [0..9] <clr><fix>4 > . . . . . . . . . I</fix><clrEnd>
    [10..19] <clr><fix>4 > . . . . . . . . o I</fix><clrEnd>
    [20..29] <clr><fix>4 > . . . . . . . o . I</fix><clrEnd>
    [30..39] <clr><fix>4 > . . . . . . o . . I</fix><clrEnd>
    [40..49] <clr><fix>4 > . . . . . o . . . I</fix><clrEnd>
    [50..59] <clr><fix>4 > . . . . o . . . . I</fix><clrEnd>
    [60..69] <clr><fix>4 > . . . o . . . . . I</fix><clrEnd>
    [70..79] <clr><fix>4 > . . o . . . . . . I</fix><clrEnd>
    [80..89] <clr><fix>4 > . o . . . . . . . I</fix><clrEnd>
    [90..99] <clr><fix>4 > o . . . . . . . . I</fix><clrEnd>
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Firing line 5' [0..99] тип=обычный
    старт: [0]
    [0..9] <fix>5 I . . . . . . . . . I</fix>
    [10..19] <fix>5 I . . . . . . . . o I</fix>
    [20..29] <fix>5 I . . . . . . . o . I</fix>
    [30..39] <fix>5 I . . . . . . o . . I</fix>
    [40..49] <fix>5 I . . . . . o . . . I</fix>
    [50..59] <fix>5 I . . . . o . . . . I</fix>
    [60..69] <fix>5 I . . . o . . . . . I</fix>
    [70..79] <fix>5 I . . o . . . . . . I</fix>
    [80..89] <fix>5 I . o . . . . . . . I</fix>
    [90..99] <fix>5 I o . . . . . . . . I</fix>
    критическое: Сообщение достижения критического значения параметром 15
- P46 'Fire 5' [0..99] тип=обычный
    старт: [0]
    [0..9] <clr><fix>5 > . . . . . . . . . I</fix><clrEnd>
    [10..19] <clr><fix>5 > . . . . . . . . o I</fix><clrEnd>
    [20..29] <clr><fix>5 > . . . . . . . o . I</fix><clrEnd>
    [30..39] <clr><fix>5 > . . . . . . o . . I</fix><clrEnd>
    [40..49] <clr><fix>5 > . . . . . o . . . I</fix><clrEnd>
    [50..59] <clr><fix>5 > . . . . o . . . . I</fix><clrEnd>
    [60..69] <clr><fix>5 > . . . o . . . . . I</fix><clrEnd>
    [70..79] <clr><fix>5 > . . o . . . . . . I</fix><clrEnd>
    [80..89] <clr><fix>5 > . o . . . . . . . I</fix><clrEnd>
    [90..99] <clr><fix>5 > o . . . . . . . . I</fix><clrEnd>
    критическое: Сообщение достижения критического значения параметром 46

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: After winding once around <ToPlanet>, you landed in the outer Centre's hangar. You had to spend a couple of hours on the weapon deactivation, brain steroid chec…
    эффект: P4(Bugbubba's disposition) +0% [скрыт]
    скрыт: P1,P2,P3,P6,P8,P9,P10,P16,P22,P23,P24,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46
  -> Path2 => Loc8  вер=1 проходов<=1 порядок=1
       текст: Go to room №1
  -> Path3 => Loc14  вер=1 проходов<=1 порядок=3
       текст: Go to Room №3
       эффект: P27(Examiner) = 3
  -> Path8 => Loc14  вер=1 проходов<=1 порядок=2
       текст: Go to Room №2
       эффект: P27(Examiner) = 2
  -> Path265 => Loc87  вер=1 проходов<=1 порядок=4
       текст: Look about

### Loc2 [обычная] визитов<=1
    Loc2-1: - Really? - the Gaalian's face lost its gloomy expression and he looked in your eyes with some hope. - Then... I have some private request. I... errr... have fa…
  -> Path33 => Loc15  вер=1 проходов<=1 порядок=5
       текст: It's a doddle, I know what to do!
  -> Path34 => Loc14  вер=1 проходов<=1 порядок=5
       текст: No, I'm not an expert in this

### Loc8 [обычная] визитов<=2
    Loc8-1: A young Gaalian with the state of body close to emaciation sat at the holographic display looking crestfallen. He took his head in the hands wrinkling the skin …
    эффект: P27(Examiner) = 1
  -> Path31 => Loc2  вер=1 проходов<=1 порядок=5
       текст: I'm all ears and will do my best
  -> Path69 => Loc14  вер=1 проходов<=1 порядок=5
       текст: I came to take the exam and I'm pressed for time

### Loc14 [обычная] визитов<=1
    выбор описания: {4-[p27]}
    Loc14-1: The room was rather dim, and it took you sometime to notice Hogger in the far corner. He turned out to be a person in ripe years with "I-have-just-eaten-a-whole…
    Loc14-2: Faeyan Highbrow who was reading dedicated literature, stood up to greet you: /  / - Hello, ranger <Ranger>. Your ambition for self-development and self-improvem…
    Loc14-3: - All right, choose your test-paper... - Half-heartedly Loho-Khan pointed to the examinational trainer. He looked completely flagging and sat silently aside. Yo…
    скрыт: P4
  -> Path394 => Loc130  вер=1 проходов<=1 порядок=5
       текст: Choose Test-paper

### Loc15 [обычная] визитов<=1
    Loc15-1: You left Room №1 and went to the Document control department. After wandering a couple of times in the Centre's multiple corridors, at last you found the room w…
  -> Path311 => Loc110  вер=1 проходов<=1 порядок=5
       текст: Listen to the conversation
  -> Path312 => Loc111  вер=1 проходов<=1 порядок=5
       текст: Enter

### Loc17 [пустая] визитов<=7
  -> Path38 => Loc138  вер=1 проходов<=1 порядок=8
       текст: Tell them all the truth
       эффект: P4(Bugbubba's disposition) = {[p4]+[-20..-10]}
       эффект: P26(x) = 3
  -> Path100 => Loc138  вер=1 проходов<=1 порядок=5
       текст: Introduce yourself as a journalist
       эффект: P4(Bugbubba's disposition) = {[p4]+[-10..0]}
       эффект: P26(x) = 6
  -> Path101 => Loc138  вер=1 проходов<=1 порядок=3
       текст: Introduce yourself as a scholar
       эффект: P4(Bugbubba's disposition) = {[p4]+[-20..-10]}
       эффект: P26(x) = 1
  -> Path102 => Loc138  вер=1 проходов<=1 порядок=1
       текст: Introduce yourself as a celebrated commodore
       эффект: P4(Bugbubba's disposition) = {[p4]+[0..10]}
       эффект: P26(x) = 5
  -> Path410 => Loc138  вер=1 проходов<=1 порядок=1
       текст: Introduce yourself as a celebrated commodore
       эффект: P4(Bugbubba's disposition) = {[p4]+[20..30]}
       эффект: P26(x) = 4
  -> Path411 => Loc138  вер=3 проходов<=1 порядок=3
       текст: Introduce yourself as a scholar
       эффект: P4(Bugbubba's disposition) = {[p4]+[20..30]}
       эффект: P26(x) = 2
  -> Path412 => Loc138  вер=2 проходов<=1 порядок=5
       текст: Introduce yourself as a journalist
       эффект: P4(Bugbubba's disposition) = {[p4]+[20..30]}
       эффект: P26(x) = 7

### Loc47 [обычная] визитов<=1
    Loc47-1: You simply passed the message to the examiner. He looked at it yearningly and read it several times. He looked happy. Ultimately, you managed to persuade Bugbub…
  -> Path395 => Loc130  вер=1 проходов<=1 порядок=5
       текст: Choose Test-paper

### Loc52 [обычная] визитов<=1
    Loc52-1: The local canteen looked rather tolerable, cosy and clean except for the fact that there were no vacant seats. /  / - Alright, <Ranger>, - Bugbubba said, immedi…
  -> Path103 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Look through the menu and make the order

### Loc53 [обычная] визитов<=19
    Loc53-1: <clr>First course:<clrEnd> /  / 1. Antibian stickjaw pods hoosh, 300 g. (230 kcal/100 g) / 2. Lorelai with sea slatters and blue algae, 150 g. (400 kcal/100g) /…
    показ: P3
  -> Path104 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the hoosh
       условия: логика {([p3]=0) or ([p3]=4)}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+300}
       эффект: P10(Kcal) = {[p10]+690}
  -> Path105 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the lorelai
       условия: логика {([p3]=0) or ([p3]=4)}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+600}
  -> Path106 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the broth
       условия: логика {([p3]=0) or ([p3]=4)}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+350}
       эффект: P10(Kcal) = {[p10]+1067,5}
  -> Path107 => Loc54  вер=1 проходов<=5 порядок=5
       текст: Look through the second course
       условия: логика {([p3]=0) or ([p3]=4)}
  -> Path108 => Loc55  вер=1 проходов<=5 порядок=6
       текст: Look through the third course
       условия: логика {([p3]=0) or ([p3]=2)}
  -> Path157 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the broth
       условия: логика {[p3]=2}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+350}
       эффект: P10(Kcal) = {[p10]+1067,5}
  -> Path158 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the hoosh
       условия: логика {[p3]=2}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+300}
       эффект: P10(Kcal) = {[p10]+690}
  -> Path159 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the lorelai
       условия: логика {[p3]=2}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+600}
  -> Path167 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the broth
       условия: логика {[p3]=6}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+350}
       эффект: P10(Kcal) = {[p10]+1067,5}
  -> Path168 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the hoosh
       условия: логика {[p3]=6}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+300}
       эффект: P10(Kcal) = {[p10]+690}
  -> Path169 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the lorelai
       условия: логика {[p3]=6}
       эффект: P3(Return) +1
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+600}

### Loc54 [обычная] визитов<=19
    Loc54-1: <clr>Second course:<clrEnd> /  / 1. Chopped shroomtoad squash, 220 g. (180 kcal/100 g.)      / 2. Mashed umbikettes in sauce, 120 g. (240 kcal/100g.)   / 3. Bak…
  -> Path110 => Loc53  вер=1 проходов<=5 порядок=6
       текст: Look through the first course
       условия: логика {([p3]=0) or ([p3]=4)}
  -> Path111 => Loc55  вер=1 проходов<=5 порядок=6
       текст: Look through the third course
       условия: логика {([p3]=0) or ([p3]=1)}
  -> Path112 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the squash
       условия: логика {([p3]=0) or ([p3]=1)}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+220}
       эффект: P10(Kcal) = {[p10]+396}
  -> Path113 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the mashed umbikettes
       условия: логика {([p3]=0) or ([p3]=1)}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+120}
       эффект: P10(Kcal) = {[p10]+286}
  -> Path114 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Take the baked tailpullers
       условия: логика {([p3]=0) or ([p3]=1)}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+85}
       эффект: P10(Kcal) = {[p10]+382,5}
  -> Path154 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the baked tailpullers
       условия: логика {[p3]=5}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+85}
       эффект: P10(Kcal) = {[p10]+382,5}
  -> Path155 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the squash
       условия: логика {[p3]=5}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+220}
       эффект: P10(Kcal) = {[p10]+396}
  -> Path156 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the mashed umbikettes
       условия: логика {[p3]=5}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+120}
       эффект: P10(Kcal) = {[p10]+286}
  -> Path164 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the mashed umbikettes
       условия: логика {[p3]=4}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+120}
       эффект: P10(Kcal) = {[p10]+286}
  -> Path165 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the baked tailpullers
       условия: логика {[p3]=4}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+85}
       эффект: P10(Kcal) = {[p10]+382,5}
  -> Path166 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the squash
       условия: логика {[p3]=4}
       эффект: P3(Return) +2
       эффект: P9(Meal volume) = {[p9]+220}
       эффект: P10(Kcal) = {[p10]+396}

### Loc55 [обычная] визитов<=22
    Loc55-1: <clr>Third course:<clrEnd> /  / 1. Bambai-boogie-due berry juice, 130 g. (200 kcal/100 g.)  / 2. Chulian dried turnip stew, 250 g. (90 kcal/100 g.) / 3. Chef's …
  -> Path109 => Loc54  вер=1 проходов<=5 порядок=6
       текст: Look through the second course
       условия: логика {([p3]=0) or ([p3]=1)}
  -> Path115 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the juice
       условия: логика {([p3]=3) or ([p3]=6)}
       эффект: P3(Return) +10
       эффект: P9(Meal volume) = {[p9]+130}
       эффект: P10(Kcal) = {[p10]+260}
  -> Path116 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the Gablingkot
       условия: логика {([p3]=3) or ([p3]=6)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+100}
       эффект: P10(Kcal) = {[p10]+250}
  -> Path117 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the stew
       условия: логика {([p3]=3) or ([p3]=6)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+250}
       эффект: P10(Kcal) = {[p10]+225}
  -> Path118 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Take the syrup
       условия: логика {([p3]=3) or ([p3]=6)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+217,5}
  -> Path149 => Loc53  вер=1 проходов<=5 порядок=6
       текст: Look through the first course
       условия: логика {([p3]=0) or ([p3]=2)}
  -> Path150 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the syrup
       условия: логика {([p3]=0) or ([p3]=2)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+217,5}
  -> Path151 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the Gablingkot
       условия: логика {([p3]=0) or ([p3]=2)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+100}
       эффект: P10(Kcal) = {[p10]+250}
  -> Path152 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the juice
       условия: логика {([p3]=0) or ([p3]=2)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+130}
       эффект: P10(Kcal) = {[p10]+260}
  -> Path153 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Take the stew
       условия: логика {([p3]=0) or ([p3]=2)}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+250}
       эффект: P10(Kcal) = {[p10]+225}
  -> Path160 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the stew
       условия: логика {[p3]=1}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+250}
       эффект: P10(Kcal) = {[p10]+225}
  -> Path161 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the juice
       условия: логика {[p3]=1}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+130}
       эффект: P10(Kcal) = {[p10]+260}
  -> Path162 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the Gablingkot
       условия: логика {[p3]=1}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+100}
       эффект: P10(Kcal) = {[p10]+250}
  -> Path163 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Take the syrup
       условия: логика {[p3]=1}
       эффект: P3(Return) +4
       эффект: P9(Meal volume) = {[p9]+150}
       эффект: P10(Kcal) = {[p10]+217,5}

### Loc56 [обычная] визитов<=4
    Loc56-1: You took the trays with complex lunch for Bugbubba and yourself and went to your table.
  -> Path170 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Lunch is served! Please start scoffing!
       ответ: Bugbubba was a regular in that canteen, so she gave the grab that you had just brought a qualified glance: / - Hot dog, <Ranger>, you should be a telepathist! T…
       условия: логика {([p9]<=335) and ([p10]>=1232)}
       эффект: P4(Bugbubba's disposition) = {[p4]+[20..30]}
  -> Path171 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Lunch is served! Please start scoffing!
       ответ: Bugbubba was a regular in that canteen, so she gave the grab that you had just brought a qualified glance: / - Alright, <Ranger>, it's very nutrition though too…
       условия: логика {([p9]>335) and ([p10]>=1723)}
       эффект: P4(Bugbubba's disposition) = {[p4]+[10..20]}
  -> Path172 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Lunch is served! Please start scoffing!
       ответ: Bugbubba was a regular in that canteen, so she gave the grab that you had just brought a qualified glance: / - <Ranger>, it won't be enough even for a dead Faey…
       условия: логика {([p9]>335) and ([p10]<=1193.5)}
       эффект: P4(Bugbubba's disposition) = {[p4]+[-10..0]}
  -> Path174 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Lunch is served! Please start scoffing!
       ответ: Bugbubba was a regular in that canteen, so she gave the grab that you had just brought a qualified glance: / - <Ranger>, it will fill my maw but not to a suffic…
       условия: логика {([p9]>335) and ([p10]>1193.5)}
       эффект: P4(Bugbubba's disposition) = {[p4]+[0..10]}

### Loc59 [обычная] визитов<=6
    выбор описания: {([p11]=1)+([p11]=2)*[2..4]}
    Loc59-1: Feeling much better after lunch, Bugbubba lay back, relaxed and started picking her teeth studiously. She gazed into space thinking about some female's stuff. /…
    Loc59-2: No reaction...
    Loc59-3: Still no reaction...
    Loc59-4: No effect...
    скрыт: P3
  -> Path230 => Loc119  вер=1 проходов<=1 порядок=2
       текст: Kiss Bugbubba on the mouth
       ответ: Bugbubba started in her seat as if stung and dotted you one: / - What are you doing?! Are you crazy?! Tut-tut, don't do it again. These slobbers are really too …
       эффект: P4(Bugbubba's disposition) = {[p4]+[-10..0]}
  -> Path231 => Loc119  вер=1 проходов<=1 порядок=5
       текст: Dig Bugbubba in the side
       ответ: - Huh? Oh, it's you, <Ranger>! So...so what was I talking about? - Bugbubba rather perplexed, collected herself. / - We were just discussing our new date... / -…
       эффект: P4(Bugbubba's disposition) = {[p4]+[5..15]}
  -> Path232 => Loc115  вер=1 проходов<=1 порядок=7
       текст: Wave your hand in front of your eyes
  -> Path317 => Loc115  вер=1 проходов<=1 порядок=6
       текст: Blow in Bugbubba's ear
  -> Path319 => Loc115  вер=1 проходов<=1 порядок=4
       текст: Have Bugbubba make a date with you
  -> Path328 => Loc119  вер=1 проходов<=1 порядок=3
       текст: Shrill out her name
       ответ: Bugbubba's pupils went pinpoint, then she collected herself and skewed at you: / - Here! Have I missed anything? / - Nope, we were just discussing our new date.…
       эффект: P4(Bugbubba's disposition) = {[p4]+[0..10]}

### Loc60 [пустая] визитов<=3
    эффект: P11(RND) = {1}
  -> Path121 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Rise from the table, say thank you to everybody and bow low
       ответ: - Pooh, <Ranger>, how vulgar of you! If you were my husband, I would give you a bash on the bonce! - thank goodness, you're not her husband! This thought made y…
       эффект: P4(Bugbubba's disposition) = {[p4]+[-10..0]}
  -> Path122 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Make everybody hear your burp
       ответ: - You surprise me, <Ranger>, you're good mannered! - you noticed that Bugbubba was nodding her fine big-eared head in approval.
       эффект: P4(Bugbubba's disposition) = {[p4]+[10..20]}
  -> Path123 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Pat your and Bugbubba's belly, and the rest of the comers too
       ответ: - That's an interesting rite! Is it what they do at your home? - Bibuba asked. You mumbled in response.
       условия: логика {[p4]<=99}
       эффект: P4(Bugbubba's disposition) = {[p4]+[5..15]}

### Loc81 [обычная] визитов<=1
    Loc81-1: It didn't take you long to find Anit and gave your card to him. After the Faeyan studied it, he said: /  / - You know theory very well, <Ranger>, I think you wo…
    эффект: P13(Move) = 0
    скрыт: P1,P2,P16
    показ: P22,P23,P24,P37,P39,P42,P43,P45
  -> Path235 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Let's go!

### Loc82 [пустая]
    эффект: P13(Move) = {1-[p13]}
  -> Path243 => Loc83  вер=1 порядок=5
       условия: логика {([p39] div 10)=0}
       эффект: P39(Firing line 2) = {1+([0..2]=0)+([0..2]=0)}
  -> Path244 => Loc83  вер=1 порядок=5
       условия: логика {([p37] div 10)=0}
       эффект: P37(Firing line 1) = {1+([0..2]=0)+([0..2]=0)}
  -> Path245 => Loc83  вер=1 порядок=5
       условия: логика {([p43] div 10)=0}
       эффект: P43(Fire line 4) = {1+([0..2]=0)+([0..2]=0)}
  -> Path246 => Loc83  вер=1 порядок=5
       условия: логика {([p41] div 10)=0}
       эффект: P41(Firing line 3) = {1+([0..2]=0)+([0..2]=0)}
  -> Path247 => Loc83  вер=1 порядок=5
       условия: логика {([p37] div 10)>0 and ([p39] div 10)>0 and ([p41] div 10)>0 and ([p43] div 10)>0 and ([p45] div 10)>0}
  -> Path248 => Loc83  вер=1 порядок=5
       условия: логика {([p45] div 10)=0}
       эффект: P45(Firing line 5) = {1+([0..2]=0)+([0..2]=0)}

### Loc83 [пустая]
    эффект: P24(Firing line) = {[p24]+(([p24] div 10) mod 10)}
  -> Path234 => Loc84  вер=1 порядок=5
       эффект: P37(Firing line 1) = {[p37]+([p37] mod 10)*10}
       эффект: P39(Firing line 2) = {[p39]+([p39] mod 10)*10}
       эффект: P41(Firing line 3) = {[p41]+([p41] mod 10)*10}
       эффект: P43(Fire line 4) = {[p43]+([p43] mod 10)*10}
       эффект: P45(Firing line 5) = {[p45]+([p45] mod 10)*10}

### Loc84 [пустая]
    эффект: P22(Missed) = {[p22]+([p37]>90)+([p39]>90)+([p41]>90)+([p43]>90)+([p45]>90)}
    эффект: P37(Firing line 1) = {[p37]*(([p37] div 10)<9)}
    эффект: P39(Firing line 2) = {[p39]*(([p39] div 10)<9)}
    эффект: P41(Firing line 3) = {[p41]*(([p41] div 10)<9)}
    эффект: P43(Fire line 4) = {[p43]*(([p43] div 10)<9)}
    эффект: P45(Firing line 5) = {[p45]*(([p45] div 10)<9)}
  -> Path405 => Loc137  вер=1 порядок=5
       эффект: P38(Fire 1) = {[p37]}
       эффект: P40(Fire 2) = {[p39]}
       эффект: P42(Fire 3) = {[p41]}
       эффект: P44(Fire 4) = {[p43]}
       эффект: P46(Fire 5) = {[p45]}

### Loc85 [УСПЕХ] визитов<=1
    Loc85-1: - Ranger <Ranger>, you have passed the category Z-45/6a certificate test successfully. We congratulate you! /  / They accompanied you to the certificate-issuing…
    скрыт: P22,P23,P24,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46

### Loc87 [обычная] визитов<=1
    Loc87-1: You leisurely went on the excursion around the Centre trying to figure out how to get that damned certificate. While different variants were coming into your mi…
    эффект: P21(Variant) = 1
  -> Path266 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Knit your brows and bark: "Say away!"
  -> Path267 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Screw up your eyes and say between your teeth: "So?"
  -> Path345 => Loc88  вер=1 проходов<=1 порядок=8
       текст: Say "Don't!" and return
       эффект: P21(Variant) = 2

### Loc88 [обычная] визитов<=4
    выбор описания: {[p21]}
    Loc88-1: -Your courage is worthy of respect, pilot! In return, I'll give you some info about the examiners though it's forbidden according to the rules. And you decide y…
    Loc88-2: You'd rather keep out of trouble and go take the exam. Which room will you choose?
  -> Path268 => Loc8  вер=1 проходов<=1 порядок=1
       текст: Go to room №1
  -> Path269 => Loc14  вер=1 проходов<=1 порядок=2
       текст: Go to Room № 2
       эффект: P27(Examiner) = 2
  -> Path270 => Loc14  вер=1 проходов<=1 порядок=3
       текст: Go to Room №3
       эффект: P27(Examiner) = 3
  -> Path271 => Loc89  вер=1 порядок=5
       текст: Get back to the ship

### Loc89 [ПРОВАЛ]
    Loc89-1: You decided that you have more important things to do and easier ways to earn your living instead of getting some unofficial certificate for the Pelengs. With t…

### Loc93 [обычная] визитов<=1
    Loc93-1: - What's the problem, pilot? Can I really help you? - the examiner grinned. /  / - Yes, I need your help, I'll make it worth your while, - you winked cunningly …
    Loc93-2: - What is it, <Ranger>, a poser? - Snipeman Hogger asked and smiled greedily. /  / - Well, not a complete poser, - you murmured. - But a good piece of advice wo…
    Loc93-3: - Can I ask you for a second? - you asked the examiner. - I have a question. /  / - Sure, you can! - Snipeman Hogger was all smiles. - But note that the quality…
    Loc93-4: - Tell me, please, - you called the examiner. - The statement of the problem is not quite clear to me... /  / Snipeman Hogger was looking at you with complete e…
  -> Path284 => Loc97  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Offer {75} cr
       ответ: - What is it??? Do you think my knowledge is that cheap? Than I can only presume that the correct answer is <clr>not 250 cr<clrEnd>...
       условия: P7(Money) 75..1000000000
       эффект: P7(Money) = {[p7]-75}
  -> Path285 => Loc97  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Offer {150} cr
       ответ: - Not enough, I'm afraid! - Snipeman exclaimed and whispered: - Very well, I'll tell you: the answers <clr>220 cr, 250 cr<clrEnd> and <clr>270 cr<clrEnd> have n…
       условия: P7(Money) 150..1000000000
       эффект: P7(Money) = {[p7]-150}
  -> Path286 => Loc97  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Offer {300} cr
       ответ: - You are very bright, <Ranger>, and will distinguish yourself! - the examiner was all smiles. Then he straightened his fashionable violet Vershace jacket (no l…
       условия: P7(Money) 300..1000000000
       эффект: P7(Money) = {[p7]-300}
  -> Path287 => Loc97  вер=1 проходов<=1 порядок=4
       текст: Don't offer anything
       ответ: - Ranger <Ranger>, - an evil glimpse flashed in the Human's eyes, - I thought you needed my help... I guess, I misunderstood you. /  / You realised something wa…
       показ: P7

### Loc97 [пустая] визитов<=1
    показ: P7
  -> Path279 => Loc120  вер=1 проходов<=1 порядок=5
       текст: Get back to the test-paper and choose the answer

### Loc110 [обычная] визитов<=1
    Loc110-1: - Had I been a trifle younger, I'd hit on that chappy big time! - a female's voice said with confidence. / - Did you say "chappy"? Give me a break - he's a real…
  -> Path313 => Loc111  вер=1 проходов<=1 порядок=5
       текст: Enter

### Loc111 [обычная] визитов<=3
    Loc111-1: The door opened automatically and you saw three females fagging over some reports. One of them was a slim and beautiful Human, stylishly coiffure a la "letz-hef…
  -> Path35 => Loc17  вер=1 проходов<=1 порядок=5
       текст: Talk female 2 and mention her name
       ответ: - Such a dunce, I am Bugbubba!!! - you heard the Maloq female's rumbling bass - Who are you to bother me for nothing?
       эффект: P4(Bugbubba's disposition) = {[10..20]} [показ]
  -> Path36 => Loc17  вер=1 проходов<=1 порядок=6
       текст: Talk to female 3 and mention her name
       ответ: - O, o! Where did you hear my name, lover-boy? - a mighty beef about two meters high grinned nicely and rose in front of you. - Who are you, lad?
       эффект: P4(Bugbubba's disposition) = {[30..40]} [показ]
  -> Path37 => Loc17  вер=1 проходов<=1 порядок=3
       текст: Talk to female 1 and mention her name
       ответ: - You are wrong, mister! - and the ginger-head Maloq female half got up from the table intercepting the lamplight. - Who are you?!
       эффект: P4(Bugbubba's disposition) = {[20..30]} [показ]

### Loc115 [пустая] визитов<=3
  -> Path318 => Loc59  вер=1 проходов<=3 порядок=5
       эффект: P11(RND) = 2

### Loc116 [пустая] визитов<=3
    скрыт: P4
  -> Path190 => Loc14  вер=1 проходов<=1 порядок=5
       текст: Return to Loho-Khan
       ответ: - I did my best but she refused absolutely from dating you, she even refuses to talk about it - she considers you a drip and a fancy pants, - you reported to Lo…
       условия: P26(x) 1..1
  -> Path261 => Loc47  вер=1 проходов<=1 порядок=5
       текст: Return to Loho-Khan
       условия: P26(x) 2..2
       эффект: P2(Young Gaalian's bonus) = 1 [показ]
  -> Path262 => Loc81  вер=1 проходов<=1 порядок=5
       текст: Return to Loho-Khan
       ответ: You simply passed the message to the examiner. He looked at it yearningly and read it several times. / - Hurray, ranger, she'll be waiting for me in half an hou…
       условия: P26(x) 3..3

### Loc119 [пустая] визитов<=3
    эффект: P11(RND) = {[25..45]}
  -> Path325 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Read
       ответ: "Wil b watin' in <clr>huf an hour <clrEnd> niar the piezomasagin' divais in the rekreation area on levl 5 / Yor Bugbubba". /  / "That's the stuff! - you thought…
       условия: логика {[p4]>=2*[p11]}
       эффект: P26(x) = 3
  -> Path330 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Read
       ответ: "Kum to the rekriation aria on levl 5 in the <clr>ivnin'<clrEnd>. / Bugbubba". /  / "Well, this will do! - you thought. - Now I'll give it to Loho-Khan!"
       условия: логика {([p4]>=[p11]) and ([p4]<=2*[p11])}
       эффект: P26(x) = 2
  -> Path331 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Read
       ответ: "If I mit u wans agan, it's yor funeral, skumbak!!!" /  / "Too bad... she must be out of spirits today, - you though. - I don't think you should show it to Loho…
       условия: логика {[p4]<=[p11]}
       эффект: P26(x) = 1

### Loc120 [обычная] визитов<=10
    выбор описания: {[p21]}
    Loc120-1: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / A trading company has a spaceship with a motor that allows a jump {27} parsec long; its tank capacity …
    Loc120-2: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / A trading company has a spaceship with a motor that allows a jump {35} parsec long; its tank capacity …
    Loc120-3: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / A trading company has a spaceship with a motor that allows a jump {19} parsec long; its tank capacity …
    эффект: P26(x) = 0
  -> Path50 => Loc123  вер=1 проходов<=1 порядок=3
       текст: 250 cr
  -> Path88 => Loc123  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Enter the secret code
       условия: логика {[p2]>=1}
       эффект: P1(Marks) +1 [показ]
       эффект: P2(Young Gaalian's bonus) -1
       эффект: P26(x) = 1
  -> Path93 => Loc93  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       условия: логика {[p27]=3}
  -> Path189 => Loc123  вер=1 проходов<=1 порядок=2
       текст: 260 cr
       эффект: P1(Marks) = {[p1]+([p21]=1)}
       эффект: P26(x) = {([p21]=1)}
  -> Path255 => Loc123  вер=1 проходов<=1 порядок=1
       текст: 270 cr
  -> Path256 => Loc123  вер=1 проходов<=1 порядок=4
       текст: 240 cr
       эффект: P1(Marks) = {[p1]+([p21]=3)}
       эффект: P26(x) = {([p21]=3)}
  -> Path258 => Loc123  вер=1 проходов<=1 порядок=5
       текст: 230 cr
       эффект: P1(Marks) = {[p1]+([p21]=2)}
       эффект: P26(x) = {([p21]=2)}
  -> Path259 => Loc123  вер=1 проходов<=1 порядок=6
       текст: 220 cr
  -> Path346 => Loc97  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me but I need your help, - you winked at the Faeyan cunningly but he remained completely imperturbable: /  / - I don't understand what help you are tal…
       условия: логика {[p27]=2}
  -> Path347 => Loc97  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me, please! - you called the examiner. - I don't quite understand what they mean here... /  / Useless - the Gaalian was buried in his thought and fell …
       условия: логика {[p27]=1}

### Loc121 [обычная] визитов<=8
    выбор описания: {[p21]}
    Loc121-1: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / According to the old Faeyan tradition, one of four spaceship cabins is furnished in a more luxurious w…
    Loc121-2: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / According to the old Faeyan tradition, one of four spaceship cabins is furnished in a more luxurious w…
    Loc121-3: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / According to the old Faeyan tradition, one of four spaceship cabins is furnished in a more luxurious w…
    Loc121-4: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / According to the old Faeyan tradition, one of four spaceship cabins is furnished in a more luxurious w…
    эффект: P26(x) = 0
  -> Path348 => Loc125  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me but I need your help, - you winked at the Faeyan cunningly but he remained completely imperturbable: /  / - I don't understand what help you are tal…
       условия: логика {[p27]=2}
  -> Path350 => Loc125  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me, please! - you called the examiner. - I don't quite understand what they mean here... /  / Useless - the Gaalian was buried in his thought and fell …
       условия: логика {[p27]=1}
  -> Path351 => Loc124  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       условия: логика {[p27]=3}
  -> Path356 => Loc126  вер=1 проходов<=1 порядок=2
       текст: Cabin №1
       эффект: P1(Marks) = {[p1]+([p21]>2)}
       эффект: P26(x) = {([p21]>2)}
  -> Path357 => Loc126  вер=1 проходов<=1 порядок=5
       текст: Cabin №3
       эффект: P1(Marks) = {[p1]+([p21]<3)}
       эффект: P26(x) = {([p21]<3)}
  -> Path358 => Loc126  вер=1 проходов<=1 порядок=6
       текст: Cabin №4
  -> Path359 => Loc126  вер=1 проходов<=1 порядок=4
       текст: Cabin №2
  -> Path396 => Loc126  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Enter the secret code
       условия: логика {[p2]>=1}
       эффект: P1(Marks) +1 [показ]
       эффект: P2(Young Gaalian's bonus) -1
       эффект: P26(x) = 1

### Loc122 [обычная] визитов<=9
    выбор описания: {[p21]}
    Loc122-1: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / Your ship's capacity is {300} items. You must equip it with a motor, fuel tank and protection field ge…
    Loc122-2: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / Your ship's capacity is {300} items. You must equip it with a motor, fuel tank and protection field ge…
    Loc122-3: <clr>Test-paper №<clrEnd>{[p5]} /  / Question [p25]. /  / Your ship's capacity is {300} items. You must equip it with a motor, fuel tank and protection field ge…
    эффект: P26(x) = 0
  -> Path360 => Loc128  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me, please! - you called the examiner. - I don't quite understand what they mean here... /  / Useless - the Gaalian was buried in his thought and fell …
       условия: логика {[p27]=1}
  -> Path361 => Loc128  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       ответ: - Excuse me but I need your help, - you winked at the Faeyan cunningly but he remained completely imperturbable: /  / - I don't understand what help you are tal…
       условия: логика {[p27]=2}
  -> Path363 => Loc127  вер=1 проходов<=1 порядок=8
       текст: Ask the examiner for help
       условия: логика {[p27]=3}
  -> Path368 => Loc129  вер=1 проходов<=1 порядок=3
       текст: 10%
       эффект: P1(Marks) = {[p1]+([p21]=1)}
       эффект: P26(x) = {([p21]=1)}
  -> Path369 => Loc129  вер=1 проходов<=1 порядок=4
       текст: 15%
       эффект: P1(Marks) = {[p1]+([p21]=2)}
       эффект: P26(x) = {([p21]=2)}
  -> Path370 => Loc129  вер=1 проходов<=1 порядок=6
       текст: 25%
  -> Path371 => Loc129  вер=1 проходов<=1 порядок=5
       текст: 20%
       эффект: P1(Marks) = {[p1]+([p21]=3)}
       эффект: P26(x) = {([p21]=3)}
  -> Path372 => Loc129  вер=1 проходов<=1 порядок=2
       текст: 5%
  -> Path397 => Loc129  вер=1 [всегда видна] проходов<=1 порядок=7
       текст: Enter the secret code
       условия: логика {[p2]>=1}
       эффект: P1(Marks) +1 [показ]
       эффект: P2(Young Gaalian's bonus) -1
       эффект: P26(x) = 1

### Loc123 [пустая]
  -> Path376 => Loc132  вер=1000 проходов<=1 порядок=5
       условия: логика {[p25]-[p1]>1}
  -> Path379 => Loc131  вер=1 порядок=5
  -> Path382 => Loc133  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=2}
  -> Path383 => Loc134  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=3}

### Loc124 [обычная] визитов<=1
    Loc124-1: - What is it, <Ranger>, a poser? - Snipeman Hogger asked and smiled greedily. /  / - Well, not a complete poser, - you murmured. - But a good piece of advice wo…
    Loc124-2: - What's the problem, pilot? Can I really help you? - the examiner grinned. /  / - Yes, I need your help, I'll make it worth your while, - you winked cunningly …
    Loc124-3: - Can I ask you for a second? - you asked the examiner. - I have a question. /  / - Sure, you can! - Snipeman Hogger was all smiles. - But note that the quality…
    Loc124-4: - Tell me, please, - you called the examiner. - The statement of the problem is not quite clear to me... /  / Snipeman Hogger was looking at you with complete e…
  -> Path352 => Loc125  вер=1 проходов<=1 порядок=4
       текст: Don't offer anything
       ответ: - Ranger <Ranger>, - an evil glimpse flashed in the Human's eyes, - I thought you needed my help... I guess, I misunderstood you. /  / You realised something wa…
       показ: P7
  -> Path353 => Loc125  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Offer {150} cr
       ответ: - It's not enough, I'm afraid! - Snipeman Hogger exclaimed and then whispered: - Very well, I'll tell you: the best cabin's number is always <clr>uneven <clrEnd…
       условия: P7(Money) 150..1000000000
       эффект: P7(Money) = {[p7]-150}
  -> Path354 => Loc125  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Offer {75} cr
       ответ: - What is it??? Do you think my knowledge is that cheap? Than I can only presume that the correct answer <clr>excludes cabin №4<clrEnd>...
       условия: P7(Money) 75..1000000000
       эффект: P7(Money) = {[p7]-75}
  -> Path355 => Loc125  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Offer {300} cr
       ответ: - You are very bright, <Ranger>! - the examiner was all smiles and you saw a very expensive centecium dummy sparkled in his mouth. Then he bent over you with a …
       условия: P7(Money) 300..1000000000
       эффект: P7(Money) = {[p7]-300}

### Loc125 [пустая] визитов<=1
  -> Path349 => Loc121  вер=1 проходов<=1 порядок=5
       текст: Get back to the test-paper and choose the answer

### Loc126 [пустая]
  -> Path377 => Loc132  вер=1000 проходов<=1 порядок=5
       условия: логика {[p25]-[p1]>1}
  -> Path380 => Loc131  вер=1 порядок=5
  -> Path384 => Loc134  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=3}
  -> Path386 => Loc133  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=2}

### Loc127 [обычная] визитов<=1
    Loc127-1: - What is it, <Ranger>, a poser? - Snipeman Hogger asked and smiled greedily. /  / - Well, not a complete poser, - you murmured. - But a good piece of advice wo…
    Loc127-2: - What's the problem, pilot? Can I really help you? - the examiner grinned. /  / - Yes, I need your help, I'll make it worth your while, - you winked cunningly …
    Loc127-3: - Can I ask you for a second? - you asked the examiner. - I have a question. /  / - Sure, you can! - Snipeman Hogger was all smiles. - But note that the quality…
    Loc127-4: - Tell me, please, - you called the examiner. - The statement of the problem is not quite clear to me... /  / Snipeman Hogger was looking at you with complete e…
  -> Path364 => Loc128  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Offer {300} cr
       ответ: - You are on the same wavelength with me, <Ranger>, it's just a pleasure dealing with you! - the examiner was all smiles. The Human took a stylish handkerchief …
       условия: P7(Money) 300..1000000000
       эффект: P7(Money) = {[p7]-300}
  -> Path365 => Loc128  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Offer {150} cr
       ответ: - Not enough, I'm afraid! - Snipeman Hogger exclaimed and then whispered: - Very well, I'll tell you: the correct answer is either <clr>10%<clrEnd>, or <clr>15%…
       условия: P7(Money) 150..1000000000
       эффект: P7(Money) = {[p7]-150}
  -> Path366 => Loc128  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Offer {75} cr
       ответ: - What is it??? Do you think my knowledge is that cheap? Then I can only presume that the correct answer is <clr>not 5%<clrEnd>...
       условия: P7(Money) 75..1000000000
       эффект: P7(Money) = {[p7]-75}
  -> Path367 => Loc128  вер=1 проходов<=1 порядок=4
       текст: Don't offer anything
       ответ: - Ranger <Ranger>, - an evil glimpse flashed in the Human's eyes, - I thought you needed my help... I guess, I misunderstood you. /  / You realised something wa…
       показ: P7

### Loc128 [пустая] визитов<=1
  -> Path362 => Loc122  вер=1 проходов<=1 порядок=5
       текст: Get back to the test-paper and choose the answer

### Loc129 [пустая]
  -> Path378 => Loc132  вер=1000 проходов<=1 порядок=5
       условия: логика {[p25]-[p1]>1}
  -> Path381 => Loc131  вер=1 порядок=5
  -> Path385 => Loc134  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=3}
  -> Path387 => Loc133  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=2}

### Loc130 [пустая] визитов<=3
    показ: P1
  -> Path373 => Loc120  вер=1 проходов<=1 порядок=5
       эффект: P21(Variant) = {[1..3]}
  -> Path374 => Loc121  вер=1 проходов<=1 порядок=5
       эффект: P21(Variant) = {[1..4]}
  -> Path375 => Loc122  вер=1 проходов<=1 порядок=5
       эффект: P21(Variant) = {[1..3]}

### Loc131 [обычная] визитов<=3
    выбор описания: {[p26]+1}
    Loc131-1: The following message appeared on the screen: /  / "This was <clr>the first<clrEnd> error. No more errors allowed!"
    Loc131-2: The following message appeared on the screen: /  / "<clr>Correct!<clrEnd>"
    эффект: P25(Question) +1
  -> Path388 => Loc130  вер=1 проходов<=3 порядок=5
       текст: Go on to the next item

### Loc132 [ПРОВАЛ]
    Loc132-1: The following message appeared on the screen: /  / "This was <clr>the second<clrEnd> error. Testing complete". /  / And the card popped crack out of the slot. /…

### Loc133 [пустая] визитов<=2
  -> Path389 => Loc135  вер=1000 проходов<=1 порядок=5
       условия: P25(Question) 2..2; P27(Examiner) 2..2
  -> Path390 => Loc136  вер=1 проходов<=1 порядок=5

### Loc134 [УСПЕХ]
    Loc134-1: - Excellent, <Ranger>!!! - the Faeyan exclaimed. - I knew you would do it! You know the theory so well that I think you deserve to get the certificate right now…

### Loc135 [обычная] визитов<=1
    Loc135-1: The following message appeared on the screen: /  / "Correct! <clr>Testing complete successfully <clrEnd>". /  / Your card came out accurately from the slot and …
    эффект: P25(Question) +1
  -> Path391 => Loc130  вер=1 проходов<=1 порядок=4
       текст: That's all right with me, of course - I lose nothing!
  -> Path392 => Loc81  вер=1 проходов<=1 порядок=5
       текст: Get along with your theory, I'd better pass the practice!

### Loc136 [обычная] визитов<=1
    выбор описания: {[p26]+1}
    Loc136-1: The following message appeared on the screen: /  / "Incorrect. This is <clr>an error<clrEnd>". /  / - Heh, <Ranger>, if you only knew how much you've disappoint…
    Loc136-2: The following message appeared on the screen: /  / "Correct! <clr> Testing complete successfully <clrEnd>". /  / The card came out accurately from the slot and …
  -> Path393 => Loc81  вер=1 проходов<=1 порядок=5
       текст: Pass the practice

### Loc137 [обычная]
    выбор описания: {[1..5]*2-[p13]}
    Loc137-1: "First aim, then shoot! And don't mix up!!!" - this was what your sergeant told you before the first firing drills in the army. Those were the days...
    Loc137-2: "This is a good simulator, by the way, very realistic", - you thought looking at the next asteroid appearing on the monitor.
    Loc137-3: So, shall we move the gun or shoot?
    Loc137-4: Your fingers gripped the trigger like grim death. No pasaran!!! Asteroids won't pass!
    Loc137-5: "Show me a fool who will carry valuable freight through an asteroid belt! - you thought. - This practical course has as less to do with the ship navigation prac…
    Loc137-6: "I'll show you now what is what! - you thought looking at the next asteroid. - What if I let it come closer?"
    Loc137-7: "Can the gun get jammed here, I wonder? - you thought. - That would be very realistic indeed!"
    Loc137-8: "It's still good that these asteroids don't shoot! - you thought. - I wish these trainer-makers were stuck into the battle with dominators! I bet that would hav…
    Loc137-9: Who is stronger - you or asteroids? Stupid question! Coping with asteroids is a doddle for such an experienced pilot like you!
    Loc137-10: You glimpsed at the shot asteroids counter: [p23] shot asteroids, that is, {20-[p23]} are left. Not that much, never say die!
  -> Path236 => Loc82  вер=1 порядок=6
       текст: Up
       условия: P24(Firing line) 2..2; логика {[p23]<20}
       эффект: P24(Firing line) -1
       скрыт: P37,P40
       показ: P38,P39
  -> Path237 => Loc82  вер=1 порядок=5
       текст: Fire!
       условия: логика {[p24]=1 and [p23]<20}
       эффект: P23(Shot down) = {[p23]+([p37]>0)}
       эффект: P37(Firing line 1) = 0
  -> Path238 => Loc82  вер=1 порядок=8
       текст: Down
       условия: P24(Firing line) 4..4; логика {[p23]<20}
       эффект: P24(Firing line) +1
       показ: P43,P46
       скрыт: P44,P45
  -> Path239 => Loc82  вер=1 порядок=5
       текст: Fire!
       условия: логика {[p24]=3 and [p23]<20}
       эффект: P23(Shot down) = {[p23]+([p41]>0)}
       эффект: P41(Firing line 3) = 0
  -> Path240 => Loc82  вер=1 порядок=5
       текст: Fire!
       условия: логика {[p24]=2 and [p23]<20}
       эффект: P23(Shot down) = {[p23]+([p39]>0)}
       эффект: P39(Firing line 2) = 0
  -> Path241 => Loc82  вер=1 порядок=5
       текст: Fire!
       условия: логика {[p24]=5 and [p23]<20}
       эффект: P23(Shot down) = {[p23]+([p45]>0)}
       эффект: P45(Firing line 5) = 0
  -> Path242 => Loc82  вер=1 порядок=5
       текст: Fire!
       условия: логика {[p24]=4 and [p23]<20}
       эффект: P23(Shot down) = {[p23]+([p43]>0)}
       эффект: P43(Fire line 4) = 0
  -> Path249 => Loc85  вер=1 проходов<=1 порядок=5
       текст: Hurray! We won!!!
       условия: логика {[p23]=20}
  -> Path399 => Loc82  вер=1 порядок=8
       текст: Down
       условия: P24(Firing line) 2..2; логика {[p23]<20}
       эффект: P24(Firing line) +1
       показ: P39,P42
       скрыт: P40,P41
  -> Path400 => Loc82  вер=1 порядок=8
       текст: Down
       условия: P24(Firing line) 3..3; логика {[p23]<20}
       эффект: P24(Firing line) +1
       показ: P41,P44
       скрыт: P42,P43
  -> Path401 => Loc82  вер=1 порядок=8
       текст: Down
       условия: P24(Firing line) 1..1; логика {[p23]<20}
       эффект: P24(Firing line) +1
       показ: P37,P40
       скрыт: P38,P39
  -> Path402 => Loc82  вер=1 порядок=6
       текст: Up
       условия: P24(Firing line) 3..3; логика {[p23]<20}
       эффект: P24(Firing line) -1
       скрыт: P39,P42
       показ: P40,P41
  -> Path403 => Loc82  вер=1 порядок=6
       текст: Up
       условия: P24(Firing line) 5..5; логика {[p23]<20}
       эффект: P24(Firing line) -1
       скрыт: P43,P46
       показ: P44,P45
  -> Path404 => Loc82  вер=1 порядок=6
       текст: Up
       условия: P24(Firing line) 4..4; логика {[p23]<20}
       эффект: P24(Firing line) -1
       скрыт: P41,P44
       показ: P42,P43

### Loc138 [обычная] визитов<=9
    выбор описания: {[p26]}
    Loc138-1: After a long fudge about the supernew superbiochemical process in some superbugs' cells, Bugbubba felt completely tired and interrupted you: /  / - Heh, you mus…
    Loc138-2: You introduce yourself to Bugbubba as a scholar, to be more correct, ammunition designer. To prove it you cited a new gun's tactical and technical parameters th…
    Loc138-3: Try as you might to praise Loho-Khan and make a hero out of him, you failed... / - You turn out to lack grip like your friend does! So what are you going to do …
    Loc138-4: You never had problems with eloquence and started picturing one fight after another and Bugbubba, completely intoxicated, listened open-mouthed and hot-eyed. Sh…
    Loc138-5: You were picturing your fights with dominators in space and on different planets. Bugbubba was listening open-mouthed. However, when you started telling her abo…
    Loc138-6: You started from afar telling her that you adored issuing school bulletins in your childhood, asking all passers-by stupid questions, and spying on the neighbou…
    Loc138-7: You introduced yourself to Bugbubba as a military journalist. To prove it you told her about a couple of fights you took part in. It sounded rather veracious. Y…
    эффект: P11(RND) = {[0..100]}
  -> Path406 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - What?! - Bugbubba was shocked. - What do you take me for?! Do you consider Maloq females as stupid as to feed every Tom, Dick and Harry if they introduce them…
       условия: P26(x) 4..5; логика {[p11]>[p4]}
       эффект: P26(x) = 1
  -> Path407 => Loc52  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - Will such a noble Maloq female buy a simple lunch for a celebrated commodore who spent all his money on the ship repair after the fight with dominators? - you…
       условия: P26(x) 4..5; логика {[p11]<=[p4]}
  -> Path408 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Offer to buy Bugbubba lunch (300 cr)
       ответ: - It's lunchtime now, shall we have a bite in the local canteen? Will you accept my offer if I buy you lunch? /  / - Yes, of course, I'm constantly hungry! I lo…
       условия: P7(Money) 300..1000000000
       эффект: P7(Money) = {[p7]-300}
       эффект: P4(Bugbubba's disposition) = {[p4]+[10..20]}
  -> Path409 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Offer Bugbubba to have lunch together (150 cr)
       ответ: - It's lunchtime now, shall we have a bite in the local canteen? - you offered. /  / - Why not? - Bugbubba said. - Do I really care who is scoffing nearby? /  /…
       условия: P7(Money) 150..1000000000
       эффект: P7(Money) = {[p7]-150}
       эффект: P4(Bugbubba's disposition) = {[p4]+[1..10]}
  -> Path413 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - What?! - Bugbubba was shocked. - Did I get it right, that <Ranger>, a scholar, is requesting a poor Maloq plodder to buy him lunch? What do you take me for?! …
       условия: P26(x) 1..2; логика {[p11]>[p4]}
       эффект: P26(x) = 1
  -> Path414 => Loc52  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - I invested all my money in the last project, - you complained. - And can't even afford lunch... /  / Bugbubba was stared blankly at you catching nothing. It s…
       условия: P26(x) 1..2; логика {[p11]<=[p4]}
  -> Path415 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - Ha-ha! - Bugbubba grinned. - Not likely! Let your buddy Loho-Khan treat you! /  / And Bugbubba left towards the Centre's canteen. Well, you failed to impress …
       условия: P26(x) 3..3
       эффект: P26(x) = 1
  -> Path416 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - Pauper journalist?! - Bugbubba got surprised. - It just cant' be! You lied to me, you are anything but a journalist. You are just a pilfer who decided to make…
       условия: P26(x) 6..7; логика {[p11]>[p4]}
       эффект: P26(x) = 1
  -> Path417 => Loc52  вер=1 проходов<=1 порядок=5
       текст: Ask Bugbubba to wine and dine you
       ответ: - You know...I got robbed! - you complained to Bugbubba. - I turned an honest penny and everything is now gone: three tape recorders, three stereocameras, and m…
       условия: P26(x) 6..7; логика {[p11]<=[p4]}

## Анализ
- стартовых: [1]
- концовки: {85: 'УСПЕХ', 89: 'ПРОВАЛ', 132: 'ПРОВАЛ', 134: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: [5]
