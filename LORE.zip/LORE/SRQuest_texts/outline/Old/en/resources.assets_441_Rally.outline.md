# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Stick shift' [0..10] тип=обычный
    старт: [1]
    [0..10] Parameter 1: <>
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Conversation' [0..3] тип=обычный
    старт: [0]
    [0..3] Parameter 2: <>
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Money' [0..1000000] тип=обычный
    старт: [1000000]
    [0..1000000] Team money: <> cr.
    критическое: Сообщение достижения критического значения параметром 4
- P4 'Car make' [0..4] тип=обычный
    старт: [0]
    [0..0] No car
    [1..1] Car make - Studebumper
    [2..2] Car make - Betta Julietta
    [3..3] Car make - Gator Piston
    [4..4] Car make - Soobaru WRX STI SBR VO
    критическое: Сообщение достижения критического значения параметром 3
- P5 'Row' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] -=-=-=-Car Properties-=-=-=-
    критическое: Сообщение достижения критического значения параметром 5
- P6 "Klim's cardiogram" [0..5] тип=смерть
    старт: [0]
    [0..5] Parameter 6: <>
    критическое: Klim abruptly clutched his heart, mumbled something unintelligible, and fell to the ground. Apparent…
- P7 'Speed' [0..100] тип=обычный
    старт: [0]
    [0..9] Same as a turtle
    [10..19] Same as a turtle
    [20..29] Same as a turtle
    [30..39] Same as a turtle
    [40..49] Lowest speeds
    [50..59] Lowest speeds
    [60..69] Fair speeds
    [70..79] Decent speeds
    [80..89] Good speeds
    [90..100] Excellent speeds!
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Weight' [0..2000] тип=обычный
    старт: [0]
    [0..2000] Car weight: <> kg
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Acceleration' [0..100] тип=обычный
    старт: [0]
    [0..9] The engine has no pull at all!
    [10..19] The engine has no pull at all!
    [20..29] The engine has no pull at all!
    [30..39] The engine is half-dead!
    [40..49] The engine is half-dead!
    [50..59] Tolerable acceleration
    [60..69] Fair acceleration
    [70..79] Decent acceleration
    [80..89] Rapid acceleration
    [90..100] The car is like a bullet!!!
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Handling' [0..100] тип=обычный
    старт: [0]
    [0..9] The car drives wherever it wants to!
    [10..19] The car drives wherever it wants to!
    [20..29] The car drives wherever it wants to!
    [30..39] The car drives all over the place!
    [40..49] The car drives all over the place!
    [50..59] The car responds
    [60..69] The car responds well
    [70..79] The car's response is highly accurate
    [80..89] The car hugs the road
    [90..100] Driver and car are one!
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Reliability' [0..100] тип=обычный
    старт: [0]
    [0..9] How does this lemon drive at all?!
    [10..19] How does this lemon drive at all?!
    [20..29] How does this lemon drive at all?!
    [30..39] A breakdown is highly likely
    [40..49] A breakdown is highly likely
    [50..59] The car is in critical condition
    [60..69] The car is fit for racing
    [70..79] The car is in good condition
    [80..89] The race car is in excellent shape!
    [90..100] Everything is perfect!
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Terrain crossing capacity' [0..30] тип=обычный
    старт: [0]
    [0..9] The ground clearance is very small
    [10..19] Average ground clearance
    [20..30] Excellent ground clearance
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Tranny!' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 13: <>
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Headlights' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Super headlights installed
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Zoopies' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You have some iron zoopies
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Nanitoid' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Nanitoid on board
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Reflective film' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] The windows have a special protective film
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Fuel tank' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] An extra tank has been installed
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Gauge' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Current speed' [0..350] тип=обычный
    старт: [0]
    [0..350] Current speed: <> km/h
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Your time' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Your time: <> min.
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Maloq time/offset' [0..100000000] тип=обычный
    старт: [0]
    [0..100000000] Maloq time: <> min.
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Peleng time/offset' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Peleng time: <> min.
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Faeyan time/offset' [0..1000000] тип=обычный
    старт: [0]
    [0..1000000] Faeyan time: <> min.
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Gaalian time/offset' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Gaalian time: <> min.
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Leg length' [0..3000] тип=обычный
    старт: [0]
    [0..1000] Short leg
    [1001..2000] Medium leg
    [2001..3000] Long leg
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Track type' [0..3] тип=обычный
    старт: [0]
    [0..0] Perfect asphalt
    [1..1] Dirt road
    [2..3] Offroad
    критическое: Сообщение достижения критического значения параметром 27
- P28 'Time remaining before heart attack' [0..40] тип=успех
    старт: [40]
    [0..40] Igorych will hang on for another <> minutes
    критическое: You heard Svyatogor's voice, as if from a great distance: / "Too late, Boss. He's...he's dead..." / …
- P29 'Durability' [0..100] тип=смерть
    старт: [1]
    [0..100] Car durability: <> %
    критическое: Your car couldn't withstand the load and simply exploded... Anyway, it was a worthy death for such d…
- P30 'Finances' [0..1000000000] тип=обычный деньги
    старт: [0]
    [0..1000000000] Parameter 30: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Breakdown' [0..100] тип=провал
    старт: [1]
    [0..100] Estimated car durability - <>%
    критическое: An unexpected explosion shook the stadium. You dashed toward the monitor and discovered that your dr…
- P32 'Driver skills' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 32: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'Strike' [0..1] тип=обычный
    старт: [0]
    [0..1] The fuel tank has been punctured!
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Distance to finish line' [0..8500] тип=обычный
    старт: [0]
    [0..1] The race is over!!!
    [2..8500] Distance to finish line: <> m
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Difference from the maloqs' [0..3000] тип=обычный
    старт: [0]
    [0..1] The maloq driver is right in front of you!
    [2..3000] Distance behind the maloqs: <> m
    критическое: Сообщение достижения критического значения параметром 35
- P36 'Difference from the pelengs' [0..3000] тип=обычный
    старт: [0]
    [0..1] The peleng driver is right in front of you!
    [2..3000] Distance behind the pelengs: <> m
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Difference from the faes' [0..4000] тип=обычный
    старт: [0]
    [0..0] The faeyan driver is right in front of you!
    [1..4000] Difference from the faes: <> m
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Difference from the gaals' [0..4000] тип=обычный
    старт: [0]
    [0..0] The gaalian driver is right in front of you!
    [1..4000] Difference from the gaalians: <> m
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Starting number' [0..5] тип=обычный
    старт: [0]
    [0..5] 
    критическое: Сообщение достижения критического значения параметром 39
- P40 "Who's hot?" [0..1] тип=обычный
    старт: [0]
    [0..1] YOU'RE IN THE LEAD!!!
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Product line' [0..99999] тип=обычный
    старт: [0]
    [0..99999] Parameter 41: <>
    критическое: Сообщение достижения критического значения параметром 41
- P42 'Cross-section number' [1..10000] тип=обычный
    старт: [1]
    [1..10000] Parameter 42: <>
    критическое: Сообщение достижения критического значения параметром 42
- P43 'Rubber' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 43: <>
    критическое: Сообщение достижения критического значения параметром 43
- P44 'Rimmed' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Wheeled' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 45: <>
    критическое: Сообщение достижения критического значения параметром 45
- P46 'Critical lag' [999..100000] тип=провал
    старт: [1000]
    [999..100000] 
    критическое: Igorych's voice sounded into your headset: / "Boss, they finished! The gaalians won! It's over!" / Y…
- P47 'Board' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 47

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You didn't have any trouble reaching the western outskirts of town where the stadium was located. The enormous structure left you a bit dumbfounded - you had ex…
    скрыт: P1,P2,P3,P4,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47
  -> Path2 => Loc2  вер=1 проходов<=1 порядок=5
       текст: Go with Klim to the stadium
       скрыт: P3
  -> Path80 => Loc5  вер=1 проходов<=1 порядок=5
       текст: Abandon this idiotic undertaking and return to your ship

### Loc2 [обычная] визитов<=1
    Loc2-1: Klim Igorych chuckled and moved toward the taxi stop. On the way to the races he described the work you were facing: "The races are between vehicles with an int…
  -> Path3 => Loc3  вер=1 проходов<=1 порядок=5
       текст: Pick Klim's brains along the way
       эффект: P2(Conversation) = 1
  -> Path4 => Loc4  вер=1 проходов<=1 порядок=6
       текст: Walk in silence, focusing your mind before the competition
       эффект: P1(Stick shift) = 1

### Loc3 [обычная] визитов<=7
    выбор описания: {[p1]}
    Loc3-1: "Hey, Igorych, can you tell me in more detail what exactly I'm supposed to do?" / "I already told you," said the mechanic, raising his eyes in surprise. "Choose…
    Loc3-2: "There's no way! We don't even know what we're driving, and his ideas for a name... There's the freak now," said Igorych. / "What do you mean we don't know?" yo…
    Loc3-3: "No problem.  Svyatogor Korchenitsa is our star. And then there's Hamilton Dudochkin and Edward Pollonso. Also not bad. They're just really young; it won't work…
    Loc3-4: "Don't overlook what we've already got!", laughed Klim. "We're swimming in that goodness. I just wish we had money. Of course, sponsors will give us some, but i…
    Loc3-5: "If they're too tough to crack, then we'll crush them! We just need to ice four teams. And then we'll be in with riches instead of being in with witches, like u…
    Loc3-6: "Hey, fella. What's up? Are you overheated?" asked Klim, looking at you somewhat flabbergasted.  / "It's just that most of the things I've gotten involved in ha…
    Loc3-7: "Why? First, you win - then you celebrate!" Klim replied. / "Yeah, I usually go to bars: sometimes it's an interesting date with a peleng, sometimes - a school …
  -> Path7 => Loc6  вер=1 проходов<=1 порядок=4
       текст: What's our team called?
       эффект: P1(Stick shift) = 2
  -> Path8 => Loc6  вер=1 проходов<=1 порядок=5
       текст: What are our drivers like?
       эффект: P1(Stick shift) = 3
  -> Path9 => Loc6  вер=1 проходов<=1 порядок=6
       текст: Do we have enough accessories?
       эффект: P1(Stick shift) = 4
  -> Path10 => Loc6  вер=1 проходов<=1 порядок=6
       текст: Can we crack the competition?
       эффект: P1(Stick shift) = 5
  -> Path11 => Loc4  вер=1 проходов<=1 порядок=9
       текст: Okay, got it. Let's go, Klim! We're going to tear off everybody's bumpers!
       эффект: P1(Stick shift) = 2
  -> Path12 => Loc6  вер=1 проходов<=1 порядок=7
       текст: No, seriously? Is the race organizer a maniac? Is everything here just about to explode? The cars have plasmagenes? There're going to be Gobisaurus on the racet…
       эффект: P1(Stick shift) = 6
  -> Path18 => Loc6  вер=1 проходов<=1 порядок=8
       текст: Say, is there a bar around here?
       эффект: P1(Stick shift) = 7

### Loc4 [обычная] визитов<=2
    выбор описания: {[p1]}
    Loc4-1: The pits were housed in a large room, albeit nearly empty. There were tools hanging on the walls, a computer in the corner...and that was it. There were no cars…
    Loc4-2: You stopped torturing Igorych and walked the rest of the way in silence. / The pits were housed in a large room, albeit nearly empty. There were tools hanging o…
  -> Path13 => Loc7  вер=1 проходов<=1 порядок=5
       текст: What do we do with the cars? And where are the drivers?
       условия: P2(Conversation) 1..3
       показ: P3,P4
  -> Path14 => Loc7  вер=1 проходов<=1 порядок=5
       текст: But what do we do with the cars? And where are the drivers?
       условия: P2(Conversation) 0..0
       показ: P3,P4

### Loc5 [ПРОВАЛ] визитов<=1
    выбор описания: {[p1]}
    Loc5-1: "To hell with these races," you stammered as you took as you sat down in the driver's seat.  But the reward is irretrievably lost...

### Loc6 [пустая]
    выбор описания: {[p1]}
  -> Path6 => Loc3  вер=1 порядок=5

### Loc7 [обычная] визитов<=1
    выбор описания: {[p2]+1}
    Loc7-1: "Earlier you didn't really want to talk to me... Weasel your own way out of it, genius." / Your only friend here seems to be the computer.  For some reason, it …
    Loc7-2: "The guys are getting closer to the start line. Right now they're getting massages. And the cars... We've got to quickly figure out which rides we're taking to …
  -> Path15 => Loc8  вер=1 проходов<=1 порядок=5
       текст: Choose a car
       эффект: P1(Stick shift) = 1

### Loc8 [обычная]
    выбор описания: {[p1]}
    Loc8-1: You began searching for a suitable make for your team. It turns out you can only quickly get three identical cars from a few manufacturers. After reviewing the …
    Loc8-2: You called Igorych over. His eyes narrowed as they ran across the text on the screen. Then they wandered thoughtfully from corner to corner, and then he said, /…
    Loc8-3: You sent the order and in a moment the cars will be delivered.
    Loc8-4: You scolded your mechanic long and loud for not being prepared for the race, for the incivility and disorder in the galaxy, and denounced him as a dominator spy…
  -> Path17 => Loc9  вер=1 проходов<=1 порядок=3
       текст: Ask Igorych to help
       условия: P2(Conversation) 1..1; P4(Car make) 0..0
       эффект: P2(Conversation) = 2
       эффект: P1(Stick shift) = 2
  -> Path20 => Loc9  вер=1 проходов<=1 порядок=7
       текст: Contact GE and order a Soobaru
       условия: P2(Conversation) 2..2; P4(Car make) 0..0
       эффект: P4(Car make) = 4
       эффект: P1(Stick shift) = 3
       эффект: P3(Money) = {[p3]-500000}
       эффект: P7(Speed) = 90
       эффект: P8(Weight) = 1250
       эффект: P9(Acceleration) = 90
       эффект: P10(Handling) = 90
       эффект: P11(Reliability) = 83
       эффект: P12(Terrain crossing capacity) = 25
  -> Path21 => Loc9  вер=1 проходов<=1 порядок=4
       текст: Choose Studebumpers to save money
       условия: P4(Car make) 0..0
       эффект: P4(Car make) = 1
       эффект: P1(Stick shift) = 3
       эффект: P3(Money) = {[p3]-150000}
       эффект: P7(Speed) = 65
       эффект: P8(Weight) = 1100
       эффект: P9(Acceleration) = 55
       эффект: P10(Handling) = 60
       эффект: P11(Reliability) = 55
       эффект: P12(Terrain crossing capacity) = 30
  -> Path22 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Buy three Bettas
       условия: P4(Car make) 0..0
       эффект: P4(Car make) = 2
       эффект: P1(Stick shift) = 3
       эффект: P3(Money) = {[p3]-250000}
       эффект: P7(Speed) = 75
       эффект: P8(Weight) = 1200
       эффект: P9(Acceleration) = 70
       эффект: P10(Handling) = 75
       эффект: P11(Reliability) = 75
       эффект: P12(Terrain crossing capacity) +20
  -> Path23 => Loc9  вер=1 проходов<=1 порядок=6
       текст: Buy Gator Pistons! And no books!
       условия: P4(Car make) 0..0
       эффект: P4(Car make) = 3
       эффект: P1(Stick shift) = 3
       эффект: P3(Money) = {[p3]-350000}
       эффект: P7(Speed) +80
       эффект: P8(Weight) = 1250
       эффект: P9(Acceleration) +85
       эффект: P10(Handling) = 80
       эффект: P11(Reliability) = 80
       эффект: P12(Terrain crossing capacity) = 10
  -> Path24 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Wait for the cars; then choose accessories
       условия: P4(Car make) 1..1
       эффект: P1(Stick shift) = 1
       показ: P7,P8,P9,P10,P11,P12
  -> Path25 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Wait for the cars; then choose accessories
       условия: P4(Car make) 2..2
       эффект: P1(Stick shift) = 2
       показ: P5,P7,P8,P9,P10,P11,P12
  -> Path27 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Wait for the cars; then choose accessories
       условия: P4(Car make) 4..4
       эффект: P1(Stick shift) = 4
       показ: P7,P8,P9,P10,P11,P12
  -> Path28 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Wait for the cars; then choose accessories
       условия: P4(Car make) 3..3
       эффект: P1(Stick shift) = 3
       показ: P7,P8,P9,P10,P11,P12
  -> Path30 => Loc9  вер=1 порядок=9
       текст: Bawl out Igorych
       условия: P4(Car make) 0..0
       эффект: P6(Klim's cardiogram) +1
       эффект: P1(Stick shift) = 4

### Loc9 [пустая] визитов<=7
    выбор описания: {5-[p4]}
  -> Path19 => Loc8  вер=1 проходов<=6 порядок=5
       условия: P4(Car make) 0..0
  -> Path29 => Loc8  вер=1 проходов<=1 порядок=5
       условия: P4(Car make) 1..4

### Loc10 [обычная]
    выбор описания: {[p1]}
    Loc10-1: Soon, three brand-spanking-new <clr>Studebumpers<clrEnd> were driven into the pits. They didn't look especially attractive, but they had saved the team a lot of…
    Loc10-2: You saw the <clr>Betta Juliettas<clrEnd> for the first time, and they didn't disappoint: splendid exterior and comfy interior. If it weren't for the several-tho…
    Loc10-3: The <clr>Gator Piston<clrEnd> is really something. The short, bright yellow cars were shaped like a gaalian pirate ship. It's like launching a nozzle-tipped roc…
    Loc10-4: Surprisingly, the cars you ordered were quickly delivered. You probably should have asked for something more. Collectable mugs or something like that. You cars …
    Loc10-5: The screen began to blink; then there were blue bars. That's the downside of Maloqsoft software, you know. In the end, you were able to wrest some good informat…
    Loc10-6: You scolded your mechanic long and loud for not being prepared for the race, for the incivility and disorder in the galaxy, and denounced him as a dominator spy…
    Loc10-7: You quickly found records of some kind. Leaving out personal information (which is a must - you've got to maintain the rangers' highly morale image; oh, and Igo…
    Loc10-8: You got mildly tired of all the fuss over hardware selection, but there's room for improvement. Or have you had enough tinkering with cars?
  -> Path31 => Loc11  вер=1 порядок=4
       текст: Search for files of some kind left behind by the previous manager
       эффект: P1(Stick shift) = 7
  -> Path32 => Loc11  вер=1 порядок=3
       текст: Look at the summary of available accessories
       эффект: P1(Stick shift) = 5
  -> Path34 => Loc12  вер=1 порядок=5
       текст: Buy engine parts
       эффект: P1(Stick shift) = 1
  -> Path36 => Loc13  вер=1 порядок=6
       текст: Buy transmission parts
       эффект: P1(Stick shift) = 1
  -> Path38 => Loc14  вер=1 порядок=7
       текст: Buy wheels and rims
  -> Path40 => Loc18  вер=1 порядок=8
       текст: Look for something unusual
       эффект: P1(Stick shift) = 1
  -> Path42 => Loc11  вер=1 порядок=2
       текст: Bawl out Igorych
       эффект: P6(Klim's cardiogram) +1
       эффект: P1(Stick shift) = 6
  -> Path75 => Loc20  вер=1 проходов<=1 порядок=9
       текст: Be done with your customizations once and for all!
       эффект: P1(Stick shift) = 1
       скрыт: P3

### Loc11 [пустая]
  -> Path33 => Loc10  вер=1 порядок=5

### Loc12 [обычная]
    выбор описания: {[p1]}
    Loc12-1: In this part of the menu, you found engines and car bodies for sale. The prices here really bite - like hungry pachvarashes - but it's hard to overstate the imp…
    Loc12-2: "Order received. Please wait," came the reply from the other side of the screen.
  -> Path35 => Loc10  вер=1 порядок=9
       текст: Return to the main menu
       эффект: P1(Stick shift) = 8
  -> Path44 => Loc15  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy Wosh electronics - 50,000 cr.
       условия: P3(Money) 50000..1000000
       эффект: P3(Money) = {[p3]-50000}
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +2
       эффект: P9(Acceleration) +2
       эффект: P11(Reliability) -5
  -> Path45 => Loc15  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy a set of pistons made from dominator materials - 125,000 cr.
       условия: P3(Money) 125000..1000000
       эффект: P3(Money) = {[p3]-125000}
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +8
       эффект: P8(Weight) -20
       эффект: P9(Acceleration) +8
       эффект: P11(Reliability) +4
  -> Path46 => Loc15  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy a titanium cylinder block made from quark bomb casings - 200,000 cr.
       условия: P3(Money) 200000..1000000
       эффект: P3(Money) = {[p3]-200000}
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +12
       эффект: P8(Weight) +50
       эффект: P9(Acceleration) +12
       эффект: P11(Reliability) -10
  -> Path48 => Loc15  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy an instant cylinder reboring kit - 30,000 cr.
       условия: P3(Money) 30000..1000000
       эффект: P3(Money) = {[p3]-30000}
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +2
       эффект: P8(Weight) -40
       эффект: P9(Acceleration) +2
       эффект: P11(Reliability) -10
  -> Path49 => Loc15  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy a carbon-fiber body set - 150,000 cr.
       условия: P3(Money) 150000..1000000
       эффект: P3(Money) = {[p3]-150000}
       эффект: P1(Stick shift) = 2
       эффект: P8(Weight) -120
  -> Path50 => Loc15  вер=1 проходов<=1 порядок=6
       текст: Buy spoilers for your doors, trunk, hood, side panels, and driver - 60,000 cr.
       условия: P3(Money) 60000..1000000
       эффект: P3(Money) = {[p3]-60000}
       эффект: P1(Stick shift) = 2
       эффект: P8(Weight) +40
       эффект: P11(Reliability) +5
  -> Path51 => Loc15  вер=1 проходов<=1 порядок=6
       текст: Buy the aerodynamic "Fear Bone" body kit - 20,000 cr.
       условия: P3(Money) 20000..1000000
       эффект: P3(Money) = {[p3]-20000}
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +5
       эффект: P8(Weight) +20
       эффект: P11(Reliability) -3
       эффект: P12(Terrain crossing capacity) -4

### Loc13 [обычная]
    выбор описания: {[p1]}
    Loc13-1: The second part of the menu, which you are looking at now, is dedicated to transmissions and suspensions. This is the link between car and driver, and car and r…
    Loc13-2: "Order received. Please wait," came the reply from the other side of the screen.
  -> Path37 => Loc10  вер=1 порядок=9
       текст: Return to the main menu
       эффект: P1(Stick shift) = 8
  -> Path52 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy the RAMBO clutch - 40,000 cr.
       условия: P3(Money) 40000..1000000
       эффект: P3(Money) = {[p3]-40000}
       эффект: P1(Stick shift) = 2
       эффект: P9(Acceleration) +4
       эффект: P11(Reliability) +4
  -> Path54 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy the seven-speed manual transmission - 80,000 cr.
       условия: P3(Money) 80000..1000000; P13(Tranny!) 0..0
       эффект: P3(Money) = {[p3]-80000}
       эффект: P13(Tranny!) = 1
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +6
       эффект: P9(Acceleration) +10
  -> Path55 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy the seven-speed automatic transmission - 100,000 cr.
       условия: P3(Money) 100000..1000000; P13(Tranny!) 0..0
       эффект: P3(Money) = {[p3]-100000}
       эффект: P13(Tranny!) = 1
       эффект: P1(Stick shift) = 2
       эффект: P7(Speed) +6
       эффект: P9(Acceleration) +14
       эффект: P11(Reliability) -5
  -> Path57 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy the Terron-style, elastic suspension bar - 60,000 cr.
       условия: P3(Money) 60000..1000000
       эффект: P3(Money) = {[p3]-60000}
       эффект: P1(Stick shift) = 2
       эффект: P9(Acceleration) +50
       эффект: P10(Handling) +4
       эффект: P11(Reliability) +3
  -> Path58 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy the PherMacson struts - 60,000 cr.
       условия: P3(Money) 60000..1000000
       эффект: P3(Money) = {[p3]-60000}
       эффект: P1(Stick shift) = 2
       эффект: P10(Handling) +6
       эффект: P11(Reliability) -4
       эффект: P12(Terrain crossing capacity) +2
  -> Path59 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy the hydraulic, hypersensitive chassis - 100,000 cr.
       условия: P3(Money) 100000..1000000
       эффект: P3(Money) = {[p3]-100000}
       эффект: P1(Stick shift) = 2
       эффект: P8(Weight) +30
       эффект: P10(Handling) +10
       эффект: P11(Reliability) -4
       эффект: P12(Terrain crossing capacity) +6
  -> Path60 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy maloq-made coil spring boosters - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 2
       эффект: P8(Weight) +100
       эффект: P11(Reliability) +12
       эффект: P12(Terrain crossing capacity) +4

### Loc14 [обычная]
    Loc14-1: The third part of the menu. This is all about wheels: rims and rubber. Oh, if only you could know the weather in advance...
    Loc14-2: "Order received. Please wait," came the reply from the other side of the screen.
  -> Path39 => Loc10  вер=1 порядок=9
       текст: Return to the main menu
       эффект: P1(Stick shift) = 8
  -> Path69 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy SPACE Razor alloy rims - 40,000 cr.
       условия: P3(Money) 40000..1000000; логика {[p44]=0}
       эффект: P3(Money) = {[p3]-40000}
       эффект: P7(Speed) +2
       эффект: P8(Weight) -20
       эффект: P9(Acceleration) +2
       эффект: P10(Handling) +2
       эффект: P44(Rimmed) = 1
  -> Path70 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy XL SPACE Razor alloy rims - 50,000 cr.
       условия: P3(Money) 50000..1000000; логика {[p44]=0}
       эффект: P3(Money) = {[p3]-50000}
       эффект: P7(Speed) +2
       эффект: P8(Weight) -10
       эффект: P9(Acceleration) +2
       эффект: P10(Handling) +2
       эффект: P12(Terrain crossing capacity) +2
       эффект: P44(Rimmed) = 1
  -> Path71 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Buy Dr. Maloq forged rims - 70,000 cr.
       условия: P3(Money) 70000..1000000; логика {[p44]=0}
       эффект: P3(Money) = {[p3]-70000}
       эффект: P7(Speed) +3
       эффект: P9(Acceleration) +3
       эффект: P10(Handling) +3
       эффект: P11(Reliability) -4
       эффект: P12(Terrain crossing capacity) +2
       эффект: P44(Rimmed) +1
  -> Path72 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy StownBridge racing slicks - 20,000 cr.
       условия: P3(Money) 20000..1000000; P43(Rubber) 0..0; логика {[p45]=0}
       эффект: P3(Money) = {[p3]-20000}
       эффект: P43(Rubber) = 1
       эффект: P19(Gauge) +1
       эффект: P45(Wheeled) +1
  -> Path73 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy classic medium tires - 20,000 cr.
       условия: P3(Money) 20000..1000000; P43(Rubber) 0..0; логика {[p45]=0}
       эффект: P3(Money) = {[p3]-20000}
       эффект: P43(Rubber) = 1
       эффект: P19(Gauge) +10
       эффект: P45(Wheeled) +1
  -> Path74 => Loc17  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Buy GoodDay tires - 20,000 cr.
       условия: P3(Money) 20000..1000000; P43(Rubber) 0..0; логика {[p45]=0}
       эффект: P3(Money) = {[p3]-20000}
       эффект: P43(Rubber) = 1
       эффект: P19(Gauge) +100
       эффект: P45(Wheeled) +1

### Loc15 [пустая]
  -> Path47 => Loc12  вер=1 порядок=5

### Loc16 [пустая]
  -> Path53 => Loc13  вер=1 порядок=5

### Loc17 [пустая]
  -> Path68 => Loc14  вер=1 порядок=5
       эффект: P1(Stick shift) = 2

### Loc18 [обычная]
    выбор описания: {[p1]}
    Loc18-1: In addition to the legal parts suppliers, you managed to find some not-so-legal outfits. The company PelengHack is willing to provide the following components: …
    Loc18-2: The guys from PelengHack brought the part in right away - and they didn't forget to tell you that they didn't know you and that you had never heard anything abo…
    Loc18-3: For some reason this part reminded you of how transitory existence can be... You're just flying along, minding your own business, and then somebody's selling yo…
  -> Path41 => Loc10  вер=1 порядок=9
       текст: Look for licensed parts, not just any old piece of crap!
       эффект: P1(Stick shift) = 8
  -> Path62 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order iron zoopies - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 3
       эффект: P15(Zoopies) = 1
  -> Path63 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order the special headlights - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 2
       эффект: P14(Headlights) = 1
  -> Path64 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order the oil additive - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 2
  -> Path65 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order the tinted window treatment - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 2
       эффект: P17(Reflective film) = 1
  -> Path66 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order a nanitoid - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 3
       эффект: P16(Nanitoid) = 1
  -> Path67 => Loc21  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Order a fuel tank - 80,000 cr.
       условия: P3(Money) 80000..1000000
       эффект: P3(Money) = {[p3]-80000}
       эффект: P1(Stick shift) = 3
       эффект: P18(Fuel tank) = 1

### Loc20 [обычная] визитов<=3
    выбор описания: {[p1]}
    Loc20-1: "Okay, that's enough! It's high time we started doing something else," you declared with a wise look and stood up from the computer.  / "Igorych, inspect the ca…
    Loc20-2: "This isn't a plank! It's a pit board. They were used to show the driver the time and stuff like that when two-way radios were inadequate. And right now it's ou…
    Loc20-3: You felt more confident, but it's unlikely that this will bring any real benefit.
  -> Path76 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Ask Igorych about the strange plank
       условия: P2(Conversation) 1..2
       эффект: P2(Conversation) = 3
       эффект: P1(Stick shift) = 2
  -> Path78 => Loc22  вер=1 проходов<=1 порядок=5
       текст: Spit over your shoulder three times and knock your head against the table
       эффект: P1(Stick shift) = 3
  -> Path79 => Loc23  вер=1 проходов<=1 порядок=5
       текст: Give the driver the go-ahead
       эффект: P26(Leg length) = 1500

### Loc21 [пустая]
  -> Path61 => Loc18  вер=1 порядок=5

### Loc22 [пустая] визитов<=1
  -> Path77 => Loc20  вер=1 проходов<=1 порядок=5

### Loc23 [обычная] визитов<=1
    Loc23-1: You checked the communication channel with Korchenitsa and froze in expectation. Yellow circles lit up on the scoreboard, and the drivers started their engines.…
    показ: P20,P21,P22,P23,P24,P25,P26,P27
  -> Path81 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Svyatogor, hit the gas and try to break away at the start!
       эффект: P19(Gauge) = 1
       эффект: P20(Current speed) = {[p7]*1,25}
  -> Path82 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Don't drop your speed, but be super careful on the turns! Don't start sliding!
       эффект: P19(Gauge) = 2
       эффект: P20(Current speed) = {[p7]}
  -> Path83 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Take care of the car for the finish. Absolutely no hotrodding!
       эффект: P19(Gauge) = 3
       эффект: P20(Current speed) = {[p7]*0,85}

### Loc24 [обычная] визитов<=3
    Loc24-1: "Aye, aye, sir!" sounded Svyatogor's voice in your headset as you lost direct sight of his race car. Now you'll have to switch to "instrument flight rules": the…
  -> Path84 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Wait and trust that you did everything correctly
       условия: P19(Gauge) 3..3
       эффект: P31(Breakdown) = {[p11]}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300-10}
       эффект: P21(Your time) = {[p26]/([p20]+([p9] div (2))-[p8]/300-10)}
  -> Path85 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Wait and trust that you did everything correctly
       условия: P19(Gauge) 2..2
       эффект: P31(Breakdown) = {[p11]-4}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300}
       эффект: P21(Your time) = {[p26]/([p20]+([p9] div (2))-[p8]/300)}
  -> Path86 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Wait and trust that you did everything correctly
       условия: P19(Gauge) 1..1
       эффект: P31(Breakdown) = {[p11]-8}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300+10}
       эффект: P21(Your time) = {[p26]/([p20]+([p9] div (2))-[p8]/300+10)}

### Loc25 [обычная] визитов<=3
    выбор описания: {[p19]}
    Loc25-1: Korchenitsa squeezed everything he could out of the car. There was a spot where he could have pulled into the lead, but the faeyan driver quickly blocked him in…
    Loc25-2: Svyatogor drove the race car carefully but with verve. But he trailed slightly behind the gaals, who were leading, and was forced to tussle with the peleng driv…
    Loc25-3: Following your instructions, Korchenitsa used the car's racing capabilities with extreme caution and wound up at the end of the pack. But it's not over yet!
    эффект: P22(Maloq time/offset) = {[17..19]}
    эффект: P23(Peleng time/offset) = {[16..18]}
    эффект: P24(Faeyan time/offset) = {[11..12]}
    эффект: P25(Gaalian time/offset) = {[8..9]}
    эффект: P26(Leg length) = 2700
    эффект: P27(Track type) = 1
    показ: P31
  -> Path87 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Just no suggestions to slow down in the future!
       эффект: P19(Gauge) = 1
       эффект: P20(Current speed) +23
  -> Path88 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Take it easy, man! Be more delicate!
       эффект: P19(Gauge) = 3
       эффект: P20(Current speed) +14
  -> Path89 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Stick to the track like glue!
       эффект: P19(Gauge) = 2
       эффект: P20(Current speed) +19

### Loc26 [обычная] визитов<=3
    Loc26-1: Igorych's beard was twitching nervously next to you. You were a little concerned, but completely in control of the situation. And somewhere out on the racetrack…
  -> Path90 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Shall we pray?
       условия: P19(Gauge) 2..2
       эффект: P31(Breakdown) = {[p31]-8}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300)}
  -> Path91 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Shall we pray?
       условия: P19(Gauge) 1..1
       эффект: P31(Breakdown) = {[p31]-18}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300+10}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300+10)}
  -> Path92 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Shall we pray?
       условия: P19(Gauge) 3..3
       эффект: P31(Breakdown) = {[p31]-4}
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300-10}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300-10)}

### Loc27 [обычная] визитов<=3
    Loc27-1: Following your instructions, the driver proved himself rather competent on this section. At least, everything that you told him to do, he did. This left you ple…
    эффект: P22(Maloq time/offset) = {[p22]+[18..20]}
    эффект: P23(Peleng time/offset) = {[p23]+[14..16]}
    эффект: P24(Faeyan time/offset) = {[p24]+[9..10]}
    эффект: P25(Gaalian time/offset) = {[p25]+[8..9]}
    эффект: P26(Leg length) = 1500
    эффект: P27(Track type) = 2
  -> Path93 => Loc28  вер=1 проходов<=1 порядок=5
       текст: Put the gas pedal to the floor and don't take your hand off the stick shift! We need a quick heat!
       эффект: P19(Gauge) = 1
       эффект: P20(Current speed) +10
  -> Path94 => Loc28  вер=1 проходов<=1 порядок=5
       текст: You've got to hit the brakes here if you don't want to kill your suspension... Slow down!
       эффект: P19(Gauge) = 3
       эффект: P20(Current speed) = {[p20]-30}
  -> Path95 => Loc28  вер=1 проходов<=1 порядок=5
       текст: Fall in and draft behind the leader!
       эффект: P19(Gauge) = 2

### Loc28 [обычная] визитов<=3
    Loc28-1: That's all. Korchenitsa is on his own now. Until the end of the stage, of course. It's so good that you let him know how his competition is doing on the racetra…
  -> Path96 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Wait for the heat results
       условия: P19(Gauge) 1..1
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300+10}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300+10)}
  -> Path97 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Wait for the heat results
       условия: P19(Gauge) 3..3
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300-10}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300-10)}
  -> Path98 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Wait for the heat results
       условия: P19(Gauge) 2..2
       эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300}
       эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300)}

### Loc29 [обычная] визитов<=3
    Loc29-1: Your team's second driver headed to the track and warmed up the race car before his stage began. Igorych started verifying the communication channel with him.  …
    эффект: P22(Maloq time/offset) = {[p22]+[9..10]}
    эффект: P23(Peleng time/offset) = {[p23]+[8..9]}
    эффект: P24(Faeyan time/offset) = {[p24]+[7..8]}
    эффект: P25(Gaalian time/offset) = {[p25]+[6..7]}
    эффект: P26(Leg length) = 2660
    эффект: P27(Track type) = 0
    эффект: P31(Breakdown) = {[p31]-([p20]/8)+[p12]/3}
  -> Path99 => Loc72  вер=1 проходов<=1 порядок=5
       текст: It's all or nothing, Svyatogor! Do something!
       эффект: P31(Breakdown) = {[p31]-28}
       эффект: P1(Stick shift) = 1
       эффект: P19(Gauge) = 1
  -> Path100 => Loc72  вер=1 проходов<=1 порядок=5
       текст: Careful - don't break down at the finish line!
       эффект: P31(Breakdown) = {[p31]-14}
       эффект: P1(Stick shift) = 1
       эффект: P19(Gauge) = 3
  -> Path101 => Loc72  вер=1 проходов<=1 порядок=5
       текст: Go as fast as is reasonable, but don't lose your position!
       эффект: P31(Breakdown) = {[p31]-21}
       эффект: P1(Stick shift) = 1
       эффект: P19(Gauge) = 2

### Loc30 [обычная]
    выбор описания: {[p1]}
    Loc30-1: Growling and snorting, Korchenitsa's rather thrashed race car barreled along toward the finish line. You were carefully following the scene, when Igorych jabbed…
    Loc30-2: Igorych endured your dressing-down without grumbling, but he was visibly offended.
    эффект: P21(Your time) = {[p21]+[p26]/([p20]+([p9] div (2))-[p8]/300)}
    эффект: P22(Maloq time/offset) = {[p22]+[7..8]}
    эффект: P23(Peleng time/offset) = {[p23]+[6..7]}
    эффект: P24(Faeyan time/offset) = {[p24]+[5..6]}
    эффект: P25(Gaalian time/offset) = {[p25]+[3..4]}
    эффект: P31(Breakdown) = {} [скрыт]
    скрыт: P26,P27
  -> Path102 => Loc31  вер=1 проходов<=1 порядок=5
       текст: Run to the racetrack
       эффект: P1(Stick shift) = 1
       эффект: P2(Conversation) -1
  -> Path103 => Loc31  вер=1 проходов<=1 порядок=5
       текст: Grab the pit board and run to the racetrack
       условия: P2(Conversation) 3..3
       эффект: P1(Stick shift) = 1
       эффект: P47(Board) = 1
  -> Path104 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Fly into hysterics right where you are
       эффект: P1(Stick shift) = 3
       эффект: P32(Driver skills) = 0
  -> Path105 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Run into the commentator booth
  -> Path136 => Loc46  вер=1 порядок=5
       текст: Bawl out Igorych
       эффект: P6(Klim's cardiogram) +1
       эффект: P1(Stick shift) = 2

### Loc31 [обычная] визитов<=3
    выбор описания: {[p1]}
    Loc31-1: You ran headlong toward the racetrack, expecting to think up something specific to do once you were on the track. It seemed to you that you were moving faster t…
    Loc31-2: "Listen, you miserable creep! I, the great <Ranger>, should be on the track already, and if you don't get out of my sight this instant, I'll just have to termin…
  -> Path109 => Loc39  вер=1 проходов<=1 порядок=5
       текст: Politely ask to be allowed to pass before you lose your cool
       эффект: P1(Stick shift) = 1
  -> Path110 => Loc35  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Slap the meddlesome maloq upside the head with the pit board
       условия: P2(Conversation) 3..3
       эффект: P1(Stick shift) = 2
       эффект: P33(Strike) = 1
  -> Path111 => Loc36  вер=1 проходов<=1 порядок=5
       текст: Engage the maloq in hand-to-hand combat

### Loc32 [обычная] визитов<=3
    Loc32-1: You tore out of there and dashed to a commentator booth. The stadium employees you encountered along the way looked at you curiously; team leaders don't usually…
  -> Path106 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Apologize and leave
       эффект: P1(Stick shift) = 1
       эффект: P32(Driver skills) = 0
  -> Path107 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Throw open the window and try to scream your instructions to your driver
       эффект: P1(Stick shift) = 1
  -> Path108 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Snatch the microphone from the commentators and give directions to your driver
       эффект: P1(Stick shift) = 2
       эффект: P32(Driver skills) = 1

### Loc33 [обычная] визитов<=1
    выбор описания: {[p1]}
    Loc33-1: You asked for forgiveness and left, this time carefully closing the door. The road back to the pits seemed like an eternity. When you got back to your own area,…
    Loc33-2: After a brief struggle, you gained the upper hand against the puny faeyan commentators and seized the microphone. Your voice blasted over the stadium like thund…
    Loc33-3: You couldn't think of anything better to do than run out of the pit in tears. Although, you did return and plonk your head onto your keyboard as you continued t…
    Loc33-4: You almost lost your voice in your effort to shout over the huge stadium and the hum of the engines. Your mentee probably didn't hear a word. There was nothing …
    Loc33-5: You found a piece of chalk somebody had lost, and quickly began to cover the pit board with symbols that your driver was supposed to understand. When his car st…
  -> Path122 => Loc41  вер=1 проходов<=1 порядок=5
       текст: There's nothing to do. Tally up the results of the first heat.
       эффект: P1(Stick shift) = 1
       эффект: P22(Maloq time/offset) = {[p22]+[8..10]}
       эффект: P23(Peleng time/offset) = {[p23]+[8..10]}
       эффект: P24(Faeyan time/offset) = {[p24]+[8..10]}
       эффект: P25(Gaalian time/offset) = {[p25]+[8..10]}

### Loc34 [СМЕРТЬ]
    выбор описания: {[p1]}
    Loc34-1: You threw yourself against the closest window, while simultaneously knocking over the commentators' table and tying yourself in knots in the cables. In a second…
    Loc34-2: You courageously dashed onto the track, hurting the gaals' time a bit; their driver had to change his trajectory to avoid cutting you down. The less agile maloq…

### Loc35 [обычная] визитов<=2
    выбор описания: {[p1]}
    Loc35-2: You swung Igorych's board and delivered a knockout blow. As a result, both the board and the maloq became inoperable. And though a head bandage and some smellin…
    Loc35-3: The run play worked. You grabbed the guard's pillar-like leg and threw your body to the side sharply. The maloq cried out and fell, striking his head against th…
  -> Path116 => Loc38  вер=1 проходов<=1 порядок=5
       текст: Move toward the racetrack
  -> Path117 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Run back through the pits to the commentator booth

### Loc36 [обычная] визитов<=1
    Loc36-1: You jabbed the maloq in the solar plexus once, and then again. His first counterblow sent you reeling back a couple of meters. You really put the guard in a fou…
  -> Path112 => Loc35  вер=1 проходов<=1 порядок=5
       текст: Use the pit board
       условия: P2(Conversation) 3..3; P47(Board) 1..1
       эффект: P47(Board) -1
       эффект: P1(Stick shift) = 2
       эффект: P33(Strike) = 1
  -> Path113 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Keep fighting and try out some kicks
  -> Path138 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Strike with your hands as accurately as possible
  -> Path139 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Combine several kinds of attacks

### Loc37 [обычная] визитов<=2
    Loc37-1: You didn't move any worse than Agent Smith, a character in an ancient film, but at the end of the day everyone has an inner Neo... As a result, after several of…
  -> Path114 => Loc35  вер=1 проходов<=1 порядок=5
       текст: Let him have it with the pit board
       условия: P2(Conversation) 3..3; P47(Board) 1..1
       эффект: P47(Board) -1
       эффект: P1(Stick shift) = 2
       эффект: P33(Strike) = 1
  -> Path115 => Loc35  вер=1 проходов<=1 порядок=5
       текст: Lunge at the maloq's legs and try to throw him
       эффект: P1(Stick shift) = 3

### Loc38 [обычная] визитов<=1
    Loc38-1: You fled, fitfully calculating your chances of being disqualified for your run-in with the maloq. Why can't anything ever go smoothly? Sometimes you think that …
  -> Path119 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Climb onto the fence and start screaming instructions
       эффект: P1(Stick shift) = 4
       эффект: P32(Driver skills) = 0
  -> Path120 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Quickly fill out the pit board and show it to the driver
       условия: P2(Conversation) 2..3; P33(Strike) 0..0; P47(Board) 1..1
       эффект: P1(Stick shift) = 5
       эффект: P32(Driver skills) = 1
  -> Path121 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Climb over the fence and run out onto the track
       эффект: P1(Stick shift) = 2

### Loc39 [пустая] визитов<=1
  -> Path118 => Loc31  вер=1 проходов<=1 порядок=5
       эффект: P1(Stick shift) = 2

### Loc41 [обычная] визитов<=8
    выбор описания: {[p1]}
    Loc41-1: Korchenitsa explained to you in detail what he had to endure on the racetrack, and Igorych showed you a report of the finish times for all of the teams. / Hones…
    Loc41-2: "I would be happy to, but the rules won't allow it! They'd just disqualify us!" said Korchenitsa, who had sunk into despair.  / "It's too bad he can't; he's a g…
    Loc41-3: "Heh, you're joking...I haven't raced for about twenty years...and my heart gives me trouble sometimes... Sorry, but that won't work," said the mechanic. It was…
    Loc41-4: Korchenitsa and Igorych looked at you in expectation.  / "Can you pull it off? The speeds out there - there's hardly enough time to react!" said Svyatogor. / "W…
    эффект: P21(Your time) = {[p21]*2+(1-[p32])*9+5} [скрыт]
    эффект: P22(Maloq time/offset) = {[p22]*2} [скрыт]
    эффект: P23(Peleng time/offset) = {[p23]*2} [скрыт]
    эффект: P24(Faeyan time/offset) = {[p24]*2} [скрыт]
    эффект: P25(Gaalian time/offset) = {[p25]*2} [скрыт]
    скрыт: P20
  -> Path123 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Svyatogor, you'll have to go again!
       условия: P1(Stick shift) 1..3
       эффект: P1(Stick shift) = 2
  -> Path125 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Well, Igorych, do you remember your youth?!
       условия: P1(Stick shift) 1..3
       эффект: P1(Stick shift) = 3
  -> Path126 => Loc42  вер=1 проходов<=1 порядок=5
       текст: If you want something done right, you've got to do it yourself! I'll drive!
       эффект: P1(Stick shift) = 4
  -> Path127 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Roll the car up to the starting line
       условия: P1(Stick shift) 4..4; логика {[p21]<=[p24] and [p21]>=[p25]}
       эффект: P39(Starting number) = 2
  -> Path130 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Roll the car up to the starting line
       условия: P1(Stick shift) 4..4; логика {[p21]<=[p25]}
       эффект: P39(Starting number) = 1
  -> Path131 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Roll the car up to the starting line
       условия: P1(Stick shift) 4..4; логика {[p21]>=[p23] and [p21]<=[p22]}
       эффект: P39(Starting number) = 4
  -> Path132 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Roll the car up to the starting line
       условия: P1(Stick shift) 4..4; логика {[p21]>=[p24] and [p21]<=[p23]}
       эффект: P39(Starting number) = 3
  -> Path133 => Loc43  вер=1 проходов<=1 порядок=5
       текст: Roll the car up to the starting line
       условия: P1(Stick shift) 4..4; логика {[p21]>=[p22]}
       эффект: P39(Starting number) = 5

### Loc42 [пустая]
  -> Path124 => Loc41  вер=1 порядок=5

### Loc43 [обычная] визитов<=4
    Loc43-1: You took a seat behind the wheel. For the first time in your life. The unfamiliar three-spoked wheel, which was lined with gobzaurus leather, proved to be no be…
    эффект: P5(Row) = 1
    эффект: P13(Tranny!) = 1
    эффект: P29(Durability) = 100 [показ]
    эффект: P34(Distance to finish line) = 8500
    показ: P14,P15,P16,P17,P18
  -> Path128 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Wait for the start
       условия: P32(Driver skills) 0..0; P39(Starting number) 2..5; логика {[p38]<=2000}
       эффект: P1(Stick shift) = 2
  -> Path129 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Wait for the start
       условия: P32(Driver skills) 1..1; P39(Starting number) 2..5; логика {[p38]<=2000}
       эффект: P1(Stick shift) = 1
  -> Path134 => Loc56  вер=1 проходов<=1 порядок=5
       текст: Wait for the start
       условия: P39(Starting number) 1..1; логика {[p38]<=2000}
       эффект: P1(Stick shift) = 3
  -> Path135 => Loc45  вер=100 порядок=5
       текст: Wait for the start
       условия: логика {[p38]>2500}

### Loc44 [обычная]
    выбор описания: {[p1]}
    Loc44-1: After overtaking another car, you felt simply marvelous! But you can't relax yet - the gaals are still ahead!
    Loc44-2: You were strained to the limit; the highly-responsive car wouldn't let you unwind, and the sports-car suspension transferred all of the bumpiness of the road di…
    Loc44-3: You released the previously-placed nanitoid from the glove compartment, and the tiny robot began whizzing busily about the cabin. After a while, with blinking l…
    Loc44-4: You were strained to the limit; the highly-responsive car wouldn't let you unwind, and the sports-car suspension transferred all of the bumpiness of the road di…
    Loc44-5: You can't see anything but road in front of you. That means your competitors are all behind you! Now if you can just avoid making any mistakes, everything will …
    Loc44-6: You can't see anything but road in front of you. That means your competitors are all behind you! Now if you can just avoid making any mistakes, everything will …
    Loc44-7: Now, with Loho-Eb behind you, you just need to carefully make it to the finish line... You're almost there... You tried to calm yourself, but that didn't work w…
    Loc44-8: Suddenly, your car veered to the side and you almost lost control. Maybe this was a sign of inexperience, or maybe it was just a technical defect... Who would h…
    Loc44-9: Now fuel is no longer being delivered from the main tank - the backup tank is in operation! No need to worry about an explosion. / You were strained to the limi…
    эффект: P46(Critical lag) = {1000+[p34]-[p38]}
  -> Path140 => Loc47  вер=1 порядок=5
       текст: Squeeze everything you can out of the car!
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 2..5
       эффект: P29(Durability) -3
       эффект: P34(Distance to finish line) = {[p34]-300}
       эффект: P1(Stick shift) = 4
       эффект: P20(Current speed) = {[p20]+[p9]/5}
       эффект: P35(Difference from the maloqs) = {[p35]-[p20]/2+25}
       эффект: P36(Difference from the pelengs) = {[p36]-[p20]/2+50}
       эффект: P37(Difference from the faes) = {[p37]-[p20]/2+60}
       эффект: P38(Difference from the gaals) = {[p38]-[p20]/2+75}
  -> Path142 => Loc48  вер=1 порядок=5
       текст: Give it your all to hold your ground among the leaders!
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 1..1
       эффект: P29(Durability) -5
       эффект: P34(Distance to finish line) = {[p34]-500}
       эффект: P20(Current speed) = {[p20]+[p9]/3}
  -> Path144 => Loc49  вер=100 проходов<=1 порядок=5
       текст: Mix it up with the maloq driver
       условия: P34(Distance to finish line) 1..8500; P35(Difference from the maloqs) 0..0; P39(Starting number) 5..5
       эффект: P1(Stick shift) = 1
  -> Path153 => Loc51  вер=100 проходов<=1 порядок=5
       текст: Battle with the peleng
       условия: P34(Distance to finish line) 1..8500; P36(Difference from the pelengs) 0..0; P39(Starting number) 4..4
       эффект: P1(Stick shift) = 1
  -> Path172 => Loc57  вер=1 проходов<=1 порядок=5
       текст: Activate the nanitoid
       условия: P16(Nanitoid) 1..1; P34(Distance to finish line) 1..8500
       эффект: P16(Nanitoid) = 0
       эффект: P29(Durability) +15
       эффект: P34(Distance to finish line) -50
       эффект: P1(Stick shift) = 3
  -> Path175 => Loc57  вер=1 проходов<=1 порядок=5
       текст: Activate the spare fuel tank
       условия: P18(Fuel tank) 1..1; P33(Strike) 1..1; P34(Distance to finish line) 1..8500
       эффект: P18(Fuel tank) = 0
       эффект: P33(Strike) = 0
       эффект: P34(Distance to finish line) = {[p34]-50}
       эффект: P1(Stick shift) = 9
  -> Path176 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Try to deal with the fae
       условия: P34(Distance to finish line) 1..8500; P37(Difference from the faes) 0..0; P39(Starting number) 3..3
       эффект: P1(Stick shift) = 1
  -> Path178 => Loc55  вер=1 проходов<=1 порядок=5
       текст: Fight for first place
       условия: P34(Distance to finish line) 1..8500; P38(Difference from the gaals) 0..0; P39(Starting number) 2..2
       эффект: P1(Stick shift) = 1
  -> Path180 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0; P39(Starting number) 2..5
  -> Path181 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0; P39(Starting number) 1..1

### Loc45 [ПРОВАЛ]
    Loc45-1: In your headset you could hear the spiritless, heavy voice of Igorych: / "They've removed us from the competition! We're too far behind; no point in fighting it…

### Loc46 [пустая]
  -> Path137 => Loc30  вер=1 порядок=5

### Loc47 [пустая]
    скрыт: P39
  -> Path141 => Loc44  вер=1 порядок=5
       условия: P5(Row) 0..0; P33(Strike) 0..0
       эффект: P1(Stick shift) = 4
  -> Path167 => Loc44  вер=1 проходов<=1 порядок=5
       условия: P5(Row) 1..1; логика {[p35]>0}
       эффект: P5(Row) = 0
       эффект: P1(Stick shift) = 8
       эффект: P39(Starting number) = 5
       показ: P35,P36,P37,P38
  -> Path168 => Loc44  вер=1 проходов<=1 порядок=5
       условия: P5(Row) 1..1; логика {[p35]=0 and [p36]>0}
       эффект: P5(Row) = 0
       эффект: P1(Stick shift) = 8
       эффект: P39(Starting number) = 4
       показ: P35,P36,P37,P38
  -> Path169 => Loc44  вер=1 проходов<=1 порядок=5
       условия: P5(Row) 1..1; логика {[p36]=0 and [p37]>0}
       эффект: P5(Row) = 0
       эффект: P1(Stick shift) = 8
       эффект: P39(Starting number) = 3
       показ: P35,P36,P37,P38
  -> Path170 => Loc44  вер=1 проходов<=1 порядок=5
       условия: P5(Row) 1..1; логика {[p37]=0 and [p38]>0}
       эффект: P5(Row) = 0
       эффект: P1(Stick shift) = 8
       эффект: P39(Starting number) = 2
       показ: P35,P36,P37,P38
  -> Path171 => Loc44  вер=1 проходов<=1 порядок=5
       условия: P5(Row) 1..1; логика {[p38]=0}
       эффект: P5(Row) = 0
       эффект: P1(Stick shift) = 8
       эффект: P39(Starting number) = 1
       показ: P35,P36,P37,P38
  -> Path174 => Loc44  вер=1 порядок=5
       условия: P5(Row) 0..0; P33(Strike) 1..1
       эффект: P1(Stick shift) = 2

### Loc48 [пустая]
  -> Path143 => Loc44  вер=1 порядок=5
       условия: P33(Strike) 0..0
       эффект: P1(Stick shift) = 5
  -> Path151 => Loc44  вер=1 порядок=5
       условия: P33(Strike) 1..1
       эффект: P1(Stick shift) = 6

### Loc49 [обычная]
    выбор описания: {[p1]}
    Loc49-1: You caught up with the maloq BMUU. Permanently tinted windows, huge rims, intimidating bumpers... How are you supposed to get around this mountain of metal?
    Loc49-2: You managed to outsmart the maloq driver; you plunged into the turn with terrific speed and perfect trajectory, while your opponent's clumsy car lagged behind b…
    Loc49-3: The maloq deftly blocked your path, and you involuntarily stopped your maneuver. Failure... But all is not lost - you got to keep fighting!
    Loc49-4: You opened the small box of metallic bugs and set them free. The tiny insects, which were slathered in motor oil, swiftly wriggled their way under the hood. In …
    Loc49-5: You flicked the lever to turn on your headlights. They unexpectedly shot out a focused beam of blinding light and then went dead and refused to turn on. Unfortu…
    Loc49-6: You caught up to the maloq and slammed into his trunk. Your stunt didn't have the desired effect; you hardly nudged your opponent from his course. / You'll have…
  -> Path145 => Loc50  вер=1 порядок=5
       текст: Use your speed and maneuverability to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 5..5
       эффект: P29(Durability) -1
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P39(Starting number) = 4
       эффект: P1(Stick shift) = 2
       эффект: P33(Strike) = 1
  -> Path146 => Loc50  вер=1 порядок=5
       текст: Use your speed and maneuverability to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 5..5
       эффект: P29(Durability) -1
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P1(Stick shift) = 3
  -> Path147 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Keep racing
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P1(Stick shift) = 4
       скрыт: P35
  -> Path149 => Loc50  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Flash your super headlights
       условия: P14(Headlights) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 5..5
       эффект: P14(Headlights) = 0
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P1(Stick shift) = 5
  -> Path150 => Loc50  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Activate the iron zoopies - and then, battering ram!
       условия: P15(Zoopies) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 5..5
       эффект: P29(Durability) -5
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P39(Starting number) = 4
       эффект: P1(Stick shift) = 4
       эффект: P14(Headlights) = 0
  -> Path152 => Loc50  вер=1 порядок=5
       текст: Try to knock your opponent off the track
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 5..5
       эффект: P29(Durability) -8
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P1(Stick shift) = 6
  -> Path189 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0

### Loc50 [пустая]
  -> Path148 => Loc49  вер=1 порядок=5

### Loc51 [обычная]
    выбор описания: {[p1]}
    Loc51-1: You caught up to the dirty-green peleng race car. Time to show these sly dogs who's king of the road!
    Loc51-2: Your maneuver failed with a crunch. The peleng controlled the road masterfully and wouldn't let you pass. It would be premature to lose hope, but you'd better t…
    Loc51-3: You had nearly passed the peleng when he suddenly flashed his headlights... He simply flashed his miserable high-power headlights, which momentarily blinded you…
    Loc51-4: You passed the peleng in a slick maneuver, but he unexpectedly turned on some sort of illegal, blinding headlights. If it weren't for your special reflective wi…
    Loc51-5: You flicked the lever to turn on your headlights. They unexpectedly shot out a focused beam of blinding light and then went dead and refused to turn on. The win…
    Loc51-6: You caught up to the peleng and slammed into his trunk. You managed to knock the wretch off the track, both moving you ahead in the race and giving you a huge f…
    Loc51-7: You caught up to the peleng and slammed into his trunk. Your stunt didn't have the desired effect; you hardly nudged your opponent from his course. / You'll hav…
    Loc51-8: You opened the small box of metallic bugs and set them free. The tiny insects, which were slathered in motor oil, swiftly wriggled their way under the hood. In …
  -> Path155 => Loc52  вер=2 порядок=5
       текст: Use your speed and maneuverability to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P29(Durability) -1
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P1(Stick shift) = 2
  -> Path156 => Loc53  вер=1 порядок=5
       текст: Use your speed and maneuverability to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P29(Durability) -2
       эффект: P34(Distance to finish line) = {[p34]-250}
  -> Path157 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Keep racing
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P1(Stick shift) = 4
       скрыт: P36
  -> Path158 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Flash your super headlights
       условия: P14(Headlights) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P14(Headlights) = 0
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P39(Starting number) = 3
       эффект: P1(Stick shift) = 5
  -> Path161 => Loc52  вер=1 порядок=5
       текст: Try to knock the peleng off course
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P29(Durability) -5
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P39(Starting number) = 3
       эффект: P1(Stick shift) = 6
  -> Path162 => Loc52  вер=2 порядок=5
       текст: Try to knock the peleng off course
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P29(Durability) -5
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P1(Stick shift) = 7
  -> Path163 => Loc52  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Apply the iron zoopies
       условия: P15(Zoopies) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 4..4
       эффект: P15(Zoopies) = 0
       эффект: P34(Distance to finish line) = {[p34]-250}
       эффект: P39(Starting number) = 3
       эффект: P1(Stick shift) = 8
  -> Path187 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0

### Loc52 [пустая]
  -> Path154 => Loc51  вер=1 порядок=5

### Loc53 [пустая]
  -> Path159 => Loc51  вер=1 порядок=5
       условия: P17(Reflective film) 0..0
       эффект: P1(Stick shift) = 3
  -> Path160 => Loc51  вер=1 порядок=5
       условия: P17(Reflective film) 1..1
       эффект: P1(Stick shift) = 4
       эффект: P39(Starting number) = 3

### Loc54 [обычная]
    выбор описания: {[p1]}
    Loc54-1: You closed in on the faeyan race car. It hardly lost any speed on the turns; the driver moved with the utmost precision. It would be anything but simple to put …
    Loc54-2: By some miracle, you slipped past the Fae-rarri during the next turn. You were just as astonished as the faeyan driver; after all, your car is less maneuverable…
    Loc54-3: You couldn't get around the fae. He controlled the situation flawlessly, giving you no space whatsoever for a maneuver. But the struggle must go on.
    Loc54-4: You flicked the lever to turn on your headlights. They unexpectedly shot out a focused beam of blinding light and then went dead and refused to turn on. Unfortu…
    Loc54-5: You opened the small box of metallic bugs and set them free. The tiny insects, which were slathered in motor oil, swiftly wriggled their way under the hood. In …
    Loc54-6: No matter what you did, you couldn't get the right angle of attack; the fae simply outmaneuvered you. On the first turn he gained several meters on you, which w…
  -> Path177 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Keep racing
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 2..2
       эффект: P1(Stick shift) = 1
       скрыт: P37
  -> Path182 => Loc60  вер=1 порядок=5
       текст: Use your personal skill and the word of God to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P29(Durability) -2
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P39(Starting number) = 2
       эффект: P1(Stick shift) = 2
  -> Path184 => Loc60  вер=5 порядок=5
       текст: Use your personal skill and the word of God to pass
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P29(Durability) -3
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P1(Stick shift) = 3
  -> Path185 => Loc60  вер=1 проходов<=1 порядок=5
       текст: Engage the battering ram
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P29(Durability) -3
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P1(Stick shift) = 6
  -> Path186 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0
  -> Path190 => Loc60  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Activate the iron zoopies and attack
       условия: P15(Zoopies) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P15(Zoopies) = 0
       эффект: P29(Durability) -5
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P39(Starting number) = 2
       эффект: P1(Stick shift) = 5
  -> Path191 => Loc60  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Turn on the super headlights
       условия: P14(Headlights) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 3..3
       эффект: P14(Headlights) = 0
       эффект: P1(Stick shift) = 4

### Loc55 [обычная]
    выбор описания: {[p1]}
    Loc55-1: You finally reached your last opponent - the gaalian motorsports star, <clr>Baastian Boo-el<clrEnd>. The best driver in the galaxy today, except perhaps for Mic…
    Loc55-3: You failed to skirt around Boo-el. His technique is vastly superior to yours, and the chances of a maneuver like that working are slim. But that doesn't at all …
    Loc55-4: You attacked awkwardly, but, like a mass of stone, your loaded, tank-like racer descended upon Baastian's car. The blow hit the right rear side panel and seriou…
    Loc55-5: No matter what you did, you couldn't get the right angle of attack - the gaal kept changing his course, yet he still remembered to take the turns beautifully an…
    Loc55-6: You flicked the lever to turn on your headlights. They unexpectedly shot out a focused beam of blinding light and then went dead and refused to turn on. Unfortu…
  -> Path179 => Loc44  вер=1 проходов<=1 порядок=5
       текст: Keep racing
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 1..1
       эффект: P1(Stick shift) = 7
       скрыт: P38
       показ: P40
  -> Path188 => Loc58  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0
  -> Path193 => Loc59  вер=1 проходов<=1 порядок=5
       текст: Finish
       условия: P34(Distance to finish line) 0..0; P39(Starting number) 1..1
  -> Path195 => Loc61  вер=10 порядок=5
       текст: Focus and try to get ahead of the gaal
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 2..2
       эффект: P29(Durability) -2
       эффект: P34(Distance to finish line) = {[p34]-150}
       эффект: P1(Stick shift) = 3
  -> Path196 => Loc61  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Activate the zoopies and use brute force
       условия: P15(Zoopies) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 2..2
       эффект: P15(Zoopies) = 0
       эффект: P34(Distance to finish line) = {[p34]-150}
       эффект: P39(Starting number) = 1
       эффект: P1(Stick shift) = 4
  -> Path197 => Loc61  вер=1 проходов<=1 порядок=5
       текст: Ram into the gaal
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 2..2
       эффект: P29(Durability) -7
       эффект: P34(Distance to finish line) = {[p34]-150}
       эффект: P1(Stick shift) = 5
  -> Path198 => Loc61  вер=1 проходов<=1 порядок=5
       текст: Apply the super headlights
       условия: P14(Headlights) 1..1; P34(Distance to finish line) 1..8500; P39(Starting number) 2..2
       эффект: P14(Headlights) = 0
       эффект: P29(Durability) -1
       эффект: P34(Distance to finish line) = {[p34]-100}
       эффект: P1(Stick shift) = 6

### Loc56 [обычная] визитов<=2
    выбор описания: {[p1]}
    Loc56-1: You heard Igorych's happy voice in your headset, / "He made it! He's driving like Korchenitsa! Sure, there were a few hiccups along the way, but still! Your sta…
    Loc56-2: At first, Igorych's voice sounded unfamiliar over the headset, and then it simply sounded haggard. / "That guy of ours... His driving wasn't so hot; he really s…
    Loc56-3: Igorych's voice forced its way into your brain, and you were sorry the headset volume wasn't adjustable. / "You're starting first. Do you hear me? Our guys gave…
    эффект: P20(Current speed) = {[p7]*3/2} [показ]
    эффект: P35(Difference from the maloqs) = {([p21]-[p22])*10}
    эффект: P36(Difference from the pelengs) = {([p21]-[p23])*10}
    эффект: P37(Difference from the faes) = {([p21]-[p24])*10}
    эффект: P38(Difference from the gaals) = {([p21]-[p25])*10}
    показ: P34
  -> Path164 => Loc47  вер=1 проходов<=1 порядок=5
       текст: Squeeze everything you can out of the car!
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 2..5
       эффект: P34(Distance to finish line) = {[p34]-400}
       эффект: P1(Stick shift) = 5
       эффект: P35(Difference from the maloqs) = {[p35]+300}
       эффект: P36(Difference from the pelengs) = {[p36]+400}
       эффект: P37(Difference from the faes) = {[p37]+600}
       эффект: P38(Difference from the gaals) = {[p38]+1000}
  -> Path165 => Loc48  вер=1 проходов<=1 порядок=5
       текст: Give it your all to hold your ground among the leaders!
       условия: P34(Distance to finish line) 1..8500; P39(Starting number) 1..1
       эффект: P29(Durability) -2
       эффект: P34(Distance to finish line) = {[p34]-300}
       эффект: P39(Starting number) = 5
       эффект: P35(Difference from the maloqs) = {[p35]+300}
       эффект: P36(Difference from the pelengs) = {[p36]+400}
       эффект: P37(Difference from the faes) = {[p37]+600}
       эффект: P38(Difference from the gaals) = {[p38]+1000}

### Loc57 [пустая]
  -> Path173 => Loc44  вер=1 порядок=5

### Loc58 [ПРОВАЛ]
    Loc58-1: You became one with the seat - and the entire car. You felt every cycle of the pistons in the engine, and it seemed to you that you could see the overheated tir…

### Loc59 [обычная] визитов<=2
    Loc59-1: You became one with the seat - and the entire car. You felt every cycle of the pistons in the engine, and it seemed to you that you could see the overheated tir…
    скрыт: P4,P5,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P20,P29,P34,P38,P40
  -> Path199 => Loc62  вер=1 проходов<=1 порядок=5
       текст: No
  -> Path200 => Loc63  вер=1 проходов<=1 порядок=3
       текст: Yes!

### Loc60 [пустая]
    эффект: P38(Difference from the gaals) = {[p38]-[10..15]}
  -> Path183 => Loc54  вер=1 порядок=5

### Loc61 [пустая]
  -> Path192 => Loc55  вер=1 порядок=5

### Loc62 [УСПЕХ] визитов<=1
    Loc62-1: You turned away from Korchenitsa and headed toward the exit. You, a great ranger, shouldn't have to worry about the fate of some lowlife mechanic. The driver cu…

### Loc63 [обычная] визитов<=1
    Loc63-1: Svyatogor dropped Klim (you almost thought "Klim's body") and ran toward the pits. You could barely keep up; your limbs weren't responding very well - evidence …
  -> Path201 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Drive to the hospital
       эффект: P28(Time remaining before heart attack) -5 [показ]
       скрыт: P4,P5,P7,P8,P9,P10,P11,P12,P14,P15,P16,P17,P18,P20,P34

### Loc64 [обычная] визитов<=1
    Loc64-1: You flattened the pedal to the floor, and the car responded with steady, but not especially sharp, acceleration. It seemed to you that it was somehow being arti…
  -> Path202 => Loc65  вер=1 проходов<=1 порядок=5
       текст: Slam on the brakes!
       эффект: P1(Stick shift) = 2
       эффект: P28(Time remaining before heart attack) -8
  -> Path203 => Loc65  вер=1 проходов<=1 порядок=5
       текст: Jerk the wheel sharply to the left, and then right.
       эффект: P1(Stick shift) = 1
       эффект: P28(Time remaining before heart attack) -6
  -> Path204 => Loc65  вер=1 проходов<=1 порядок=5
       текст: Jerk the wheel sharply to the right, and then left.
       эффект: P1(Stick shift) = 3
       эффект: P28(Time remaining before heart attack) -4

### Loc65 [обычная] визитов<=3
    выбор описания: {[p1]}
    Loc65-1: You pulled the fastest maneuver of your life, which would have been quick enough to frighten even the toughest pirate. The Lambo Genie flew into the opposite la…
    Loc65-2: The braking system on this car is above all commendations; you even managed to avoid touching the old lady with the hood, though all the conditions were right f…
    Loc65-3: You pulled the fastest maneuver of your life, which would have been quick enough to frighten even the toughest pirate. Happily, there was nobody on the sidewalk…
  -> Path206 => Loc67  вер=1 проходов<=1 порядок=5
       текст: Hit the jeep in the front
       эффект: P1(Stick shift) = 1
       эффект: P28(Time remaining before heart attack) -14
  -> Path207 => Loc67  вер=1 проходов<=1 порядок=5
       текст: Hit the jeep in the middle
       эффект: P1(Stick shift) = 2
       эффект: P28(Time remaining before heart attack) -10
  -> Path208 => Loc67  вер=1 проходов<=1 порядок=5
       текст: Hit the jeep in the back
       эффект: P1(Stick shift) = 3
       эффект: P28(Time remaining before heart attack) -4

### Loc66 [УСПЕХ]
    Loc66-1: With Korchenitsa's help, you brought Igorych to a doctor, but it was too late - neither a heart massage, or a defibrillator could help... / You had already arri…

### Loc67 [обычная] визитов<=7
    выбор описания: {[p1]}
    Loc67-1: You careened into the very front of the jeep, severely damaging your bumper. You hardly moved the metallic gobzaurus at all. You had to back up and navigate aro…
    Loc67-2: You careened into the middle of the jeep, severely damaging your bumper. You hardly moved the metallic gobzaurus at all. You had to back up and navigate around …
    Loc67-3: You hit the lightest, rearmost part of the jeep, such that your Lambo just clipped the road titan's back axle, leaving it spinning like a top in the ill-fated i…
    Loc67-4: Korchenitsa quickly cut the cable with a pen knife and again looked at you questioningly.
    Loc67-5: "No more cables," Svyatogor announced. "Now let's see what she can do!"
  -> Path209 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Tell Korchenitsa to cut the white cable
       эффект: P41(Product line) = {[p41]+1*[p42]}
  -> Path211 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Tell Korchenitsa to cut the red cable
       эффект: P41(Product line) = {[p41]+2*[p42]}
  -> Path212 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Keep going
       условия: логика {[p41]>9999 and [p41]<>52134}
       эффект: P1(Stick shift) = 1
       эффект: P28(Time remaining before heart attack) -20
  -> Path213 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Tell Korchenitsa to cut the blue cable
       эффект: P41(Product line) = {[p41]+3*[p42]}
  -> Path214 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Tell Korchenitsa to cut the green cable
       эффект: P41(Product line) = {[p41]+4*[p42]}
  -> Path215 => Loc70  вер=1 проходов<=1 порядок=5
       текст: Tell Korchenitsa to cut the black cable
       эффект: P41(Product line) = {[p41]+5*[p42]}
  -> Path216 => Loc69  вер=1 проходов<=1 порядок=5
       текст: Keep going
       условия: логика {[p41]>9999 and [p41]=52134}
       эффект: P1(Stick shift) = 2
       эффект: P28(Time remaining before heart attack) -9

### Loc68 [обычная] визитов<=1
    Loc68-1: You caught a glimpse of the mechanic. His appearance didn't bode well. Then you pointed the car toward the hospital and, after thanking the heavens that there w…
  -> Path218 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Stop the car and carry Igorych by hand
  -> Path219 => Loc71  вер=1 проходов<=1 порядок=5
       текст: Drive to the freight elevator
       эффект: P28(Time remaining before heart attack) -6

### Loc69 [обычная] визитов<=2
    выбор описания: {[p1]}
    Loc69-1: The last cable was cut, and there was a boost in power that you had never felt before. Svyatogor gloomily remarked that you had probably chosen the wrong order.…
    Loc69-2: As soon as the black cable was cut, the car seemed to get its second wind. The powerful acceleration pressed you into your seat, and you even wondered if this b…
  -> Path205 => Loc66  вер=1 проходов<=1 порядок=5
       текст: Stop the car and carry Igorych by hand
  -> Path217 => Loc68  вер=1 проходов<=1 порядок=5
       текст: Drive the car into the hospital building
       эффект: P28(Time remaining before heart attack) -5

### Loc70 [пустая] визитов<=6
  -> Path210 => Loc67  вер=1 проходов<=5 порядок=5
       условия: P41(Product line) 0..9999
       эффект: P1(Stick shift) = 4
       эффект: P42(Cross-section number) = {[p42]*10}
  -> Path220 => Loc67  вер=1 проходов<=1 порядок=5
       условия: P41(Product line) 10000..99999
       эффект: P1(Stick shift) = 5

### Loc71 [УСПЕХ] визитов<=1
    Loc71-1: You honked and raced down the corridors of the hospital. Svyatogor completely lost control of himself and tried to grab the wheel from you, but you elbowed him …
    эффект: P30(Finances) = {[p30]+2000}

### Loc72 [пустая] визитов<=1
    эффект: P20(Current speed) = {[p20]+([p9] div (2))-[p8]/300+5*[p19]}
  -> Path221 => Loc30  вер=1 проходов<=1 порядок=5

## Анализ
- стартовых: [1]
- концовки: {5: 'ПРОВАЛ', 34: 'СМЕРТЬ', 45: 'ПРОВАЛ', 58: 'ПРОВАЛ', 62: 'УСПЕХ', 66: 'УСПЕХ', 71: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
