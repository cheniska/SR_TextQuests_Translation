# Квест (формат 1111111126)
Сложность 30; стартовая локация: [13]; путей по умолчанию: 1

## Параметры
- P1 'Total' [0..500] тип=обычный
    старт: [0]
    [0..500] <fix>Number of electors (thou.):</fix>
    критическое: Сообщение достижения критического значения параметром 12
- P2 'Number of the Gaals' [0..100] тип=обычный
    старт: [15..25]
    [0..100] <fix><format=left,9>Gaals:</format><format=left,3><></format></fix>
    критическое: Сообщение достижения критического значения параметром 1
- P3 'Number of the Faes' [0..100] тип=обычный
    старт: [15..25]
    [0..100] <fix><format=left,9>Faes:</format><format=left,3><></format></fix>
    критическое: Сообщение достижения критического значения параметром 2
- P4 'Number of the Humans' [0..100] тип=обычный
    старт: [15..25]
    [0..100] <fix><format=left,9>Humans:</format><format=left,3><></format></fix>
    критическое: Сообщение достижения критического значения параметром 3
- P5 'Number of the Pelengs' [0..100] тип=обычный
    старт: [15..25]
    [0..100] <fix><format=left,9>Pelengs:</format><format=left,3><></format></fix>
    критическое: Сообщение достижения критического значения параметром 4
- P6 'Number of the Maloqs' [0..100] тип=обычный
    старт: [15..25]
    [0..100] <fix><format=left,9>Maloqs:</format><format=left,3><></format></fix>
    критическое: Сообщение достижения критического значения параметром 5
- P7 'Round' [0..7] тип=обычный
    старт: [1]
    [0..7] <fix>You are supported by</fix>
    критическое: Сообщение достижения критического значения параметром 11
- P8 'Gaals' [0..100] тип=обычный
    старт: [30..50]
    [0..100] <fix><format=left,9>Gaals:</format><format=left,4><>%</format></fix>
    критическое: Сообщение достижения критического значения параметром 6
- P9 'Faes' [0..100] тип=обычный
    старт: [30..50]
    [0..100] <fix><format=left,9>Faes:</format><format=left,4><>%</format></fix>
    критическое: Сообщение достижения критического значения параметром 7
- P10 'Humans' [0..100] тип=обычный
    старт: [20..40]
    [0..100] <fix><format=left,9>Humans:</format><format=left,4><>%</format></fix>
    критическое: Сообщение достижения критического значения параметром 8
- P11 'Pelengs' [0..100] тип=обычный
    старт: [40..60]
    [0..100] <fix><format=left,9>Pelengs:</format><format=left,4><>%</format></fix>
    критическое: Сообщение достижения критического значения параметром 9
- P12 'Maloqs' [0..100] тип=обычный
    старт: [20..50]
    [0..100] <fix><format=left,9>The Maloqs:</format><format=left,4><>%</format></fix>
    критическое: Сообщение достижения критического значения параметром 10
- P13 'Us' [0..500] тип=обычный
    старт: [0]
    [0..500] 
    критическое: Сообщение достижения критического значения параметром 13
- P14 'x (log)' [0..100] тип=обычный
    старт: [0]
    [0..100] Log <>
    критическое: Сообщение достижения критического значения параметром 15
- P15 'x1 (et)' [0..100] тип=обычный
    старт: [0]
    [0..100] Et <>
    критическое: Сообщение достижения критического значения параметром 16
- P16 'x2 (pop)' [0..100] тип=обычный
    старт: [0]
    [0..100] Pop <>
    критическое: Сообщение достижения критического значения параметром 17
- P17 'x3 (pat)' [0..100] тип=обычный
    старт: [0]
    [0..100] Pat <>
    критическое: Сообщение достижения критического значения параметром 18
- P18 'x4 (cin)' [0..100] тип=обычный
    старт: [0]
    [0..100] Cin <>
    критическое: Сообщение достижения критического значения параметром 19
- P19 'x5 (cons)' [0..100] тип=обычный
    старт: [0]
    [0..100] Cons <>
    критическое: Сообщение достижения критического значения параметром 20
- P20 'y1' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 14
- P21 'y2' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 21
- P22 'y3' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 22
- P23 'y4' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 23
- P24 'y5 (Chp)' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Length' [0..10] тип=обычный
    старт: [7]
    [0..10] Votes are being counted
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Time' [0..30] тип=обычный
    старт: [0]
    [0..30] 
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Question' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 27

## Локации и переходы

### Loc1 [обычная]
    Loc1-1: In accordance with the latest sociological polls we will get approximately: /  / <fix> / <format=left,2>{([p2]*[p8]) / 100}</format> <format=left,2>from</format…
    эффект: P1(Total) = {[p2]+[p3]+[p4]+[p5]+[p6]}
  -> Path2 => Loc2  вер=1 порядок=5
       текст: Go to the electoral committee and see how the vote count is done
       условия: логика {[p7]>=[p25]}
       эффект: P1(Total) = 0
       эффект: P7(Round) = 1
       эффект: P13(Us) = 0
       эффект: P14(x (log)) = 0
       эффект: P15(x1 (et)) = 0
       эффект: P16(x2 (pop)) = 0
       эффект: P17(x3 (pat)) = 0
       эффект: P18(x4 (cin)) = 0
       эффект: P19(x5 (cons)) = 0
       эффект: P20(y1) = 0
       эффект: P21(y2) = 0
       эффект: P22(y3) = 0
       эффект: P23(y4) = 0
       эффект: P24(y5 (Chp)) = 0
       эффект: P26(Time) = 0
  -> Path21 => Loc12  вер=1 порядок=5
       текст: Further
       условия: P14(x (log)) ∈[0]; логика {[p7]<[p25]}
  -> Path365 => Loc27  вер=1 порядок=5
       текст: Further
       условия: P14(x (log)) ∈[1]; логика {[p7]<[p25]}
       эффект: P23(y4) = 8
  -> Path395 => Loc26  вер=1 порядок=5
       текст: Further
       условия: P14(x (log)) ∈[2]; логика {[p7]<[p25]}

### Loc2 [пустая]
    показ: P25,P26
  -> Path4 => Loc3  вер=1 порядок=5
       условия: логика {[p18]<[p5]}
       эффект: P18(x4 (cin)) +1
       эффект: P23(y4) = {[p23]+([1..100]<=[p11])}
  -> Path5 => Loc3  вер=1 порядок=5
       условия: логика {[p19]<[p6]}
       эффект: P19(x5 (cons)) +1
       эффект: P24(y5 (Chp)) = {[p24]+([1..100]<=[p12])}
  -> Path6 => Loc3  вер=1 порядок=5
       условия: логика {[p15]<[p2]}
       эффект: P15(x1 (et)) +1
       эффект: P20(y1) = {[p20]+([1..100]<=[p8])}
  -> Path7 => Loc3  вер=1 порядок=5
       условия: логика {[p16]<[p3]}
       эффект: P16(x2 (pop)) +1
       эффект: P21(y2) = {[p21]+([1..100]<=[p9])}
  -> Path8 => Loc3  вер=1 порядок=5
       условия: логика {[p17]<[p4]}
       эффект: P17(x3 (pat)) +1
       эффект: P22(y3) = {[p22]+([1..100]<=[p10])}

### Loc3 [пустая]
    эффект: P1(Total) +1
    эффект: P26(Time) +1
  -> Path14 => Loc2  вер=4000 порядок=5
       условия: логика {[p1]<(([p7]*([p2]+[p3]+[p4]+[p5]+[p6])) div 5)}
  -> Path15 => Loc9  вер=1 порядок=5
       эффект: P13(Us) = {[p20]+[p21]+[p22]+[p23]+[p24]}
  -> Path19 => Loc9  вер=300 порядок=5
       условия: логика {[p1]>([p2]+[p3]+[p4]+[p5]+[p6])*9/10}
       эффект: P13(Us) = {[p20]+[p21]+[p22]+[p23]+[p24]}

### Loc9 [обычная]
    выбор описания: {([p7]=5)+1}
    Loc9-1: New data appeared on the board. /  / Approximately {[p7]*20}% of the ballots have been counted. Preliminary results are: /  / <fix> / <format=left,19>          …
    Loc9-2: Final data appeared on the board. /  / {[p7]*20}% of the ballots have been counted. The final results are: /  / <fix> / <format=left,19>          <Ranger></form…
    скрыт: P25,P26
  -> Path16 => Loc2  вер=1 порядок=5
       текст: Wait another hour
       условия: P7(Round) 0..4
       эффект: P7(Round) +1
       эффект: P26(Time) = 0
  -> Path17 => Loc11  вер=1 порядок=5
       текст: Alas, we lost...
       условия: P7(Round) 5..7; логика {2*[p13]<[p1]}
  -> Path18 => Loc10  вер=1 порядок=5
       текст: We won!!!
       условия: P7(Round) 5..7; логика {2*[p13]>[p1]}
  -> Path51 => Loc23  вер=1 порядок=5
       текст: Scram before it's not to late!!!
       условия: P7(Round) 0..4
  -> Path413 => Loc108  вер=1 порядок=5
       текст: And what now?
       условия: P7(Round) 5..7; логика {2*[p13]=[p1]}

### Loc10 [обычная]
    Loc10-1: As soon as the election results appeared on the board, an armed security guard shot down Abu Linkoln Husseyn from a blaster. The body of your unfortunate rival …
  -> Path52 => Loc24  вер=1 порядок=5
       текст: Ok, I'll sign it, as we agreed!
  -> Path53 => Loc25  вер=1 порядок=5
       текст: Ha!!! You think I am a moron?! Now I will rule planet <ToPlanet> on my own!.

### Loc11 [СМЕРТЬ]
    Loc11-1: - This is some kind of mistake! - you shouted, seeing that an armed security guard is approaching you. - The election must have been rigged! /  / These words se…

### Loc12 [обычная]
    выбор описания: {10*([p7]=[p25])+[1..3]*([p7]<>[p25])}
    Loc12-1: You are in the election headquarters. This morning, <CurDate>, is day [p7] of the election campaign. You can spend the morning speaking to the reporters or go c…
    Loc12-2: Today <CurDate>, is day [p7] of the election campaign. The whole resources of the election headquarters are all at your command. Usually in the morning we condu…
    Loc12-3: Today <CurDate>, is day [p7] of the election campaign. You count how many days are left. Looks like {[p25]-[p7]}. We must use this time to our best advantage. U…
    Loc12-10: The election campaign is over! Today is the election day! /  / Canvassing is prohibited today, so you have nothing more to do than to enjoy your time and antici…
    эффект: P23(y4) = 0
    показ: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12
  -> Path20 => Loc1  вер=1 порядок=9
       текст: Hear the forecast
       эффект: P14(x (log)) = 0
  -> Path54 => Loc27  вер=1
       текст: Work with documents until lunch
       условия: логика {[p7]<[p25]}
  -> Path77 => Loc29  вер=100 проходов<=3 порядок=5
       текст: Organise a press conference
       условия: логика {[p7]<[p25]}
       эффект: P15(x1 (et)) = 0
  -> Path78 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Organise a press conference
       ответ: You ordered to organise a press conference and got down to the preparation of the text for your address. But within 30 minutes a disheartened Kill Young called …
       условия: логика {[p7]<[p25]}
       эффект: P23(y4) = 6
  -> Path82 => Loc36  вер=1 порядок=7
       текст: Use black PR
       условия: P24(y5 (Chp)) 0..99; логика {[p7]<[p25]}
  -> Path199 => Loc66  вер=1 порядок=3
       текст: Start canvassing among the crowd
       условия: логика {[p7]<[p25]}
       эффект: P14(x (log)) = 0
  -> Path236 => Loc2  вер=1
       текст: Go to the electoral committee and see how the vote count is done
       условия: логика {[p7]>=[p25]}
       эффект: P1(Total) = 0
       эффект: P7(Round) = 1
       эффект: P13(Us) = 0
       эффект: P14(x (log)) = 0
       эффект: P15(x1 (et)) = 0
       эффект: P16(x2 (pop)) = 0
       эффект: P17(x3 (pat)) = 0
       эффект: P18(x4 (cin)) = 0
       эффект: P19(x5 (cons)) = 0
       эффект: P20(y1) = 0
       эффект: P21(y2) = 0
       эффект: P22(y3) = 0
       эффект: P23(y4) = 0
       эффект: P24(y5 (Chp)) = 0
       эффект: P26(Time) = 0

### Loc13 [СТАРТ]
    Loc13-1: Two seriously looking Pelengs met you in a small spaceport of the <ToPlanet> planet. The first introduced himself as Kill Young, official representative of the …
    эффект: P7(Round) = 1 [скрыт]
    эффект: P24(y5 (Chp)) = 0
    эффект: P25(Length) = 7 [скрыт]
    эффект: P27(Question) = 0
    показ: P1,P2,P3,P4,P5,P6
    скрыт: P8,P9,P10,P11,P12,P14,P15,P16,P17,P18,P19,P26
  -> Path46 => Loc20  вер=1 порядок=5
       текст: Strange that such a warm post is claimed by only two candidates. What's wrong?
       эффект: P27(Question) +1
  -> Path49 => Loc22  вер=1 порядок=1
       текст: Ok, guys, see you all tomorrow, it's time for me to sleep!
  -> Path416 => Loc109  вер=1 проходов<=1 порядок=3
       текст: Please tell me more about <ToPlanet> planet
       эффект: P27(Question) +2

### Loc14 [пустая] визитов<=10
  -> Path24 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today, the parliament of the <ToPlanet> planet has issued a decree on providing access to the polling stations for all the <clr>Pelengs<clrEnd>, that were depor…
       эффект: P5(Number of the Pelengs) = {[p5]+[p23]}
  -> Path25 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today, Gaalian rights activists achieved the recovery of electoral right for the <clr>Maloq<clrEnd> dissidents and pacifists. The number of Maloq voters increas…
       эффект: P6(Number of the Maloqs) = {[p6]+[p23]}
  -> Path26 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today, the parliament of the <ToPlanet> plant issued a decree on the lowering of the electoral age qualification limit for the <clr>Faes<clrEnd> to {[22..28]} y…
       эффект: P3(Number of the Faes) = {[p3]+[p23]}
  -> Path27 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today Faeyan Ethics Committee of the <ToPlanet>'s parliament insisted that the <clr>Faes<clrEnd>, who tasted alcohol or drugs be deprived of the right to vote. …
       условия: P3(Number of the Faes) 5..100
       эффект: P3(Number of the Faes) = {[p3]-[p23]}
  -> Path28 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today the Human and other Mammal Rights Backers and Quarter-backers Committee succeeded in providing the right to vote for all the imprisoned <clr>Humans<clrEnd…
       эффект: P4(Number of the Humans) = {[p4]+[p23]}
  -> Path41 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today the government of the <ToPlanet> planet provided Green Card for all the <clr>Gaalian<clrEnd> fugitives, that arrived to the planet during the past year. N…
       эффект: P2(Number of the Gaals) = {[p2]+[p23]}
  -> Path42 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today, the radical wing of the Maloq faction of the <ToPlanet> planet enacted a law that prohibits voting for any of the <clr>Maloqs<clrEnd>, who served less th…
       условия: P6(Number of the Maloqs) 5..100
       эффект: P6(Number of the Maloqs) = {[p6]-[p23]}
  -> Path43 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today the Peleng drug dealers lobby in the <ToPlanet>'s parliament demanded that the <clr>Pelengs<clrEnd> who spent no time in prison, be deprived of the right …
       условия: P5(Number of the Pelengs) 5..100
       эффект: P5(Number of the Pelengs) = {[p5]-[p23]}
  -> Path44 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: According to the decision of the Children Protection Committee of the <ToPlanet> parliament, the <clr>Humans<clrEnd> will be allowed to vote only when they turn…
       эффект: P4(Number of the Humans) = {[p4]-[p23]}
  -> Path45 => Loc15  вер=1 проходов<=1 порядок=5
       ответ: Today the Peleng, Human and Maloq factions of the <ToPlanet>'s parliament insisted that the <clr>Gaals<clrEnd> who are older than {10*[15..20]} years be deprive…
       условия: P2(Number of the Gaals) 5..100
       эффект: P2(Number of the Gaals) = {[p2]-[p23]}

### Loc15 [пустая]
  -> Path23 => Loc17  вер=1 порядок=5
       текст: Go to bed

### Loc16 [пустая]
  -> Path39 => Loc14  вер=2 проходов<=10 порядок=5
       эффект: P23(y4) = {[2..5]}
  -> Path60 => Loc19  вер=5 порядок=5
  -> Path106 => Loc46  вер=1 проходов<=5 порядок=5
       эффект: P23(y4) = {[2..4]}

### Loc17 [пустая]
    эффект: P7(Round) +1
  -> Path40 => Loc12  вер=1 порядок=5

### Loc18 [пустая] визитов<=10
    эффект: P15(x1 (et)) +1
  -> Path57 => Loc28  вер=1 проходов<=1 порядок=5
  -> Path76 => Loc32  вер=1 проходов<=1 порядок=5
  -> Path92 => Loc35  вер=1 проходов<=1 порядок=5
  -> Path93 => Loc34  вер=1 проходов<=1 порядок=5
  -> Path100 => Loc55  вер=1 проходов<=1 порядок=5
  -> Path142 => Loc49  вер=1 проходов<=1 порядок=5
  -> Path180 => Loc44  вер=1 проходов<=1 порядок=5
  -> Path181 => Loc57  вер=1 проходов<=1 порядок=5
  -> Path184 => Loc60  вер=1 проходов<=1 порядок=5
  -> Path185 => Loc61  вер=1 проходов<=1 порядок=5

### Loc19 [пустая]
  -> Path61 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today at the meeting with the local drag trafficking tycoons Abu Linkoln Husseyn promised that in case he is elected president he will legalise drugs for sale i…
       эффект: P8(Gaals) = {[p8]+[5..10]}
       эффект: P9(Faes) = {[p9]+[5..10]}
       эффект: P10(Humans) = {[p10]+[5..10]}
       эффект: P11(Pelengs) = {[p11]-[25..40]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
  -> Path63 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn told his press conference that he considers the <clr>Maloqs<clrEnd> to be an inferior race. This statement undermined his positions am…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[10..15]}
  -> Path79 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn promised at an antiwar rally to ban free weapons trade on the planet <ToPlanet> if he is elected president. The <clr>Faes<clrEnd> and …
       эффект: P8(Gaals) = {[p8]-[12..17]}
       эффект: P9(Faes) = {[p9]-[7..12]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[12..17]}
  -> Path80 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn announced at his press conference that he considered all scientists and especially humanities research fellows to be useless mouths. A…
       эффект: P8(Gaals) = {[p8]+[7..12]}
       эффект: P9(Faes) = {[p9]+[7..12]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[7..12]}
       эффект: P12(Maloqs) = {[p12]-[10..15]}
  -> Path81 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn donated a large amount of money for the opening of a column dedicated to all planet <ToPlanet>'s citizens, who died in action against …
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path91 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn said in the interview to the <clr>"Young Generation"<clrEnd> Magazine that he could not tolerate hatch-ball. This at once cut him shor…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path98 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Today Abu Linkoln Husseyn promised at a rally in front of a military plant to increase spending on defence already in the first quarter of his presidency. <clr>…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]+[-2..2]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path99 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Presidential candidate Abu Linkoln Husseyn issued a decree on general pardon for all the planet <ToPlanet>'s prisoners. The decree will be enforced as soon as A…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]+[7..12]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[15..20]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path105 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: Presidential candidate Abu Linkoln Husseyn proclaimed that on the first day of his presidency he will introduce the Prohibition. This was very much liked by the…
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path367 => Loc31  вер=1 проходов<=1 порядок=5
       ответ: A local veteran was on the stereovision today - Arch-Major Booze, Grulgarian War Vet. He appealed to every <clr>Maloq<clrEnd> citizen to vote for fearless and m…
       эффект: P12(Maloqs) = {[p12]-[7..12]}
  -> Path415 => Loc31  вер=1 порядок=5
       ответ: Today the news by a merest chance showed Abu Linkoln Husseyn's last year Tax Return. It turned out that all the property of your rival consisted of two room apa…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}

### Loc20 [обычная]
    Loc20-1: - Were you not aware of this? - the Peleng said in amazement. - In order to avoid a scandal, accusations of rigging the election and gerrymandering, civil wars …
  -> Path47 => Loc21  вер=1 порядок=9
       текст: What?! If I lose, I will be killed? I'm getting out of here immediately!!!
  -> Path48 => Loc22  вер=1 порядок=6
       текст: OK! Good bye, folks, I need to have some sleep!
  -> Path418 => Loc109  вер=1 порядок=7
       текст: Sure! By the way, tell me more about planet <ToPlanet>
       условия: P27(Question) 0..1

### Loc21 [ПРОВАЛ]
    Loc21-1: Neglecting all arguments of the Pelengs, you head for the spaceport. You failed your mission, but saved your life!

### Loc22 [обычная]
    Loc22-1: Breakfast was served into your room that morning. After the breakfast a luxurious car took you to a high building of the official representation office of the <…
  -> Path50 => Loc38  вер=1 порядок=5
       текст: Start work
       эффект: P14(x (log)) = 5
       эффект: P15(x1 (et)) = {5}
       эффект: P16(x2 (pop)) = {5}
       эффект: P17(x3 (pat)) = {5}
       эффект: P18(x4 (cin)) = {5}
       эффект: P19(x5 (cons)) = {5}
       скрыт: P13,P20,P21,P22,P23,P24

### Loc23 [ПРОВАЛ]
    Loc23-1: Taking advantage of everyone's being busy, you stealthily left the building and ran headlong to the spaceport. /  / You failed your mission, but saved your life…

### Loc24 [УСПЕХ]
    Loc24-1: - Fine, <Ranger>! - the Peleng encouraged you, as soon as he saw your signature on the document. - You're a nice guy! And therefore you will not be just allowed…

### Loc25 [СМЕРТЬ]
    Loc25-1: Having heard this, the Pelengs looked at each other. /  / - This is the third time already, - Strangle Lee uttered listlessly, taking a crossbow out of the pock…

### Loc26 [обычная]
    выбор описания: {[p23]}
    Loc26-1: You requested price lists from all the neighbourhood's liquor stores and plunged into a review of these documents for a considerable amount of time, checking wh…
    Loc26-2: So, day [p7] of the election campaign is over! You are in your hotel room. Are you interested in the events that happened in the world today?
    Loc26-3: It was either your image-makers that underpaid the dirty reporter or he was initially sent by Abu Linkoln Husseyn's guys from his election headquarters... In an…
  -> Path22 => Loc16  вер=1 порядок=5
       текст: Watch stereovision system
  -> Path394 => Loc1  вер=1 порядок=9
       текст: Hear the forecast
       эффект: P14(x (log)) = 2

### Loc27 [обычная]
    выбор описания: {[p23]+1}
    Loc27-1: You took taken a black piece of paper and wrote: "Lunch Menu". You surrounded yourself with cooking books and plunged into a profound gastronomic survey. By lun…
    Loc27-2: You ordered the dirty reporter to blacken Abu Linkoln Husseyn before the <clr>Gaals<clrEnd>. Having settled down different details with you and your assistants,…
    Loc27-3: When you asked the dirty reporter to discredit Abu Linkoln Husseyn before the <clr>Maloqs<clrEnd>, he assured you that nothing was easier, and that everything w…
    Loc27-4: At first the dirty reporter refused to perform the mission of blackening Abu Linkoln Husseyn - a human - in front of <clr>humans <clrEnd> as almost impossible. …
    Loc27-5: You tasked the dirty reporter to blacken Abu Linkoln Husseyn in the eyes of the Pelengs. Having received a solid advance payment from your assistant Kill Young …
    Loc27-6: - You can do whatever you like, but make it so than none of the highbrowed <clr>Faes<clrEnd> vote for Husseyn! - this was a mission you assigned to the dirty re…
    Loc27-7: You had a good lunch and were ready to plunge into your election campaign with renewed strength. The journalists usually take rest after lunch, but you can cont…
    Loc27-8: As long as you remained undecided you lost precious time. Well, it's already late to go canvassing among the people, but you can still manage to have an ad shot…
    Loc27-9: So what would you like to do?
  -> Path55 => Loc26  вер=1
       текст: Document work
       эффект: P23(y4) = 1
  -> Path198 => Loc66  вер=1 порядок=3
       текст: Start canvassing among the crowd
       эффект: P14(x (log)) = 1
  -> Path341 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Visit a social event
       условия: P7(Round) 6..6
  -> Path342 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Visit a social event
       условия: P7(Round) 2..2
  -> Path343 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Visit a social event
       условия: P7(Round) 3..3
  -> Path344 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Visit a social event
       условия: P7(Round) 4..4
  -> Path345 => Loc88  вер=1 проходов<=1 порядок=5
       текст: Visit a social event
       условия: P7(Round) 5..5
  -> Path364 => Loc1  вер=1 порядок=9
       текст: Hear the forecast
       эффект: P14(x (log)) = 1

### Loc28 [обычная] визитов<=1
    Loc28-1: The floor was passed to an aged grey-headed human. /  / - Old Gink, <clr>Young Generation<clrEnd> Magazine. Please, tell us why you have become a ranger?
  -> Path58 => Loc30  вер=1
       текст: In time of trouble all reasonable citizens of the Galaxy must lay their lives in preventing the Dominators' threat!
       ответ: - Is he really such an idiot or just looks like it? - a baffled <clr>Peleng<clrEnd> journalist asked his <clr>Human<clrEnd> colleague. /  / - Well, one will go …
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path59 => Loc30  вер=1 порядок=4
       текст: When you are flying in a bottomless blackness of the space, which is packed with the light of faraway stars, the truth can be revealed to you in the light of pr…
       ответ: - I wonder, where does he get such dope? - a <clr>Peleng<clrEnd> journalist murmured in admiration. Others were in a state of complete trans after your response…
       эффект: P8(Gaals) = {[p8]+[0..1]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path64 => Loc30  вер=1 порядок=1
       текст: Profession of a ranger means freedom and the possibility to find one's own self!
       ответ: - Dog's crap! - a <clr>Maloq<clrEnd> journalist exploded in anger. - If you want freedom - enlist in the army! /  / - Or engage in science, - a <clr>Faeyan<clrE…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path65 => Loc30  вер=1 порядок=9
       текст: So what? No thirst work - go, loot the transports, and track in dope. The main thing is to get away from the Dominators in time!
       ответ: Your insolent and cynical response enraged all but the <clr>Pelengs<clrEnd>. You had to wait 30 minutes when the guard was calming down the journalists and trie…
       эффект: P8(Gaals) = {[p8]-[5..10]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]+[10..20]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path66 => Loc30  вер=1 порядок=6
       текст: Well who can understand him? One has to do something...
       ответ: Your flat response made no impression on those present.
       эффект: P8(Gaals) = {[p8]+[-2..2]}
       эффект: P9(Faes) = {[p9]+[-2..2]}
       эффект: P10(Humans) = {[p10]+[-2..2]}
       эффект: P11(Pelengs) = {[p11]+[-2..2]}
       эффект: P12(Maloqs) = {[p12]+[-2..2]}

### Loc29 [обычная] визитов<=3
    Loc29-1: Your press conference proved to be a real barnstormer among the journalists of all races. The large hall of your election headquarters was packed with reporters…
    Loc29-2: The next press conference was attended by many journalists of various races. The large hall of your election headquarters was packed almost to the max. Your spe…
    Loc29-3: Your press conference somehow made no great boom among the journalists - the large hall of your election headquarters was filled only by half. Looks like the pr…
  -> Path56 => Loc18  вер=1 проходов<=3 порядок=5
       текст: Any questions?

### Loc30 [пустая]
  -> Path67 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path88 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that: now, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc31 [пустая]
  -> Path62 => Loc17  вер=1 порядок=5
       текст: Go to bed

### Loc32 [обычная] визитов<=1
    Loc32-1: A Gaalian journalist took the floor. /  / - Professor Noo Pasaran, <clr>Interracial Relations Ethics<clrEnd> Almanac. My question is this. Imagine that your spa…
  -> Path69 => Loc33  вер=1 порядок=1
       текст: Gaal, so that you would not even think of asking such idiotic questions!
       ответ: Enraged to the bottom of his heart, the <clr>Gaalian<clrEnd> professor took his seat. But your response provoked unanimous applause of all the rest present in t…
       эффект: P8(Gaals) = {[p8]-[10..15]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
  -> Path70 => Loc33  вер=1 порядок=2
       текст: Faeyan, because it is easy to handle him!
       ответ: By all appearance, your pragmatic approach found support only among the <clr>Pelengs<clrEnd>. The <clr>Humans<clrEnd> remained indifferent, <clr>Gaals<clrEnd> w…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path71 => Loc33  вер=1 порядок=3
       текст: Human, for their meat is most tender!
       ответ: - Have you tasted it already?! - a <clr>Human<clrEnd> journalist next to you shouted throwing the lens of a stereocamera at you. His argument seemed very convin…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[5..10]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[-1..1]}
  -> Path72 => Loc33  вер=1 порядок=5
       текст: Peleng, for they are capable of any kind of beastliness!
       ответ: - Wrong!!! - the <clr>Pelengs<clrEnd> who were present in the hall exclaimed. - We are not capable of any beastliness, we would generously help you in eating so…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[7..12]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path73 => Loc33  вер=1 порядок=6
       текст: Maloq, for their meat will last long!
       ответ: The <clr>Faes, Humans and Pelengs<clrEnd> liked the sharp logic of you answer. One <clr>Gaal<clrEnd> was shaking his head in sadness - he definitely saw some mo…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[7..12]}
  -> Path74 => Loc33  вер=1 порядок=7
       текст: Dominator, as they are our common enemy!
       ответ: - But this is stupid! - one of the <clr>Faes<clrEnd> said. - Dominators posses quite a different metabolism, which cannot be complied with any of the other race…
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path75 => Loc33  вер=1 порядок=9
       текст: No one, because the eating of reasonable beings is absolutely non-ethical!
       ответ: The <clr>Gaal<clrEnd> applauded - he seemed to be waiting for just this kind of answer. But a <clr>Peleng<clrEnd> said: /  / - Stupid! In this case the others w…
       эффект: P8(Gaals) = {[p8]+[7..12]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[-1..1]}

### Loc33 [пустая]
  -> Path68 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path89 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that: now, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc34 [обычная] визитов<=1
    Loc34-1: A Peleng was the fastest to react: /  / - Zap Katze, <clr>Lump of Mud<clrEnd> newspaper. Imagine that you are testing a Maloq Bumblebee fighter. A crazy mainten…
  -> Path118 => Loc48  вер=1 порядок=6
       текст: This is a slander about Maloq fighters! I will not answer this question!!!
       ответ: After such an answer a huge ovation from the <clr>Maloqs<clrEnd> was guaranteed! But all the others did not even try to hide contempt for your stupidity, since …
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[7..12]}
  -> Path119 => Loc48  вер=1
       текст: (Censored)
       ответ: Your phrase cased great laugh among the <clr>Humans and Pelengs<clrEnd> - these guys understand what a good phase is! But the <clr>Gaals and Maloqs<clrEnd> were…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path135 => Loc48  вер=1 порядок=5
       текст: I think that the command does not have anything to do with it
       ответ: You reply was not so logical, but the <clr>Maloqs and Gaals<clrEnd> liked it because of its patriotism and objectivity respectively. But the <clr>Pelengs, Human…
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path136 => Loc48  вер=1 порядок=2
       текст: I think that I would sue him, if I would survive such a mess
       ответ: Your reasonable and civilised response was to everyone's liking, except the <clr>Pelengs and Maloqs<clrEnd> - the first apparently were not in support of legal …
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path137 => Loc48  вер=1 порядок=4
       текст: I think I am the one to blame - I should not have agreed to test a Maloq fighter
       ответ: Your reply to the provocative question sounded rather reasonable so that everyone, naturally except the <clr>Maloqs<clrEnd>, was pleased. The Maloqs thought is …
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}

### Loc35 [обычная] визитов<=1
    Loc35-1: One of the Gaals managed to get the floor before his colleagues. /  / - Shooch Yaa, <clr>Spiritual Essence of the Iike-Baana<clrEnd> stereoprogram. Tell me, wha…
  -> Path94 => Loc37  вер=1 порядок=6
       текст: The colour of blood of enemies killed by me
       ответ: <clr>Gaals and Faes<clrEnd> were apparently jarred by open violence inherent to your answer. Although the members of other races liked its honesty and openness,…
       эффект: P8(Gaals) = {[p8]-[7..12]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
  -> Path95 => Loc37  вер=1 порядок=7
       текст: Its not the colour that's important, it's composition of the colours
       ответ: The <clr>Gaal<clrEnd> started nodding satisfactorily - he was apparently inclined to hear something like that. Although someone of the <clr>Maloqs<clrEnd> fetch…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[-1..2]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]+[-2..1]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path96 => Loc37  вер=1 порядок=4
       текст: Colour of 1000 cr banknote
       ответ: Red faces of the <clr>Maloqs<clrEnd> were distorted out of contempt for such an answer, the <clr>Gaals<clrEnd> must have known more beautiful colours, but the <…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path97 => Loc37  вер=1 порядок=3
       текст: Colour of freshly brewed beer
       ответ: Laughter in the Human seats showed that this response brought you uncontested sympathies of the <clr>Humans<clrEnd>. The <clr>Pelengs<clrEnd> also stayed please…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[7..12]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path114 => Loc37  вер=1 порядок=1
       текст: The colour of dead Dominator parts
       ответ: You reply made no impression in general, as the reporters sitting in the conference hall were rarely leaving Planet <ToPlanet> and could hardly imagine what thi…
       эффект: P8(Gaals) = {[p8]+[-2..2]}
       эффект: P9(Faes) = {[p9]+[0..2]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
  -> Path141 => Loc37  вер=1 порядок=9
       текст: Unfortunately I am colour blind, daltonian - I cannot distinguish colours
       ответ: Shooch Yaa sat down ashamed. The reaction of the hall showed that your forced confession filled the <clr>Faeyan, Gaalian and Human<clrEnd> hearts with pity and …
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}

### Loc36 [обычная]
    Loc36-1: Kill Young looked at you with a shade of doubt on his face. /  / - Black PR is considered to be a very <clr> dirty trick<clrEnd>. It allows to effectively black…
  -> Path150 => Loc12  вер=1 порядок=9
       текст: Don't use dirty methods
  -> Path151 => Loc51  вер=1 проходов<=1 порядок=4
       текст: Humans
       эффект: P23(y4) = 3
  -> Path152 => Loc51  вер=1 проходов<=1 порядок=7
       текст: Maloqs
       эффект: P23(y4) = 2
  -> Path153 => Loc51  вер=1 проходов<=1 порядок=6
       текст: Pelengs
       эффект: P23(y4) = 4
  -> Path154 => Loc51  вер=1 проходов<=1 порядок=2
       текст: Gaals
       эффект: P23(y4) = 1
  -> Path155 => Loc51  вер=1 проходов<=1 порядок=3
       текст: Faes
       эффект: P23(y4) = 5

### Loc37 [пустая]
  -> Path83 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path90 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that: now, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc38 [обычная]
    Loc38-1: Three experts were waiting for you in the adjacent room. You shook hands with them and sat down at a round table. Placing a pile of papers in front of himself, …
  -> Path84 => Loc41  вер=1 порядок=3
       текст: Taxes are going down
       эффект: P16(x2 (pop)) +1
       эффект: P20(y1) = {1}
       эффект: P21(y2) = {[1..5]}
  -> Path85 => Loc40  вер=1 порядок=6
       текст: Taxes are rising up
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P16(x2 (pop)) -2
       эффект: P17(x3 (pat)) +1
       эффект: P20(y1) = {3}
       эффект: P21(y2) = {[1..5]}
  -> Path86 => Loc39  вер=1 порядок=5
       текст: The taxes will stay on the same level they are now
       эффект: P19(x5 (cons)) +1
       эффект: P20(y1) = {2}
       эффект: P21(y2) = {[1..4]}

### Loc39 [обычная]
    выбор описания: {[p21]}
    Loc39-1: - What about cancelling the duplicate profit tax?
    Loc39-2: - You mean, the protests of rights activists concerning the illegitimacy of the pregnancy tax will still be ignored?
    Loc39-3: - You mean, the quarterly tax covering budget deficit will remain in force?
    Loc39-4: - So, I gather that the specific tax for maintaining the struggle with the Dominators will not be abandoned?
  -> Path124 => Loc42  вер=1 порядок=5
       текст: Ah, yes, we will definitely cancel that tax
       эффект: P8(Gaals) = {[p8]+([p21]=4)*[2..5]+([p21]=2)*[3..7]+([p21]=3)*[1..3]}
       эффект: P10(Humans) = {[p10]+([p21]=1)*[2..5]}
       эффект: P11(Pelengs) = {[p11]+([p21]=1)*[1..3]}
       эффект: P12(Maloqs) = {[p12]-([p21]=4)*[3..7]}
       эффект: P14(x (log)) -2
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -1
  -> Path125 => Loc42  вер=1 порядок=5
       текст: I told you - everything will be as it used to be!!!
       эффект: P8(Gaals) = {[p8]-([p21]=2)*[3..7]-([p21]=4)*[1..3]-([p21]=3)*[1..3]}
       эффект: P9(Faes) = {[p9]+([p21]=2)*[1..3]}
       эффект: P10(Humans) = {[p10]-([p21]=1)*[3..7]}
       эффект: P11(Pelengs) = {[p11]-([p21]=1)*[2..5]}
       эффект: P12(Maloqs) = {[p10]+([p21]=4)*[2..5]}
       эффект: P14(x (log)) +1
       эффект: P15(x1 (et)) = {[p15]-([p21]=3)*2}
       эффект: P17(x3 (pat)) = {[p17]+([p21]=3)}
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) +1
  -> Path126 => Loc42  вер=1 порядок=5
       текст: This issue will be resolved independently
       эффект: P14(x (log)) +1
       эффект: P15(x1 (et)) +1
       эффект: P18(x4 (cin)) -1
  -> Path131 => Loc42  вер=1 порядок=5
       текст: Well, we will definitely abolish all unjust taxes and will add just ones, but in general everything will remain as it used to be!
       эффект: P8(Gaals) = {[p8]+[0..2]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P14(x (log)) -2
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) +1
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) -1
  -> Path132 => Loc42  вер=1 порядок=5
       текст: It's the first time I hear about a problem like that. What do you mean?!
       эффект: P8(Gaals) = {[p8]-([p21]=2)*[1..3]}
       эффект: P10(Humans) = {[p10]-([p21]=1)*[1..3]}
       эффект: P12(Maloqs) = {[p12]+([p21]=4)*[1..3]}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -3

### Loc40 [обычная]
    выбор описания: {[p21]}
    Loc40-1: - Are you worried about the production slide?
    Loc40-2: - Are you afraid that this will lead to the rise of the shadow economy?
    Loc40-3: - Are you worried about the drop of the tax collection?
    Loc40-4: - Are you afraid of the sharp decrease of the gross product?
    Loc40-5: - Will it cause a negative reaction of the population?
  -> Path127 => Loc42  вер=1 порядок=5
       текст: Not at all!
       эффект: P8(Gaals) = {[p8]-([p21]=5)*[1..3]}
       эффект: P9(Faes) = {[p9]-([p21]=4)*[1..3]}
       эффект: P10(Humans) = {[p10]-[3..5]}
       эффект: P11(Pelengs) = {[p11]+([p21]=2)*[3..7]+([p21]=3)*[1..3]}
       эффект: P12(Maloqs) = {[p12]-([p21]=1)*[1..3]+([p21]=4)*[1..3]}
       эффект: P14(x (log)) +2
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) = {[p16]-([p21]=5)}
       эффект: P17(x3 (pat)) = {[p17]-(([p21]=1) or ([p21]=4))}
       эффект: P18(x4 (cin)) +2
  -> Path128 => Loc42  вер=1 порядок=5
       текст: This is not the most horrible thing that might happen
       эффект: P8(Gaals) = {[p8]-([p21]=5)*[1..3]-([p21]=2)*[2..5]}
       эффект: P9(Faes) = {[p9]-([p21]=5)*[1..3]}
       эффект: P10(Humans) = {[p10]-([p21]<>2)*[3..7]}
       эффект: P11(Pelengs) = {[p11]+([p21]=2)*[7..12]-([p21]=5)*[1..3]}
       эффект: P12(Maloqs) = {[p12]+([p21]=5)*[2..5]-([p21]=1)*[2..5]}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) = {[p16]-([p21]=5)}
       эффект: P17(x3 (pat)) = {[p17]-2*(([p21]=1) or ([p21]=4))-([p21]=3)}
  -> Path129 => Loc42  вер=1 порядок=5
       текст: Well, we are not going to raise taxes a lot! Well, a little bit, maybe...
       эффект: P14(x (log)) -2
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +1
  -> Path133 => Loc42  вер=1 порядок=5
       текст: I think we can subsidise business from the budget, you should not be so concerned about it.
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-([p21]=5)+([p21]<>5)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -2
  -> Path134 => Loc42  вер=1 порядок=5
       текст: If such a problem arises will we be solving it at that time. Why beat brains with it now?
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) +1
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) +1

### Loc41 [обычная]
    выбор описания: {[p21]}
    Loc41-1: - Therefore, I gather that the compensation to the state employees paid from the budget will not be increased?
    Loc41-2: - I gather, you are not going to devote additional funds for the development of the science?
    Loc41-3: - Do you mean that no money will go for the reform of the army?
    Loc41-4: - So, the state employees will have to survive the salary delays once again?
    Loc41-5: - You mean, the budget will still have a deficit?
  -> Path120 => Loc42  вер=1 порядок=5
       текст: We will see
       эффект: P9(Faes) = {[p9]-([p21]=2)}
       эффект: P12(Maloqs) = {[p12]-([p21]=3)}
       эффект: P15(x1 (et)) -2
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +2
       эффект: P19(x5 (cons)) -1
  -> Path121 => Loc42  вер=1 порядок=5
       текст: That's right!
       эффект: P9(Faes) = {[p9]-([p21]=2)*[3..7]}
       эффект: P12(Maloqs) = {[p12]-([p21]=3)*[3..7]}
       эффект: P14(x (log)) +1
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +2
  -> Path122 => Loc42  вер=1 порядок=5
       текст: We will make an exception
       эффект: P9(Faes) = {[p9]+([p21]=2)*[2..5]}
       эффект: P12(Maloqs) = {[p12]+([p21]=2)*[2..5]}
       эффект: P14(x (log)) -2
       эффект: P16(x2 (pop)) +1
  -> Path123 => Loc42  вер=1 порядок=5
       текст: I think we will find individual sponsors for that
       эффект: P9(Faes) = {[p9]+([p21]=2)*[2..5]}
       эффект: P12(Maloqs) = {[p12]-([p21]=3)*[2..5]}
       эффект: P14(x (log)) = {[p14]-([p21]=1)}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) -2
  -> Path130 => Loc42  вер=1 порядок=5
       текст: The main thing is that the planet have enough money to feed the presidential administration, all the rest is unessential
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[0..2]}
       эффект: P15(x1 (et)) -2
       эффект: P16(x2 (pop)) -2
       эффект: P18(x4 (cin)) +3

### Loc42 [обычная]
    Loc42-1: - Well, now my next question. What of the areas of your <clr>budget<clrEnd> policy will be prioritised?
  -> Path157 => Loc52  вер=1 порядок=3
       текст: Law and Order
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) +2
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) +1
       эффект: P22(y3) = {3}
  -> Path158 => Loc52  вер=1 порядок=2
       текст: Armament and Defence
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]+[7..12]}
       эффект: P15(x1 (et)) -1
       эффект: P17(x3 (pat)) +2
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) +1
       эффект: P22(y3) = {2}
  -> Path159 => Loc52  вер=1 порядок=6
       текст: Science and Education
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P15(x1 (et)) +1
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -1
       эффект: P22(y3) = {6}
  -> Path160 => Loc52  вер=1 порядок=7
       текст: Art and Culture
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
       эффект: P15(x1 (et)) +2
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -1
       эффект: P22(y3) = {7}
  -> Path161 => Loc52  вер=1 порядок=4
       текст: Business and Trade
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-3*([p20]=3)+([p20]=1)}
       эффект: P15(x1 (et)) = {[p15]-[p20]+2}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) = {[p18]+([p20]=3)*2}
       эффект: P19(x5 (cons)) -1
       эффект: P22(y3) = {4}
  -> Path162 => Loc52  вер=1 порядок=1
       текст: Strengthening of the authority
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) +2
       эффект: P19(x5 (cons)) +1
       эффект: P22(y3) = {1}
  -> Path163 => Loc52  вер=1 порядок=5
       текст: Sports and Physical Training
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) -1
       эффект: P22(y3) = {5}
  -> Path164 => Loc52  вер=1 порядок=9
       текст: All the areas will have the same priority
       эффект: P14(x (log)) = {[p14]-6+[p20]}
       эффект: P15(x1 (et)) = {[p15]-5+[p20]}
       эффект: P16(x2 (pop)) +2
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) = {[p18]+([p20]=1)}
       эффект: P22(y3) = {8}

### Loc43 [пустая]
  -> Path229 => Loc69  вер=1 порядок=5
       эффект: P14(x (log)) = {[p14]*([p14]<10)+9*([p14]>9)}
       эффект: P15(x1 (et)) = {[p15]*([p15]<10)+9*([p15]>9)}
       эффект: P16(x2 (pop)) = {[p16]*([p16]<10)+9*([p16]>9)}
       эффект: P17(x3 (pat)) = {[p17]*([p17]<10)+9*([p17]>9)}
       эффект: P18(x4 (cin)) = {[p18]*([p18]<10)+9*([p18]>9)}
       эффект: P19(x5 (cons)) = {[p19]*([p19]<10)+9*([p19]>9)}

### Loc44 [обычная] визитов<=1
    Loc44-1: A bold young man managed to get the floor before anyone else could. /  / - Jim Hakker, <clr>Computer Game News<clrEnd> Weekly. Recently I was playing a quest, t…
  -> Path103 => Loc45  вер=1 порядок=7
       текст: Well, why can't you kill the chief, and that's that!
       ответ: You reply was very well taken by the <clr>Maloqs, Pelengs and Humans<clrEnd>, but the <clr>Faes and Gaals<clrEnd> were apparently more accustomed with solving f…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path104 => Loc45  вер=1 порядок=9
       текст: I consider computer gaming as complete idiocracy and time spent in vain!
       ответ: The reaction of the crowd showed that the <clr>Maloqs, Pelengs and Faes <clrEnd> also thought that time can be spent more useful than that. ("Science!", "Drill!…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]-[5..10]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path113 => Loc45  вер=1 порядок=1
       текст: All you need is a good trade. Buy cheap, sell with a higher price, betray partners from time to time - and everything will be okey-dokey.
       ответ: <clr>Humans and Pelengs<clrEnd> unconditionally shared your opinion about how to gain success in life and computer games. The <clr>Gaals<clrEnd> were frowning o…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path115 => Loc45  вер=1 порядок=5
       текст: You should buy the local booze for all your money, make the chief drunk, and you can count that the idol is yours!
       ответ: <clr>Humans, Pelengs and Maloqs<clrEnd> laughed at that - yes, that's how it is best to treat other races, without mittens!!! But some mumbling against "non-eth…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path138 => Loc45  вер=1 порядок=2
       текст: You need to study the culture of that tribe, learn their folkways and customs. Why, they can just give this idol to you themselves!
       ответ: The <clr>Gaals and Faes<clrEnd> liked the tactics you proposed - really, the knowledge is the best clue to anything! Only the <clr>Maloqs and Pelengs <clrEnd> w…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[-2..2]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path139 => Loc45  вер=1 порядок=3
       текст: I would try to shock this tribe by the technical progress - I would show them my spaceship, weaponry and materiel. I think the locals would become more complian…
       ответ: The <clr>Faes<clrEnd>, were impressed by this line of action the most, for they were so proud of their technical progress. The <clr>Humans, Pelengs, and Maloqs<…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
  -> Path140 => Loc45  вер=1 порядок=8
       текст: This game implies stealing the cultural values of the primeval races, it should be outlawed at once and for all!
       ответ: After such a reply the <clr>Gaals<clrEnd> applauded you in standing, and the stupid <clr>Maloqs<clrEnd>, were quick to follow suit, for they would rather miss a…
       эффект: P8(Gaals) = {[p8]+[7..12]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}

### Loc45 [пустая]
  -> Path101 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that - sorry, it's lunchtime!
       условия: P15(x1 (et)) 3..100
  -> Path102 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2

### Loc46 [пустая] визитов<=5
  -> Path107 => Loc47  вер=1 проходов<=1 порядок=5
       ответ: Today a blast sounded in the Faeyan research and development institute as a result of careless treatment of hexanotoluol. The death toll amounted to over [p23] …
       эффект: P3(Number of the Faes) = {[p3]-[p23]}
       эффект: P9(Faes) = {[p9]-[7..12]}
  -> Path109 => Loc47  вер=1 проходов<=1 порядок=5
       ответ: The training of the <clr>Maloq<clrEnd> corps of the planet <ToPlanet>'s armed forces ended in tragedy today. One of the pseudonuclear warhead missile wandered f…
       эффект: P6(Number of the Maloqs) = {[p6]-[p23]}
       эффект: P9(Faes) = {[p9]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[10..15]}
  -> Path110 => Loc47  вер=1 проходов<=1 порядок=5
       ответ: A terrible wreck happened in a densely populated <clr>Human<clrEnd> quarter of the capital today when a cargo astracopter crashed 10 minutes after take off! Acc…
       эффект: P4(Number of the Humans) = {[p4]-[p23]}
       эффект: P10(Humans) = {[p10]-[7..12]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
  -> Path111 => Loc47  вер=1 проходов<=1 порядок=5
       ответ: Mass suicide of [p23] thousand <clr>Pelengs<clrEnd> - members of a totalitarian sect "Path to Nowhere" - shocked today all the progressive public of the planet …
       эффект: P5(Number of the Pelengs) = {[p5]-[p23]}
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]-[0..2]}
  -> Path112 => Loc47  вер=1 проходов<=1 порядок=5
       ответ: A terrible act of terrorism in the Gaalian Fine Arts and Abstract Logic Museum claimed the lives of [p23] thousands <clr>Gaals<clrEnd>! A radical <clr>Maloq Ord…
       эффект: P2(Number of the Gaals) = {[p2]-[p23]}
       эффект: P8(Gaals) = {[p8]-[10..15]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}

### Loc47 [пустая]
  -> Path108 => Loc17  вер=1 порядок=5
       текст: Go to bed

### Loc48 [пустая]
  -> Path116 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path117 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that: now, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc49 [обычная] визитов<=1
    Loc49-1: A powerful Maloq brushed aside all his colleagues and took the floor. /  / - Karra Bbach, <clr>Unconventional Situations Civil Defence<clrEnd> stereo-program. I…
  -> Path145 => Loc50  вер=1 порядок=1
       текст: I would pay the money - it's stupid to lose the life and spaceship because of them money
       ответ: This judicious decision impressed the <clr>Gaals<clrEnd> (life is more expensive than money!), <clr>Faes<clrEnd> (the ship's depreciation value would exceed the…
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path146 => Loc50  вер=1 порядок=6
       текст: I would engage in fight! This is the highest honour for any reasonable being to die in action!
       ответ: - Excellent, <Ranger>! - Karra Bach exclaimed sitting down accompanied by excited roar of other <clr>Maloq<clrEnd> journalists. - I would not expect any other r…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[12..17]}
  -> Path147 => Loc50  вер=1 порядок=2
       текст: I would try to jump into a hyper - you can always heal yourself there, having shot a couple of pirates
       ответ: - It's more likely that the pirates will shoot you in the hyper! - someone of the <clr>Pelengs<clrEnd> shouted offended. Looks like you answer will not gain sup…
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path148 => Loc50  вер=1 порядок=5
       текст: I would begin negotiations, bargain and hang out for terms, kill time and try to get to the nearest planet
       ответ: Your tactics were fully endorsed by the <clr>Humans<clrEnd> - the acknowledged masters of the Galaxy in bargaining and killing time. The <clr>Faes and Gaals<clr…
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[5..10]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path149 => Loc50  вер=1
       текст: I would pay him, then land at a planet, repair the ship, take off, find that pirate and victimise him!
       ответ: The reaction was ambiguous. /  / The <clr>Maloqs<clrEnd> decided that to postpone the fight until the conditions get better is a good manoeuvre!. / - The main t…
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}

### Loc50 [пустая]
  -> Path143 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path144 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that: now, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc51 [пустая]
    эффект: P22(y3) = {[1..99]}
    эффект: P24(y5 (Chp)) = {[p24]+[20..24]}
  -> Path156 => Loc26  вер=100 порядок=5
       условия: логика {[p22]<=[p24]}
       эффект: P8(Gaals) = {[p8]-[10..20]}
       эффект: P9(Faes) = {[p9]-[10..20]}
       эффект: P10(Humans) = {[p10]-[7..12]}
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P12(Maloqs) = {[p12]-[7..12]}
       эффект: P23(y4) = 3
       эффект: P24(y5 (Chp)) = 100
  -> Path192 => Loc65  вер=1 порядок=5
       условия: логика {[p23]=3}
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[20..30]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path194 => Loc65  вер=1 порядок=5
       условия: логика {[p23]=4}
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[20..30]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path195 => Loc65  вер=1 порядок=5
       условия: логика {[p23]=5}
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[20..30]}
       эффект: P10(Humans) = {[p10]-[0..2]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path196 => Loc65  вер=1 порядок=5
       условия: логика {[p23]=1}
       эффект: P8(Gaals) = {[p8]+[20..30]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]+[-2..1]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path197 => Loc65  вер=1 порядок=5
       условия: логика {[p23]=2}
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[20..30]}

### Loc52 [обычная]
    Loc52-1: - Fine! Now I would like to hear more about each particular area. What are you planning to do to increase <clr>the military strength<clrEnd> of <ToPlanet>?
  -> Path165 => Loc53  вер=1 порядок=3
       текст: We will develop new military technologies
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
       эффект: P14(x (log)) = {[p14]+([p22]=2)}
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -1
  -> Path166 => Loc53  вер=1 порядок=2
       текст: We will construct new military plants
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]+([p22]=2)}
       эффект: P15(x1 (et)) -1
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) = {[p18]-([p22]=2)}
  -> Path167 => Loc53  вер=1 порядок=5
       текст: We will increase the term of military duty for five years
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
       эффект: P14(x (log)) = {[p14]+([p22]=2)}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -2
       эффект: P17(x3 (pat)) +2
  -> Path168 => Loc53  вер=1 порядок=1
       текст: We will procure new weapons from industrially developed countries
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=2)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=2)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) = {[p18]+([p22]=2)}
  -> Path169 => Loc53  вер=1 порядок=8
       текст: Why strengthen it? It is strong enough
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=2)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=2)}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) = {[p18]+([p22]=2)}
       эффект: P19(x5 (cons)) +1
  -> Path170 => Loc53  вер=1 порядок=7
       текст: We will increase military payroll
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]+([p22]=2)-2+[p20]}
       эффект: P15(x1 (et)) = {[p15]-2+[p20]}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) = {[p18]+([p20]=1)}
  -> Path171 => Loc53  вер=1 порядок=9
       текст: We will dismiss the army, and transfer military expenses for peaceful purposes. No one will attack us anyway!
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[0..2]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[7..12]}
       эффект: P14(x (log)) = {[p14]-[p20]+2-5*([p22]=2)}
       эффект: P15(x1 (et)) = {[p15]-2*([p22]=2)}
       эффект: P17(x3 (pat)) = {[p17]-3-([p22]=1)-([p22]=2)}
       эффект: P18(x4 (cin)) = {[p18]+2*([p22]=2)}
       эффект: P19(x5 (cons)) -2

### Loc53 [обычная]
    Loc53-1: - Interesting decision! And what are you planning to do in regards to the <clr>law enforcement<clrEnd>?
  -> Path172 => Loc54  вер=1 порядок=1
       текст: We will have to promulgate a more rigid penal code
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P14(x (log)) = {[p14]+([p22]=3)+2*([p22]=1)}
       эффект: P15(x1 (et)) = {[p15]-1+([p22]=3)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) +2
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -1
  -> Path173 => Loc54  вер=1
       текст: We will build new prisons and imprison one and all
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P14(x (log)) = {[p14]-1+([p22]=3)+2*([p22]=1)}
       эффект: P15(x1 (et)) -2
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) -1
  -> Path174 => Loc54  вер=1 порядок=3
       текст: We will increase policemen salaries
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P14(x (log)) = {[p14]+([p22]=3)+[p20]-2}
       эффект: P15(x1 (et)) = {[p15]+([p22]=3)-2+[p20]}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) = {[p18]+([p22]=1)}
  -> Path175 => Loc54  вер=1 порядок=7
       текст: We will reconsider all the cases and free all who were convicted unjustly
       эффект: P8(Gaals) = {[p8]+[5..10]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=1)-([p22]=3)}
       эффект: P15(x1 (et)) +2
       эффект: P16(x2 (pop)) +2
       эффект: P18(x4 (cin)) -2
       эффект: P19(x5 (cons)) -1
  -> Path176 => Loc54  вер=1 порядок=9
       текст: We will proclaim general clemency on the day I am elected
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = {[p14]-3*([p22]=3)}
       эффект: P15(x1 (et)) = {[p14]-2*([p22]=3)}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -2
       эффект: P18(x4 (cin)) +1
  -> Path177 => Loc54  вер=1 порядок=5
       текст: We will have to conduct a reform of the criminal court system, with meticulous observance of all the formalities stipulated by the law.
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]+([p22]=3)-([p22]=1)}
       эффект: P15(x1 (et)) = {[p15]+1+([p22]=3)}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -2
       эффект: P18(x4 (cin)) = {[p18]-([p22]=3)}
       эффект: P19(x5 (cons)) -2
  -> Path200 => Loc54  вер=1 порядок=4
       текст: We will not do anything, we will leave anything as it is
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P14(x (log)) = {[p14]-([p22]=3)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=3)}
       эффект: P18(x4 (cin)) = {[p18]+([p22]=3)}
       эффект: P19(x5 (cons)) +1

### Loc54 [обычная]
    Loc54-1: - I hope that these steps will prove effective! And what will be your policy towards <clr>media freedom<clrEnd>?
  -> Path208 => Loc67  вер=1 порядок=1
       текст: Free press hampers the conduct of an effective policy, so I will not have free press during my presidency!
       эффект: P8(Gaals) = {[p8]-[5..10]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[7..12]}
       эффект: P14(x (log)) = {[p14]-([p22]=7)+3*([p22]=1)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=7)-1}
       эффект: P16(x2 (pop)) -2
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) +1
  -> Path209 => Loc67  вер=1 порядок=5
       текст: Surely, the press will stay free! Well, maybe we will censor something this time or that...
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P14(x (log)) -1
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) +1
  -> Path210 => Loc67  вер=1 порядок=2
       текст: The only really free press is the one that backs the supreme power!
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P14(x (log)) = {[p14]+3*([p22]=1)-2*([p22]=7)}
       эффект: P15(x1 (et)) = {[p15]-1-([p22]=7)+([p22]=1)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) +2
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) +1
  -> Path211 => Loc67  вер=1
       текст: My opinion is that the press must be eliminated and all the journalists be shot down! It's the most useless of professions!!!
       эффект: P8(Gaals) = {[p8]-[5..10]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P14(x (log)) = {[p14]-([p22]=7)+2*([p22]=1)}
       эффект: P15(x1 (et)) -3
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) = {[p17]+([p22]=1)}
       эффект: P18(x4 (cin)) +2
       эффект: P19(x5 (cons)) -1
  -> Path212 => Loc67  вер=1 порядок=7
       текст: Freedom of speech - this is the highest value, so nothing is to be spared for the free press!
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=1)+2*([p22]=7)}
       эффект: P15(x1 (et)) = {[p15]+2-([p22]=1)+([p22]=7)}
       эффект: P16(x2 (pop)) +2
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) -2
  -> Path213 => Loc67  вер=1 порядок=9
       текст: The press will be absolutely free! We will publish a Drug Addict Journal and Young Terrorist Newspaper, as well as all the rest of the editions that are being u…
       эффект: P8(Gaals) = {[p8]+[0..2]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path214 => Loc67  вер=1 порядок=6
       текст: The press? For all I care about the press, let it live, I don't read newspapers anyway...
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]-([p22]=7)-([p22]=1)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=7)}
       эффект: P18(x4 (cin)) +2
       эффект: P19(x5 (cons)) +1

### Loc55 [обычная] визитов<=1
    Loc55-1: A weasel-like Fae slipped to the microphone faster than the gaping representatives of other races. /  / - Od-dalani Tall Mud, <clr>"Lynching Pseudo-Science"<clr…
  -> Path201 => Loc56  вер=1 порядок=5
       текст: Everything depends on the situation, if it is profitable for me - I believe, if not - I believe not
       ответ: Your response was fully endorsed by the <clr>Humans and Pelengs<clrEnd>, most of them were going along the same lines in philosophy. All the rest were disgusted…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path202 => Loc56  вер=1 порядок=2
       текст: If I win this election - this means God exists!
       ответ: Now even the Maloqs understood that this was a joke, but not all of them liked it...
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
  -> Path203 => Loc56  вер=1 порядок=6
       текст: No, because the rangers' Charter does not say anything about God
       ответ: Only the <clr>Maloqs and Faes<clrEnd> took your response at it's face value. The former liked it but the latter were disappointed in your mental capabilities. T…
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path204 => Loc56  вер=1 порядок=4
       текст: I do believe! I recall how having doped myself with cocaine I conversed with him for quite a time...
       ответ: Your mentioning cocaine made <clr>Pelengs<clrEnd> to start a vivid ovation. <clr>Humans<clrEnd> also appreciated your humour. Although your popularity went down…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[10..15]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path205 => Loc56  вер=1 порядок=1
       текст: Yes, the Universe must have been created by someone, if not by God, then by whom?
       ответ: Od-delani Tall Mud could not appreciate your words in spite of all their logic. He started arguing, citing quotes from his own magazine. The <clr>Faes <clrEnd>,…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path206 => Loc56  вер=1 порядок=8
       текст: No, because God's existence has not been proved scientifically
       ответ: This was exactly the thing the <clr>Faes<clrEnd> expected to hear from you. In any case the triangle faces of the Faes who were present were smiling wide and tu…
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[7..12]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]+[-1..2]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path207 => Loc56  вер=1 порядок=9
       текст: Honestly, I am agnostic!
       ответ: Meaningful use of unclear words with unclear meaning is the best way to achieve respect of the <clr>Gaals, Fayans<clrEnd> and, perhaps, <clr>Humans<clrEnd>. But…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}

### Loc56 [пустая]
  -> Path178 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that - sorry, it's lunchtime!
       условия: P15(x1 (et)) 3..100
  -> Path179 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2

### Loc57 [обычная] визитов<=1
    Loc57-1: A clothed in military uniform Maloq journalist, so huge that he even surpassed all the limits set for that powerful race, easily gained the floor.  /  / - Serge…
  -> Path230 => Loc58  вер=1 порядок=2
       текст: I am taking up exercise every morning!
       ответ: <clr>Maloqs<clrEnd> gave you an ovation, for according to the regulations, the real warrior must do fitness and shooting exercises every day. <clr>Humans<clrEnd…
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
  -> Path231 => Loc58  вер=1 порядок=3
       текст: I don't have time to go to the gym
       ответ: Your confession was more or less accepted by the <clr>Maloqs<clrEnd> (truly, sergeant Barrack tried to shout something about the necessity to maintain constant …
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path232 => Loc58  вер=1 порядок=9
       текст: And why should I support it?
       ответ: - Right! - someone of the <clr>Faes<clrEnd> exclaimed. - The brain is the main thing, anything else will come! /  / - Not the brains but the money, - one of the…
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path233 => Loc58  вер=1 порядок=5
       текст: I regularly took to yoga and meditation
       ответ: <clr>Gaals and Humans<clrEnd> started to respect you right away, for their meditation, yoga, occult and other shuck schools have long been arguing whose school …
       эффект: P8(Gaals) = {[p8]+[5..10]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[5..10]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path234 => Loc58  вер=1 порядок=7
       текст: Real ranger must first of all keep his banking account in fitness and not his physical shape!
       ответ: <clr>Humans and Pelengs<clrEnd> showed their complete solidarity with you - one's banking account is no doubt much more important than one's health! But the <cl…
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
  -> Path235 => Loc58  вер=1 порядок=6
       текст: I smoke hash and think I am a tough body-builder
       ответ: Your reply provoked vivid applause among the <clr>Pelengs<clrEnd>, and the <clr>Humans<clrEnd> seemed also to be not completely void of humour. But all the rest…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}

### Loc58 [пустая]
  -> Path182 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2
  -> Path183 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that - sorry, it's lunchtime!
       условия: P15(x1 (et)) 3..100

### Loc59 [пустая]
  -> Path186 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that - sorry, it's lunchtime!
       условия: P15(x1 (et)) 3..100
  -> Path188 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2

### Loc60 [обычная] визитов<=1
    Loc60-1: A weasel-like Peleng with a cunning snout gained the floor: /  / - Hush Baba, <clr>Law and how to dodge it<clrEnd> stereo-program. In order to open your own bus…
  -> Path238 => Loc59  вер=1 порядок=8
       текст: It's not good to bribe, everything must be done strictly according to the law!
       ответ: Applause of the <clr>Gaalian<clrEnd> journalists was equal in its loudness to the jeering and laughter heard from the <clr>Peleng and Human <clrEnd> sectors. Bu…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[5..10]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path251 => Loc59  вер=1 порядок=7
       текст: You can buy good gun for this money, after which there should be no more problems concerning the permits
       ответ: - Yeah, this is how the real <clr>Maloq<clrEnd> would answer! - shouted one of the members of that militaristic race. /  / - Nothing will be gained by such meth…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
  -> Path252 => Loc59  вер=1 порядок=6
       текст: You should pay the Mafioso and he will deal with the others on his own part
       ответ: - Yes, this is the best decision! - Shooch Yaa exclaimed. - Where have you got this knowledge of life?? You must be are a regular viewer of my program "The Law …
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[2..5]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path253 => Loc59  вер=1 порядок=9
       текст: I think it's better to start your own business in a different location!
       ответ: Your joke was a good thing to dissipate the tension. Everyone, except the <clr>Maloqs<clrEnd>, who found some non-patriotic lining in it, seemed to like it.
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path254 => Loc59  вер=1 порядок=4
       текст: You should set the Mayor against various committees and then inform on the local Mafiosi chief to the police, after which you can quickly gather all the require…
       ответ: - Yeah! - Hush Baba said. - If you will remain alive after informing on the Mafiosi chief! /  / - All right, - a <clr>Gaal<clrEnd> suddenly spoke up for you. - …
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[-1..1]}
  -> Path255 => Loc59  вер=1 порядок=3
       текст: You should pay the Mayor and the Police Chief, and then win the rest with their help
       ответ: - This can work, - Hush Baba murmured deep in thought. - The only thing is that 1000 cr will hardly be enough to satisfy their appetites... /  / The others reac…
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[0..2]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
  -> Path256 => Loc59  вер=1 порядок=5
       текст: You should save as much money as you can so that there'll be enough to bribe everyone.
       ответ: Your naïve response provoked everyone's laughter in the sector of the <clr>Humans, Maloqs and Pelengs<clrEnd>. /  / - You will not save so much money in all you…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}

### Loc61 [обычная] визитов<=1
    Loc61-1: Somehow the journalists were not eager to ask you questions. At last a short Faeyan reporter stood up: /  / - Blubb Lubb, <clr>Quantum Mechanics for Elementary …
  -> Path237 => Loc62  вер=1
       текст: Same thing as now - the money!
       ответ: Derided in his best feelings, Blub Lubb has taken his seat. His irritation spread throughout all the <clr>Faeyan<clrEnd> and a part of <clr>Gaalian <clrEnd> sea…
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
  -> Path239 => Loc62  вер=1 порядок=1
       текст: Most of all I loved the baseball bat - you can play baseball with it or kick someone if the need occurs!
       ответ: Baseball is a Human game, so that the sympathies of <clr>Humans<clrEnd> were all yours. Alternative use of the bat was acclaimed by the <clr>Maloqs<clrEnd> and …
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path240 => Loc62  вер=1 порядок=9
       текст: And where did you get it that I went to school at all?!
       ответ: No one could understand what you were counting for in providing an answer like that. Ignoramuses can now provoke sympathy only among <clr>Maloqs<clrEnd>, and th…
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
  -> Path241 => Loc62  вер=1 порядок=2
       текст: I liked all the subjects, I was always keen on learning!
       ответ: This was just the kind of answer the Faeyan teacher was hoping to get as well as the whole <clr>Faeyan<clrEnd> sector. The <clr>Gaals<clrEnd> also liked your qu…
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]+[5..10]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path242 => Loc62  вер=1 порядок=7
       текст: Most of all I liked the military science. Can't you see that from me?!
       ответ: - Yeah, right! - Blub Lubb remarked sarcastically, sitting down. But the ironic comments of the <clr>Faes<clrEnd> and the <clr>Gaals<clrEnd> were overwhelmed by…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
  -> Path243 => Loc62  вер=1 порядок=5
       текст: I enjoyed the Humanities, like Ethics or Philosophy
       ответ: If you were intended to gain the respect of the <clr>Gaals<clrEnd>, you have hit it right! The <clr>Humans<clrEnd> also liked subjects of this kind, but the <cl…
       эффект: P8(Gaals) = {[p8]+[5..10]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
  -> Path244 => Loc62  вер=1 порядок=6
       текст: I loved the sciences, they can be applied somehow at least, unlike the Humanities nonsense!
       ответ: Your response provokes an ambiguous reaction. On the one hand, the sciences enjoy great respect of the <clr>Faeyan, Pelengs<clrEnd> and even <clr>Maloqs<clrEnd>…
       эффект: P8(Gaals) = {[p8]-[3..7]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}

### Loc62 [пустая]
  -> Path187 => Loc63  вер=1 порядок=5
       текст: I would like to finish my press conference on that - sorry, it's lunchtime!
       условия: P15(x1 (et)) 3..100
  -> Path189 => Loc64  вер=1 порядок=5
       текст: Next question, please
       условия: P15(x1 (et)) 0..2

### Loc63 [пустая]
  -> Path190 => Loc27  вер=1 порядок=5
       эффект: P23(y4) = {6}

### Loc64 [пустая]
  -> Path191 => Loc18  вер=1 порядок=5

### Loc65 [пустая]
  -> Path193 => Loc27  вер=1 порядок=5

### Loc66 [обычная]
    Loc66-1: You expressed a wish to have a campaign ad shot for you, and soon an image maker, photographs, make-up artists and several other persons of unknown professions …
    эффект: P15(x1 (et)) = 50
    эффект: P16(x2 (pop)) = 50
    эффект: P17(x3 (pat)) = 50
    эффект: P18(x4 (cin)) = 50
    эффект: P19(x5 (cons)) = 50
  -> Path245 => Loc70  вер=1 проходов<=1 порядок=2
       текст: Make an advertisement reel
       эффект: P17(x3 (pat)) = {[p17]-[1..3]}
       эффект: P21(y2) = 3
  -> Path246 => Loc70  вер=1 проходов<=1
       текст: Put the posters in the streets
       эффект: P15(x1 (et)) = {[p15]-[1..3]}
       эффект: P21(y2) = 3
  -> Path247 => Loc70  вер=1 проходов<=1 порядок=4
       текст: Make advertisement T-shirts
       эффект: P19(x5 (cons)) = {[p19]-[1..3]}
       эффект: P21(y2) = 2
  -> Path248 => Loc70  вер=1 проходов<=2 порядок=5
       текст: Purchase advertisement badges.
       эффект: P16(x2 (pop)) = {[p16]-[0..2]}
       эффект: P19(x5 (cons)) = {[p19]-[0..2]}
       эффект: P21(y2) = 2
  -> Path249 => Loc70  вер=1 проходов<=3 порядок=6
       текст: Write leaflets
       эффект: P15(x1 (et)) = {[p15]-[0..2]}
       эффект: P17(x3 (pat)) = {[p17]-[0..2]}
       эффект: P18(x4 (cin)) = {[p18]-[0..2]}
       эффект: P21(y2) = 1
  -> Path250 => Loc70  вер=1 порядок=8
       текст: Send Spam via e-mail
       эффект: P15(x1 (et)) = {[p15]-[0..2]}
       эффект: P16(x2 (pop)) = {[p16]-[0..2]}
       эффект: P17(x3 (pat)) = {[p17]-[0..2]}
       эффект: P18(x4 (cin)) = {[p18]-[0..2]}
       эффект: P19(x5 (cons)) = {[p19]-[0..2]}
       эффект: P21(y2) = 1
  -> Path257 => Loc27  вер=1 порядок=9
       текст: We will not do anything, I changed my mind!
       условия: P14(x (log)) ∈[1]
  -> Path258 => Loc12  вер=1 порядок=9
       текст: We will not do anything, I changed my mind!
       условия: P14(x (log)) ∈[0]

### Loc67 [обычная]
    Loc67-1: - Please, be assured that the journalists will judge your words on their merits! Now, please tell me what is your position in regards to the budget appropriatio…
  -> Path215 => Loc68  вер=1
       текст: I think this is the most useless item of expenditure. We will cut it down first!
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=5)-[p20]+2}
       эффект: P15(x1 (et)) = {[p15]-([p22]=5)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) = {[p18]+([p22]=5)}
  -> Path216 => Loc68  вер=1 порядок=9
       текст: The spending on sport is not enough! This should be our policy's priority!
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
       эффект: P14(x (log)) = {[p14]-([p22]<>5)+2*([p22]=5)-([p20]=1)}
       эффект: P15(x1 (et)) = {[p15]-([p22]<>5)}
       эффект: P17(x3 (pat)) +1
  -> Path217 => Loc68  вер=1 порядок=5
       текст: I recognise only the intellectual sports - chess, draughts, making of iike-baanas. All the rest is crap!
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]-[5..10]}
       эффект: P14(x (log)) = {[p14]+([p22]=6)+([p22]=7)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=5)}
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) -1
  -> Path218 => Loc68  вер=1 порядок=2
       текст: This is all trifling! There are more important areas. And our main funds will be directed there!
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]-([p22]=5)*3+([p22]<>8)}
       эффект: P15(x1 (et)) -1
  -> Path219 => Loc68  вер=1 порядок=8
       текст: You can make good money on sport, if you manage to make a timely investment. We will first develop the economically rewarding sports!
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = {[p14]+2*([p22]=4)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=5)-1+([p22]=4)}
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +1
  -> Path220 => Loc68  вер=1 порядок=4
       текст: I am myself not interested in sports, so it's for the house members to decide how much to spend on it
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = {[p14]-([p22]=5)-([p22]=1)}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) -1
       эффект: P19(x5 (cons)) +1
  -> Path221 => Loc68  вер=1 порядок=7
       текст: We will primarily subsidise mass physical training and child sport, because they are the nation's health. And big sport will manage to survive without governmen…
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]-[3..7]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[5..10]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=4)+2*([p22]=2)+[p20]-2}
       эффект: P15(x1 (et)) = {[p15]+([p22]=2)-([p22]=4)}
       эффект: P16(x2 (pop)) -1
       эффект: P17(x3 (pat)) +2
       эффект: P18(x4 (cin)) -1

### Loc68 [обычная]
    Loc68-1: Well, well, everything's clear with the sports! Now, the final question - what can the labour force engaged in <clr>Science and Education<clrEnd> be hoping for?
  -> Path222 => Loc43  вер=1 порядок=9
       текст: We will lay off all chair warmers and that's all!
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[5..10]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]-([p22]=6)*3+2-[p20]}
       эффект: P15(x1 (et)) -1
       эффект: P16(x2 (pop)) -1
       эффект: P18(x4 (cin)) +1
       эффект: P19(x5 (cons)) -1
  -> Path223 => Loc43  вер=1 порядок=8
       текст: The funding for the education and science has been reduced substantially
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]-2*([p22]=6)+2-[p20]}
       эффект: P15(x1 (et)) = {[p15]-([p22]=6)}
       эффект: P16(x2 (pop)) +1
  -> Path224 => Loc43  вер=1 порядок=5
       текст: We will subsidise only the useful areas of science such as the development of new armament
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P14(x (log)) = {[p14]+([p22]=2)*2}
       эффект: P15(x1 (et)) = {[p15]-([p22]=6)-2+([p22]=2)}
       эффект: P17(x3 (pat)) +1
       эффект: P18(x4 (cin)) +1
  -> Path225 => Loc43  вер=1
       текст: Our policy will be to prioritise on the development of science!
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = {[p14]+2*([p22]=6)-([p22]<>8)-2+[p20]}
       эффект: P15(x1 (et)) = {[p15]+([p22]=6)-([p22]<>8)}
  -> Path226 => Loc43  вер=1 порядок=4
       текст: Everything will stay as it used to be - I can't see a point in changing anything
       эффект: P14(x (log)) = {[p14]-([p22]=6)}
       эффект: P15(x1 (et)) = {[p15]-([p22]=6)}
       эффект: P16(x2 (pop)) -1
       эффект: P19(x5 (cons)) +2
  -> Path227 => Loc43  вер=1 порядок=2
       текст: We will increase research fellows' and professors' salaries
       эффект: P14(x (log)) = {[p14]+([p22]=6)+[p20]-2}
       эффект: P15(x1 (et)) = {[p15]+([p22]=6)+[p20]-2}
       эффект: P16(x2 (pop)) +1
       эффект: P18(x4 (cin)) = {[p18]+[p20]-2}
  -> Path228 => Loc43  вер=1 порядок=6
       текст: Conducting our own research is a waste of time. It would be cheaper to steal from the neighbours, wouldn't it?
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]-[3..7]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = {[p14]-([p22]=6)*2+([p22]=4)}
       эффект: P15(x1 (et)) = {[p15]-2-([p22]=6)}
       эффект: P16(x2 (pop)) +1
       эффект: P17(x3 (pat)) -1
       эффект: P18(x4 (cin)) +2

### Loc69 [обычная]
    Loc69-1: Having answered the last question you dismissed the experts and nicely entertained yourself for the rest of the day... /  / In the evening the stereovision broa…
    эффект: P8(Gaals) = {[p8]+([p14]-5)+3*([p15]-5)-([p16]-5)-2*([p18]-5)+([p19]-5)}
    эффект: P9(Faes) = {[p9]+3*([p14]-5)+([p15]-5)-([p16]-5)+([p17]-5)}
    эффект: P10(Humans) = {[p10]-([p14]-5)+([p15]-5)+3*([p16]-5)+([p17]-5)+2*([p18]-5)-([p19]-5)}
    эффект: P11(Pelengs) = {[p11]-([p14]-5)-2*([p15]-5)+2*([p16]-5)-2*([p17]-5)+3*([p18]-5)}
    эффект: P12(Maloqs) = {[p12]-2*([p15]-5)-([p16]-5)+3*([p17]-5)-2*([p18]-5)+2*([p19]-5)}
  -> Path87 => Loc17  вер=1 порядок=5
       текст: Familiarise yourself with the data and get to bed
       эффект: P24(y5 (Chp)) = 0
       показ: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12

### Loc70 [обычная]
    Loc70-1: - At first you should select the costume and the background, - the image maker said. - What would you prefer?
  -> Path259 => Loc72  вер=1 проходов<=8
       текст: In ranger outfit at the backdrop of a spaceship
       эффект: P19(x5 (cons)) = {[p19]+[0..2]}
       эффект: P20(y1) = 1
  -> Path260 => Loc71  вер=1 проходов<=8 порядок=1
       текст: In a scientist robe at the backdrop of a lab
       эффект: P16(x2 (pop)) = {[p16]+[0..2]}
       эффект: P20(y1) = 2
  -> Path261 => Loc75  вер=1 проходов<=8 порядок=2
       текст: In army uniform at the backdrop of a plasmotank
       эффект: P15(x1 (et)) = {[p15]-[0..1]}
       эффект: P16(x2 (pop)) = {[p16]-[0..1]}
       эффект: P18(x4 (cin)) = {[p18]-[0..1]}
       эффект: P19(x5 (cons)) = {[p19]+[1..4]}
       эффект: P20(y1) = 3
  -> Path262 => Loc76  вер=1 проходов<=8 порядок=9
       текст: In white doctor's gown with a syringe in hand at the backdrop of a ward
       эффект: P15(x1 (et)) = {[p15]+[0..1]}
       эффект: P18(x4 (cin)) = {[p18]+[0..1]}
       эффект: P20(y1) = 8
  -> Path263 => Loc74  вер=1 проходов<=8 порядок=4
       текст: In sporting outfit at the backdrop of a stadium
       эффект: P16(x2 (pop)) = {[p16]-[0..2]}
       эффект: P17(x3 (pat)) = {[p17]+[0..2]}
       эффект: P19(x5 (cons)) = {[p19]+[0..2]}
       эффект: P20(y1) = 4
  -> Path264 => Loc78  вер=1 проходов<=8 порядок=5
       текст: In business suit at the backdrop of skyscrapers
       эффект: P17(x3 (pat)) = {[p17]+[1..3]}
       эффект: P18(x4 (cin)) = {[p18]+[0..2]}
       эффект: P19(x5 (cons)) = {[p19]-[1..3]}
       эффект: P20(y1) = 5
  -> Path265 => Loc77  вер=1 проходов<=8 порядок=8
       текст: In builder's outfit at the backdrop of recent projects
       эффект: P15(x1 (et)) = {[p15]+[0..2]}
       эффект: P20(y1) = 7
  -> Path266 => Loc73  вер=1 проходов<=8 порядок=7
       текст: In Hawaiian shirt with golden chain at the backdrop of an luxury restaurant
       эффект: P17(x3 (pat)) = {[p17]+[0..2]}
       эффект: P18(x4 (cin)) = {[p18]+[1..3]}
       эффект: P19(x5 (cons)) = {[p19]-[1..3]}
       эффект: P20(y1) = 6

### Loc71 [обычная] визитов<=8
    Loc71-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path270 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]+(-2*[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-[p21] to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(-[p21] to 2*[p21])}
  -> Path299 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path307 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path315 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(0 to 2*[p21])}
  -> Path323 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(3*[p21] to 7*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path331 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path334 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path357 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}

### Loc72 [обычная] визитов<=8
    Loc72-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path271 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]-(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(-[p21] to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path300 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-[p21] to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(-[p21] to [p21])}
  -> Path308 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path316 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-2*[p21] to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-2*[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path324 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to [p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path332 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path333 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path356 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]-(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}

### Loc73 [обычная] визитов<=8
    Loc73-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path274 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path295 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]-(2*[p21] to 5*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(3*[p21] to 7*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}
  -> Path303 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path311 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path319 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(3*[p21] to 7*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path327 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path338 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(1 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path361 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}

### Loc74 [обычная] визитов<=8
    Loc74-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path273 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path297 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path305 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path313 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path321 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path329 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]-(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 23*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path340 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]-(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path359 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}

### Loc75 [обычная] визитов<=8
    Loc75-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path272 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-[p21] to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path298 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]-(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(3*[p21] to 7*[p21])}
  -> Path306 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path314 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]-(1 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(1 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(1 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(1 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(3*[p21] to 7*[p21])}
  -> Path322 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(3*[p21] to 7*[p21])}
  -> Path330 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]-(2*[p21] to 5*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(3*[p21] to 7*[p21])}
  -> Path335 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]-(1 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(1 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(1 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(3*[p21] to 7*[p21])}
  -> Path358 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}

### Loc76 [обычная] визитов<=8
    Loc76-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path269 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path293 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(3*[p21] to 7*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}
  -> Path301 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]-(-[p21] to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(-[p21] to [p21])}
  -> Path309 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(1 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]+(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(-[p21] to [p21])}
  -> Path317 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path325 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(2*[p21] to 5*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path336 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path363 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(1 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(3*[p21] to 7*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}

### Loc77 [обычная] визитов<=8
    Loc77-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path268 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]-(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]+(2*[p21] to 5*[p21])}
  -> Path294 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(0 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(0 to 2*[p21])}
  -> Path302 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]-(-2*[p21] to [p21])}
  -> Path310 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(2*[p21] to 5*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path318 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]-(0 to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(0 to [p21])}
  -> Path326 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(0 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(-[p21] to [p21])}
  -> Path337 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(-[p21] to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(-[p21] to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+([p21] to 3*[p21])}
  -> Path362 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]+(2*[p21] to 5*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(1 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(1 to 2*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}

### Loc78 [обычная] визитов<=8
    Loc78-1: - Fine! - exclaimed the image maker, after he had given necessary orders to make-up artists, costume designers and set dressers. - Now the only thing left for u…
  -> Path267 => Loc79  вер=1 проходов<=1 порядок=9
       текст: Kill Dominators, save the Galaxy!
       эффект: P15(x1 (et)) = {[p15]+(0 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]-(-[p21] to [p21])}
       эффект: P18(x4 (cin)) = {[p18]-(-[p21] to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]+(-[p21] to [p21])}
  -> Path296 => Loc86  вер=1 проходов<=1 порядок=4
       текст: Let's give happiness to the population!!!
       эффект: P15(x1 (et)) = {[p15]-(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path304 => Loc85  вер=1 проходов<=1 порядок=1
       текст: We protect freedom!
       эффект: P15(x1 (et)) = {[p15]+([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+([p21] to 3*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}
  -> Path312 => Loc83  вер=1 проходов<=1
       текст: Vote with your heart!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-[p21] to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}
  -> Path320 => Loc84  вер=1 проходов<=1 порядок=7
       текст: Bread and circuses!
       эффект: P15(x1 (et)) = {[p15]+(-[p21] to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to 2*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]-(-[p21] to [p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path328 => Loc81  вер=1 проходов<=1 порядок=8
       текст: We will maintain order!
       эффект: P15(x1 (et)) = {[p15]+(1 to 2*[p21])}
       эффект: P16(x2 (pop)) = {[p16]+(-[p21] to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+([p21] to 3*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(1 to 2*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path339 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Protect our children!
       эффект: P15(x1 (et)) = {[p15]-([p21] to 3*[p21])}
       эффект: P16(x2 (pop)) = {[p16]-([p21] to 3*[p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-([p21] to 3*[p21])}
  -> Path360 => Loc82  вер=1 проходов<=1 порядок=5
       текст: Live better, be happy!
       эффект: P15(x1 (et)) = {[p15]+(0 to [p21])}
       эффект: P16(x2 (pop)) = {[p16]-(0 to [p21])}
       эффект: P17(x3 (pat)) = {[p17]+(2*[p21] to 5*[p21])}
       эффект: P18(x4 (cin)) = {[p18]+(2*[p21] to 5*[p21])}
       эффект: P19(x5 (cons)) = {[p19]-(2*[p21] to 5*[p21])}

### Loc79 [обычная]
    выбор описания: {[p20]}
    Loc79-1: Space ranger outfit nicely matched the slogan which you uttered, but together they looked more like an advertisement of a rangers' centre, than of a presidentia…
    Loc79-2: The scientist's gown didn't match the militantly slogan that you uttered, and thus the voters' reactions didn't please you...
    Loc79-3: Military uniform and a militant slogan - that's all you need to attract the <clr>Maloqs<clrEnd>! <clr>The Humans<clrEnd> also liked your efforts, only the pacif…
    Loc79-4: It were just the <clr>Maloqs<clrEnd> who enjoyed the profundity of your ad spot - a war against Dominators requires a good body shape!!! The others acknowledged…
    Loc79-5: Your advertisement didn't reach the minds of your voters - it was that your either wanted to wage an economic war against Dominators, or these were the galaxy o…
    Loc79-6: In this fit-to-drink outfit your slogan reminded rather a toast than a serious slogan. And this genre is popular only among the <clr>Humans, Gaals<clrEnd> and <…
    Loc79-7: Your voters' reaction to your ad was very distressing, - the militant slogan didn't match the peaceful outfit of a builder at all. Only the <clr>Maloqs<clrEnd> …
    Loc79-8: Your ad was not that effective. As the polls showed, the dressed in white doctor reminded the population of huge losses that the coalition has recently suffered…
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path276 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path284 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc80 [обычная]
    выбор описания: {[p20]}
    Loc80-1: The idea to protect children from the Dominator threat was understandable to all races, so that your ad was not an alien thing to them all. The only thing is th…
    Loc80-2: Knowledge means protection from troubles of all kind! The journalists interpreted your slogan in this way, and that position gained full support among the <clr>…
    Loc80-3: If you aimed at gaining the support of the <clr>Maloqs<clrEnd>, you pushed the right button! The image of a defender found support among the <clr>Humans<clrEnd>…
    Loc80-4: Protect our children from rachitis - this was how the smart-heads from the local stereovision office paraphrased your slogan. The ad turned out to be rather stu…
    Loc80-5: The fact that the best protection for one's offspring can be obtained by means of a substantial bank account was long crystal clear to the <clr>Humans<clrEnd> a…
    Loc80-6: One could not imagine a more idiotic combination of the outfit, backdrop and the slogan! Even the <clr>Pelengs<clrEnd> realised that after spending the night at…
    Loc80-7: Your ad turned out to be rather unclear: no one could understand whether you were hinting at the possible construction of bomb shelters, or just urged to protec…
    Loc80-8: Children are the ones who get sick most of all, and therefore the doctors should be the category of the population that should dedicate all the efforts to the p…
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path283 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path288 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc81 [обычная]
    выбор описания: {[p20]}
    Loc81-1: Your canvassing was very well accepted by the <clr>Maloqs<clrEnd> (rangers bravely fight Dominators), by the <clr>Humans<clrEnd> (ranger are good traders and fo…
    Loc81-2: The scientists in the role of law enforcement officers were laughed at by everyone, except the <clr>Faes<clrEnd> and the <clr>Gaals<clrEnd>, who tried to prove …
    Loc81-3: Rare ad had been the cause of such a vivid public response. The <clr>Maloqs<clrEnd> announced that you were their national hero, and <clr>Peleng<clrEnd> pirates…
    Loc81-4: The ad turned out to be ineffective. Why should sportsmen maintain the order? Is this a hint at the racketeers, whose 'army' ranks isn't thinning off thanks to …
    Loc81-5: "Hucksters will get everything under control!" - this conclusion drawn from your ad was the most popular joke among the <clr>Maloqs<clrEnd>. But the <clr>Humans…
    Loc81-6: The ad turned out to be very unsuccessful - only the <clr>Pelengs<clrEnd> endorsed the idea of bandit law and order. All the rest of them were highly disappoint…
    Loc81-7: Why should the builders restore order? Will they build more new jails, is that what you meant? No one liked your ad - the voters were confused.
    Loc81-8: Your ad provoked vivid disputes among the public. Everyone decided that you are hinting at the development of new technologies of genetic selection and cloning …
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path281 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path290 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc82 [обычная]
    выбор описания: {[p20]}
    Loc82-1: The polls showed that the ranger life was associated with merry times only among the <clr>Humans<clrEnd> and the <clr>Pelengs<clrEnd>. All the other races were …
    Loc82-2: <clr>The Pelengs<clrEnd> and <clr>the Maloqs<clrEnd> find very little fun in the work of scientists, therefore they did not like your ad. The races of high inte…
    Loc82-3: If you possess a plasmatank, you can have fun the way you like - this is well known to every <clr>Peleng<clrEnd> and <clr>Maloq<clrEnd>, as well as <clr>Human<c…
    Loc82-4: Sport as a means of entertainment and staying fit is honoured by all races, except the <clr>Faes<clrEnd>, which reflected in your ratings.
    Loc82-5: Improvement of the life standards thanks to the efforts of the big business has long been supported by <clr>Humans<clrEnd> and <clr>Pelengs<clrEnd>, but the <cl…
    Loc82-6: The sight of a merry life that was sprawling from your ad, was much to the liking of the <clr>Humans<clrEnd> and <clr>Pelengs<clrEnd>, but the <clr>Maloqs <clrE…
    Loc82-7: The idea of constructing a better life was fully backed by the <clr>Gaals<clrEnd>, and partly - by the <clr>Humans<clrEnd> and <clr>Faes<clrEnd>. But the <clr>M…
    Loc82-8: Everyone knows what kind of narcotic fun can a syringe deliver. But only <clr>Pelengs<clrEnd> fully welcome the idea...
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path282 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path289 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc83 [обычная]
    выбор описания: {[p20]}
    Loc83-1: Where is a ranger's heart? You're right - in his spaceship. And voters' interests are mainly on <ToPlanet>. That was why your spot turned out to be totally inef…
    Loc83-2: Your spot in general won the hearts of the <clr>Faes<clrEnd>, the <clr>Gaals<clrEnd> and <clr>Humans<clrEnd> were also more or less pleased. It's only the stupi…
    Loc83-3: The hearts of the <clr>Maloqs<clrEnd> are yours forever after such an ad! The Humans also treated this kind of ad benevolently, only the peace-loving <clr>Faes<…
    Loc83-4: "Trained body means healthy heart. And healthy heart is your right choice!" - this was the comment of the leading sports editions caused by your ad. Such positi…
    Loc83-5: What can be closer to <clr>Human<clrEnd> and <clr>Peleng<clrEnd> hearts than money? Big money! But the <clr>Maloqs<clrEnd> were insulted by your ad - this simpl…
    Loc83-6: It would have been appropriate if you wrote: "Vote with your liver!" - this conclusion was drawn by the participants of the "Justice and All" talk show with Har…
    Loc83-7: The idea of honest and constructive labour suited the tastes of everyone liking, but lazy <clr>Pelengs<clrEnd> and militaristic <clr>Maloqs<clrEnd>.
    Loc83-8: The doctor's mouth requesting everyone to vote with their heart was understood by many electors too literally, so that most of them could not easily comprehend …
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path280 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path291 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc84 [обычная]
    выбор описания: {[p20]}
    Loc84-1: The slogan that the Humans invented in the days of yore remains popular among this race even now. One should also acknowledge that rangers often trade with food…
    Loc84-2: <clr>Faeyan<clrEnd> media devoted multifaceted praise to your ad - and really, who can give bread and games to the masses but the scientists?! <clr>Gaals<clrEnd…
    Loc84-3: <clr>Maloqs<clrEnd> were besides themselves: a war is the main bread and games for the real warriors! Among the <clr>Humans<clrEnd> and <clr>Pelengs<clrEnd> the…
    Loc84-4: The popularity of sport championships among the <clr>Humans, Maloqs<clrEnd> and <clr>Pelengs<clrEnd> was high enough, so that your ad brought you some of their …
    Loc84-5: Your ad turned out to be rather popular among the <clr>Humans<clrEnd>, there were a lot of them who sincerely believed that only business people can feed the po…
    Loc84-6: The sight of a boozed guy, enjoying his time in a bar, accompanied by a bourgeois slogan only caused the disgust of most of the electors. <clr>Gaals<clrEnd> acc…
    Loc84-7: Your ad provoked a vivid discussion among gaalian philosophers, which was titled "Can Earning Your Bread by Toil and Moil Be a Show?" The multitude thought that…
    Loc84-8: Your ad was interpreted differently by various races. <clr>Pelengs, Maloqs, Humans<clrEnd> and <clr>Gaals<clrEnd> decided that you are hinting at the legalizati…
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path279 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path292 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc85 [обычная]
    выбор описания: {[p20]}
    Loc85-1: Rangers are the real defenders of the Free Galaxy from the Dominator invasion. No one was against this, but the inhabitants of <ToPlanet> had more vital problem…
    Loc85-2: A sickly scientist playing the role of a defender of rights and freedoms looked rather comic. Anyway the <clr>Maloqs<clrEnd> and <clr>Pelengs<clrEnd> made a lau…
    Loc85-3: "Looks more like the freedom is in need to be protected from you!" - <clr>gaalian<clrEnd> rights activists were jeering.  /  / "Right! - echoed the <clr>Peleng<…
    Loc85-4: What did you mean to say, claiming that the sportsmen are the defenders of freedom. Your voters could not unravel this phrase-mystery anyhow. The <clr>Faes<clrE…
    Loc85-5: "Entrepreneurial freedom - this is the backbone of any planet's prosperity!" - thus <clr>Human<clrEnd> newspapers interpreted your ad, and only the <clr>Maloqs<…
    Loc85-6: The appearance of a mafioso, who apparently was wanted in the cooler, was in such a dissonant with the slogans to protect the freedom, that your ad was an absol…
    Loc85-7: "What's in that?!" - electors could not understand, looking at a vigorous builder, who was defending freedom with a trowel and a plumb. Complete meaninglessness…
    Loc85-8: Why a doctor should be standing up to the cause of defending freedom was beyond the understanding of the most of your electors. The fact that your ad was illogi…
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path278 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path287 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc86 [обычная]
    выбор описания: {[p20]}
    Loc86-1: The logic of your ad was unclear - how come rangers could bring happiness for the population? Or did you mean those products that were smuggled by the rangers t…
    Loc86-2: Your ad found a vivid response in the hearts of the <clr>Faes, Gaals<clrEnd> and <clr>Humans<clrEnd> - really, the scientists will give happiness to the populat…
    Loc86-3: The idea of happiness built by bayonets sympathised only the <clr>Maloqs<clrEnd>. All the rest remained sceptical to this kind of "happiness"...
    Loc86-4: "Happiness is your health!" - that was the general comment that your ad found among <ToPlanet>' mass media. This approach was supported by the <clr>Maloqs, Huma…
    Loc86-5: Gaining happiness by means of profitable trade bargains totally matched the mentality of the <clr>Humans<clrEnd> and <clr>Pelengs<clrEnd>, but the <clr>Maloqs<c…
    Loc86-6: "We will give happiness to the people, but we will steal it from them before!" - this was how <clr>Gaalian<clrEnd> and <clr>Faeyan<clrEnd> newspapers interprete…
    Loc86-7: The idea of building happiness with own hands caught everyone's fancy. Even the <clr>Maloqs<clrEnd> remained pleased, for they thought that you were hinting at …
    Loc86-8: The promise to give happiness to the population pronounced with a needle in your hand was understood unambiguously. But meanwhile the <clr>Pelengs<clrEnd> suppo…
    эффект: P8(Gaals) = {[p8]+[p15]-50}
    эффект: P9(Faes) = {[p9]+[p16]-50}
    эффект: P10(Humans) = {[p10]+[p17]-50}
    эффект: P11(Pelengs) = {[p11]+[p18]-50}
    эффект: P12(Maloqs) = {[p12]+[p19]-50}
  -> Path277 => Loc87  вер=1 порядок=5
       текст: Go for lunch
       условия: P14(x (log)) ∈[0]
  -> Path286 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       условия: P14(x (log)) ∈[1]

### Loc87 [пустая]
  -> Path275 => Loc27  вер=1 порядок=5
       условия: P14(x (log)) ∈[0]
       эффект: P23(y4) = 6
  -> Path285 => Loc26  вер=1 порядок=5
       условия: P14(x (log)) ∈[1]
       эффект: P23(y4) = 2

### Loc88 [пустая]
  -> Path346 => Loc89  вер=1 порядок=5
       эффект: P14(x (log)) = {[1..100]}

### Loc89 [обычная]
    Loc89-1: Within several minutes Kill Young brought you the activities list for. Where do you want to go?
  -> Path347 => Loc27  вер=1 порядок=9
       текст: I changed my mind, we will not go to speak with the crowd today!
       эффект: P23(y4) = 7
  -> Path348 => Loc96  вер=1 порядок=7
       текст: To the military plant
       условия: P14(x (log)) 1..59
  -> Path349 => Loc92  вер=1 проходов<=1 порядок=2
       текст: To iike-baana exhibition
       условия: P14(x (log)) кратно[13]
  -> Path350 => Loc90  вер=1 проходов<=1 порядок=3
       текст: To hatchball match
       условия: P14(x (log)) кратно[5]
  -> Path351 => Loc91  вер=1 порядок=4
       текст: To antiwar rally
       условия: P14(x (log)) кратно[3]
  -> Path352 => Loc93  вер=1 порядок=6
       текст: To a local garrison
       условия: P14(x (log)) некратно[2]
  -> Path353 => Loc94  вер=1 порядок=8
       текст: To the nearest prison
       условия: P14(x (log)) 41..100
  -> Path354 => Loc95  вер=1 проходов<=1
       текст: To fairy-tale amusement park
       условия: P14(x (log)) кратно[11]
  -> Path355 => Loc97  вер=1 порядок=5
       текст: To the meeting with university students
       условия: логика {([p14]<20) or ([p14]>80)}
  -> Path366 => Loc98  вер=1 проходов<=1 порядок=1
       текст: To Lyapzva Hiz xenopark
       условия: P14(x (log)) кратно[7]

### Loc90 [пустая] визитов<=1
  -> Path408 => Loc103  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[-1..2]}
       эффект: P14(x (log)) = 1
  -> Path409 => Loc103  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]-[0..1]}
       эффект: P9(Faes) = {[p9]-[0..1]}
       эффект: P10(Humans) = {[p10]-[2..5]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]+[0..1]}
       эффект: P14(x (log)) = 2
  -> Path410 => Loc103  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]-[0..1]}
       эффект: P9(Faes) = {[p9]-[0..1]}
       эффект: P10(Humans) = {[p10]+[3..7]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P12(Maloqs) = {[p12]+[0..1]}
       эффект: P14(x (log)) = 3

### Loc91 [пустая]
  -> Path387 => Loc102  вер=3 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = 1
  -> Path388 => Loc102  вер=3 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = 2
  -> Path389 => Loc102  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[0..1]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]+[0..2]}
       эффект: P14(x (log)) = 3
  -> Path398 => Loc102  вер=2 порядок=5
       условия: P8(Gaals) 0..25
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[0..2]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = 4

### Loc92 [пустая] визитов<=1
  -> Path411 => Loc105  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 1
  -> Path412 => Loc105  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[0..1]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P11(Pelengs) = {[p11]-[0..1]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
       эффект: P14(x (log)) = 2
  -> Path414 => Loc105  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]+[3..7]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = 3

### Loc93 [пустая]
  -> Path404 => Loc101  вер=2 порядок=5
       условия: P12(Maloqs) 30..100
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P14(x (log)) = 1
  -> Path405 => Loc101  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]-[-1..1]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[3..7]}
       эффект: P14(x (log)) = 2
  -> Path406 => Loc101  вер=3 порядок=5
       эффект: P8(Gaals) = {[p8]-[-1..1]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[-1..1]}
       эффект: P11(Pelengs) = {[p11]-[-1..1]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
       эффект: P14(x (log)) = 3
  -> Path407 => Loc101  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]+[-1..1]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 4

### Loc94 [пустая]
  -> Path390 => Loc104  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[3..7]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 1
  -> Path391 => Loc104  вер=2 порядок=5
       условия: P12(Maloqs) 0..20
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P14(x (log)) = 2
  -> Path392 => Loc104  вер=2 порядок=5
       условия: P11(Pelengs) 0..30
       эффект: P11(Pelengs) = {[p11]-[1..3]}
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[1..3]}
       эффект: P14(x (log)) = 3
  -> Path393 => Loc104  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]+[0..1]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = 4

### Loc95 [пустая] визитов<=1
  -> Path384 => Loc106  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = 1
  -> Path385 => Loc106  вер=3 порядок=5
       условия: P12(Maloqs) 0..45
       эффект: P12(Maloqs) = {[p12]+[3..7]}
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]-[2..5]}
       эффект: P14(x (log)) = 2
  -> Path386 => Loc106  вер=3 порядок=5
       условия: P8(Gaals) 0..40; P9(Faes) 0..40
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]-[0..2]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 3

### Loc96 [пустая]
  -> Path400 => Loc100  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]+[-1..1]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = 1
  -> Path401 => Loc100  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[0..2]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = 2
  -> Path402 => Loc100  вер=2 порядок=5
       эффект: P8(Gaals) = {[p8]-[2..5]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[-1..2]}
       эффект: P11(Pelengs) = {[p11]-[-1..2]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = 3
  -> Path403 => Loc100  вер=2 порядок=5
       условия: P12(Maloqs) 0..25
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P8(Gaals) = {[p8]-[-1..1]}
       эффект: P9(Faes) = {[p9]+[0..1]}
       эффект: P10(Humans) = {[p10]+[0..1]}
       эффект: P11(Pelengs) = {[p11]+[0..1]}
       эффект: P14(x (log)) = 4

### Loc97 [пустая]
  -> Path369 => Loc99  вер=3 порядок=5
       условия: P8(Gaals) 0..50; P9(Faes) 0..50; P10(Humans) 0..50
       эффект: P8(Gaals) = {[p8]+[0..1]}
       эффект: P9(Faes) = {[p9]+[0..1]}
       эффект: P10(Humans) = {[p10]+[0..1]}
       эффект: P11(Pelengs) = {[p11]+[0..1]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 1
  -> Path370 => Loc99  вер=1 порядок=5
       эффект: P8(Gaals) = {[p8]+[0..2]}
       эффект: P9(Faes) = {[p9]+[0..2]}
       эффект: P10(Humans) = {[p10]+[0..2]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 2
  -> Path371 => Loc99  вер=3 порядок=5
       условия: P8(Gaals) 40..100; P9(Faes) 40..100; P10(Humans) 40..100
       эффект: P8(Gaals) = {[p8]+[2..5]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P10(Humans) = {[p10]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[0..2]}
       эффект: P12(Maloqs) = {[p12]-[2..5]}
       эффект: P14(x (log)) = 3
  -> Path372 => Loc99  вер=2 порядок=5
       условия: P8(Gaals) 0..50; P9(Faes) 0..50; P10(Humans) 0..50; P11(Pelengs) 70..100; P12(Maloqs) 0..50
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]-[0..2]}
       эффект: P11(Pelengs) = {[p11]+[5..10]}
       эффект: P12(Maloqs) = {[p12]-[1..3]}
       эффект: P14(x (log)) = 4
  -> Path373 => Loc99  вер=3 порядок=5
       условия: P8(Gaals) 20..80; P9(Faes) 20..80; P10(Humans) 20..80; P11(Pelengs) 20..80; P12(Maloqs) 20..80
       эффект: P8(Gaals) = {[p8]+[0..2]}
       эффект: P9(Faes) = {[p9]+[-2..1]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[-2..1]}
       эффект: P14(x (log)) = 5
  -> Path374 => Loc99  вер=3 порядок=5
       условия: P8(Gaals) 0..20
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]+[1..3]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = 6
  -> Path375 => Loc99  вер=3 порядок=5
       условия: P8(Gaals) 0..70; P9(Faes) 0..70; P10(Humans) 0..70; P11(Pelengs) 0..70; P12(Maloqs) 70..100
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]+[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P11(Pelengs) = {[p11]-[0..2]}
       эффект: P12(Maloqs) = {[p12]+[2..5]}
       эффект: P14(x (log)) = 7

### Loc98 [пустая] визитов<=1
  -> Path396 => Loc107  вер=1 порядок=5
       условия: P11(Pelengs) 20..100
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P8(Gaals) = {[p8]-[0..2]}
       эффект: P9(Faes) = {[p9]-[1..3]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[0..2]}
       эффект: P14(x (log)) = 1
  -> Path397 => Loc107  вер=1 порядок=5
       условия: P8(Gaals) 0..50; P10(Humans) 0..50
       эффект: P8(Gaals) = {[p8]-[1..3]}
       эффект: P10(Humans) = {[p10]-[1..3]}
       эффект: P9(Faes) = {[p9]+[2..5]}
       эффект: P11(Pelengs) = {[p11]+[2..5]}
       эффект: P12(Maloqs) = {[p12]+[-1..1]}
       эффект: P14(x (log)) = 2
  -> Path399 => Loc107  вер=1 порядок=5
       условия: P11(Pelengs) 0..30
       эффект: P11(Pelengs) = {[p11]+[-1..1]}
       эффект: P8(Gaals) = {[p8]+[1..3]}
       эффект: P9(Faes) = {[p9]-[0..2]}
       эффект: P10(Humans) = {[p10]+[1..3]}
       эффект: P12(Maloqs) = {[p12]-[0..2]}
       эффект: P14(x (log)) = 3

### Loc99 [обычная]
    выбор описания: {[p14]}
    Loc99-1: You were not so popular among the <clr>Humans, Faes<clrEnd> and <clr>Gaals<clrEnd> - the majority of the university students. Therefore, your conference was not…
    Loc99-2: You were not lucky: a hyper-rock concert was taking place simultaneously with your conference, and the bulk of the student was there. But anyway the conversatio…
    Loc99-3: It turned out that you were rather popular among the students, the best part of whom were the <clr>Humans, Faes<clrEnd> and <clr>Gaals<clrEnd>. The crowd that c…
    Loc99-4: It looked like you were a cult figure among <clr>Peleng<clrEnd> youth, and they were the main crowd who agreed to meet you. Your popularity among the other race…
    Loc99-5: Your meeting did not provoke any boom, but it was not ignored anyway. The hall was full of members of different races and in your responses to student's questio…
    Loc99-6: Your low popularity among the Gaals, who comprised the bulk of the university higher officers played you a bad trick. At the very beginning they deliberately co…
    Loc99-7: To your surprise your meeting was attended by a lot of Maloqs - it seems that you are very popular among them. This realisation played its part in your meeting …
  -> Path368 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc100 [обычная]
    выбор описания: {[p14]}
    Loc100-1: You became a professional ranger when you were visiting a military plant. You criticised the spaceship cannons produced by the plant as if you were an expert. "…
    Loc100-2: You were courteous to the max during your tour of the plant - you praised their production procedures and the standard of the equipment, having thus pleased the…
    Loc100-3: During your visit to the plant you solemnly promised to make more military awards and appropriate substantial funds for the development of new military technolo…
    Loc100-4: The visit to the plant was sabotaged - hostile <clr>Maloq<clrEnd> board of directors ordered not to let you in!  /  / "Stupid soldiery!" - you were shouting in …
  -> Path383 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc101 [обычная]
    выбор описания: {[p14]}
    Loc101-1: You seem to be honoured by the military - they organised a military parade and a muster of combat vehicles. You expressed your delight regarding the garrison's …
    Loc101-2: Luck was not on your sight - all the military personnel was engaged in a drill during your visit. Enraged, you blew off steam at the face of a Maloq general: hi…
    Loc101-3: The visit of the garrison was going rather routinely: you were let through all the rooms, showed the garrison's banner and the Regulations Study Room, after whi…
    Loc101-4: There was a picket line in front of the entry control point comprised of the <clr>Human and Other Mammal Rights Backers and Quarter-backers Committee<clrEnd>. T…
  -> Path380 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc102 [обычная]
    выбор описания: {[p14]}
    Loc102-1: Speaking at an antiwar rally, you solemnly promised that in case you win the elections the defence spending will be cut sharply, and the funds saved will be dir…
    Loc102-2: Speaking at an antiwar rally, you stated that the planet <ToPlanet> does not need its own space fleet. Although the <ToPlanet> planet never maintained its own s…
    Loc102-3: You arrived when the rally had already started and missed the addresses of the first speakers. Therefore, when you promised to cut the army by the third it was …
    Loc102-4: You were stupid enough to arrive at an antiwar rally clothed in ranger's clothes. Where your image makers were looking after all?! As a result of this the crowd…
  -> Path377 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc103 [обычная]
    выбор описания: {[p14]}
    Loc103-1: You visited a hatch-ball match. The action did not interest you but you fearlessly spent all the 6 rounds at the stands. The <clr>Humans<clrEnd> and <clr>Peleng…
    Loc103-2: During a hatch-ball match between the Humans and the Pelengs you suddenly remembered that your rival Abu Linkoln Husseyn is a Human. So you started to actively …
    Loc103-3: Today the stadium saw a principle battle between the Human and the Peleng teams. It so happened that the first of them was wearing the colours of your home plan…
  -> Path381 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc104 [обычная]
    выбор описания: {[p14]}
    Loc104-1: You were somewhat surprised that the bulk of the jail inmates was comprised of the <clr>Humans<clrEnd> and <clr>Pelengs<clrEnd>. Your promise to announce a pres…
    Loc104-2: Unfortunately the prison governor, a Maloq, refused to let you in! Well, public poll analysts were rightly urging you to improve your positions among this race.…
    Loc104-3: Someone from the first cells threw a lump of stingy swamp mud at you - that's what means a low popularity among the Pelengs! You decided to see no more cells af…
    Loc104-4: Today you visited that part of the prison where the state prisoners were confined - mainly <clr>Humans<clrEnd> and <clr>Gaals<clrEnd>. You promised to liberalis…
  -> Path378 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc105 [обычная]
    выбор описания: {[p14]}
    Loc105-1: You spent some time wandering about the exhibition halls, expressing your delight concerning the Gaalian iike-baanas, in which you did not understand a thing. T…
    Loc105-2: Walking around the exhibition halls, you were so vividly expressing your admiration towards the iike-baanas, that you subconsciously touched one and broke it do…
    Loc105-3: During the tour around the hall you became so lyrical that promised to make the art of making iike-baanas a mandatory part of school program in case you are ele…
  -> Path379 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc106 [обычная]
    выбор описания: {[p14]}
    Loc106-1: You decided to relax and visited a local fairy-tale amusement park. You were getting fun as a child the whole night: riding on the merry-go-round, wandering in …
    Loc106-2: You decided to relax and visited a local fairy-tale amusement park. But soon you got sick and tired of just walking around the tree-lined paths and of riding on…
    Loc106-3: Walking around the fairy-tale amusement park, you decided to mix business with pleasure and improve your rating among the <clr>Faes<clrEnd> and <clr>Gaals<clrEn…
  -> Path376 => Loc87  вер=1 порядок=5
       текст: Further
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc107 [обычная]
    выбор описания: {[p14]}
    Loc107-1: The officers spent the whole night introducing you to the xenopark. Looking at the animals of all types you were vividly expressing your admiration. In doing so…
    Loc107-2: An unpleasant incident occurred in front of the xenopark - picketers from Animal Rights Organisation (mainly - <clr>Gaals<clrEnd> and <clr>Humans<clrEnd>) pelte…
    Loc107-3: You were not so popular among the <clr>Pelengs<clrEnd>, owners of the xenopark, therefore they did not provide any special service during your visit to the park…
  -> Path382 => Loc87  вер=1 порядок=5
       текст: Return to the hotel
       эффект: P14(x (log)) = {1}
       эффект: P23(y4) = 2

### Loc108 [СМЕРТЬ]
    Loc108-1: - Cool, we have equal votes! - you exclaimed. - Does this mean that we both won? /  / - No! - Kill Young answered, trying to get away from you ASAP. - This mean…

### Loc109 [обычная]
    Loc109-1: - Well, what is there to say?, Kill Young said surprisedly. <ToPlanet> is a typical marginal little planet that tries hard to make a name for itself. To be hone…
  -> Path417 => Loc22  вер=1 порядок=1
       текст: Ok, guys, see you all tomorrow, it's time for me to sleep!
  -> Path419 => Loc20  вер=1 порядок=5
       текст: Strange that such a warm post is claimed by only two candidates. What's wrong?
       условия: P27(Question) кратно[2]

## Анализ
- стартовых: [13]
- концовки: {11: 'СМЕРТЬ', 21: 'ПРОВАЛ', 23: 'ПРОВАЛ', 24: 'УСПЕХ', 25: 'СМЕРТЬ', 108: 'СМЕРТЬ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
