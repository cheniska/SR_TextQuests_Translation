# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 '1st judge' [1..10] тип=обычный
    старт: [1..5]
    [1..1] 1st judge: <clr>Maloq<clrEnd>
    [2..2] 1st judge: <clr>Peleng<clrEnd>
    [3..3] 1st judge: <clr>Human<clrEnd>
    [4..4] 1st judge: <clr>Faeyan<clrEnd>
    [5..5] 1st judge: <clr>Gaalian<clrEnd>
    [6..6] 1st judge: <clr>Maloq<clrEnd>, rate [p2]
    [7..7] 1st judge: <clr>Peleng<clrEnd>, rate [p2]
    [8..8] 1st judge: <clr>Human<clrEnd>, rate [p2]
    [9..9] 1st judge: <clr>Faeyan<clrEnd>, rate [p2]
    [10..10] 1st judge: <clr>Gaalian<clrEnd>, rate [p2]
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Rate 1' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 20
- P3 '2nd judge' [1..10] тип=обычный
    старт: [1..5]
    [1..1] 2nd judge: <clr>Maloq<clrEnd>
    [2..2] 2nd judge: <clr>Peleng<clrEnd>
    [3..3] 2nd judge: <clr>Human<clrEnd>
    [4..4] 2nd judge: <clr>Faeyan<clrEnd>
    [5..5] 2nd judge: <clr>Gaalian<clrEnd>
    [6..6] 2nd judge: <clr>Maloq<clrEnd>, rate [p4]
    [7..7] 2nd judge : <clr>Peleng<clrEnd>, rate [p4]
    [8..8] 2nd judge : <clr>Human<clrEnd>, rate [p4]
    [9..9] 2nd judge : <clr>Faeyan<clrEnd>, rate [p4]
    [10..10] 2nd judge : <clr>Gaalian<clrEnd>, rate [p4]
    критическое: Сообщение достижения критического значения параметром 2
- P4 'Rate 2' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 21
- P5 '3rd judge' [1..10] тип=обычный
    старт: [1..5]
    [1..1] 3rd judge: <clr>Maloq<clrEnd>
    [2..2] 3rd judge: <clr>Peleng<clrEnd>
    [3..3] 3rd judge: <clr>Human<clrEnd>
    [4..4] 3rd judge: <clr>Faeyan<clrEnd>
    [5..5] 3rd judge: <clr>Gaalian<clrEnd>
    [6..6] 3rd judge: <clr>Maloq<clrEnd>, rate [p6]
    [7..7] 3rd judge: <clr>Peleng<clrEnd>, rate [p6]
    [8..8] 3rd judge: <clr>Human<clrEnd>, rate [p6]
    [9..9] 3rd judge: <clr>Faeyan<clrEnd>, rate [p6]
    [10..10] 3rd judge: <clr>Gaalian<clrEnd>, rate [p6]
    критическое: Сообщение достижения критического значения параметром 3
- P6 'Rate 3' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 22
- P7 '4th judge' [1..10] тип=обычный
    старт: [1..5]
    [1..1] 4th judge: <clr>Maloq<clrEnd>
    [2..2] 4th judge: <clr>Peleng<clrEnd>
    [3..3] 4th judge: <clr>Human<clrEnd>
    [4..4] 4th judge: <clr>Faeyan<clrEnd>
    [5..5] 4th judge: <clr>Gaalian<clrEnd>
    [6..6] 4th judge: <clr>Maloq<clrEnd>, rate [p8]
    [7..7] 4th judge: <clr>Peleng<clrEnd>, rate [p8]
    [8..8] 4th judge: <clr>Human<clrEnd>, rate [p8]
    [9..9] 4th judge: <clr>Faeyan<clrEnd>, rate [p8]
    [10..10] 4th judge: <clr>Gaalian<clrEnd>, rate [p8]
    критическое: Сообщение достижения критического значения параметром 4
- P8 'Rate 4' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 23
- P9 '5th judge' [1..10] тип=обычный
    старт: [1..5]
    [1..1] 5th judge: <clr>Maloq<clrEnd>
    [2..2] 5th judge: <clr>Peleng<clrEnd>
    [3..3] 5th judge: <clr>Human<clrEnd>
    [4..4] 5th judge: <clr>Faeyan<clrEnd>
    [5..5] 5th judge: <clr>Gaalian<clrEnd>
    [6..6] 5th judge: <clr>Maloq<clrEnd>, rate [p10]
    [7..7] 5th judge: <clr>Peleng<clrEnd>, rate [p10]
    [8..8] 5th judge: <clr>Human<clrEnd>, rate [p10]
    [9..9] 5th judge: <clr>Faeyan<clrEnd>, rate [p10]
    [10..10] 5th judge: <clr>Gaalian<clrEnd>, rate [p10]
    критическое: Сообщение достижения критического значения параметром 5
- P10 'Rate 5' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 24
- P11 'Component' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter # 14: <>
    критическое: Сообщение достижения критического значения параметром 14
- P12 'Component' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter # 15: <>
    критическое: Сообщение достижения критического значения параметром 15
- P13 'Component' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter # 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P14 'Last component' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter # 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P15 'Thickness' [0..21] тип=провал
    старт: [2]
    [0..21] Pizza thickness: <>
    критическое: After you added the last component your pizza started to look like the Pisa Tower. One careless move…
- P16 'Calories' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza calories: <>
    критическое: Сообщение достижения критического значения параметром 8
- P17 'Meatness' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza meatness: <>
    критическое: Сообщение достижения критического значения параметром 11
- P18 'Fishness' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza fishness: <>
    критическое: Сообщение достижения критического значения параметром 12
- P19 'Vegginess' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza vegginess: <>
    критическое: Сообщение достижения критического значения параметром 18
- P20 'Exoticness' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza exoticness: <>
    критическое: Сообщение достижения критического значения параметром 10
- P21 'Estheticness' [0..100] тип=обычный
    старт: [0]
    [0..100] Pizza estheticness: <>
    критическое: Сообщение достижения критического значения параметром 9
- P22 'Audience support' [0..100] тип=обычный
    старт: [1..50]
    [0..100] Audience support: <>%
    критическое: Сообщение достижения критического значения параметром 6
- P23 'Player money' [0..500000] тип=обычный деньги
    старт: [2000]
    [0..500000] Your money: <> cr
    критическое: Сообщение достижения критического значения параметром 26
- P24 'Audience support to the Faeyan' [0..100] тип=обычный
    старт: [50..100]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 27
- P25 'Satiation' [0..14] тип=провал
    старт: [0]
    [0..1] Could eat an elephant
    [2..3] You are not very hungry
    [4..5] You refreshed the inner man
    [6..8] You've had your fill
    [9..11] You almost fed up
    [12..14] You are about to burst
    критическое: After you sent the last bit in down to your stomach you felt you were full. The stomach became heavy…
- P26 'Credit' [0..100] тип=обычный
    старт: [100]
    [0..100] Credit: <> cr
    критическое: Сообщение достижения критического значения параметром 30
- P27 'The judge is corrupted' [0..5] тип=обычный
    старт: [0]
    [0..5] Judge № <> is corrupted
    критическое: Сообщение достижения критического значения параметром 29
- P28 'Sum' [0..50] тип=обычный
    старт: [0]
    [0..50] Your sum: <>
    критическое: Сообщение достижения критического значения параметром 13
- P29 'x' [0..10] тип=обычный
    старт: [0]
    [0..10] MAIN COMPETITORS:
    критическое: Сообщение достижения критического значения параметром 31
- P30 'Viro Nulph' [0..50] тип=обычный
    старт: [0]
    [0..50] Viro Nulph: <>
    критическое: Сообщение достижения критического значения параметром 19
- P31 "Gluck O'Naate" [0..50] тип=обычный
    старт: [0]
    [0..50] Gluck O'Naate: <>
    критическое: Сообщение достижения критического значения параметром 28
- P32 'Bit Bitey' [0..50] тип=обычный
    старт: [0]
    [0..50] Bit Bitey: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'Maloq' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Peleng' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Human' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 35
- P36 'Faeyan' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Gaalian' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 'place' [1..100] тип=обычный
    старт: [1]
    [1..100] 
    критическое: Сообщение достижения критического значения параметром 38

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: Anyone who'd arrive to the planet of <ToPlanet> at this time, couldn't but notice the general excitement. Right at the spaceport you were met by a funny Maloq w…
    скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P24,P27,P28,P29,P30,P31,P32
    показ: P23,P25,P26
  -> Path2 => Loc3  вер=1 проходов<=1 порядок=3
       текст: Go to the tournament
  -> Path3 => Loc10  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Visit "Pizza-Hack"
       эффект: P29(x) = 1

### Loc3 [обычная] визитов<=4
    Loc3-1: The entrance of the <clr>"Grand Cocktail"<clrEnd> palace was crowded. The poster on the facade read in capitals: <clr>"WELCOME THE BEST CHEFS OF THE GALAXY!!!"<…
    эффект: P22(Audience support) = {[20..60]} [показ]
    скрыт: P25,P26
  -> Path28 => Loc21  вер=1 проходов<=1 порядок=8
       текст: Hey dude, get lost. I am not really into interviews today
  -> Path30 => Loc19  вер=1 проходов<=1
       текст: I am representing the planet of <FromPlanet>!
       ответ: - Where is this planet? - looks like this Doughnut'puke only made it through prep school. It took you a while to explain to this extravagant reporter where the …
       эффект: P22(Audience support) = {[p22]+[5..20]}
  -> Path98 => Loc19  вер=1 проходов<=1 порядок=5
       текст: I am here by myself!
       ответ: - Hmm... - Doughnut'puke seemed disappointed. What will the audience think of you after an answer like that, you wondered? But the reporter proceeded with his q…
       эффект: P22(Audience support) = {[p22]+[0..10]}
  -> Path99 => Loc19  вер=1 проходов<=1 порядок=2
       текст: I represent the rangers of the Galaxy!
       ответ: You felt proud. You cheeks were slowly turning pink. The larger part of the population liked the rangers. Suddenly you remembered about the badge on your chest …
       эффект: P22(Audience support) = {[p22]+[10..15]}

### Loc4 [обычная]
    выбор описания: {[p29]}
    Loc4-1: You opened the menu on the page that read <clr>"Regular Meals"<clrEnd>.
    Loc4-2: The waiter brought in a monster of a mug filled to the brim with punch with a thin straw in it. Throwing away the unnecessary item, you started gulping up the p…
    Loc4-3: You remembered hearing something about this planet called Earth, where they had these farms where they bred this special monkey breed - the fluffy baboon. These…
    Loc4-4: The waiter smiled helpfully and rushed to place your order.  /  / The beef stake was soaked in blood and covered with ashes. It's been a long time since you las…
    Loc4-5: - Sire, - the waiter disappeared somewhere in the depths of the restaurant. /  / Five minutes later he brought in a tray, with some nice-looking dish on it. The…
    Loc4-6: After this long flight you felt you were lacking vitamins. The salad of fresh vegetables and fruit was just what you needed. In fact the Faeyan largely feed off…
  -> Path4 => Loc16  вер=1 [всегда видна] порядок=3
       текст: Beefsteak Maloq-style (10 cr)
       условия: логика {([p26]+[p23])>=10}
       эффект: P25(Satiation) +2
       эффект: P23(Player money) = {[p23]-(10-[p26])*([p26]<10)}
       эффект: P26(Credit) -10
       эффект: P29(x) = 4
  -> Path5 => Loc16  вер=1 [всегда видна] порядок=6
       текст: Marinade escargots in pastry (25 cr)
       условия: логика {([p26]+[p23])>=25}
       эффект: P25(Satiation) +1
       эффект: P23(Player money) = {[p23]-(25-[p26])*([p26]<25)}
       эффект: P26(Credit) -25
       эффект: P29(x) = 5
  -> Path6 => Loc16  вер=1 [всегда видна] порядок=5
       текст: Eggs with brains and sour cream (20 cr)
       условия: логика {([p26]+[p23])>=20}
       эффект: P25(Satiation) +1
       эффект: P23(Player money) = {[p23]-(20-[p26])*([p26]<20)}
       эффект: P26(Credit) -20
       эффект: P29(x) = 3
  -> Path7 => Loc16  вер=1 [всегда видна] порядок=4
       текст: "Home Sweet Home" Faeyan salad (10 cr)
       условия: логика {([p26]+[p23])>=10}
       эффект: P25(Satiation) +1
       эффект: P23(Player money) = {[p23]-(10-[p26])*([p26]<10)}
       эффект: P26(Credit) -10
       эффект: P29(x) = 6
  -> Path8 => Loc16  вер=1 [всегда видна] порядок=2
       текст: "Jolly Gaalian" punch (5 cr)
       условия: логика {([p26]+[p23])>=5}
       эффект: P25(Satiation) -2
       эффект: P23(Player money) = {[p23]-(5-[p26])*([p26]<5)}
       эффект: P26(Credit) -5
       эффект: P29(x) = 2
  -> Path9 => Loc10  вер=1
       текст: Open the menu at "Pizzas"
       эффект: P29(x) = 2
  -> Path106 => Loc3  вер=1 порядок=9
       текст: Leave the restaurant and head for the competition

### Loc10 [обычная]
    выбор описания: {[p29]}
    Loc10-1: Nice quiet music played inside the "Pizza-Hack" restaurant. The ultra-photon lamps, built into the walls and ceiling, produced a soft light, creating a coy home…
    Loc10-2: You opened the menu at the page that read <clr>"Pizzas"<clrEnd>.
    Loc10-3: They did not serve Gaalian pizzas on all planets. The trouble with them was that these pizzas contained some <clr>rare exotic components<clrEnd>, that in some c…
    Loc10-4: In fact pizza was something that the Human race initially came up. That is why Human-made pizzas usually had a very <clr>well balanced<clrEnd> taste quality, wi…
    Loc10-5: The Maloq pizza was fat and thick. <clr>Calories<clrEnd> were literally pouring out of it like a cornucopia. Cutting a slice you felt the taste of <clr>meat<clr…
    Loc10-6: Some time later that waiter brought in something on a tray that looked slightly like pizza. Earlier on the Pelengs used to eat only neon and minerals, and only …
    Loc10-7: The Peleng pizza, rather expectedly, was rich with <clr>seafood<clrEnd>. This pizza was multi-layered, with fins and branchiae of all kinds of <clr>sea-dwelling…
    показ: P25
  -> Path10 => Loc35  вер=1 [всегда видна] порядок=1
       текст: "King-size" (Maloqs) (25 cr)
       условия: логика {([p26]+[p23])>=25}
       эффект: P25(Satiation) +3
       эффект: P23(Player money) = {[p23]-(25-[p26])*([p26]<25)}
       эффект: P26(Credit) -25
       эффект: P29(x) = 5
  -> Path11 => Loc35  вер=1 [всегда видна] порядок=2
       текст: "Seafood" (Pelengs) (20 cr)
       условия: логика {([p26]+[p23])>=20}
       эффект: P25(Satiation) +2
       эффект: P23(Player money) = {[p23]-(20-[p26])*([p26]<20)}
       эффект: P26(Credit) -20
       эффект: P29(x) = 7
  -> Path12 => Loc35  вер=1 [всегда видна] порядок=5
       текст: "Stunning" (Humans) (20 cr)
       условия: логика {([p26]+[p23])>=20}
       эффект: P25(Satiation) +2
       эффект: P23(Player money) = {[p23]-(20-[p26])*([p26]<20)}
       эффект: P26(Credit) -20
       эффект: P29(x) = 4
  -> Path13 => Loc35  вер=1 [всегда видна] порядок=6
       текст: "Vegetarian" (Faeyans) (15 cr)
       условия: логика {([p26]+[p23])>=15}
       эффект: P25(Satiation) +1
       эффект: P23(Player money) = {[p23]-(15-[p26])*([p26]<15)}
       эффект: P26(Credit) -15
       эффект: P29(x) = 6
  -> Path14 => Loc35  вер=1 [всегда видна] порядок=7
       текст: "Heavenly" (Gaalians) (20 cr)
       условия: логика {([p26]+[p23])>=20}
       эффект: P25(Satiation) +1
       эффект: P23(Player money) = {[p23]-(20-[p26])*([p26]<20)}
       эффект: P26(Credit) -20
       эффект: P29(x) = 3
  -> Path16 => Loc4  вер=1
       текст: Open the menus at "Standard Meals"
       эффект: P29(x) = 1
  -> Path107 => Loc3  вер=1 порядок=9
       текст: Leave the restaurant and head for the competition

### Loc16 [пустая]
  -> Path104 => Loc4  вер=1 порядок=5

### Loc19 [пустая] визитов<=3
  -> Path35 => Loc20  вер=1 проходов<=1 порядок=5
       текст: This will not be the first time when I show whose the master around here!
       ответ: The response was as provoking, as it could get. But at that point of time emotion won over self-control, so you only had to hope that the audience would get you…
       эффект: P22(Audience support) = {[p22]+[0..30]}
  -> Path102 => Loc20  вер=1 проходов<=1 порядок=2
       текст: Yessir. This is my debut!
       ответ: You decided to be honest. That was your golden rule. /  / - And finally, the last question, - the boring reporter was getting on your nerves, - How does it feel…
       эффект: P22(Audience support) = {[p22]+[10..25]}
  -> Path103 => Loc20  вер=1 проходов<=1 порядок=4
       текст: Competitions of that kind were an alternative to the existing practice of Galaxy-wide global conferences aimed at finding interracial compromises and improving …
       ответ: Gracefully you slipped away from a direct answer. Now you had to hope that the government of the planet of  <ToPlanet> did invest into education. The confused r…
       эффект: P22(Audience support) = {[p22]+[0..15]}

### Loc20 [пустая] визитов<=3
  -> Path32 => Loc21  вер=1 проходов<=1 порядок=1
       текст: In fact it's going to be the first time I am making a pizza!
       ответ: Doughnut'puke's face formed into a surprised grimace: /  / - Well, in that case we can only wish you the best of luck, ranger <Ranger>!  /  / It is common knowl…
       эффект: P22(Audience support) = {[p22]+[10..15]} [показ]
  -> Path100 => Loc21  вер=1 проходов<=1 порядок=4
       текст: It's a hard question. I feel a bit shy.
       ответ: - Not to worry, you are positively going to make it, we do believe in you, - the reporter decided to cheer you up. Lack of self-confidence would seldom find any…
       эффект: P22(Audience support) = {[5..15]+[p22]/2} [показ]
  -> Path101 => Loc21  вер=1 проходов<=1 порядок=6
       текст: Excellent! I'll kick their asses!!!
       ответ: - That was one tough statement! - the reporter was overjoyed. Looks like it was his first interview, and it certainly appeared a success. Although, what will th…
       эффект: P22(Audience support) = {[p22]+[-5..35]} [показ]

### Loc21 [обычная] визитов<=2
    Loc21-1: The hall, where the competition for the Galaxy's best pizza cook was to be held, was overcrowded. The spectators cheered and made constant "waves". Because of t…
    эффект: P11(Component) = 0
    эффект: P12(Component) = 0
    эффект: P13(Component) = 0
    эффект: P14(Last component) = 3
    показ: P1,P3,P5,P7,P9,P22
  -> Path108 => Loc22  вер=1 проходов<=1 порядок=4
       текст: Not pay attention to the Peleng
       эффект: P29(x) = 1
  -> Path109 => Loc36  вер=1 проходов<=1 порядок=5
       текст: Walk up to the Peleng

### Loc22 [пустая]
    выбор описания: {[p29]}
    Loc22-1: You ignored the signs of the Peleng and stoically waited to the end of the official part. Finally you along with a couple of dozens of other participants - repr…
    Loc22-2: Giving the Peleng <clr>1000<clrEnd> cr, you went back to the hall. Just at that moment you along with a couple of dozens of other participants - representatives…
    эффект: P11(Component) = {[p12]}
    эффект: P12(Component) = {[p13]}
    эффект: P13(Component) = {[p14]}
    эффект: P28(Sum) = {[p11]}
    показ: P15,P16,P17,P18,P19,P20,P21
  -> Path38 => Loc23  вер=1
       текст: Meat, fish
  -> Path39 => Loc24  вер=1 порядок=1
       текст: Carbohydrates
  -> Path40 => Loc25  вер=1 порядок=2
       текст: Veggies, fruit
  -> Path41 => Loc26  вер=1 порядок=3
       текст: Spices
  -> Path42 => Loc27  вер=1 порядок=4
       текст: Exotic components
  -> Path43 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Send the pizza into the oven
       условия: P15(Thickness) 10..20
       эффект: P30(Viro Nulph) = {[41..44]+(([p1]=[p3])+([p1]=[p5])+([p1]=[p7])+([p1]=[p9])+([p3]=[p5])+([p3]=[p7])+([p3]=[p9])+([p5]=[p7])+([p5]=[p9])+([p7]=[p9]))/2}
       эффект: P33(Maloq) = {[p16]/2+[p17]/3+[p18]/10-[p20]/10-[p21]/5}
       эффект: P34(Peleng) = {[p16]/10-[p17]/10+[p18]/2+[p19]/3+[p20]/5-[p21]/10}
       эффект: P35(Human) = {[p21]/5+[p20]/5+4*([p16]>4)*([p17]>4)*([p18]>4)*([p19]>4)*([p20]>4)*([p21]>4)+2*([p16]>2)*([p17]>2)*([p18]>2)*([p19]>2)*([p20]>2)*([p21]>2)}
       эффект: P36(Faeyan) = {[p16]/10-[p17]/4+[p18]/10+[p19]/2+[p21]/10+[p20]/10}
       эффект: P37(Gaalian) = {-[p16]/4-[p17]/10-[p18]/10+[p19]/10+[p21]/2+[p20]/2}

### Loc23 [обычная]
    Loc23-1: You decided to add some protein-rich components to the pizza, thus increasing its calories. Meat and fish from famous manufacturers would be just the right thin…
  -> Path44 => Loc22  вер=1 проходов<=2
       текст: Parm ham, sliced
       ответ: The Parm ham has been known around the Galaxy since penchekryak knows when. Everyone save for Faeyans, who were ardent environmentalists, liked this ancient foo…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 1
       эффект: P16(Calories) +3
       эффект: P17(Meatness) +2
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path45 => Loc22  вер=1 проходов<=2 порядок=1
       текст: Dry cod
       ответ: The cod was most-positively over-dried. That was the downside of the ultra-modern processing technologies. The undervacuum smoke-ovens definitely spoiled the in…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 3
       эффект: P16(Calories) +1
       эффект: P18(Fishness) +2
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path46 => Loc22  вер=1 проходов<=2 порядок=2
       текст: Mutton blade
       ответ: They only had real rams left in the famous zoo of <clr>"MicroWorld"<clrEnd> back on Earth, which was still headed by the famous uncle Bill. All other rams in th…
       эффект: P15(Thickness) +3
       эффект: P14(Last component) = 1
       эффект: P16(Calories) +4
       эффект: P17(Meatness) +2
       эффект: P20(Exoticness) +1
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path47 => Loc22  вер=1 проходов<=2 порядок=3
       текст: Fresh deepwater squids
       ответ: You felt like your creation could really use a touch of fish. Your attention was caught by a transparent package from which the bulging eyes of some sea creatur…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 5
       эффект: P16(Calories) +3
       эффект: P17(Meatness) +1
       эффект: P18(Fishness) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path48 => Loc22  вер=1 проходов<=2 порядок=4
       текст: Sowbelly
       ответ: Nothing increases the calories of a pizza like sowbelly! This is the basic truth. Without giving it much thought you reached out for the <clr>white<clrEnd> appe…
       эффект: P15(Thickness) +3
       эффект: P14(Last component) = 5
       эффект: P16(Calories) +5
       эффект: P17(Meatness) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path49 => Loc22  вер=1 проходов<=2 порядок=5
       текст: Gutted herring
       ответ: The barrel with herrings stood nearby. You rolled up your sleeves and started fishing out the right erm... fish. Despite your expectations the herring was not g…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 2
       эффект: P16(Calories) +2
       эффект: P17(Meatness) +1
       эффект: P18(Fishness) +2
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
       эффект: P22(Audience support) = {[p22]+[3..7]}
  -> Path50 => Loc22  вер=1 проходов<=2 порядок=6
       текст: Jerbooster tenderloin from Arnarique Goudad
       ответ: The Maloq planet of Arnarique Goudad has always been known for its jerboosters. About half of the planet's population picked poor jerbooster hunting as their da…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 4
       эффект: P16(Calories) +2
       эффект: P17(Meatness) +2
       эффект: P20(Exoticness) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path117 => Loc22  вер=1 порядок=7
       текст: Other type of products
       эффект: P11(Component) = {[p28]}
       эффект: P12(Component) = {[p11]}
       эффект: P13(Component) = {[p12]}
       эффект: P14(Last component) = {[p13]}

### Loc24 [обычная]
    Loc24-1: Some carbohydrates would increase the calories and at the same time would make animal rights activists happy. The choice of the noble!
  -> Path52 => Loc22  вер=1 проходов<=2
       текст: Potatoes, chopped
       ответ: Potatoes as vegetables under different names and of different varieties are grown pretty much everywhere in the Galaxy. This is one of the main agricultural pro…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 3
       эффект: P16(Calories) +2
       эффект: P19(Vegginess) +3
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path53 => Loc22  вер=1 проходов<=2 порядок=1
       текст: Mashed peas
       ответ: The lack of vegetarian and excess of high-calorie products can be easily compensated with <clr>green<clrEnd> peas. For several past centuries mashed peas have b…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 4
       эффект: P16(Calories) +3
       эффект: P19(Vegginess) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path54 => Loc22  вер=1 проходов<=2 порядок=2
       текст: Parmesan cheese
       ответ: Cheeses have always been an indispensable component of any pizza, and Parmesan was definitely one of the best sorts. But it just happened so that on this very p…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 3
       эффект: P16(Calories) +2
       эффект: P17(Meatness) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path55 => Loc22  вер=1 проходов<=2 порядок=3
       текст: Ground rusks
       ответ: All dwellers of the Galaxy remembered the famine of 3017. Back then in the times of desperate fighting against the Klissans the Galaxy was going through the 2nd…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 2
       эффект: P16(Calories) +3
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path56 => Loc22  вер=1 проходов<=2 порядок=4
       текст: Corn cakes
       ответ: Corn is a high-calorie and a very important agricultural product. Semi-readies with a proud brand <clr>"Corn Forever"<clrEnd> were stacked in a neat stash and l…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 3
       эффект: P16(Calories) +3
       эффект: P19(Vegginess) +2
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
       эффект: P22(Audience support) = {[p22]-[2..5]}
  -> Path57 => Loc22  вер=1 проходов<=2 порядок=5
       текст: "Macaroni" noodles
       ответ: You knit an intricate noodle pattern on top of the pizza. The <clr>white<clrEnd> knotwork looked a lot like the most sophisticated Celtic patterns ever to appea…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 5
       эффект: P16(Calories) +3
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path58 => Loc22  вер=1 проходов<=2 порядок=6
       текст: Margarine with preservatives
       ответ: Your attention was caught by a small glass can of <clr>yellow<clrEnd> colour. Lots of calories and little thickness - just what you needed! Prior to applying th…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 3
       эффект: P16(Calories) +3
       эффект: P17(Meatness) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path116 => Loc22  вер=1 порядок=7
       текст: Other type of products
       эффект: P11(Component) = {[p28]}
       эффект: P12(Component) = {[p11]}
       эффект: P13(Component) = {[p12]}
       эффект: P14(Last component) = {[p13]}

### Loc25 [обычная]
    Loc25-1: The fruits and vegetables were to soften and brighten up the taste of your pizza, and please the vegetarians. The organisers offered a wide selection of those. …
  -> Path60 => Loc22  вер=1 проходов<=2
       текст: Mango (pulp)
       ответ: The mango pulp smelled of fresh paint. Bright sun, tender sea, tanned birds - these were the thoughts provoked by the sight of these ripe and juicy fruits of <c…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 1
       эффект: P19(Vegginess) +1
       эффект: P20(Exoticness) +1
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path61 => Loc22  вер=1 проходов<=2 порядок=1
       текст: Crated coconut
       ответ: The coconuts in the basket were fresh from the palm-tree and not grated at all. Right by the bucket there stood a short round-headed poor-looking Maloq. As they…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 5
       эффект: P19(Vegginess) +1
       эффект: P20(Exoticness) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
       эффект: P22(Audience support) = {[p22]+[3..7]}
  -> Path62 => Loc22  вер=1 проходов<=2 порядок=2
       текст: Bamboo sprouts
       ответ: The <clr>green<clrEnd> sprout of bamboo were marinated in three-litre cans.  The can opener lay nearby. The organisers did their best to provide the tournament …
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 4
       эффект: P19(Vegginess) +1
       эффект: P20(Exoticness) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path63 => Loc22  вер=1 проходов<=2 порядок=3
       текст: Fresh cucumber
       ответ: These vegetables were very popular with the folks all over the Galaxy. For the most part they were served as a marinated appetiser to all kinds of liquor and we…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 4
       эффект: P19(Vegginess) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path64 => Loc22  вер=1 проходов<=2 порядок=4
       текст: Dried tomatoes
       ответ: What kind of pizza would it be without <clr>red<clrEnd> tomatoes? The modern method of production of dried tomatoes reserved from the use latest technologies. I…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 1
       эффект: P19(Vegginess) +2
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path65 => Loc22  вер=1 проходов<=2 порядок=5
       текст: Beans
       ответ: This kind of food was extremely popular in the densely populated worlds of the Galaxy. Beans were the cheapest kind of food available, and could easily feed a f…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 2
       эффект: P16(Calories) +2
       эффект: P19(Vegginess) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path66 => Loc22  вер=1 проходов<=2 порядок=6
       текст: Local zucchini
       ответ: The zucchinis were spread all over the Galaxy by some terrorists. They started procreating rapidly and soon were occupying all the uninhabited territories. On s…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 3
       эффект: P19(Vegginess) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path118 => Loc22  вер=1 порядок=7
       текст: Other type of products
       эффект: P11(Component) = {[p28]}
       эффект: P12(Component) = {[p11]}
       эффект: P13(Component) = {[p12]}
       эффект: P14(Last component) = {[p13]}

### Loc26 [обычная]
    Loc26-1: Spices usually added little to the actual taste of the pizza, but for some reason or other all the cooks were making a very extensive use of them. Main thing wa…
  -> Path68 => Loc22  вер=1 проходов<=2
       текст: Estragon mustard
       ответ: Estragon was used to rub the private parts of Taron stallions before long-distance runs. Estragon was also used to make excellent mustard. The <clr>yellow<clrEn…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 3
       эффект: P19(Vegginess) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=1)-([p14]=3)+([p11]<>3 and [p12]<>3 and [p13]<>3 and [p14]<>3)}
  -> Path69 => Loc22  вер=1 проходов<=2 порядок=1
       текст: Aromatic greens
       ответ: Your attention was caught by a bright green box, that stood right in the centre of the cart with spices. The box read - <clr>"The freshest and the most aromatic…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 4
       эффект: P19(Vegginess) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path70 => Loc22  вер=1 проходов<=2 порядок=2
       текст: Pumpkin seeds
       ответ: A friend from Earth told you once that back on this planet they eat pumpkin seeds on every corner, and the husks of the seeds literally pave the streets. "Well,…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 4
       эффект: P19(Vegginess) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path71 => Loc22  вер=1 проходов<=2 порядок=3
       текст: Rusk sauce
       ответ: In order to get rid of the endless reserves of rusks stored in case of famine, a certain Peleng craftsman named Lyakusha Steeveenzon came up with an original sa…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 2
       эффект: P16(Calories) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path72 => Loc22  вер=1 проходов<=2 порядок=4
       текст: Ground fish bones
       ответ: The research in the field of new nutrients resulted in grinding and crumbling everything that could possibly be ground and crumbled. The <clr>white<clrEnd> powd…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 5
       эффект: P18(Fishness) +1
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path73 => Loc22  вер=1 проходов<=2 порядок=5
       текст: Vinegar (100%)
       ответ: When you poured some vinegar onto your pizza, it produced an odd hissing sound and started foaming. After the foam settled in, you noticed that all of the compo…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 1
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path74 => Loc22  вер=1 проходов<=2 порядок=6
       текст: Smoke-smell essence
       ответ: This <clr>brown<clrEnd> spice made of processed meat waste was packed in flasks that looked a bit like a famous deodorant for men. Thanks to its unusual and rat…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 2
       эффект: P17(Meatness) +1
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path115 => Loc22  вер=1 порядок=7
       текст: Other type of products
       эффект: P11(Component) = {[p28]}
       эффект: P12(Component) = {[p11]}
       эффект: P13(Component) = {[p12]}
       эффект: P14(Last component) = {[p13]}

### Loc27 [обычная]
    Loc27-1: The exotic components were separated into a special product category. The use of those made any dish taste original and exotic. All of these components have bee…
  -> Path76 => Loc22  вер=1 проходов<=2
       текст: Portobello mushrooms
       ответ: The poisonous <clr>green<clrEnd> Portobello mushrooms could be made eatable if processed in the right way. However, one or two could still remain lethally toxic…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 4
       эффект: P19(Vegginess) +1
       эффект: P20(Exoticness) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=4)+([p14]<>3)+([p11]<>4 and [p12]<>4 and [p13]<>4 and [p14]<>4)}
  -> Path77 => Loc22  вер=1 проходов<=2 порядок=1
       текст: Royal crab claws
       ответ: In order for a crab to be considered royal its claws must have been longer than 2 meters. These monsters were bred at special farms in the open ocean. Due to th…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 1
       эффект: P16(Calories) +1
       эффект: P17(Meatness) +1
       эффект: P18(Fishness) +1
       эффект: P20(Exoticness) +2
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
  -> Path78 => Loc22  вер=1 проходов<=2 порядок=2
       текст: Fresh brain, packed
       ответ: The <clr>white<clrEnd> brains of a special macaque breed were truly a gourmet dish. Only the real judges of ancient cuisine could truly appreciate their unusual…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 5
       эффект: P16(Calories) +2
       эффект: P17(Meatness) +1
       эффект: P20(Exoticness) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path79 => Loc22  вер=1 проходов<=2 порядок=3
       текст: Bourbon
       ответ: The favourite swill of the Rangers. It has become so popular, that the rangers managed to devastate almost all of the reserves of this liquor on Earth. The cons…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 2
       эффект: P16(Calories) +1
       эффект: P20(Exoticness) +2
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path80 => Loc22  вер=1 проходов<=2 порядок=4
       текст: Pearl onion
       ответ: This unique product was lying under a cap in a special glass unit. Right next to it there was a detailed instruction on correct extraction and use of the unusua…
       эффект: P15(Thickness) +1
       эффект: P14(Last component) = 5
       эффект: P19(Vegginess) +1
       эффект: P20(Exoticness) +2
       эффект: P21(Estheticness) = {[p21]-2*([p14]=5)+([p14]<>3)+([p11]<>5 and [p12]<>5 and [p13]<>5 and [p14]<>5)}
  -> Path81 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Yong boar saddle
       ответ: The saddle of a young boar was only presented at the tournament in one copy. It was put onto a separate cart and occupied more place scene than anything else. G…
       эффект: P15(Thickness) +5
       эффект: P14(Last component) = 1
       эффект: P16(Calories) +4
       эффект: P17(Meatness) +4
       эффект: P20(Exoticness) +4
       эффект: P21(Estheticness) = {[p21]+([p14]<>2)-2*([p14]=1)+([p11]<>1 and [p12]<>1 and [p13]<>1 and [p14]<>1)}
       эффект: P22(Audience support) = {[p22]+[10..20]}
  -> Path82 => Loc22  вер=1 проходов<=2 порядок=5
       текст: Monstrodile liver oil
       ответ: A monstrodile was a very rare beast that could only be found very deep in the ocean. According to the latest scientific researches its liver could even digest m…
       эффект: P15(Thickness) +2
       эффект: P14(Last component) = 2
       эффект: P17(Meatness) +1
       эффект: P18(Fishness) +1
       эффект: P20(Exoticness) +3
       эффект: P21(Estheticness) = {[p21]+([p14]=4)+([p14]=5)-([p14]=2)+([p11]<>2 and [p12]<>2 and [p13]<>2 and [p14]<>2)}
  -> Path83 => Loc22  вер=1 порядок=7
       текст: Other type of products
       эффект: P11(Component) = {[p28]}
       эффект: P12(Component) = {[p11]}
       эффект: P13(Component) = {[p12]}
       эффект: P14(Last component) = {[p13]}

### Loc28 [обычная] визитов<=1
    Loc28-1: Finally your pizza was ready. It was your sound opinion that your masterpiece had all the necessary components in required quantities.  /  / You raised a white …
    эффект: P28(Sum) = {[p2]+[p4]+[p6]+[p8]+[p10]}
  -> Path120 => Loc38  вер=1 проходов<=1 порядок=5
       текст: View the results of other participants
       эффект: P38(place) = {1+([p30]>[p28])+([p31]>[p28])+([p32]>[p28])}

### Loc29 [УСПЕХ]
    выбор описания: {[p38]}
    Loc29-1: Finally the summed results appeared on the table. And sure enough you <clr>won <clrEnd> the first prize!!! The judge announced the results: /  / 1st place - ran…
    Loc29-2: Finally the summed results appeared on the table. And sure enough you <clr>won <clrEnd> the second prize!!! The judge announced the results: /  / 1st place - Vi…
    Loc29-3: Finally the summed results appeared on the table. And sure enough you <clr>won <clrEnd> the third prize!!! The judge announced the results: /  / 1st place - Vir…
    эффект: P23(Player money) = {[p23]+1000-250*[p38]}
    эффект: P28(Sum) = {} [показ]
    скрыт: P15,P16,P17,P18,P19,P20,P21
    показ: P30,P31,P32

### Loc30 [ПРОВАЛ]
    Loc30-1: Finally the summed results appeared on the table. And sure enough you <clr>lost <clrEnd>!!! The judge announced the results: /  / 1st place - Viro Nulph who str…
    скрыт: P15,P16,P17,P18,P19,P20,P21
    показ: P28,P30

### Loc31 [обычная] визитов<=4
    Loc31-1: As it turned out two of the contenders including yourself struck the same amount of points! So how are they going to determine the winner? According to the rule…
    скрыт: P15,P16,P17,P18,P20,P21
    показ: P28,P30
  -> Path87 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Show him a tongue
       ответ: You showed your huge tongue, as a response to the verbal attack of your opponent. He pulled on a face and called you some rude word, which you could not even ma…
       эффект: P22(Audience support) = {[p22]+[-5..10]}
  -> Path89 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Do nothing
       ответ: You gave him your best ear-to-ear grin, showing the opponent that his tongue-lashing meant little to you, and that you indeed were above that. What you did forg…
       эффект: P22(Audience support) = {[p22]+[-5..10]}
  -> Path91 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Pull down your pants and give the opponent a "full-moon".
       ответ: This exotic move had different meanings among different races. Apparently, back in the home-system of your opponent it was used to demonstrate maximum possible …
  -> Path92 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Call him names too
       ответ: In response your opponent grabbed the nearest pizza component left over from the competition and threw it right at you. Judging by the smell that struck you in …
       эффект: P22(Audience support) = {[p22]+[-10..20]}

### Loc32 [пустая] визитов<=2
    эффект: P24(Audience support to the Faeyan) = {[60..100]-10*[p38]}
  -> Path88 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Wait for the audience's judgement
       условия: логика {[p22]<=[p24]}
       эффект: P38(place) +1
  -> Path93 => Loc34  вер=1 проходов<=1 порядок=5
       текст: Wait for the audience's judgement
       условия: логика {[p22]>=[p24]}

### Loc33 [обычная] визитов<=1
    Loc33-1: Finally the master of ceremony took the mike and announced: /  / - Ladies and gentlemen... The first contender... The magnificent and the wonderful... The charm…
  -> Path124 => Loc29  вер=1 проходов<=1 порядок=5
       условия: P38(place) 1..3
  -> Path125 => Loc30  вер=1 проходов<=1 порядок=5
       условия: P38(place) 4..100

### Loc34 [обычная] визитов<=1
    Loc34-1: Finally the master of ceremony took the mike and announced: /  / - Ladies and gentlemen... The first contender... The magnificent and the wonderful... The charm…
  -> Path126 => Loc29  вер=1 проходов<=1 порядок=5
       условия: P38(place) 1..3

### Loc35 [пустая]
  -> Path105 => Loc10  вер=1 порядок=5

### Loc36 [обычная] визитов<=1
    Loc36-1: - You are a new guy here, aren't you? - the Peleng asked you. - I could help you. I could buy the favour of any judge for you for a laughably small price of  <c…
  -> Path37 => Loc22  вер=1
       текст: Refuse the Peleng services
       эффект: P29(x) = 1
  -> Path110 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Corrupt judge #2
       условия: P23(Player money) 1000..500000
       эффект: P23(Player money) = {[p23]-1000}
       эффект: P27(The judge is corrupted) = 2 [показ]
       эффект: P29(x) = 2
  -> Path111 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Corrupt judge #3
       условия: P23(Player money) 1000..500000
       эффект: P23(Player money) = {[p23]-1000}
       эффект: P27(The judge is corrupted) = 3 [показ]
       эффект: P29(x) = 2
  -> Path112 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Corrupt judge #4
       условия: P23(Player money) 1000..500000
       эффект: P23(Player money) = {[p23]-1000}
       эффект: P27(The judge is corrupted) = 4 [показ]
       эффект: P29(x) = 2
  -> Path113 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Corrupt judge #5
       условия: P23(Player money) 1000..500000
       эффект: P23(Player money) = {[p23]-1000}
       эффект: P27(The judge is corrupted) = 5 [показ]
       эффект: P29(x) = 2
  -> Path114 => Loc22  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Corrupt judge #1
       условия: P23(Player money) 1000..500000
       эффект: P23(Player money) = {[p23]-1000}
       эффект: P27(The judge is corrupted) = 1 [показ]
       эффект: P29(x) = 2

### Loc37 [пустая] визитов<=1
    эффект: P2(Rate 1) = {10*([p27]=1)+([p27]<>1)*([p33]*([p1]=1)+[p34]*([p1]=2)+[p35]*([p1]=3)+[p36]*([p1]=4)+[p37]*([p1]=5)+[-1..1])}
    эффект: P4(Rate 2) = {10*([p27]=2)+([p27]<>2)*([p33]*([p3]=1)+[p34]*([p3]=2)+[p35]*([p3]=3)+[p36]*([p3]=4)+[p37]*([p3]=5)+[-1..1])}
    эффект: P6(Rate 3) = {10*([p27]=3)+([p27]<>3)*([p33]*([p5]=1)+[p34]*([p5]=2)+[p35]*([p5]=3)+[p36]*([p5]=4)+[p37]*([p5]=5)+[-1..1])}
    эффект: P8(Rate 4) = {10*([p27]=4)+([p27]<>4)*([p33]*([p7]=1)+[p34]*([p7]=2)+[p35]*([p7]=3)+[p36]*([p7]=4)+[p37]*([p7]=5)+[-1..1])}
    эффект: P10(Rate 5) = {10*([p27]=5)+([p27]<>5)*([p33]*([p9]=1)+[p34]*([p9]=2)+[p35]*([p9]=3)+[p36]*([p9]=4)+[p37]*([p9]=5)+[-1..1])}
    эффект: P31(Gluck O'Naate) = {[p30]-[1..2]}
  -> Path119 => Loc28  вер=1 проходов<=1 порядок=5
       эффект: P1(1st judge) +5
       эффект: P3(2nd judge) +5
       эффект: P5(3rd judge) +5
       эффект: P7(4th judge) +5
       эффект: P9(5th judge) +5
       эффект: P32(Bit Bitey) = {[p31]-[1..3]}

### Loc38 [обычная] визитов<=1
    Loc38-1: You remembered your sum: [p28]. The results of other main contenders started appearing on the table: Viro Nulph (Human) - [p30], Gluck O'Naate (Gaalian) - [p31]…
    скрыт: P15,P16,P17,P18,P19,P20,P21
    показ: P28,P29,P30,P31,P32
  -> Path84 => Loc29  вер=1 проходов<=1 порядок=5
       условия: P38(place) 1..3
  -> Path86 => Loc31  вер=100 проходов<=1 порядок=5
       условия: логика {[p28]=[p31]}
       эффект: P38(place) = 2
       показ: P30,P31,P32
  -> Path121 => Loc30  вер=1 проходов<=1 порядок=5
       условия: P38(place) 4..100
       эффект: P38(place) = {[3..7]+2*([p32]-[p28])/3}
  -> Path122 => Loc31  вер=100 проходов<=1 порядок=5
       условия: логика {[p28]=[p32]}
       эффект: P38(place) = 3
       показ: P30,P31,P32
  -> Path123 => Loc31  вер=100 проходов<=1 порядок=5
       условия: логика {[p28]=[p30]}
       эффект: P38(place) = 1
       показ: P30,P31,P32

## Анализ
- стартовых: [1]
- концовки: {29: 'УСПЕХ', 30: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
