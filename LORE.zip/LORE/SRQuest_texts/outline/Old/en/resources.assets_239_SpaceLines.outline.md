# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Money' [0..1000000000] тип=смерть
    старт: [0]
    [0..1000000000] Money: <> cr.
    критическое: A phone call from Lyakusha Moneybags awoke you early in the morning. He was clearly in a foul mood a…
- P2 'Number of liners' [0..100] тип=обычный
    старт: [5]
    [0..100] Number of liners - <>
    критическое: Ваше пари выиграно
- P3 'Popularity' [10..100] тип=провал
    старт: [45]
    [10..100] Company popularity: <>%
    критическое: The company's popularity has dropped and you won't be able to seriously compete with other companies…
- P4 'Parameter 4' [0..20] тип=провал
    старт: [20]
    [0..20] Days remaining: <>
    критическое: In the morning they were already waiting for you in the director's office. Lyakusha Moneybags and hi…
- P5 '3' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Number of guards - [p33]
    критическое: Сообщение достижения критического значения параметром 5
- P6 '4' [0..100] тип=обычный
    старт: [0]
    [0..100] Popularity - [p3]%
    критическое: Сообщение достижения критического значения параметром 6
- P7 '5' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Advertising expenses - [p32] cr.
    критическое: Сообщение достижения критического значения параметром 7
- P8 '6' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Days remaining - [p4]
    критическое: Сообщение достижения критического значения параметром 8
- P13 'Ships destroyed' [-100..100] тип=обычный
    старт: [0]
    [-100..100] destroyed
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Ships plundered' [-100..100] тип=обычный
    старт: [0]
    [-100..100] plundered
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Total stolen' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 15: <>
    критическое: Сообщение достижения критического значения параметром 15
- P16 'interest' [-1000..2000] тип=обычный
    старт: [0]
    [-1000..2000] Parameter 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Parameter 17' [-1000..2000] тип=обычный
    старт: [0]
    [-1000..2000] Parameter 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P18 'passage' [1..6] тип=обычный
    старт: [1]
    [1..6] Parameter 18: <>
    критическое: Сообщение достижения критического значения параметром 18
- P19 'balance' [0..2000000000] тип=обычный
    старт: [0]
    [0..2000000000] Parameter 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'repair equipment' [0..2] тип=обычный
    старт: [1]
    [0..2] Parameter 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'comfort enhancement' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'weaponization of ships' [0..2] тип=обычный
    старт: [2]
    [0..2] Parameter 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'increased seats' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'applications' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Down payment' [10000..30000] тип=обычный
    старт: [10000]
    [10000..30000] Parameter 25: <>
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Number of hired liners' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter 26: <>
    критическое: Сообщение достижения критического значения параметром 26
- P27 'profit per day' [0..100000000] тип=обычный
    старт: [0]
    [0..100000000] Parameter 27: <>
    критическое: Сообщение достижения критического значения параметром 27
- P28 'pilot wages' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 28: <>
    критическое: Сообщение достижения критического значения параметром 28
- P29 'repairs' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 29: <>
    критическое: Сообщение достижения критического значения параметром 29
- P30 'terrain crossing capacity' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 30: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'total' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 31: <>
    критическое: Сообщение достижения критического значения параметром 31
- P32 'advertising expenses' [0..20000] тип=обычный
    старт: [0]
    [0..20000] Parameter 32: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'security' [1..100] тип=обычный
    старт: [1]
    [1..100] Liner guards <>
    критическое: Сообщение достижения критического значения параметром 33
- P34 'guard wages' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 34: <>
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Guard absenteeism' [0..10000000] тип=обычный
    старт: [0]
    [0..10000000] Parameter 35: <>
    критическое: Сообщение достижения критического значения параметром 35
- P36 'Contraband' [0..2] тип=обычный
    старт: [1]
    [0..2] Parameter 36: <>
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Wages' [0..10000] тип=обычный
    старт: [1500]
    [0..10000] Parameter 37: <>
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Flag' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 38: <>
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Flag 1' [0..5] тип=обычный
    старт: [0]
    [0..5] Parameter 39: <>
    критическое: Сообщение достижения критического значения параметром 39
- P40 "Player's money" [0..999999999] тип=обычный деньги
    старт: [0]
    [0..999999999] Parameter 40: <>
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Debt' [0..1000000000] тип=обычный
    старт: [0]
    [0..1000000000] Parameter 41: <>
    критическое: Сообщение достижения критического значения параметром 41

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: After landing in the spaceport, you immediately enter the waiting room. A strapping peleng and a human, who was skinny almost to the point of collapsing, had be…
    эффект: P1(Money) = {[49234..51876]} [скрыт]
    эффект: P28(pilot wages) = 1500 [скрыт]
    скрыт: P2,P3,P4,P5,P6,P7,P8,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40,P41
  -> Path2 => Loc2  вер=1 проходов<=1 порядок=5
       текст: "Yeah, I understand perfectly. As soon as we get into the office, I'm going to get started working."
       эффект: P18(passage) = 0
  -> Path78 => Loc33  вер=1 порядок=4
       текст: Yes! I'd like to understand the situation, so to speak

### Loc2 [обычная]
    выбор описания: {[p18]}
    Loc2-1: You are in the director's office. It was small, but decorated in a no-nonsense business style. There was an expensive desk made of black wood with a computer on…
    Loc2-2: The following morning, which was a workday, a message arrived at your computer saying that yesterday pirates had attacked some of the liners. / Ships destroyed …
    Loc2-3: The next morning, before you had managed to get dressed, the office girl dropped by and brought you the previous day's report. /  / <fix> / --------------------…
    Loc2-4: The office girl informed you that the following day there were no liners that would work for your company.
    Loc2-5: As you went into the office in the morning you noticed that the office girl wasn't at her desk and the door to your office was slightly open. / A lady was stand…
    Loc2-6: On the way to your office, the office girl met you. / "I tried to kick them out, but they wouldn't listen to me... / "Who?" / "Two guys in black. They're in you…
    эффект: P1(Money) = {} [показ]
    эффект: P19(balance) = {[p1]}
    эффект: P25(Down payment) = {[p3]*250}
    эффект: P34(guard wages) = {[p33]*1500}
    эффект: P41(Debt) = {([p1] div 3)}
    показ: P2,P5,P6,P7,P8
  -> Path3 => Loc32  вер=1
       текст: Hire liners
       условия: логика {[p1]>=[p25] and [p30]=0 and [p4]>5 and [p18]<5}
       эффект: P24(applications) = {[0..10]}
  -> Path10 => Loc7  вер=1 порядок=9
       текст: Don't do anything else - just relax.
       условия: логика {[p18]<5}
       эффект: P3(Popularity) = {[p3]+[p33]*0,2+[p32] div 3000+[p21]*5}
       эффект: P14(Ships plundered) = 0
       эффект: P18(passage) = 1
       эффект: P19(balance) = {[p1]}
       эффект: P28(pilot wages) = {[p2]*[p37]}
       эффект: P29(repairs) = 0
       эффект: P30(terrain crossing capacity) = 0
       эффект: P34(guard wages) = {[p33]*1500}
       эффект: P35(Guard absenteeism) = 0
       эффект: P36(Contraband) = 1
  -> Path35 => Loc17  вер=1 порядок=3
       текст: Talk with the staff members
       условия: логика {[p18]<5}
  -> Path107 => Loc3  вер=1
       текст: Hire liners
       условия: логика {[p1]>=[p25] and [p30]=0 and [p4]<6}
       эффект: P24(applications) = 10
  -> Path109 => Loc46  вер=1 порядок=5
       текст: I agree with your proposal. Honestly, I'm sick of it all.
       условия: логика {[p18]=5}
       эффект: P40(Player's money) = {[p40]+5000}
  -> Path110 => Loc47  вер=1 порядок=7
       текст: No! I keep my word, and I don't quit what I've started. That's my final answer.
       условия: логика {[p18]=5}
  -> Path114 => Loc48  вер=1 порядок=5
       текст: I'll give you {[p1]div3} cr.
       условия: логика {[p18]=6}
       эффект: P1(Money) = {[p1]-[p41]}
  -> Path115 => Loc48  вер=1 порядок=6
       текст: I'll give you one liner
       условия: логика {[p18]=6}
       эффект: P2(Number of liners) -1
  -> Path116 => Loc48  вер=1 порядок=7
       текст: I'm not giving you a thing. Get out of my office before I call security
       условия: логика {[p18]=6}
       эффект: P3(Popularity) -25

### Loc3 [обычная]
    Loc3-1: When hiring a liner you have to make a downpayment of between 10,000 and 25,000 cr., depending on your popularity. The more popular, the greater the down paymen…
  -> Path4 => Loc4  вер=1
       текст: 1
       эффект: P26(Number of hired liners) = 1
  -> Path5 => Loc4  вер=1 порядок=1
       текст: 2
       условия: логика {[p1]>=[p25]*2 and [p24]>=2}
       эффект: P26(Number of hired liners) = 2
  -> Path6 => Loc4  вер=1 порядок=2
       текст: 3
       условия: логика {[p1]>=[p25]*3 and [p24]>=3}
       эффект: P26(Number of hired liners) = 3
  -> Path7 => Loc4  вер=1 порядок=3
       текст: 4
       условия: логика {[p1]>=[p25]*4 and [p24]>=4}
       эффект: P26(Number of hired liners) = 4
  -> Path8 => Loc4  вер=1 порядок=4
       текст: 5
       условия: логика {[p1]>=[p25]*5 and [p24]>=5}
       эффект: P26(Number of hired liners) = 5
  -> Path73 => Loc4  вер=1 порядок=5
       текст: 6
       условия: логика {[p1]>=[p25]*6 and [p24]>=6}
       эффект: P26(Number of hired liners) = 6
  -> Path74 => Loc4  вер=1 порядок=6
       текст: 7
       условия: логика {[p1]>=[p25]*7 and [p24]>=7}
       эффект: P26(Number of hired liners) = 7
  -> Path75 => Loc4  вер=1 порядок=7
       текст: 8
       условия: логика {[p1]>=[p25]*8 and [p24]>=8}
       эффект: P26(Number of hired liners) = 8
  -> Path76 => Loc4  вер=1 порядок=8
       текст: 9
       условия: логика {[p1]>=[p25]*9 and [p24]>=9}
       эффект: P26(Number of hired liners) = 9
  -> Path77 => Loc4  вер=1 порядок=9
       текст: 10
       условия: логика {[p1]>=[p25]*10 and [p24]>=10}
       эффект: P26(Number of hired liners) = 10
  -> Path102 => Loc2  вер=1 порядок=9
       текст: Don't hire a liner

### Loc4 [пустая]
    эффект: P1(Money) = {[p1]-[p25]*[p26]}
    эффект: P2(Number of liners) = {[p2]+[p26]}
  -> Path9 => Loc2  вер=1 порядок=5
       условия: логика {[p2]<50}
       эффект: P18(passage) = 1
       эффект: P26(Number of hired liners) = 0
       эффект: P30(terrain crossing capacity) = 1
  -> Path63 => Loc27  вер=1 порядок=5
       условия: логика {[p2]>=50}

### Loc5 [пустая]
    эффект: P2(Number of liners) = {[p2]-[p13]}
    эффект: P15(Total stolen) = {[p14]*[1000..2000]}
    эффект: P29(repairs) = {[p29]+([p14]*500)/[p20]}
  -> Path14 => Loc21  вер=1 порядок=5
       эффект: P27(profit per day) = {([p2]/[p36])*(10000+[p23]*2500)*[p3]/100}

### Loc7 [пустая]
    эффект: P29(repairs) = {([p2]*[300..500])/[p20]}
  -> Path33 => Loc16  вер=1 порядок=5
       эффект: P18(passage) = 1
       эффект: P38(Flag) = 0
  -> Path69 => Loc31  вер=1.5 порядок=5
       эффект: P38(Flag) = 0
  -> Path80 => Loc34  вер=100 проходов<=1 порядок=5
       условия: логика {[p2]>25 and [p38]=0}
  -> Path91 => Loc41  вер=1 проходов<=1 порядок=5
       условия: логика {[p2]>10 and [p38]=0}
  -> Path94 => Loc42  вер=1 проходов<=1 порядок=5
       условия: логика {[p2]>=20 and [p38]=0}
  -> Path96 => Loc43  вер=1 проходов<=1 порядок=5
       условия: логика {[p3]>=90 and [p38]=0}

### Loc9 [пустая]
    эффект: P31(total) = {[p1]+[p27]-[p28]-[p29]-[p34]-[p32]}
  -> Path17 => Loc24  вер=1 порядок=5
       эффект: P1(Money) = {[p31]} [показ]
       эффект: P3(Popularity) -2

### Loc10 [пустая]
    эффект: P31(total) = {[p1]+[p27]-[p15]-[p28]-[p29]-[p34]-[p32]}
  -> Path18 => Loc24  вер=1 порядок=5
       эффект: P1(Money) = {[p31]} [показ]
       эффект: P3(Popularity) = {[p3]-([p13]*2+[p14]*1,5)-2}

### Loc12 [обычная]
    Loc12-1: A human woman came into your office. She was good-looking and wearing stylish, posh clothing. / "Well, what do you have to tell me?" you began after half a minu…
  -> Path22 => Loc14  вер=1 порядок=1
       текст: Spend 5,000 cr. on advertising
       условия: логика {[p1]>=5000 and [p39]<>2}
       эффект: P32(advertising expenses) = 5000
       эффект: P39(Flag 1) = 2
  -> Path23 => Loc14  вер=1 порядок=3
       текст: Spend 10,000 cr. on advertising
       условия: логика {[p1]>=10000 and [p39]<>3}
       эффект: P32(advertising expenses) = 10000
       эффект: P39(Flag 1) = 3
  -> Path24 => Loc14  вер=1 порядок=5
       текст: Spend 15,000 cr. on advertising
       условия: логика {[p1]>=15000 and [p39]<>4}
       эффект: P32(advertising expenses) = 15000
       эффект: P39(Flag 1) = 4
  -> Path25 => Loc14  вер=1 порядок=7
       текст: Spend 20,000 cr. on advertising
       условия: логика {[p1]>=20000 and [p39]<>5}
       эффект: P32(advertising expenses) = 20000
       эффект: P39(Flag 1) = 5
  -> Path60 => Loc28  вер=1 порядок=9
       текст: Talk with somebody else
  -> Path106 => Loc14  вер=1 порядок=8
       текст: Don't spend 1 cr. on advertising
       условия: логика {[p32]>0 and [p39]<>1}
       эффект: P32(advertising expenses) = 0
       эффект: P39(Flag 1) = 1

### Loc13 [обычная]
    Loc13-1: An enormous maloq wearing camouflage offered you a piece of paper and stood up quietly. /  / The current security conditions for pilots are as follows: / Liners…
  -> Path39 => Loc20  вер=1 порядок=3
       текст: Hire guards
  -> Path40 => Loc19  вер=1 порядок=5
       текст: Fire guards
       условия: логика {[p33]>1}
  -> Path46 => Loc28  вер=1 порядок=5
       текст: Talk with somebody else
  -> Path59 => Loc26  вер=1 порядок=7
       текст: Return to the office

### Loc14 [пустая]
  -> Path26 => Loc28  вер=1 порядок=5
       эффект: P18(passage) = 1

### Loc15 [пустая]
    эффект: P34(guard wages) = {[p33]*1500}
  -> Path32 => Loc2  вер=1 порядок=5
       эффект: P18(passage) = 1

### Loc16 [пустая]
    эффект: P16(interest) = {(100-((([p33]-[p35])/[p2])*[120..140]))}
    эффект: P17(Parameter 17) = {(100-((([p33]-[p35])/[p2])*[100..120]))}
  -> Path34 => Loc29  вер=1 порядок=5
       условия: логика {[p16]>0 and [p17]>0}
       эффект: P14(Ships plundered) = {((([p2]/[p36])*[p17]) div 100)*[p22]/2}
  -> Path67 => Loc31  вер=1 порядок=5
       условия: логика {[p16]<=0 and [p17]<=0}
  -> Path70 => Loc31  вер=1 порядок=5
       условия: логика {[p16]<=0 or [p17]<=0}

### Loc17 [обычная]
    Loc17-1: Which staff member would you like to talk to?
  -> Path36 => Loc12  вер=1 порядок=3
       текст: Talk with the advertising manager
  -> Path37 => Loc13  вер=1 порядок=2
       текст: Talk with the security chief
       условия: логика {[p2]>[p33]}
  -> Path38 => Loc18  вер=1 порядок=1
       текст: Talk with the chief accountant
  -> Path49 => Loc26  вер=1 порядок=9
       текст: Return to the office
       эффект: P18(passage) = 1
  -> Path50 => Loc22  вер=1 порядок=4
       текст: Talk with the chief engineer
  -> Path103 => Loc45  вер=1 порядок=2
       текст: Talk with the security chief
       условия: логика {[p2]<[p33]}

### Loc18 [обычная]
    Loc18-1: The strapping fae offered you a sheet of paper with the daily report. /  / <fix> / -------------------------------------------------- / <format=left,27> Balance…
  -> Path16 => Loc26  вер=1 порядок=5
       текст: Return to the office
       эффект: P18(passage) = 1
  -> Path56 => Loc28  вер=1 порядок=5
       текст: Talk with somebody else

### Loc19 [обычная]
    Loc19-1: How many ship guards do you want to fire?
  -> Path41 => Loc15  вер=1
       текст: 1
       условия: логика {[p33]>1}
       эффект: P33(security) -1
  -> Path42 => Loc15  вер=1 порядок=1
       текст: 3
       условия: логика {[p33]>3}
       эффект: P33(security) -3
  -> Path43 => Loc15  вер=1 порядок=2
       текст: 5
       условия: логика {[p33]>5}
  -> Path44 => Loc15  вер=1 порядок=4
       текст: 7
       условия: логика {[p33]>7}
       эффект: P33(security) -7
  -> Path45 => Loc15  вер=1 порядок=5
       текст: 10
       условия: логика {[p33]>10}
       эффект: P33(security) -10
  -> Path101 => Loc17  вер=1 порядок=9
       текст: Don't fine

### Loc20 [обычная]
    Loc20-1: How many ship guards do you want to hire?
  -> Path27 => Loc15  вер=1
       текст: 1
       эффект: P33(security) +1
  -> Path28 => Loc15  вер=1 порядок=1
       текст: 3
       эффект: P33(security) +3
  -> Path29 => Loc15  вер=1 порядок=2
       текст: 5
       эффект: P33(security) +5
  -> Path30 => Loc15  вер=1 порядок=4
       текст: 7
       эффект: P33(security) +7
  -> Path31 => Loc15  вер=1 порядок=5
       текст: 10
       эффект: P33(security) +10
  -> Path100 => Loc17  вер=1 порядок=9
       текст: Don't hire

### Loc21 [пустая]
  -> Path47 => Loc10  вер=1 порядок=5
       условия: логика {[p13]>0 and [p14]>0 or [p13]>0 or [p14]>0}
       эффект: P18(passage) = 2
  -> Path48 => Loc10  вер=1 порядок=5
       условия: логика {[p13]<=0 and [p14]<=0}
       эффект: P18(passage) = 1

### Loc22 [обычная]
    Loc22-1: The chief engineer, an elderly peleng sporting a beard and glasses, proposes the following: /  / 1. Stock up on the latest equipment for routine maintenance and…
  -> Path51 => Loc23  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Buy new repair equipment for <clr>20,000 cr.<clrEnd>
       условия: логика {[p1]>=20000}
       эффект: P1(Money) = {[p1]-20000}
       эффект: P20(repair equipment) = 2
  -> Path52 => Loc23  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Enhance comfort for <clr>25,000 cr.<clrEnd>
       условия: логика {[p1]>=25000}
       эффект: P1(Money) = {[p1]-25000}
       эффект: P21(comfort enhancement) = 1
  -> Path53 => Loc23  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Equip liners with protective measures for <clr>30,000 cr.<clrEnd>
       условия: логика {[p1]>=30000}
       эффект: P1(Money) = {[p1]-30000}
       эффект: P22(weaponization of ships) = 1
  -> Path54 => Loc23  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Increase the number of seats for <clr>30,000 cr.<clrEnd>
       условия: логика {[p1]>=30000}
       эффект: P1(Money) = {[p1]-30000}
       эффект: P23(increased seats) = 1
  -> Path61 => Loc26  вер=1 порядок=6
       текст: Return to the office
  -> Path64 => Loc28  вер=1 порядок=5
       текст: Talk with somebody else

### Loc23 [пустая]
  -> Path55 => Loc22  вер=1 порядок=5
       эффект: P18(passage) = 1

### Loc24 [пустая]
  -> Path57 => Loc2  вер=1 порядок=5
       условия: логика {[p31]>0 and [p4]<>11 and [p4]<>16}
       эффект: P4(Parameter 4) -1
  -> Path58 => Loc25  вер=1 порядок=5
       условия: логика {[p31]<=0}
  -> Path108 => Loc2  вер=1 проходов<=1 порядок=5
       условия: логика {[p31]>0 and [p4]=11}
       эффект: P4(Parameter 4) -1
       эффект: P18(passage) = 5
  -> Path113 => Loc2  вер=1 проходов<=1 порядок=5
       условия: логика {[p31]>0 and [p4]=16}
       эффект: P4(Parameter 4) -1
       эффект: P18(passage) = 6

### Loc25 [ПРОВАЛ]
    Loc25-1: A phone call from Lyakusha Moneybags awoke you early in the morning. He was clearly in a foul mood and asked you to come into the office right away. / In an ins…

### Loc26 [пустая]
    эффект: P18(passage) = 1
  -> Path62 => Loc2  вер=1 порядок=5

### Loc27 [УСПЕХ]
    Loc27-1: After engaging the last batch of liners, you dialed Lyakusha Moneybags's phone number and told him the good news. He was so happy that in ten minutes he had joi…

### Loc28 [пустая]
  -> Path65 => Loc17  вер=1 порядок=5

### Loc29 [пустая]
    эффект: P13(Ships destroyed) = {(((([p2]/[p36])-[p14])*[p16]) div 100)*[p22]/2}
  -> Path66 => Loc5  вер=1 порядок=5

### Loc31 [пустая]
  -> Path11 => Loc9  вер=1 порядок=5
       эффект: P18(passage) = 3
       эффект: P27(profit per day) = {([p2]/[p36])*(10000+[p23]*2500)*[p3]/100}

### Loc32 [пустая]
  -> Path71 => Loc3  вер=1 порядок=5
       условия: логика {[p24]>0}
  -> Path72 => Loc2  вер=1 порядок=5
       условия: логика {[p24]=0}
       эффект: P18(passage) = 4
       эффект: P30(terrain crossing capacity) = 1

### Loc33 [обычная]
    Loc33-1: "It all started when my father departed to another world," began Lyakusha. "I inherited his company, which had been his darling his whole life and had provided …
  -> Path79 => Loc2  вер=1 порядок=5
       текст: Okay, I get it clearly now. Yeah...this is a hairy little problem. Get down here to the office. Not a minute to lose!

### Loc34 [обычная] визитов<=1
    Loc34-1: Less than half an hour later the office girl, quite agitated, ran into the office with huge round eyes and a pale face. / "What happened?" you asked, getting up…
    эффект: P38(Flag) = 1
  -> Path81 => Loc35  вер=1 порядок=4
       текст: Okay. I'll talk to them. Meanwhile, you report this to the galactic police.
  -> Path82 => Loc36  вер=1 порядок=5
       текст: I'm not going to talk to them. Let the galactic police handle this!

### Loc35 [обычная]
    Loc35-1: After connecting to line five and gathering your strength, you picked up the receiver: / "I'm here." / "Listen very carefully. We're deadly serious and don't in…
  -> Path83 => Loc37  вер=1 порядок=5
       текст: I agree to your demands. In a few seconds a couple of liners will be on the closest uninhabited planet. You can transfer into them there.  The money will be tra…
  -> Path85 => Loc39  вер=1 порядок=5
       текст: I don't have that kind of money! And you should know that the galactic police are on their way!

### Loc36 [обычная]
    Loc36-1: "But they say they'll detonate the liner with all the passengers, and then our reputation will be completely destroyed."
  -> Path86 => Loc40  вер=1 порядок=5
       текст: What do I care!
  -> Path90 => Loc35  вер=1 порядок=5
       текст: Okay. I'll talk with them.

### Loc37 [обычная]
    Loc37-1: "We're men of our word. As soon as our conditions are met, we'll release everybody!" /  / After a couple of hours you received a message that the hijacked liner…
  -> Path84 => Loc44  вер=1 порядок=5
       текст: Life goes on!
       эффект: P1(Money) = {[p1]-([p1] div 1,5)}
       эффект: P3(Popularity) -10
       эффект: P2(Number of liners) -2

### Loc39 [обычная]
    Loc39-1: In about an hour, several people flashing GCTU (Galactic Counterterrorism Unit) badges entered your office. They informed you that your liner had been detonated…
  -> Path89 => Loc44  вер=1 порядок=5
       текст: Of course, I'll pay. It's the least I can do for the victims' families!
       эффект: P1(Money) = {[p1]-([p1]/1,2)}
       эффект: P3(Popularity) -20

### Loc40 [СМЕРТЬ]
    Loc40-1: In about an hour, several people flashing GCTU (Galactic Counterterrorism Unit) badges entered your office. They slapped handcuffs on you and took you into cust…

### Loc41 [обычная] визитов<=1
    Loc41-1: The office girl was in your office in twenty minutes. / "Today is Defender of the Galaxy Day!" / "Congratulations. So what?" / "Our liners don't have any guards…
    эффект: P38(Flag) = 1
  -> Path92 => Loc16  вер=1 порядок=5
       текст: Send liners without guards
       эффект: P34(guard wages) = 0
       эффект: P35(Guard absenteeism) = {[p33]}
  -> Path93 => Loc2  вер=1 порядок=3
       текст: Postpone all flights for today
       эффект: P1(Money) = {[p1]-[p32]}
       эффект: P3(Popularity) -10
       эффект: P4(Parameter 4) -1
       эффект: P18(passage) = 3
       эффект: P27(profit per day) = 0

### Loc42 [обычная] визитов<=1
    Loc42-1: The office girl came into your office and said that an hour ago some people were detained at the spaceport. They had been attempting to remove very rare animals…
    эффект: P38(Flag) = 1
  -> Path95 => Loc16  вер=1 проходов<=1 порядок=5
       текст: Nothing can be done. Half of the flights will have to be postponed.
       эффект: P36(Contraband) = 2

### Loc43 [обычная] визитов<=1
    Loc43-1: In less than five minutes, the chief accountant came into your office. / "What happened?" you asked. / "Well, it happened that the pilots are demanding an pay r…
    эффект: P38(Flag) = 1
  -> Path97 => Loc16  вер=1 порядок=5
       текст: Fine. Let's double it.
       эффект: P37(Wages) = 3000
  -> Path98 => Loc16  вер=1 порядок=9
       текст: Fine. Let's triple it.
       эффект: P37(Wages) = 4500

### Loc44 [пустая]
  -> Path99 => Loc16  вер=1 порядок=5

### Loc45 [обычная]
    Loc45-1: An enormous maloq wearing camouflage offered you a piece of paper and stood up quietly. /  / The current security conditions for pilots are as follows: / Liners…
  -> Path104 => Loc20  вер=1 порядок=3
       текст: Hire guards
  -> Path105 => Loc19  вер=1 порядок=5
       текст: Fire guards
       условия: логика {[p33]>1}
  -> Path112 => Loc26  вер=1 порядок=7
       текст: Return to the office

### Loc46 [ПРОВАЛ]
    Loc46-1: After thinking it over again, you took the money after all. You quickly gathered all of your gear and headed for the spaceport.

### Loc47 [пустая]
  -> Path111 => Loc2  вер=1 порядок=5
       эффект: P18(passage) = 1

### Loc48 [пустая]
  -> Path117 => Loc2  вер=1 порядок=5
       эффект: P18(passage) = 1

## Анализ
- стартовых: [1]
- концовки: {25: 'ПРОВАЛ', 27: 'УСПЕХ', 40: 'СМЕРТЬ', 46: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
