# Квест (формат 1111111126)
Сложность 70; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Relation' [0..10] тип=обычный
    старт: [0]
    [0..10] RELATION TO YOU:
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Prince' [0..15] тип=провал
    старт: [5]
    [0..2] Prince Tardym: <clr>irritated<clrEnd>
    [3..4] Prince Tardym: <clr>despise<clrEnd>
    [5..6] Prince Tardym: <clr>distrust<clrEnd>
    [7..9] Prince Tardym: <clr>normal<clrEnd>
    [10..11] Prince Tardym: <clr>good<clrEnd>
    [12..13] Prince Tardym: <clr>liking<clrEnd>
    [14..15] Prince Tardym: <clr>respect<clrEnd>
    критическое: Suddenly the Maloq Prince made a wry face and pointed in your direction: / - Get this sorry wonky ou…
- P3 "Prince Tardym's wife" [0..13] тип=провал
    старт: [5]
    [0..1] Tardym's wife: <clr>irritated<clrEnd>
    [2..3] Tardym's wife: <clr>despise<clrEnd>
    [4..5] Tardym's wife: <clr>distrust<clrEnd>
    [6..7] Tardym's wife: <clr>normal<clrEnd>
    [8..9] Tardym's wife: <clr>interest<clrEnd>
    [10..11] Tardym's wife: <clr>liking<clrEnd>
    [12..13] Tardym's wife: <clr>respect<clrEnd>
    критическое: Suddenly the Maloq Princess sighed heavily and jerked her husband's sword-belt: / - Tari, I did ask …
- P4 'YOU ARE DRESSED IN:' [0..5] тип=обычный
    старт: [0]
    [0..5] YOU ARE DRESSED IN:
    критическое: Сообщение достижения критического значения параметром 5
- P5 'Clothes type' [0..5] тип=обычный
    старт: [2]
    [0..0] Belts, sword-belts, weapons
    [1..1] Defense panzer
    [2..2] Ranger suit
    [3..3] Butler suit
    [4..4] Neat tuxedo
    [5..5] Rich and flamboyant suit
    критическое: Сообщение достижения критического значения параметром 6
- P6 'Presents (rfl/shll/bpck)' [0..111] тип=обычный
    старт: [111]
    [0..111] Parameter N 11: <>
    критическое: Сообщение достижения критического значения параметром 11
- P7 'money' [0..99999999] тип=обычный деньги
    старт: [1000]
    [0..99999999] Your money: <> cr
    критическое: Сообщение достижения критического значения параметром 2
- P9 'Hint used' [0..1] тип=обычный
    старт: [0]
    [0..1] Параметр номер 9: <>
    критическое: Сообщение достижения критического значения параметром 9
- P12 'Dialogue' [0..10] тип=обычный
    старт: [1]
    [0..10] Parameter N 12: <>
    критическое: Сообщение достижения критического значения параметром 12
- P13 'KINZA' [0..1] тип=обычный
    старт: [0]
    [0..1] <clr>KINZA:<clrEnd>
    критическое: Сообщение достижения критического значения параметром 16
- P14 'Alcohol:' [0..100] тип=обычный
    старт: [0]
    [0..100] Alcohol: <> percent.
    критическое: Сообщение достижения критического значения параметром 13
- P15 'Transparency' [0..100] тип=обычный
    старт: [0]
    [0..100] Transparency: <>%
    критическое: Сообщение достижения критического значения параметром 14
- P16 'Carbonation' [0..100] тип=обычный
    старт: [0]
    [0..100] Carbonation: <> units.
    критическое: Сообщение достижения критического значения параметром 15
- P17 'Attempts' [0..10] тип=обычный
    старт: [0]
    [0..10] ======================<br>Cubes more needed: <>
    критическое: Сообщение достижения критического значения параметром 17
- P20 'Discil' [0..5] тип=обычный
    старт: [5]
    [0..5] Parameter N 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'hukhmel' [0..5] тип=обычный
    старт: [5]
    [0..5] Parameter N 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'repusator' [0..5] тип=обычный
    старт: [5]
    [0..5] Parameter N 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'water' [0..5] тип=обычный
    старт: [5]
    [0..5] Parameter N 23: <>
    критическое: Сообщение достижения критического значения параметром 23

## Локации и переходы

### Loc1 [СТАРТ] визитов<=6
    выбор описания: {[p12]}
    Loc1-1: You arrived on the planet of <ToPlanet> early in the morning and landed your ship on the Government Palace landing platform. Judging by the general air of excit…
    Loc1-2: - There are several reasons for that.  /  / First of you have been all over this Galaxy and I am sure you met Maloqs on more than one occasion, so you must know…
    Loc1-3: - Princess Hanna ge-de Ka'Boom Teodam Crunch "Looks Killer" was born in the family of a technician. When she received her right to bear arms, she swore to becom…
    Loc1-4: - The Prince himself was born to the family of famous warriors, who have been occupying the throne of his native system for several generations already. Most ob…
    Loc1-5: - In fact I know very little of them.  /  / The Maloq race was born on a hot planet, the majority of which is desert. Throughout its development, the Maloq civi…
    Loc1-6: - The welcoming ceremony will be in true Maloq tradition, this is a seated event. You will be entertaining and escorting the envoys.  /  / First there will be t…
    скрыт: P6,P9,P12,P13,P14,P15,P16,P17,P20,P21,P22,P23
    показ: P7
  -> Path2 => Loc2  вер=1 проходов<=1
       текст: I don't think, I have any questions, let me pick my suit
  -> Path4 => Loc3  вер=1 проходов<=1 порядок=2
       текст: Why did the <ToPlanet> government choose me?
       эффект: P12(Dialogue) = {2}
  -> Path5 => Loc3  вер=1 проходов<=1 порядок=5
       текст: What can you tell me about the Prince's wife?
       эффект: P12(Dialogue) = {3}
  -> Path6 => Loc3  вер=1 проходов<=1 порядок=4
       текст: Tell me about Prince Tardym
       эффект: P12(Dialogue) = {4}
  -> Path7 => Loc3  вер=1 проходов<=1 порядок=6
       текст: What can you say about Maloqs in general?
       эффект: P12(Dialogue) = {5}
  -> Path8 => Loc3  вер=1 проходов<=1 порядок=3
       текст: What is the structure of the ceremony?
       эффект: P12(Dialogue) = {6}

### Loc2 [обычная] визитов<=1
    Loc2-1: You approach a huge wardrobe, which, as it seemed to you, contains everything that may be needed to make the necessary impression on the high-ranking couple. / …
  -> Path9 => Loc4  вер=1 проходов<=1 порядок=5
       текст: Stay in your space-suit
  -> Path10 => Loc4  вер=1 проходов<=1 порядок=4
       текст: Put on a butler suit, like all the other servants
       эффект: P5(Clothes type) = {3}
  -> Path11 => Loc4  вер=1 проходов<=1 порядок=9
       текст: Put on a strangely designed suit made of belts, sheathes, and swordbelts
       эффект: P5(Clothes type) = {0}
  -> Path12 => Loc4  вер=1 проходов<=1 порядок=7
       текст: Put on a set of light armour
       эффект: P5(Clothes type) = {1}
  -> Path13 => Loc4  вер=1 проходов<=1 порядок=2
       текст: Put on a tuxedo
       эффект: P5(Clothes type) = {4}
  -> Path14 => Loc4  вер=1 проходов<=1
       текст: Pull on a magnificently-scenting fashionable jacket, decorated with precious stones
       эффект: P5(Clothes type) = {5}

### Loc3 [пустая] визитов<=6
  -> Path3 => Loc1  вер=1 проходов<=6 порядок=5

### Loc4 [обычная] визитов<=2
    Loc4-1: Alright truly , now you are prepared to meet the dear guests... Although, you never understood, where exactly this way of meeting the guests would be considered…
  -> Path116 => Loc47  вер=1 проходов<=1 порядок=3
       текст: Listen my brood man... I mean - my good man, maybe you know...
  -> Path146 => Loc5  вер=1 проходов<=1 порядок=5
       текст: Then again, I reconsidered, you are free to go.

### Loc5 [обычная] визитов<=3
    Loc5-1: Soon the sound of the trumpets... or, to be more exact, a gobzaurus with a sore throat and an accompaniment of fighting penchekryaks announced the arrival of th…
  -> Path32 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Meet the Maloq envoys as fits properly
       эффект: P2(Prince) = {[p2]-([p5]=5)*2-[1..2]*([p5]=4)-([p5]=3)+([p5]=2)*[0..1]+([p5]=0)*2+([p5]=1)*[1..2]}
       эффект: P3(Prince Tardym's wife) = {[p2]+([p5]=5)*2+[1..2]*([p5]=4)-([p5]=0)*2-[1..2]*([p5]=1)-[0..1]*([p5]=2)}
  -> Path142 => Loc53  вер=1 проходов<=1 порядок=5
       текст: Hide in the nearest dog-hole and wait
  -> Path143 => Loc54  вер=1 проходов<=1 порядок=5
       текст: Pull out your blasters and "surprise" the envoys with an unexpected appearance

### Loc6 [обычная] визитов<=8
    выбор описания: {[p12]}
    Loc6-1: Prince Tardym Whatsitcalled. With a Prince like that his subjects should have no fear of Dominators. I mean this guy could eat a gobzaurus and ask for seconds a…
    Loc6-2: You remembered seeing a couple have times when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's ha…
    Loc6-3: You decided that the most neutral and universal demonstration of politeness would be a bow. And the more important and high-ranking the guest is, the lower shou…
    Loc6-4: Letting out a loud battle cry you kicked the Prince right between the legs with all your might - this custom or something similar to it was what your Peleng-fri…
    Loc6-5: You remembered a couple of instances when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's hard to…
    Loc6-6: Without giving it a second thought you simply gripped the Prince by the hand and attempted to shake it. Tardym's face drew tight, and he was already about to co…
    Loc6-7: You remembered a couple of instances when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's hard to…
  -> Path18 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Now greet the Prince's wife
       условия: P4(YOU ARE DRESSED IN:) ∉[2]; логика {[p12]>1}
       эффект: P4(YOU ARE DRESSED IN:) +1
       эффект: P12(Dialogue) = {1}
  -> Path22 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Lead them to the banquet hall
       условия: P1(Relation) ∈[2]
       эффект: P12(Dialogue) = {1}
  -> Path24 => Loc9  вер=1 проходов<=1 порядок=3
       текст: Punch the Prince in the shoulder with all your might
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -2
       эффект: P11(Самочувствие) = {[p11]-[3..5]}
       эффект: P12(Dialogue) = {2}
  -> Path26 => Loc9  вер=1 проходов<=1 порядок=8
       текст: Bow to the Prince 33 times
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {3}
  -> Path27 => Loc9  вер=1 проходов<=1 порядок=2
       текст: Slightly punch the Prince on the jaw
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) +1
       эффект: P11(Самочувствие) = {[p11]-[5..7]}
       эффект: P12(Dialogue) = {5}
  -> Path28 => Loc9  вер=1 проходов<=1 порядок=5
       текст: Kick the Prince between the legs
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -1
       эффект: P11(Самочувствие) = {[p11]-[15..25]}
       эффект: P12(Dialogue) = {4}
  -> Path47 => Loc9  вер=1 проходов<=1
       текст: Shake the Prince's hand
       условия: P12(Dialogue) ∈[1]
       эффект: P12(Dialogue) = {6}
  -> Path48 => Loc9  вер=1 проходов<=1 порядок=1
       текст: Jab the Prince full-force on the jaw
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) +2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P11(Самочувствие) = {[p11]-[12..17]}
       эффект: P12(Dialogue) = {7}

### Loc7 [обычная] визитов<=8
    выбор описания: {[p12]}
    Loc7-1: You carefully approached Princess Hanna ge-de Ka'Boom (who knows, what if something falls off her toilet and right onto you foot, crippling you for life) trying…
    Loc7-2: You carefully took the Princess's hairy hand into yours... it must be mentioned here, that bringing that muscular monster of a hand to your lips took you quite …
    Loc7-3: You remembered a couple of times when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's hard to ima…
    Loc7-4: Looking around yourself you spotted a vase with flowers and pulled out a couple. Your firmly paced towards the Princess, fell onto one knee and presented the fl…
    Loc7-5: You remembered a couple of times when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's hard to ima…
    Loc7-6: You remembered a couple of times when Maloqs would exchange punches to greet each other, allegedly demonstrating their strength and amiability. It's hard to ima…
    Loc7-7: You goggled your eyes frantically and spat the Princess right into the face. Having accomplished that preposterous act, you started jumping around and yelling w…
  -> Path19 => Loc6  вер=1 проходов<=1 порядок=5
       текст: Now greet the Prince himself
       условия: P4(YOU ARE DRESSED IN:) ∉[2]; логика {[p12]>1}
       эффект: P4(YOU ARE DRESSED IN:) +1
       эффект: P12(Dialogue) = {1}
  -> Path23 => Loc10  вер=1 проходов<=1 порядок=5
       текст: Lead them to the banquet hall
       условия: P1(Relation) ∈[2]
       эффект: P12(Dialogue) = {1}
  -> Path25 => Loc8  вер=1 проходов<=1
       текст: Kiss the Princess's hand
       условия: P12(Dialogue) ∈[1]
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {2}
  -> Path29 => Loc8  вер=1 проходов<=1 порядок=5
       текст: Punch the Princess in the shoulder
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) -2
       эффект: P11(Самочувствие) = {[p11]-[1..5]}
       эффект: P12(Dialogue) = {3}
  -> Path30 => Loc8  вер=1 проходов<=1 порядок=1
       текст: Give the Princess a flower and bow
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +2
       эффект: P12(Dialogue) = {4}
  -> Path31 => Loc8  вер=1 проходов<=1 порядок=2
       текст: Slightly jab the Princess on the jaw
       условия: P12(Dialogue) ∈[1]
       эффект: P3(Prince Tardym's wife) -1
       эффект: P11(Самочувствие) = {[p11]-[3..5]}
       эффект: P12(Dialogue) = {5}
  -> Path49 => Loc8  вер=1 проходов<=1 порядок=1
       текст: Jab the Princess full swing on the cheek
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) -1
       эффект: P11(Самочувствие) = {[p11]-[10..15]}
       эффект: P12(Dialogue) = {6}
  -> Path50 => Loc8  вер=1 проходов<=1 порядок=6
       текст: Spit into the face of the Princess and shriek wildly
       условия: P12(Dialogue) ∈[1]
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {7}

### Loc8 [пустая]
    эффект: P1(Relation) +1
  -> Path21 => Loc7  вер=1 порядок=5

### Loc9 [пустая]
    эффект: P1(Relation) +1
  -> Path20 => Loc6  вер=1 порядок=5

### Loc10 [обычная] визитов<=7
    Loc10-1: You enter the main banquet hall. There the preparations for the reception have been completed already - tables were turned and greeted you with the gleaming of …
  -> Path33 => Loc12  вер=1 проходов<=1 порядок=1
       текст: Put the basin in the middle, knife on the left and fork on the right
       эффект: P12(Dialogue) = {3}
  -> Path34 => Loc12  вер=1 проходов<=1
       текст: Put the basin in the middle, knife on the right and fork on the left
       эффект: P12(Dialogue) = {3}
  -> Path35 => Loc12  вер=1 проходов<=1 порядок=3
       текст: Put the basin in the middle, fork on the left, and drive the knife into the table on the right
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {2}
  -> Path36 => Loc12  вер=1 проходов<=1 порядок=4
       текст: Put the basin in the middle, and stick both the knife and the fork (what the heck?) into the table on both sides
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {2}
  -> Path37 => Loc12  вер=1 проходов<=1 порядок=7
       текст: Throw everything on the floor - let them know their place
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {4}
  -> Path38 => Loc12  вер=1 проходов<=1 порядок=6
       текст: Put the basin down on the table, put the knife in it, and stealthily stick the fork into the back of the chair
       эффект: P2(Prince) -1
       эффект: P12(Dialogue) = {1}
  -> Path58 => Loc20  вер=1 проходов<=1 порядок=9
       текст: Stick the fork right into the eye of Prince Tardym and laugh wildly

### Loc11 [обычная] визитов<=2
    выбор описания: {([p5]>3)+([p5]=3)*3+([p5]=2)*2+([p5]<2)*4}
    Loc11-1: You slowly approached the Maloqs accompanied by a suit of bodyguards, trying to keep your hands in clear view, but at the same time showing that you are ready t…
    Loc11-2: You slowly approached the Maloqs accompanied by a suit of bodyguards, trying to keep your hands in clear view, but at the same time showing that you are ready t…
    Loc11-3: You slowly approached the Maloqs accompanied by a suit of bodyguards, trying to keep your hands in clear view, but at the same time showing that you are ready t…
    Loc11-4: You slowly approached the Maloqs accompanied by a suit of bodyguards, trying to keep your hands in clear view, but at the same time showing that you are ready t…
    эффект: P1(Relation) = {0}
    эффект: P4(YOU ARE DRESSED IN:) = {0}
    эффект: P12(Dialogue) = {1}
  -> Path16 => Loc6  вер=1 проходов<=1 порядок=5
       текст: Greet the Prince first
       эффект: P4(YOU ARE DRESSED IN:) +1
  -> Path17 => Loc7  вер=1 проходов<=1 порядок=5
       текст: Greet the Maloq Princess
       эффект: P4(YOU ARE DRESSED IN:) +1

### Loc12 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc12-1: Having accomplished your mean doing, you quietly stepped aside. Talking to his wife, Tardym leaned back in his chair and... Well, if we should be polite and cut…
    Loc12-2: Satisfied the Prince grunted and drove his knife into the table in one powerful blow. You could have staked the fee from your next government mission that the t…
    Loc12-3: Prince Tardym did not pay any attention to this layout of the tableware, although you noticed that for all the other delegation member's knives had been driven …
    Loc12-4: Prince Tardym watched your actions in bewilderment ad was about to sound his indignation, when the Princess hushed him, explaining that some of the more primiti…
  -> Path39 => Loc13  вер=1 проходов<=1 порядок=5
       текст: Bring the first course from the kitchen
       эффект: P1(Relation) = {0}
       эффект: P4(YOU ARE DRESSED IN:) = {0}
       эффект: P9(Hint used) = 0
       эффект: P12(Dialogue) = {1}

### Loc13 [обычная] визитов<=6
    выбор описания: {[p12]}
    Loc13-1: Now was the time to serve the Maloq food. I rushed out into the dining room following the example of other servants. Taking the tray with strange brownish mass,…
    Loc13-2: - Er, say, oh brave warrior. I am at a loss here, maybe you can help me - what do you normally start you meals with and what is this thing on the plate? /  / - …
    Loc13-3: You stopped one of the waiters who was passing by and asked what kind of a drink would be better for Maloq diplomats. He answered after a short pause: /  / - No…
    Loc13-4: Noticing a Peleng-know-all who was passing you by, you waved a bundle of credits invitingly: / - Hey. You, two hundred, come over here... /  / Tsiga Romalych ma…
  -> Path40 => Loc14  вер=1 проходов<=1 порядок=6
       текст: Ask the young Maloq for advice before he left
       условия: P9(Hint used) 0..0
       эффект: P1(Relation) +1
       эффект: P12(Dialogue) = {2}
  -> Path41 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Take the barmy juice
       эффект: P4(YOU ARE DRESSED IN:) = {2}
  -> Path42 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Take the sour milk
       эффект: P3(Prince Tardym's wife) +1
       эффект: P4(YOU ARE DRESSED IN:) = {3}
  -> Path43 => Loc15  вер=1 проходов<=1 порядок=5
       текст: Take the fresh blood
       эффект: P4(YOU ARE DRESSED IN:) = {1}
  -> Path46 => Loc14  вер=1 проходов<=1 порядок=7
       текст: Ask one of the Human-waiter for help
       условия: P9(Hint used) 0..0
       эффект: P12(Dialogue) = {3}
  -> Path141 => Loc14  вер=1 [всегда видна] проходов<=1 порядок=8
       текст: Buy the info from the passing by Peleng-waiter (200 creds)
       условия: P9(Hint used) 0..0; логика {[p7]>=200}
       эффект: P7(money) = {[p7]-200}
       эффект: P12(Dialogue) = {4}

### Loc14 [пустая] визитов<=1
    эффект: P9(Hint used) = 1
  -> Path45 => Loc13  вер=1 проходов<=1 порядок=5

### Loc15 [пустая] визитов<=1
    Loc15-1: You put the glasses on the tray, although one can hardly refer to a one-litre vessel as a glass. The young Maloq once again suggested that you play a joke on hi…
  -> Path52 => Loc16  вер=1 проходов<=1 порядок=5

### Loc16 [обычная] визитов<=1
    выбор описания: {[p4]}
    Loc16-1: You carefully placed the glasses on the tray, took the plates with the "salad" in your other hand, and left the kitchen. /  / When you put the glasses with bloo…
    Loc16-2: You carefully placed the glasses on the tray, took the plates with the "salad" in your other hand, and left the kitchen. /  / When you put the wineglasses in fr…
    Loc16-3: You carefully placed the glasses on the tray, took the plates with the "salad" in your other hand, and left the kitchen. /  / When you put the glasses with milk…
    эффект: P2(Prince) = {[p2]+([p4]=1)-([p4]=2)}
  -> Path53 => Loc21  вер=1 проходов<=1 порядок=5
       текст: Stand behind the Prince and wait till the first course is over
       эффект: P2(Prince) -1
       эффект: P12(Dialogue) = {1}
  -> Path54 => Loc21  вер=1 проходов<=1 порядок=6
       текст: Stand to the side of the Prince and wait till the first course is over
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {2}
  -> Path55 => Loc21  вер=1 проходов<=1 порядок=2
       текст: Stand between the Prince and his wife and wait till the first course is over
       эффект: P12(Dialogue) = {3}
  -> Path56 => Loc22  вер=1 проходов<=1 порядок=7
       текст: Stand to the side of the Princess and wait till the first course is over
       эффект: P12(Dialogue) = {1}
  -> Path57 => Loc21  вер=1 проходов<=1 порядок=8
       текст: Crawl under the table and wait till the first course is over
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {4}
  -> Path59 => Loc19  вер=1 проходов<=1 порядок=9
       текст: Climb on the table and jump all over it carefully stepping into the plates
       эффект: P12(Dialogue) = {1}

### Loc19 [ПРОВАЛ]
    выбор описания: {[p12]}
    Loc19-1: Outraged by your awful behaviour the diplomats tried to knock you off the table with stools and trays, but you skilfully dodged the improvised projectiles and c…
    Loc19-2: Having said that you glanced at Tardym. Why, oh why, were you not born deaf and blind? Or better, why were you not born a beautiful smelling flower on a field i…

### Loc20 [СМЕРТЬ] визитов<=1
    Loc20-1: Suddenly you got it into your head that you don't like the Prince, and grinned spitefully. Grabbing a fork you drove it right through the eye of the Maloq heir.…

### Loc21 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc21-1: Unfazed, you stood behind the Prince. He tried to concentrate on his food, but kept glancing back at you. Finally he managed: /  / - Hey, you... ranger, you bet…
    Loc21-2: Unfazed, you stood by the Prince's side. He glanced approvingly in your direction: / - Looks like not all of the saucermen are as helplessly dumb as I used to t…
    Loc21-3: Unfazed, you stood between the Prince and his wife. He looked at you disapprovingly: /  / - I do not think, that in case of any danger you'd be able to kill fas…
    Loc21-4: Unfazed, you crawled under the table and let out a sigh of relief. However already the next instance you regretted your own stupidity - the massive legs of the …
  -> Path63 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Continue

### Loc22 [обычная] визитов<=5
    выбор описания: {[p12]}
    Loc22-1: Unfazed, you stood on the left side of the Princess (Tardym sat on her other side). The Prince noticed you position and raised his hairy and rather a muscled ey…
    Loc22-2: - Run? - Tardym looked surprised - Somehow I thought that the rangers knew no fear and were always prepared to meet danger face to face.  /  / - Looks like you …
    Loc22-3: - What is that kind of a stupid custom? - Tardym looked surprised, - are your females so weak that they even cannot break off a leg of a hypofrog or split open …
    Loc22-4: - That's my man, a tactically correct disposition, - the Maloq Prince laughed and paused to consider what he'd just blurted out. - If anything happens, the retr…
  -> Path60 => Loc19  вер=1 проходов<=1 порядок=9
       текст: This way it is more convenient to pick something from her pockets
       условия: P12(Dialogue) ∈[1]
       эффект: P12(Dialogue) = {2}
  -> Path62 => Loc24  вер=1 проходов<=1 порядок=5
       текст: Continue
       условия: P12(Dialogue) ∉[1]
  -> Path64 => Loc23  вер=1 проходов<=1 порядок=6
       текст: The distance from here to the exit is shorter - just in case
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {2}
  -> Path65 => Loc23  вер=1 проходов<=1 порядок=2
       текст: From here it's is just more convenient to serve the lady at the table, you know pass her sauces, wipe her dirty mug
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {3}
  -> Path66 => Loc23  вер=1 проходов<=1 порядок=5
       текст: In case anything happens, it's easier to bring ammo from here, and take away the enemy bodies
       условия: P12(Dialogue) ∈[1]
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {4}

### Loc23 [пустая] визитов<=1
  -> Path61 => Loc22  вер=1 проходов<=1 порядок=5

### Loc24 [обычная] визитов<=5
    Loc24-1: Meanwhile the guests started a casual conversation, everyone wanted to tell something extraordinary that happened to them... If one should really believe that M…
    эффект: P12(Dialogue) = {1}
  -> Path67 => Loc25  вер=1 проходов<=1 порядок=9
       текст: Tell them how much tribute you have collected from the merchants over the past month, and how many you killed at that
       эффект: P2(Prince) -2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {1}
  -> Path68 => Loc25  вер=1 проходов<=1 порядок=2
       текст: Tell them how you captured the Super-Mega-Brain of the Dominators and subjected it to cruel torments
       эффект: P2(Prince) -1
       эффект: P12(Dialogue) = {4}
  -> Path69 => Loc25  вер=1 проходов<=1 порядок=5
       текст: Boast about the order you cut out for yourself with a blaster from Terron's hull
       эффект: P2(Prince) = {[p2]+[0..1]}
       эффект: P3(Prince Tardym's wife) = {[p3]+[0..1]}
       эффект: P12(Dialogue) = {2}
  -> Path70 => Loc25  вер=1 проходов<=1
       текст: Tell them about your scalp collection that you took from the most arrant thugs and pirates of this Galaxy
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {3}
  -> Path71 => Loc25  вер=1 проходов<=1 порядок=6
       текст: Remember a romantic story of your feelings towards a Princess who had been kidnapped by hyper-pirates
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +2
       эффект: P12(Dialogue) = {5}

### Loc25 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc25-1: Your story seemed to have not only a terrifying effect on the Prince himself, but on everyone else present as well. Looks like they did not have much liking for…
    Loc25-2: Obviously, you did not have any orders - this was simply an ancient coin, molten slightly from an energy-gun shot, but the Maloqs did not necessarily have to kn…
    Loc25-3: The Maloq military seemed to like your story - as it turned out scalping the enemy was rather a common thing for the Maloqs. They neglected stealing and looting…
    Loc25-4: - Lies! - A Maloq envoy rose to protest. - Everybody knows that it was me who destroyed that Super-Whatsitcalled!!! All the saucermen are mean liars always tryi…
    Loc25-5: Already half-way through your exciting story, the Maloqs started yawning widely demonstrating their indifference. Somebody asked you how many victims and blaste…
  -> Path72 => Loc26  вер=1 проходов<=1 порядок=5
       текст: Bring the strong brings and relevant food

### Loc26 [обычная] визитов<=1
    Loc26-1: The array of alcoholic and conditionally alcoholic drinks was quite impressive. And that was not counting the aldehyde and alkali cocktails that you recognised …
  -> Path73 => Loc27  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Off him 200 creds as rent for the cart and promise to be careful with it
       условия: логика {[p7]>=200}
       эффект: P2(Prince) -1
       эффект: P7(money) = {[p7]-200}
       эффект: P12(Dialogue) = {1}
  -> Path74 => Loc27  вер=1 проходов<=1 порядок=3
       текст: Use the principle of ancient conqueror Caesar "divide and snatch", threatening the waiter with your blaster
       эффект: P2(Prince) -1
       эффект: P12(Dialogue) = {2}
  -> Path75 => Loc27  вер=1 проходов<=1 порядок=7
       текст: Backhand him right into the ear just for the kicks of it and hint that his face could suffer a lot of damage from Mr. Iron-tray here
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {3}
  -> Path76 => Loc27  вер=1 проходов<=1 порядок=9
       текст: Prostrate on the floor, lick his feet, and beg him to let you "take a ride on this modern technology wonder"
       эффект: P2(Prince) -2
       эффект: P12(Dialogue) = {4}
  -> Path77 => Loc27  вер=1 проходов<=1 порядок=4
       текст: Show him your blood-shot eyes, start producing foam from your mouth, in short put some psychological pressure on the guy
       эффект: P2(Prince) +2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {5}

### Loc27 [обычная] визитов<=3
    выбор описания: {[p12]}
    Loc27-1: Without taking his time to think, the cook agreed and took the money. /  / - Huckster, - the disgusted voice of the Maloq Prince and commander-in-chief (or vice…
    Loc27-2: The scared cook-boy gladly gave you the cart, glancing suspiciously on the blaster barrel. /  / - You sorry extorter! - the disgusted voice of the Maloq Prince …
    Loc27-3: Rubbing his aching jaw, the cook submitted his cart to you and reached out for the security button.  /  / - Ha, - the approving voice of the Maloq Prince and co…
    Loc27-4: Apparently the sight seemed funny to the kitchen-boy and he gave you the cart laughing. /  / - How can anyone be so pathetic, ranger, - the disgusted voice of t…
    Loc27-5: The psychic attack made the necessary effect, and cook gave you the cart, deciding not to mess with a madman.  /  / - Ha, - the approving voice of the Maloq Pri…
  -> Path79 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Serve the drinks and food on the table
  -> Path118 => Loc45  вер=1 проходов<=1 порядок=5
       текст: Listen to what the cook has to offer
  -> Path145 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Jab the cook on the jaw, so that he learns to take care of himself, and not wait for the others to help him
       ответ: As it turned out some of the cooks out there would make excellent sprinters - you'd hardly entered the hall with the drinks, and this little worm was already fi…
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) -1

### Loc29 [обычная] визитов<=5
    Loc29-1: The Maloqs met the brought alcohol with much enthusiasm. Appropriate drinks were brought for government members and higher officials of planet <ToPlanet> too, a…
  -> Path80 => Loc30  вер=1 проходов<=1 порядок=7
       текст: To the beautiful Maloq women present - to the flowers and sunshine in the lives of real men - I mean - Maloqs
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {1}
  -> Path81 => Loc30  вер=1 проходов<=1 порядок=4
       текст: To the most courageous, the most hair, and the most powerful  - to all the Maloq ladies gathered here!
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {2}
  -> Path82 => Loc30  вер=1 проходов<=1
       текст: To just get drunk and then even the Maloq women would look like beautiful furies, I mean houris
       эффект: P2(Prince) -2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {3}
  -> Path83 => Loc30  вер=1 проходов<=1 порядок=5
       текст: To those who brings us ammo and our kids, those who heat our beds and prepare our breakfasts, those who jab their enemies and husbands on their jaws, I raise th…
       эффект: P2(Prince) +2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {2}
  -> Path84 => Loc30  вер=1 проходов<=1 порядок=8
       текст: Like sunrays they shine through laser-burnt armour - Their tanks run the enemy down in the gutter - So passionate tender, machineguns they tremble - They'll fin…
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {4}

### Loc30 [обычная] визитов<=4
    выбор описания: {[p12]}
    Loc30-1: The toast was only appreciated by the beautiful women present, or, to be more exact, only by the Prince's wife who had a soft spot for foreign-planet exotics an…
    Loc30-2: His highness truly appreciated your toast for its truthfulness and irony. As it turned out the Maloqs even had a sense of humour, if only a bit... different. In…
    Loc30-3: Had it not been for the stopping gesture of the Maloq Prince, you would have suffered major injuries and gravely consequences. Just like the males of any other …
    Loc30-4: Oh the great power of poetry! As it turned each and everyone present managed to find something they longed to hear in these lines. The grim vets heard about the…
  -> Path87 => Loc32  вер=1 проходов<=1 порядок=4
       текст: Pretend that you stumbled and drop the glass so that it breaks
       эффект: P2(Prince) -1
       эффект: P12(Dialogue) = {1}
  -> Path88 => Loc32  вер=1 проходов<=1 порядок=5
       текст: Carefully pour the contents of the goblet into the nearby flowerpot and on the carpet, explaining that this is a tradition
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +2
       эффект: P12(Dialogue) = {3}
  -> Path89 => Loc32  вер=1 проходов<=1 порядок=7
       текст: Refuse the drink, explaining that your religious beliefs prohibit you from drinking acids in public
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {2}
  -> Path90 => Loc32  вер=1 проходов<=1
       текст: Kill your glass in one swing, providing your heirs with a considerable insurance policy
       эффект: P2(Prince) +2
       эффект: P11(Самочувствие) = {[p11]-[20..30]}
       эффект: P12(Dialogue) = {4}

### Loc32 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc32-1: The glass fell on the floor, but did not break, although all of its contents spilled out. Strangely enough the carpet did not start to dissolve.  /  / - You are…
    Loc32-2: His highness looked very disappointed, but his wife - on the contrary - seemed very interested hearing about this unusual religion. In order to talk yourself ou…
    Loc32-3: Such a way of handling the precious liquid, especially an alcoholic one, offended the Maloq Prince, and he chuckled in disapproval. Hanna Ka'Boom on the contrar…
    Loc32-4: Mentally you said farewell to all your friends, and promised all your enemies to come back in shape of a ethereal spirit and wretch their existence, after which…
  -> Path91 => Loc41  вер=1 проходов<=1 порядок=5
       текст: Continue
       эффект: P1(Relation) = {3}
       эффект: P12(Dialogue) = {0}

### Loc33 [обычная] визитов<=1
    Loc33-1: So, all the gifts have been given now, and all the plates have been finished... It's quiet in the fridge - because there's no one to make noise in the morgue? I…
  -> Path92 => Loc34  вер=1 проходов<=1 порядок=7
       текст: Oh! She is like a morning flower washed with dew and shining in the rays of the dawn!
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +2
       эффект: P12(Dialogue) = {1}
  -> Path93 => Loc34  вер=1 проходов<=1
       текст: Well, to be completely frank with you, I'd easily go on a recon mission with her. And I'd follow her to the attack too, right behind her back, this would be the…
       эффект: P2(Prince) +1
       эффект: P12(Dialogue) = {2}
  -> Path94 => Loc34  вер=1 проходов<=1 порядок=4
       текст: Had I been a Maloq, I'd definitely hit on her and challenge you in a Duel of Honour, or where it is that you fight for you females.
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P12(Dialogue) = {3}
  -> Path95 => Loc35  вер=1 проходов<=1 порядок=9
       текст: Listen, instead of talking about females, I suggest that you come over to the planet of <ToPlanet> - let's go fishing, break a couple of necks in the local bars…
       условия: P2(Prince) 1..15 ∈[14, 15]
  -> Path96 => Loc34  вер=1 проходов<=1 порядок=6
       текст: A strong woman is the dream of any Maloq or general. But this dress fits her like a woman's saddle would fit a gobzaurus. Full armour would look heaps better
       эффект: P2(Prince) +2
       эффект: P3(Prince Tardym's wife) -1
       эффект: P12(Dialogue) = {4}
  -> Path97 => Loc36  вер=1 порядок=9
       текст: Listen, instead of talking about females, I suggest that you come over to the planet of <ToPlanet> - let's go fishing, break a couple of necks in the local bars…
       условия: P2(Prince) 1..15 ∉[14, 15]

### Loc34 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc34-1: The Maloq Prince scratched his neck in bemusement, trying to understand the meaning of what he just heard, but soon gave it up - poetic similes were completely …
    Loc34-2: - Exactly! That's what I am always saying, ranger, - the Maloq smacked you on the shoulder, driving the metal legs of your chair into the marble floor. - Me and…
    Loc34-3: - I'd be happy to tear your throat out, ranger, - the Maloq said joyfully, - normally we do not fight for females in Duels of Honours, but in regular fights I b…
    Loc34-4: - I always said the same to her, but do you really think it is possible to convince a woman with fists like these? - the Prince agreed with you. / You sized up …
  -> Path98 => Loc37  вер=1 проходов<=1 порядок=5
       текст: Continue

### Loc35 [УСПЕХ] визитов<=1
    Loc35-1: - That's right, I say there is nothing better than cracking a couple of stubborn foreheads. By the way what is the meaning of "goofy itching"? /  / Of course, h…

### Loc36 [ПРОВАЛ]
    Loc36-1: - Why the hell would I do that? Besides I didn't like you anyway, you've been hanging about here for the entire evening, ogled at my wife and tried to show off …

### Loc37 [обычная] визитов<=1
    Loc37-1: Having satisfied his curiosity, the Prince rejoined the diplomatic conversation that was happening at the table.   /  / After listening to it for a while, you s…
  -> Path99 => Loc38  вер=1 порядок=5
       текст: Stick the fork into the Prince's side and invite him to the planet of <FromPlanet> with a friendly visit
       условия: P2(Prince) 1..15 ∉[15]
       эффект: P12(Dialogue) = {1}
  -> Path100 => Loc39  вер=1 проходов<=1 порядок=5
       текст: Stick the fork into the Prince's side and invite him to the planet of <FromPlanet> with a friendly visit
       условия: P2(Prince) 1..15 ∈[15]
       эффект: P12(Dialogue) = {1}
  -> Path101 => Loc40  вер=1 проходов<=1 порядок=5
       текст: Go out and take a walk in the garden around the Government Palace

### Loc38 [ПРОВАЛ]
    Loc38-1: In one swift motion Tardym twisted your arm and grope your neck. Somebody cried out "Assassination attempt!", and soon the cry was supported by a dozen more voi…

### Loc39 [УСПЕХ] визитов<=1
    Loc39-1: In one swift motion Tardym twisted your arm and grope your neck. Somebody cried out "Assassination attempt!", and soon the cry was supported by a dozen more voi…

### Loc40 [обычная] визитов<=1
    Loc40-1: You carefully slipped from behind the table and went out to take a walk in the park. The fresh fragrance of flowers in the air besotted just like Maloq wine, an…
  -> Path114 => Loc43  вер=1000 порядок=5
       текст: I am sorry, Prince-general, but I have a very interesting proposal for you...
       условия: логика {[p2]<14 and [p3]<12}
  -> Path115 => Loc44  вер=1 проходов<=1 порядок=5
       текст: I am sorry, Prince-general, but I have a very interesting proposal for you...
       условия: логика {[p2]>=13 or [p3]>=12}
       эффект: P12(Dialogue) = {([p2]>12)*1+([p3]>12)*2}
  -> Path140 => Loc52  вер=50 порядок=5
       текст: I am sorry, Prince-general, but I have a very interesting proposal for you...
       условия: логика {[p2]<4 or [p3]<=3}

### Loc41 [обычная] визитов<=10
    выбор описания: {[p12]+1}
    Loc41-1: But as it turned out this was not the end of surprises. The Prince delivered another pair of pompous toasts and satisfied, refrained from further participation …
    Loc41-2: - Why would I need this "Jumper"? - Tardym looked surprised. - It's not my size, and besides, I prefer to use jet-boosts in battle - they are much more reliable…
    Loc41-3: - Cracks! My favourite, - the Prince exclaimed joyfully, - where did you get these yum-yum? /  / He opened the box right there and then, tossed a handful of she…
    Loc41-4: - A weapon like this would not suit a true warrior. Why would I need a sharp eye and a steady hand, if with this gun even a blind epileptic would be a able to k…
    Loc41-5: - Why would I need this "Jumper"? - she looked surprised, - It's not even my size, besides I prefer ordnance over hand-to-hand combat. This think is for the kid…
    Loc41-6: - They are marvellous! - the Princes was completely charmed, - I shall wear them on my neck or stick them in my ears like human females do. /  / - And then some…
    Loc41-7: - This one is just the right thing for my dear wife, - Tardym smiled, - I wouldn't have found anything better for her myself. /  / But Princess Hanna did not se…
    Loc41-8: - Wow! - one of the two brothers exclaimed, but the same instance his face once again became impenetrable, just like the face of any decent Maloq warrior. /  / …
    Loc41-9: - So what do we do with those? - the brothers looked in bewilderment. /  / - Yes, this seems like a wrong gift for these warriors, - the father agreed, but Prin…
    Loc41-10: - A good sword or a destruction emitter would have suited them better, without them ultra-modern technicalities, - the cut-throats' father sounded irritated. / …
  -> Path103 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the strange backpack to Prince Tardym
       условия: P1(Relation) ∈[3]; логика {[p6] mod 10=1}
       эффект: P2(Prince) -1
       эффект: P6(Presents (rfl/shll/bpck)) -1
       эффект: P12(Dialogue) = {1}
  -> Path104 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the super-rifle to Prince Tardym
       условия: P1(Relation) ∈[3]; логика {([p6] div 100)=1}
       эффект: P2(Prince) -1
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-100}
       эффект: P12(Dialogue) = {3}
  -> Path105 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the beautiful shells to Prince Tardym
       условия: P1(Relation) ∈[3]; логика {([p6] div 10) mod 10=1}
       эффект: P2(Prince) +1
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-10}
       эффект: P12(Dialogue) = {2}
  -> Path106 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the beautiful shells to Princess Hanna
       условия: P1(Relation) ∈[2]; логика {([p6] div 10) mod 10=1}
       эффект: P3(Prince Tardym's wife) +2
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-10}
       эффект: P12(Dialogue) = {5}
  -> Path107 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the super-rifle to Princess Hanna
       условия: P1(Relation) ∈[2]; логика {([p6] div 100)=1}
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) -1
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-100}
       эффект: P12(Dialogue) = {6}
  -> Path108 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the strange backpack to Princess Hanna
       условия: P1(Relation) ∈[2]; логика {[p6] mod 10=1}
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) -1
       эффект: P6(Presents (rfl/shll/bpck)) -1
       эффект: P12(Dialogue) = {4}
  -> Path109 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the super-rifle to the Prince's sons
       условия: P1(Relation) ∈[1]; логика {([p6] div 100)=1}
       эффект: P2(Prince) -2
       эффект: P3(Prince Tardym's wife) +1
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-100}
       эффект: P12(Dialogue) = {9}
  -> Path110 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the beautiful shells to the Prince's sons
       условия: P1(Relation) ∈[1]; логика {([p6] div 10) mod 10=1}
       эффект: P2(Prince) -1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P6(Presents (rfl/shll/bpck)) = {[p6]-10}
       эффект: P12(Dialogue) = {8}
  -> Path111 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Give the strange backpack to the Prince's sons
       условия: P1(Relation) ∈[1]; логика {[p6] mod 10=1}
       эффект: P2(Prince) +1
       эффект: P3(Prince Tardym's wife) +1
       эффект: P6(Presents (rfl/shll/bpck)) -1
       эффект: P12(Dialogue) = {7}
  -> Path113 => Loc33  вер=1 проходов<=1 порядок=5
       текст: Continue
       условия: P1(Relation) ∈[0]

### Loc42 [пустая]
    эффект: P1(Relation) -1
  -> Path102 => Loc41  вер=1 порядок=5

### Loc43 [ПРОВАЛ]
    Loc43-1: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions, but the Prince s…

### Loc44 [УСПЕХ] визитов<=1
    выбор описания: {[p12]}
    Loc44-1: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions, and the Prince s…
    Loc44-2: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions, but the Prince d…

### Loc45 [обычная] визитов<=1
    Loc45-1: - The point is that this whole banquet is organised in accordance with the Maloq traditions, but what they do not have is the main Maloq dish, or rather - drink…
  -> Path119 => Loc29  вер=1 проходов<=1 порядок=5
       текст: Nah! For all I know you could be a Dominator spy who wants to use me to poison the Prince?
       скрыт: P13,P14,P15,P16,P17
  -> Path120 => Loc48  вер=1 проходов<=1 порядок=5
       текст: Alright, give me the recipe and the ingredients. Let's make some tequila-boom for this Ka'Boom!
       эффект: P12(Dialogue) = {[1..4]}

### Loc46 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc46-1: - Right, Taiga, tell me about my past. But most of all tell me about my glorious future... /  / The Peleng snatched the money from you and rolled his eyes obvio…
    Loc46-2: - Say, Taiga, how do I destroy the Dominators? / The Peleng snatched the money from you: /  / - Piece of cake. All you need is a faster engine, more powerful gu…
    Loc46-3: - Say, Taiga, how do I destroy the Dominators? / The Peleng snatched the money from you: /  / - Right. The robots report each to their own superbrain. By destro…
    Loc46-4: - Say, Taiga, how do Maloqs normally greet each other? /  / The Peleng snatched the money from you: /  / - When greeting each other Maloqs demonstrate mutual re…
    Loc46-5: - Say, Taiga, how do Maloqs normally greet each other? /  / The Peleng snatched the money from you: /  / - The Maloqs have a tradition of a force-greeting, whic…
    Loc46-6: - Say, Taiga, when I will be able to buy me a good hull? /  / The Peleng snatched the money from you: /  / - You should watch the corsair named Santa Clause. If…
    Loc46-7: - Say, Taiga, when will the next Space Rangers be released? /  / The Peleng snatched the money from you and rolled his eyes as if going into a trance:  / - I se…
  -> Path15 => Loc5  вер=1 проходов<=1 порядок=2
       текст: Run to the palace entrance to meet the Prince

### Loc47 [обычная] визитов<=1
    Loc47-1: - Two hundred... - the Peleng responded and winked at you trickily. / - Nice to meet you, Two Hundred, and I am <Ranger>. So I just wanted to ask... / - Two hun…
  -> Path117 => Loc5  вер=1 проходов<=1
       текст: Stick your greediness where the sun never shines!
  -> Path133 => Loc46  вер=1 [всегда видна] порядок=6
       текст: Tell me, gipsy, what I've seen and will yet see in my life... (100 creds)
       условия: логика {[p7]>=100}
       эффект: P7(money) = {[p7]-100}
       эффект: P12(Dialogue) = {1}
  -> Path134 => Loc46  вер=1 [всегда видна] порядок=9
       текст: Tell me how do I win over the Dominators (200 creds)
       условия: логика {[p7]>=200}
       эффект: P7(money) = {[p7]-200}
       эффект: P12(Dialogue) = {3}
  -> Path135 => Loc46  вер=1 [всегда видна] порядок=8
       текст: Tell me how do I win over the Dominators (100 creds)
       условия: логика {[p7]>=100}
       эффект: P7(money) = {[p7]-100}
       эффект: P12(Dialogue) = {2}
  -> Path136 => Loc46  вер=1 [всегда видна] порядок=2
       текст: What's the best way to greet the Maloq embassy? (200 creds)
       условия: логика {[p7]>=200}
       эффект: P7(money) = {[p7]-200}
       эффект: P12(Dialogue) = {4}
  -> Path137 => Loc46  вер=1 [всегда видна] порядок=1
       текст: What's the best way to greet the Maloq embassy? (100 creds)
       условия: логика {[p7]>=100}
       эффект: P7(money) = {[p7]-100}
       эффект: P12(Dialogue) = {5}
  -> Path138 => Loc46  вер=1 [всегда видна] порядок=5
       текст: When will I be able to buy me a real good hull? (100 creds)
       условия: логика {[p7]>=100}
       эффект: P7(money) = {[p7]-100}
       эффект: P12(Dialogue) = {6}
  -> Path139 => Loc46  вер=1 [всегда видна] порядок=5
       текст: When is the release date of the next "Space Rangers"? (100 creds)
       условия: логика {[p7]>=100}
       эффект: P7(money) = {[p7]-100}
       эффект: P12(Dialogue) = {7}

### Loc48 [обычная] визитов<=1
    выбор описания: {[p12]}
    Loc48-1: - Excellent! Here you go. The recipe couldn't be simpler - take some <clr>white shabby-lee whine<clrEnd> and add the same amount of other components so that the…
    Loc48-2: - Excellent! Here you go. The recipe could not be simpler take barmy <clr>faryuk juice<clrEnd> and add the same amount of other components so that the relative …
    Loc48-3: - Excellent! Here you go. The recipe could not be simpler take some <clr>moonshine<clrEnd> and add the same amount of other components so that the relative comp…
    Loc48-4: - Excellent! Here you go. The recipe could not be simpler take some <clr>plain water<clrEnd> and add the same amount of other components so that the relative co…
  -> Path121 => Loc49  вер=1 проходов<=1 порядок=5
       текст: Start
       условия: P12(Dialogue) ∈[1]
       эффект: P14(Alcohol:) = {15}
       эффект: P15(Transparency) = {70}
       эффект: P16(Carbonation) = {25}
       эффект: P17(Attempts) = {10}
  -> Path122 => Loc49  вер=1 проходов<=1 порядок=5
       текст: Start
       условия: P12(Dialogue) ∈[3]
       эффект: P14(Alcohol:) = {70}
       эффект: P15(Transparency) = {35}
       эффект: P16(Carbonation) = {25}
       эффект: P17(Attempts) = {10}
  -> Path123 => Loc49  вер=1 проходов<=1 порядок=5
       текст: Start
       условия: P12(Dialogue) ∈[2]
       эффект: P14(Alcohol:) = {10}
       эффект: P15(Transparency) = {60}
       эффект: P16(Carbonation) = {10}
       эффект: P17(Attempts) = {10}
  -> Path124 => Loc49  вер=1 проходов<=1 порядок=5
       текст: Start
       условия: P12(Dialogue) ∈[4]
       эффект: P14(Alcohol:) = {0}
       эффект: P15(Transparency) = {90}
       эффект: P16(Carbonation) = {10}
       эффект: P17(Attempts) = {10}

### Loc49 [обычная]
    выбор описания: {[p12]}
    Loc49-1: So you have:  / - absorblob: [p20] ccm;  / - hiphops: [p21] ccm;  / - repusator: [p22] ccm;  / - water: [p23] ccm. /  / They work as follows: / A.  Strength: <c…
    Loc49-2: So you have:  / - absorblob: [p20] ccm;  / - hiphops: [p21] ccm;  / - repusator: [p22] ccm;  / - water: [p23] ccm.  /  / They work as follows: / A.  Strength: <…
    Loc49-3: So you have:  / - absorblob: [p20] ccm;  / - hiphops: [p21] ccm;  / - repusator: [p22] ccm;  / - water: [p23] ccm. /  / They work as follows: / A.  Strength: <c…
    Loc49-4: So you have:  / - absorblob: [p20] ccm;  / - hiphops: [p21] ccm;  / - repusator: [p22] ccm;  / - water: [p23] ccm. /  / They work as follows: / A.  Strength: <c…
    эффект: P13(KINZA) = {} [показ]
    показ: P14,P15,P16,P17
  -> Path126 => Loc50  вер=1 порядок=5
       текст: Add 1 ccm of repusator
       условия: P17(Attempts) ∉[0]; P22(repusator) ∉[0]
       эффект: P17(Attempts) -1
       эффект: P22(repusator) -1
       эффект: P14(Alcohol:) +3
       эффект: P15(Transparency) -2
       эффект: P16(Carbonation) -8
  -> Path128 => Loc51  вер=1 порядок=5
       текст: Looks like you are getting there
       условия: P17(Attempts) ∈[0]
  -> Path129 => Loc50  вер=1 порядок=1
       текст: Add 1 ccm of absorblob
       условия: P17(Attempts) ∉[0]; P20(Discil) ∉[0]
       эффект: P17(Attempts) -1
       эффект: P20(Discil) -1
       эффект: P14(Alcohol:) -5
       эффект: P15(Transparency) +12
       эффект: P16(Carbonation) -5
  -> Path130 => Loc50  вер=1 порядок=2
       текст: Add 1 ccm of hiphops
       условия: P17(Attempts) ∉[0]; P21(hukhmel) ∉[0]
       эффект: P17(Attempts) -1
       эффект: P21(hukhmel) -1
       эффект: P14(Alcohol:) +15
       эффект: P15(Transparency) -7
       эффект: P16(Carbonation) +3
  -> Path131 => Loc50  вер=1 порядок=7
       текст: Add 1 ccm of water
       условия: P17(Attempts) ∉[0]; P23(water) ∉[0]
       эффект: P17(Attempts) -1
       эффект: P23(water) -1
       эффект: P14(Alcohol:) -10
       эффект: P15(Transparency) +10
       эффект: P16(Carbonation) +1

### Loc50 [пустая]
  -> Path127 => Loc49  вер=1 порядок=5

### Loc51 [обычная]
    выбор описания: {([p14]>=55 and [p15]>=80 and [p16]<=10)+1}
    Loc51-1: The cook took the "cocktail" you just made and let several droplets of it drip into the analyser. Judging by the numbers that appeared on the display your Chins…
    Loc51-2: The cook took the "cocktail" you just made and let several droplets of it drip into the analyser. Judging by the numbers that appeared on the display your impro…
    эффект: P7(money) = {[p7]+([p14]>=55 and [p15]>=80 and [p16]<=10)*500}
  -> Path132 => Loc29  вер=1 порядок=5
       текст: Serve the drinks and food on the table
       эффект: P2(Prince) +2
       скрыт: P13,P14,P15,P16,P17

### Loc52 [ПРОВАЛ]
    выбор описания: {([p2]<4)*1+([p3]<3)*2+([p3]<3 and [p2]<4)*3}
    Loc52-1: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions. The Prince pause…
    Loc52-2: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions. The Prince pause…
    Loc52-3: You used all of your rhetoric skills to invite the Prince to the planet of <FromPlanet>, where he would get the warmest of possible receptions.  /  / - No, - th…

### Loc53 [обычная] визитов<=1
    Loc53-1: Not wanting to test your luck any further you decided to make a funk-hole in pile of rags behind the nearest door. However in the very last moment the pile of r…
    эффект: P2(Prince) -1
  -> Path144 => Loc11  вер=1 проходов<=1 порядок=5
       текст: Meat the Maloq embassy...
       эффект: P2(Prince) = {[p2]-([p5]=5)*2-[1..2]*([p5]=4)-([p5]=3)+([p5]=2)*[0..1]+([p5]=0)*2+([p5]=1)*[1..2]}
       эффект: P3(Prince Tardym's wife) = {[p2]+([p5]=5)*2+[1..2]*([p5]=4)-([p5]=0)*2-[1..2]*([p5]=1)-[0..1]*([p5]=2)}

### Loc54 [СМЕРТЬ] визитов<=1
    Loc54-1: Pulling out your blasters you leaped from around the corner and shouted "Boom!!!", trying to surprise the embassy. / "Bang-Bang-Bang" - the Prince's guards unle…

## Анализ
- стартовых: [1]
- концовки: {19: 'ПРОВАЛ', 20: 'СМЕРТЬ', 35: 'УСПЕХ', 36: 'ПРОВАЛ', 38: 'ПРОВАЛ', 39: 'УСПЕХ', 43: 'ПРОВАЛ', 44: 'УСПЕХ', 52: 'ПРОВАЛ', 54: 'СМЕРТЬ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
