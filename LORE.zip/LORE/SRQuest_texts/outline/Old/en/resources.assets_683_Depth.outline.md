# Квест (формат 1111111126)
Сложность 90; стартовая локация: [37]; путей по умолчанию: 1

## Параметры
- P1 'southern grade' [1..20] тип=обычный
    старт: [1..20]
    [1..20] southern grade: <>m each 10m
    критическое: Сообщение достижения критического значения параметром 7
- P2 'western grade' [1..20] тип=обычный
    старт: [1..20]
    [1..20] western grade: <> m each 10m
    критическое: Сообщение достижения критического значения параметром 8
- P3 'current direction' [1..3] тип=обычный
    старт: [1..3]
    [1..1] current: north to south
    [2..2] current: west to east
    [3..3] current: south to north
    критическое: Сообщение достижения критического значения параметром 11
- P4 'current speed' [1..30] тип=обычный
    старт: [1..3]
    [1..30] current speed: <> m/min
    критическое: Сообщение достижения критического значения параметром 12
- P5 'thrust' [-100..100] тип=обычный
    старт: [0]
    [-100..100] thrust: <> m/min
    критическое: Сообщение достижения критического значения параметром 24
- P6 'Plateau' [1..100] тип=обычный
    старт: [6..10]
    [1..100] Bathyscaph turn:
    критическое: Сообщение достижения критического значения параметром 9
- P7 'Turn angle' [-180..180] тип=обычный
    старт: [0]
    [-180..-141] westwards
    [-140..-101] south-westwards
    [-100..-61] southwards
    [-60..-21] south-eastwards
    [-20..19] eastwards
    [20..59] north-eastwards
    [60..99] northwards
    [100..139] north-westwards
    [140..180] westwards
    критическое: Сообщение достижения критического значения параметром 19
- P8 'X Co-ordinates' [-1000000000..1000000000] тип=обычный
    старт: [-100..100]
    [-1000000000..1000000000] target co-ordinates:<br>X: <>
    критическое: Сообщение достижения критического значения параметром 5
- P9 'Y co-ordinates' [-1000000000..1000000000] тип=обычный
    старт: [-100..100]
    [-1000000000..1000000000] Y: <>
    критическое: Сообщение достижения критического значения параметром 6
- P10 'Vertical speed' [-1000..1000] тип=обычный
    старт: [0]
    [-1000..1000] Diving speed: <> m/min
    критическое: Сообщение достижения критического значения параметром 17
- P11 'Target depth' [0..10000] тип=обычный
    старт: [4000..8000]
    [0..10000] Depth of target occurrence: <> m
    критическое: Сообщение достижения критического значения параметром 1
- P12 'Diving depth' [0..10000] тип=обычный
    старт: [0]
    [0..10000] Diving depth: <> m
- P13 'Max depth' [0..10000] тип=обычный
    старт: [10000]
    [0..10000] Max diving depth: <> m
    критическое: Сообщение достижения критического значения параметром 2
- P14 'Sea depth' [0..10000] тип=обычный
    старт: [0]
    [0..10000] Sea depth: <> m
    критическое: Сообщение достижения критического значения параметром 4
- P15 'air reserve' [0..90] тип=смерть
    старт: [90]
    [0..90] air reserve: <> min.
    критическое: You felt that you were losing consciousness. I was becoming impossible to resist the suffocation...
- P16 'Rescue time' [0..90] тип=обычный
    старт: [60..70]
    [0..90] Time remaining: <> min
    критическое: Сообщение достижения критического значения параметром 14
- P17 'Monster' [-180..300] тип=обычный
    старт: [200]
    [-180..300] Parameter no. 15: <>
    критическое: Сообщение достижения критического значения параметром 15
- P18 'Bottom' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Searchlight' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter no. 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P20 'Hull' [0..100] тип=смерть
    старт: [100]
    [0..100] Hull: <> %
    критическое: Just before the water started streaming into the hold, you glanced at the hull strength indicator. I…
- P21 'Accomplishment' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter no. 21: <>
- P22 'Ballast' [0..1300] тип=обычный
    старт: [1300]
    [0..1300] 
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Cargo' [0..1000] тип=обычный
    старт: [0]
    [0..0] Ballast: {[p22]} kg
    [1..1000] Ballast: {[p22]} kg, cargo: <> kg
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Money' [0..100000000] тип=обычный деньги
    старт: [0]
    [0..100000000] Parameter no. 10: <>
    критическое: Сообщение достижения критического значения параметром 10

## Локации и переходы

### Loc2 [пустая] визитов<=1
    эффект: P12(Diving depth) = {1}
  -> Path135 => Loc37  вер=1 проходов<=1 порядок=1

### Loc3 [ПРОВАЛ]
    Loc3-1: - Well, up to you, might as well do without you...  /  / You returned back to the spaceport. Mission failed.

### Loc4 [пустая] визитов<=1
    эффект: P12(Diving depth) = {2}
  -> Path159 => Loc37  вер=1 проходов<=1 порядок=1

### Loc8 [обычная]
    выбор описания: {[p12]}
    Loc8-1: - Excellent. You can head for the "Mermaid" naval base straight away. You will dive from there. Our people will escort you. /  / Half an hour later you were alr…
    Loc8-2: The display of your onboard hydro-locator will be showing the distance to target in two co-ordinates <clr>by X and Y axis<clrEnd>. At that <clr>you bathyscaph s…
    Loc8-3: The display of your onboard hydro-locator will be showing the distance to target in two co-ordinates <clr>by X and Y axis<clrEnd>. At that <clr>you bathyscaph s…
    Loc8-4: The display of your onboard hydro-locator will be showing the distance to target in two co-ordinates <clr>by X and Y axis<clrEnd>. At that <clr>you bathyscaph s…
    Loc8-5: The display of your onboard hydro-locator will be showing the distance to target in two co-ordinates <clr>by X and Y axis<clrEnd>. At that <clr>you bathyscaph s…
    Loc8-6: The object lies at the depth of [p11] meters from the waterline. I must say we are lucky. The space alien stopped on a small horizontal plateau, located on a ve…
    Loc8-7: - Simply <clr>turn on the searchlights<clrEnd>. The object is quite large so you must spot it at once.
    Loc8-8: Judging by the look that the captain gave you, his opinion of you had just started dropping. Nonetheless he answered: /  / - First of all you must <clr>land on …
    показ: P8,P9
  -> Path15 => Loc15  вер=1 проходов<=1
       текст: No more questions, sir. I am ready to dive
  -> Path160 => Loc40  вер=1 порядок=6
       текст: Tell me more about the co-ordinate system
  -> Path162 => Loc41  вер=1 порядок=4
       текст: Tell me about the bottom relief
  -> Path164 => Loc42  вер=1 порядок=5
       текст: How do I find the object once I'm on the plateau?
  -> Path166 => Loc43  вер=1 порядок=7
       текст: I seem to be a bit on the slow side today... Can you explain to me what is it exactly that you want me to do?!

### Loc12 [обычная]
    выбор описания: {[p12]>300}
    Loc12-1: In front of you, you saw the bathyscaph control knobs and the instrumentation display. What are you going to do next?
    эффект: P10(Vertical speed) = {([p22]+[p23]-1000)*(([p22]+[p23]<1000) or ([p12]<[p14]))}
  -> Path20 => Loc20  вер=1 [всегда видна] порядок=1
       текст: Increase thrust by 10 m/min
       ответ: The engine was located right under you. You felt its even buzz increase.
       условия: P5(thrust) 10..90
       эффект: P5(thrust) +10
  -> Path21 => Loc20  вер=1 [всегда видна] порядок=2
       текст: Decrease thrust by 10 m/min
       ответ: You pulled the control lever further back. The back thrust increased. Now you had adjust to underwater currents and go to your point of destination.
       условия: P5(thrust) -90..-10
       эффект: P5(thrust) -10
  -> Path25 => Loc13  вер=1 порядок=6
       текст: Transmit SOS signal!!!
       ответ: - May-Day, May-Day! - you screamed hysterically into the transmitter.  / - What happened? Over, - you heard the worried voice of the captain.
       условия: P12(Diving depth) 100..5000
  -> Path31 => Loc28  вер=1 порядок=5
       текст: Turn on the searchlights
       ответ: You turned on the searchlights, and a bright ray of light broke through the thick of the water. The light power was enough to see several meters ahead. You noti…
       условия: P12(Diving depth) 1000..10000; P19(Searchlight) ∈[0]
       эффект: P19(Searchlight) = 1
  -> Path44 => Loc20  вер=1 порядок=1
       текст: Increase thrust by 10 m/min
       ответ: You felt a buzz right under your seat. You imagined the fans of the back turbine increase their momentum. The bathyscaph shuddered. You estimated the co-ordinat…
       условия: P5(thrust) ∈[0]
       эффект: P5(thrust) +10
  -> Path45 => Loc20  вер=1 порядок=1
       текст: Increase thrust by 10 m/min
       ответ: You pushed the speed lever forward will full force. Judging by the buzz that came from beyond the fans now revolved slower.
       условия: P5(thrust) -100..-20
       эффект: P5(thrust) +10
  -> Path46 => Loc20  вер=1 порядок=1
       текст: Increase thrust by 10 m/min
       ответ: The engine noise went quieter and quieter until the fans of the back turbine finally stopped. Now your small ship was fully in the powers of underwater currents…
       условия: P5(thrust) ∈[-10]
       эффект: P5(thrust) +10
  -> Path47 => Loc20  вер=1 порядок=2
       текст: Decrease thrust by 10 m/min
       ответ: You decided to move back. The engine roared. Did they forget to get a silencer on this thing?
       условия: P5(thrust) ∈[0]
       эффект: P5(thrust) -10
  -> Path48 => Loc20  вер=1 порядок=2
       текст: Decrease thrust by 10 m/min
       ответ: Pulling the lever you heard the engine go silent. It became very quiet and the feeling of loneliness together with tons of water over your head overwhelmed you.…
       условия: P5(thrust) ∈[10]; P12(Diving depth) 1000..10000
       эффект: P5(thrust) -10
  -> Path49 => Loc20  вер=1 порядок=2
       текст: Decrease thrust by 10 m/min
       ответ: In order to stop the engine you had to slightly pull the main lever. The turbines stopped. The engine went silent. What next? Your "Kid" was now fully in the po…
       условия: P5(thrust) ∈[10]; P12(Diving depth) 0..1000
       эффект: P5(thrust) -10
  -> Path50 => Loc20  вер=1 порядок=2
       текст: Decrease thrust by 10 m/min
       ответ: You decided to reduce the main thrust. One move, and the engine buzz became quieter. The back fan flapping reduced.
       условия: P5(thrust) 20..100
       эффект: P5(thrust) -10
  -> Path55 => Loc34  вер=1 порядок=9
       текст: Do nothing
       ответ: Judging by your own calculations, you were moving in the right direction. Now you just had to wait for the "Kid" to arrive to the point of destination. You lean…
  -> Path73 => Loc13  вер=1 порядок=6
       текст: Transmit SOS signal!!!
       ответ: - Help-help! - you screamed into the microphone.  / But it was silent. "Strange, - you thought, - I guess I dived too deep! I am doomed to die here in this damn…
       условия: P12(Diving depth) 5000..10000
  -> Path80 => Loc28  вер=1 порядок=5
       текст: Turn off the searchlights
       ответ: Behind the illuminators it was pitch-dark. Gauge lights flickered softly in the deckhouse and the main engine buzzed quietly. You tried not to think of the icy …
       условия: P19(Searchlight) ∈[1]
       эффект: P19(Searchlight) = 0
  -> Path99 => Loc34  вер=1 порядок=9
       текст: Do nothing
       ответ: You decided to have some rest, leaned back in your seat and produced a hamburger - courtesy of a Gaalian girl off the "Mermaid" who gave it to you right before …
  -> Path100 => Loc34  вер=3 порядок=9
       текст: Do nothing
       ответ: You figured you could use a short rest - the bathyscaph was moving in the right direction.
       условия: P18(Bottom) ∈[0]
  -> Path109 => Loc34  вер=200 порядок=9
       текст: Do nothing
       условия: P18(Bottom) ∈[1]
  -> Path110 => Loc18  вер=1 [всегда видна]
       текст: Drop the ballast
       условия: P22(Ballast) 1..1300
  -> Path122 => Loc28  вер=1 порядок=5
       текст: Turn on the searchlights
       ответ: Green scales flashed in the front illuminator. A huge wriggling shadow of some depth dweller loomed over the bathyscaph. This creature was definitely not friend…
       условия: P17(Monster) ∈[1]; P19(Searchlight) ∈[0]
       эффект: P19(Searchlight) = 1
  -> Path141 => Loc21  вер=1 порядок=3
       текст: Turn the bathyscaph
  -> Path153 => Loc34  вер=300 порядок=9
       текст: Do nothing
       условия: P17(Monster) -180..180
  -> Path156 => Loc34  вер=3 порядок=9
       текст: Do nothing

### Loc13 [пустая]
  -> Path33 => Loc33  вер=1 порядок=5
       текст: I don't know what to do. This damn iron tin just wouldn't listen to me!
       ответ: - Did you read the documentation? Over, - the captain asked. / - I don't remember. Over. / - Are you a diver or what? Over, - you could hear a shade of doubt in…
       условия: P12(Diving depth) 0..5000
  -> Path72 => Loc33  вер=1 порядок=5
       текст: Get me out of here - quick!
       ответ: - What?! Are you nuts?! What about the alien? - the captain boomed in resentment. / - What bloody alien! I don't want to die in this abyss! Besides, I am no sub…
       условия: P12(Diving depth) 0..5000; P21(Accomplishment) ∈[0]
  -> Path74 => Loc33  вер=1 порядок=5
       условия: P12(Diving depth) 5000..10000
  -> Path75 => Loc33  вер=1 порядок=5
       текст: Get me out of here - quick!
       ответ: - Didn't you read the documentation? - the voice in the headphones asked. - drop off the ballast and you'll come up like a cork out of the bottle. Over.
       условия: P12(Diving depth) 0..5000; P21(Accomplishment) ∉[0]
  -> Path76 => Loc33  вер=1 порядок=5
       текст: I am running out of oxygen! I am suffocating!
       ответ: - Drop off the ballast and the sea will push you up to the surface. Over.
       условия: P12(Diving depth) 0..5000; P15(air reserve) 1..10
  -> Path91 => Loc33  вер=1 проходов<=1 порядок=5
       текст: I am attacked by a monster!
       ответ: - What? What does it look like? Over. / - It's a got a huge mouth, that is full of teeth, and it's definitely not going to make friends with me. Over. / - Ah...…
       условия: P12(Diving depth) 0..5000; P17(Monster) -180..180; P19(Searchlight) ∈[1]
  -> Path92 => Loc33  вер=200 порядок=5
       текст: I am attacked by a monster!
       ответ: The headphones responded to you with loud rattling. / - Damn! - you cursed loudly. Then you pronounced a long phrase that made a lot of sense and had a very dee…
       условия: P12(Diving depth) 5000..10000; P17(Monster) -180..180; P19(Searchlight) ∈[1]

### Loc15 [обычная] визитов<=1
    Loc15-1: The bathyscaph was located on the front deck and was ready for the dive. Inside it was very cozy. That is aside from the fact that you could only turn one foot …
    эффект: P12(Diving depth) = {0} [показ]
    эффект: P14(Sea depth) = {[p11]+(([p8]-[p6]/2)*[p2]/10)+(([p9]-[p6]/2)*[p1]/10)} [показ]
    показ: P3,P4,P5,P6,P7,P8,P9,P10,P11,P13,P15,P20,P23
    скрыт: P22
  -> Path18 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Thanks!!!

### Loc18 [обычная]
    Loc18-1: How much do you intend to drop?
  -> Path37 => Loc35  вер=1 [всегда видна]
       текст: 50 kg
       эффект: P22(Ballast) -50
  -> Path38 => Loc35  вер=1 [всегда видна] порядок=1
       текст: 20 kg
       эффект: P22(Ballast) -20
  -> Path39 => Loc35  вер=1 [всегда видна] порядок=2
       текст: 10 kg
       эффект: P22(Ballast) -10
  -> Path40 => Loc35  вер=1 [всегда видна] порядок=3
       текст: 5 kg
       эффект: P22(Ballast) -5
  -> Path41 => Loc35  вер=1 [всегда видна] порядок=4
       текст: 2 kg
       эффект: P22(Ballast) -2
  -> Path86 => Loc35  вер=1 [всегда видна] порядок=5
       текст: 1 kg
       эффект: P22(Ballast) -1
  -> Path169 => Loc12  вер=1 порядок=9
       текст: Change your mind

### Loc19 [пустая]
    эффект: P8(X Co-ordinates) = {[p8]+(-[p5]*([p7]=0)-[p5]*7*(([p7]=45) or ([p7]=(-45)))/10+[p5]*7*(([p7]=135) or ([p7]=(-135)))/10+[p5]*(([p7]=180) or ([p7]=(-180)))-[p4]*([p3]=2))*([p18]=0)}
    эффект: P9(Y co-ordinates) = {[p9]+(-[p5]*([p7]=90)-[p5]*7*(([p7]=45) or ([p7]=(135)))/10+[p5]*7*(([p7]=(-135)) or ([p7]=(-45)))/10+[p5]*([p7]=(-90))+[p4]*([p3]=1)-[p4]*([p3]=3))*([p18]=0)}
    эффект: P10(Vertical speed) = {([p22]+[p23]-1000)*(([p22]+[p23]<1000) or ([p12]<[p14]))}
    эффект: P15(air reserve) -1
    эффект: P16(Rescue time) -1
  -> Path57 => Loc23  вер=1 порядок=5
       эффект: P14(Sea depth) = {[p11]+(([p8]*[p8]>[p6]*[p6]/4)*([p8]-[p6]/2)*[p2]/10)+(([p9]-[p6]/2)*[p1]/10)*([p9]*[p9]>[p6]*[p6]/4)}

### Loc20 [пустая]
  -> Path43 => Loc19  вер=1 порядок=5

### Loc21 [обычная]
    Loc21-1: You looked down at the no-contact sensor panel with arrow buttons, pointing in all four directions. The buttons were lit from the back with neon lights. Make yo…
  -> Path23 => Loc39  вер=1 порядок=2
       текст: Westwards
       ответ: This wasn't too difficult. Somewhere on the right a turbine started buzzing. The bathyscaph turned slowly to the right direction.
       условия: P7(Turn angle) ∉[180, -180]
       эффект: P7(Turn angle) = 180
  -> Path52 => Loc39  вер=1 порядок=3
       текст: South-westwards
       ответ: The bathyscaph obediently turned in the required direction. You felt like a real submariner. Even the great Jab Hick Gusto from the planet of Gargyng could not …
       условия: P7(Turn angle) ∉[-135]
       эффект: P7(Turn angle) = -135
  -> Path53 => Loc39  вер=1
       текст: Northwards
       ответ: Pushing the up-arrow button you felt the turbine buzz somewhere on the left. The bathyscaph obediently turned in the required direction.
       условия: P7(Turn angle) ∉[90]
       эффект: P7(Turn angle) = 90
  -> Path54 => Loc39  вер=1 порядок=4
       текст: Southwards
       ответ: Rotating around the vertical axis, you thought of home. Somewhere far away now, emerald gardens bloomed and visitant birds made their nests. "Why am I rememberi…
       условия: P7(Turn angle) ∉[-90]
       эффект: P7(Turn angle) = -90
  -> Path142 => Loc39  вер=1 порядок=1
       текст: Northwestwards
       ответ: You hardly put your finger near the button, and the turn engines already started working. Excellent assembly quality - hopefully it stays that way!
       условия: P7(Turn angle) ∉[135]
       эффект: P7(Turn angle) = 135
  -> Path143 => Loc39  вер=1 порядок=5
       текст: South-eastwards
       ответ: You were so firm in your decision to go south-eastwards that you pushed the button down until it cracked. You got scared - you could break the sensitive Pantel …
       условия: P7(Turn angle) ∉[-45]
       эффект: P7(Turn angle) = -45
  -> Path144 => Loc39  вер=1 порядок=6
       текст: Eastwards
       ответ: This was your favorite direction. Back when you were a kid you enjoyed watching the rising star of your home planet.
       условия: P7(Turn angle) ∉[0]
       эффект: P7(Turn angle) = 0
  -> Path145 => Loc39  вер=1 порядок=7
       текст: North-eastwards
       ответ: You pressed the button and the bathyscaph obediently turned in the right direction. You enjoyed navigating this ship, despite the fact that it was much smaller …
       условия: P7(Turn angle) ∉[-45]
       эффект: P7(Turn angle) = 45
  -> Path168 => Loc12  вер=1 порядок=9
       текст: Change your mind

### Loc23 [пустая]
    эффект: P12(Diving depth) = {([p12]+[p10])*(([p12]+[p10])<[p14])+[p14]*(([p12]+[p10])>=[p14])}
  -> Path58 => Loc12  вер=20 порядок=5
  -> Path59 => Loc12  вер=20 проходов<=1 порядок=5
       ответ: You small ship was rushing down with enormous speed. You saw a blur of underwater creatures pass by. The diving speed was so high, you couldn't even make out wh…
       условия: P10(Vertical speed) 0..1000
  -> Path61 => Loc12  вер=200 проходов<=1 порядок=5
       ответ: You've noticed the first raise of light from above. You were gradually reaching the surface!
       условия: P10(Vertical speed) -1000..-1; P12(Diving depth) 0..500
  -> Path62 => Loc25  вер=500 проходов<=1 порядок=5
       ответ: Suddenly you felt a strong hit! The bathyscaph boomed and stood motionless. Looks like you hit the ocean bottom! The collision was so powerful you glanced caref…
       условия: P10(Vertical speed) 50..1000; P18(Bottom) ∈[0]; P21(Accomplishment) ∈[0]; логика {[p12]=[p14]}
       эффект: P18(Bottom) = 1
       эффект: P20(Hull) = {[p20]-[p10]/3}
  -> Path66 => Loc25  вер=100 порядок=5
       ответ: You continued sitting there at the bottom. Looks like the bathyscaph anchored to the ocean bottom with its own weight had no intention to move. Minutes flew by,…
       условия: P18(Bottom) ∈[1]; P21(Accomplishment) ∈[0]; логика {(([p22]+[p23])>=1005) and ([p12]=[p14])}
  -> Path68 => Loc26  вер=500000 проходов<=1 порядок=5
       ответ: Suddenly something flashed in the searchlights. You took a closer look and distinctly saw an egg-like silhouette just metres in front of you. "Here it is! I fou…
       условия: P19(Searchlight) ∈[1]; P21(Accomplishment) ∈[0]; логика {([p8]<[p6]/2) and ([p8]>(-[p6]/2)) and ([p9]<[p6]/2) and ([p9]>(-[p6]/2)) and ([p12]>=[p14]-10)}
  -> Path77 => Loc27  вер=100000 проходов<=1 порядок=5
       условия: P12(Diving depth) ∈[0]; P21(Accomplishment) ∈[1]
       эффект: P24(Money) = {[p24]+2000}
  -> Path78 => Loc27  вер=100000 проходов<=1 порядок=5
       условия: P12(Diving depth) ∈[0]; P21(Accomplishment) ∈[2]
  -> Path82 => Loc29  вер=100 проходов<=1 порядок=5
       ответ: Surrounded by the pitch darkness of ocean waters, you wanted to talk to someone. / - Captain. Over. / In response you heard some words, interrupted with loud no…
       условия: P12(Diving depth) 5000..10000
  -> Path84 => Loc29  вер=100 проходов<=1 порядок=5
       ответ: - <Ranger>, <Ranger>. Over, - suddenly you heard the captain's voice in the headphones. / - Yes. What is it? Over. / - Looks like we have a problem. The unident…
       условия: P12(Diving depth) 2000..10000
       эффект: P16(Rescue time) = {} [показ]
  -> Path85 => Loc29  вер=100 проходов<=1 порядок=5
       ответ: You looked at the clock and understood you were late. Even if there was a living creature there inside, it was surely dead by now. "Well, this way or that, but …
       условия: P16(Rescue time) ∈[0]
       эффект: P21(Accomplishment) = {([p21]=1)*2}
  -> Path98 => Loc31  вер=100000 порядок=5
       условия: P12(Diving depth) ∈[0]; P21(Accomplishment) ∈[0]
  -> Path101 => Loc32  вер=200 порядок=5
       условия: P17(Monster) -180..180; P18(Bottom) ∈[0]
  -> Path119 => Loc25  вер=500 проходов<=1 порядок=5
       ответ: The bathyscaph shook slightly and you understood that you hit the ocean bottom. "Right on!" It seemed to you that you saw the rates on the hull strength indicat…
       условия: P10(Vertical speed) -1000..50; P18(Bottom) ∈[0]; P21(Accomplishment) ∈[0]; логика {([p12]=[p14])}
       эффект: P18(Bottom) = 1
       эффект: P20(Hull) = {[p20]-[p10]/3}
  -> Path120 => Loc25  вер=50 порядок=5
       ответ: You bathyscaph stayed immobile. Together with the capsule in its gripper, it reminded more of a huge spider clenching its victim. Fish were swimming around you …
       условия: P18(Bottom) ∈[1]; P21(Accomplishment) ∉[0]; логика {(([p22]+[p23])>1000) and ([p12]=[p14])}
  -> Path121 => Loc32  вер=1 проходов<=1 порядок=5
       условия: P12(Diving depth) 1000..10000; P17(Monster) ∈[200]
       эффект: P17(Monster) = {[-180..180]}
  -> Path123 => Loc36  вер=100000 проходов<=1 порядок=5
       условия: логика {[p12]>[p13]}
  -> Path124 => Loc25  вер=200 проходов<=1 порядок=5
       ответ: A red number lit on the indicator: [p12]. A bit under it you saw another number: "<clr>Max depth:<clrEnd> [p13]". You went to a critical depth! Maybe it's time …
       условия: логика {([p12]+200)>=[p13]}
  -> Path125 => Loc25  вер=200 проходов<=1 порядок=5
       ответ: Suddenly you saw a light flashing under the air reserve controller. After glancing briefly at the indicator you felt creepy. You had only enough air for another…
       условия: P15(air reserve) 1..15
  -> Path126 => Loc25  вер=100 проходов<=1 порядок=5
       ответ: In the light of the searchlights you saw the bottom of the ocean! You met the sight with much enthusiasm despite the [p12] meters of water over your head. / The…
       условия: P18(Bottom) ∈[0]; P19(Searchlight) ∈[1]; логика {(([p12]+5)>=[p14]) and ([p12]<>[p14])}
  -> Path146 => Loc25  вер=500 проходов<=1 порядок=5
       ответ: Thanks to the dropped ballast the bathyscaph managed to rise from the bottom and start drifting. Now you moved constantly scrapping your "belly" against the rif…
       условия: P18(Bottom) ∈[1]; P21(Accomplishment) ∈[0]; логика {(([p22]+[p23])>=1000) and (([p22]+[p23])<1005)}
       эффект: P18(Bottom) = 0
       эффект: P20(Hull) = {[p20]-[p10]}
       эффект: P12(Diving depth) -1
  -> Path147 => Loc25  вер=50 проходов<=1 порядок=5
       условия: P18(Bottom) ∈[0]; логика {[p12]=[p14]}
       эффект: P20(Hull) = {[p20]-[p10]}
       эффект: P12(Diving depth) -1
  -> Path152 => Loc25  вер=1 проходов<=1 порядок=5
       условия: логика {(([p22]+[p23])>1000) and ([p12]=[p14])}
  -> Path157 => Loc25  вер=200 порядок=5
       условия: P18(Bottom) ∈[1]; P21(Accomplishment) ∈[0]; логика {(([p22]+[p23])>=1005) and ([p12]=[p14])}
  -> Path158 => Loc29  вер=100 проходов<=1 порядок=5
       ответ: You heard some squeaking on the right. The hull strength indicator was flashing red. It showed [p20]. Another second and you will be crashed with the thick of t…
       условия: P20(Hull) 1..10

### Loc25 [пустая]
  -> Path63 => Loc12  вер=1 порядок=5

### Loc26 [пустая] визитов<=1
  -> Path69 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Switch on the gripper
       ответ: You pushed the button activating the powerful oscular probes of the gripper. Their operation principle was based on the Kalterbruener pseudo-vacuum effect. Down…
       условия: P12(Diving depth) 0..5000
       эффект: P18(Bottom) = 1
       эффект: P21(Accomplishment) = 1
       эффект: P23(Cargo) = {[1..3]*100}
  -> Path71 => Loc12  вер=1 проходов<=1 порядок=5
       текст: Switch on the gripper
       ответ: You pushed the button activating the powerful oscular probes of the gripper. Their operation principle was based on the Kalterbruener pseudo-vacuum effect. Down…
       условия: P12(Diving depth) 5000..10000
       эффект: P18(Bottom) = 1
       эффект: P21(Accomplishment) = 1
       эффект: P23(Cargo) = {[1..3]*100}

### Loc27 [УСПЕХ]
    выбор описания: {[p21]}
    Loc27-1: You popped up on the surface like a cork out of the bottle! / The Mermaid rescue boat drifted nearby. When you climbed out of the bathyscaph, everyone who was i…
    Loc27-2: You popped up on the surface like a cork out of the bottle! / The Mermaid rescue boat drifted nearby. When you climbed out of the bathyscaph, everyone who was i…

### Loc28 [пустая]
  -> Path79 => Loc12  вер=1 порядок=5

### Loc29 [пустая]
  -> Path83 => Loc12  вер=1 порядок=5

### Loc30 [пустая]
  -> Path88 => Loc12  вер=1 порядок=5

### Loc31 [ПРОВАЛ]
    Loc31-1: You popped up on the surface like a cork out of the bottle! / The Mermaid rescue boat drifted nearby. You climbed out of the bathyscaph and took a deep breath o…

### Loc32 [пустая]
  -> Path87 => Loc30  вер=10000 проходов<=1 порядок=5
       ответ: Suddenly you felt a strong hit. Something flashed in front of the illuminator.  / "What the...!" The hull strength indicator showed considerable damage. "What i…
       эффект: P20(Hull) -5
  -> Path89 => Loc30  вер=100 проходов<=1 порядок=5
       ответ: A strong hit shuddered the entire bathyscaph. Suddenly you saw a scary open maw, riddled with huge caries-stricken teeth, appeared in the illuminator. / - Ye go…
       условия: P12(Diving depth) 0..5000; P19(Searchlight) ∈[1]
       эффект: P20(Hull) -5
  -> Path90 => Loc30  вер=10000 проходов<=1 порядок=5
       ответ: Another strong hit shook the entire bathyscaph. Suddenly you saw a scary open maw, riddled with huge caries-stricken teeth, appeared in the illuminator. / - Ye …
       условия: P12(Diving depth) 5000..10000; P19(Searchlight) ∈[1]
       эффект: P20(Hull) -5
  -> Path93 => Loc30  вер=1 порядок=5
       ответ: You again felt something hit the ship on the side. How long is it going to last?
       условия: P19(Searchlight) ∈[0]
       эффект: P20(Hull) -5
  -> Path94 => Loc30  вер=1 порядок=5
       ответ: The underwater beast continued to wriggle around you bathyscaph trying desperately to swallow it. The hits of its huge teeth against the hull did not go unnotic…
       условия: P19(Searchlight) ∈[1]
       эффект: P20(Hull) -5
  -> Path95 => Loc30  вер=100 проходов<=1 порядок=5
       ответ: The manoeuvre with your searchlights in the face of the monster worked perfectly! You scared the sea beast away. Apparently the ruler of the deep did not expect…
       условия: P12(Diving depth) 0..5000; P19(Searchlight) ∈[1]; логика {([p7]<([p17]+45)) and ([p7]>([p17]-45))}
       эффект: P17(Monster) = 300
  -> Path96 => Loc30  вер=100 проходов<=1 порядок=5
       ответ: The manoeuvre with your searchlights in the face of the monster worked perfectly! You scared the sea beast away. Apparently the ruler of the deep did not expect…
       условия: P12(Diving depth) 5000..10000; P19(Searchlight) ∈[1]; логика {([p7]<([p17]+45)) and ([p7]>([p17]-45))}
       эффект: P17(Monster) = 300
  -> Path97 => Loc30  вер=5 проходов<=1 порядок=5
       ответ: Chased by the sea beast, you did notice how you climbed back closer to the surface. Here it suddenly left you alone. (Obviously, the deep-water prehistoric anim…
       условия: P12(Diving depth) 0..500
       эффект: P17(Monster) = 300

### Loc33 [пустая]
  -> Path104 => Loc12  вер=1 порядок=5

### Loc34 [пустая]
  -> Path107 => Loc19  вер=1 порядок=5

### Loc35 [пустая]
  -> Path42 => Loc19  вер=1 порядок=5
       ответ: Feeling a slight bump you understood that another portion of the unnecessary cargo was dropped. The "Kid" rocked softly. Now the dive speed is going to be slowe…
       условия: P18(Bottom) ∈[0]; логика {([p22]+[p23])>1000}
  -> Path114 => Loc19  вер=100 порядок=5
       ответ: You dropped the last kilograms that allowed the bathyscaph to sink deeper. After the ship shuddered yet another time you did not notice anything special, but th…
       условия: логика {([p22]+[p23])=1000}
  -> Path115 => Loc19  вер=100 проходов<=1 порядок=5
       ответ: You felt the already familiar shudder and the ship started climbing up. "Gotta get out of here, before I got squished ", - you thought to yourself and reported …
       условия: P12(Diving depth) 0..5000; логика {([p22]+[p23])<1000}
       эффект: P18(Bottom) = 0
  -> Path116 => Loc19  вер=100 проходов<=1 порядок=5
       ответ: You felt the already familiar shudder and the ship started climbing up. "Gotta get out of here, before I got squished ", - you thought to yourself and reported …
       условия: P12(Diving depth) 5000..10000; логика {([p22]+[p23])<1000}
       эффект: P18(Bottom) = 0
  -> Path117 => Loc19  вер=100 проходов<=1 порядок=5
       ответ: You felt the already familiar shudder and the ship started climbing up. "Gotta get out of here, before I got squished ", - you thought to yourself and reported …
       условия: P12(Diving depth) 0..5000; P21(Accomplishment) ∈[0]; логика {([p22]+[p23])<1000}
       эффект: P18(Bottom) = 0
  -> Path118 => Loc19  вер=1 порядок=5
       ответ: Another portion of unnecessary cargo started sinking to the bottom. The bathyscaph was rocking from side to side because of the constant ballast drop. The speed…
       условия: логика {([p22]+[p23])<1000}
       эффект: P18(Bottom) = 0
  -> Path148 => Loc19  вер=1 порядок=5
       ответ: You got rid of yet another portion of the ballast. Now the bathyscaph's will be less.
       условия: P18(Bottom) ∈[1]; логика {([p22]+[p23])>1000}
  -> Path154 => Loc19  вер=1 порядок=5
  -> Path155 => Loc19  вер=1 порядок=5
       ответ: The bathyscaph was climbing up. "High-time to get out of here!" You were overwhelmed with joy. Ahead of you there was the surface and a breath of fresh air. "I …
       условия: логика {([p22]+[p23])<800}

### Loc36 [СМЕРТЬ] визитов<=1
    Loc36-1: Suddenly the siren went off, and you noticed traces of water run down the illuminators. The same second you head started aching, the pressure was growing quickl…

### Loc37 [СТАРТ]
    выбор описания: {[p12]+1}
    Loc37-1: Apparently the cold season has begun on planet <ToPlanet>. As you marched towards the government house you felt the freezing wind pierce right through you. The …
    Loc37-2: - This a bathyscaph for deep dives. Unfortunately I do not understand much about these submarine apparatuses. Here is the documentation - take your time to stud…
    Loc37-3: - Well... I think that a daredevil fighter that you should not fear anything, should he now? - the officer winked. - However if we are talking dangers, I think,…
    эффект: P4(current speed) = {} [скрыт]
    эффект: P6(Plateau) = {} [скрыт]
    эффект: P8(X Co-ordinates) = {} [скрыт]
    эффект: P9(Y co-ordinates) = {} [скрыт]
    эффект: P13(Max depth) = {} [скрыт]
    скрыт: P1,P2,P3,P5,P7,P10,P11,P12,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24
  -> Path4 => Loc4  вер=1 проходов<=1 порядок=2
       текст: What dangers can I encounter?
  -> Path127 => Loc2  вер=1 проходов<=1 порядок=1
       текст: What is this R I-00-M thing? Never heard of it
  -> Path140 => Loc8  вер=1 проходов<=1
       текст: Alright. I can help you. Where is your bathyscaph?
       эффект: P4(current speed) = {[p4]*10}
       эффект: P6(Plateau) = {[p6]*10}
       эффект: P8(X Co-ordinates) = {[p8]*10}
       эффект: P9(Y co-ordinates) = {[p9]*10}
       эффект: P11(Target depth) = {10*([p11] div 10)+[5..9]}
       эффект: P12(Diving depth) = {1}
       эффект: P13(Max depth) = {([p11] div 500+1)*500}
  -> Path151 => Loc3  вер=1 порядок=5
       текст: I think I reconsidered. I really don't feel like risking my life because of some space alien! There's enough of them up there among the stars, isn't it?! I am g…

### Loc39 [пустая]
  -> Path51 => Loc19  вер=1 порядок=5

### Loc40 [пустая]
    эффект: P12(Diving depth) = {2+([p8]<0)+2*([p9]<0)}
  -> Path161 => Loc8  вер=1 порядок=5

### Loc41 [пустая]
    эффект: P12(Diving depth) = {6}
  -> Path163 => Loc8  вер=1 порядок=5

### Loc42 [пустая]
    эффект: P12(Diving depth) = {7}
  -> Path165 => Loc8  вер=1 порядок=5

### Loc43 [пустая]
    эффект: P12(Diving depth) = {8}
  -> Path167 => Loc8  вер=1 порядок=5

## Анализ
- стартовых: [37]
- концовки: {3: 'ПРОВАЛ', 27: 'УСПЕХ', 31: 'ПРОВАЛ', 36: 'СМЕРТЬ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
