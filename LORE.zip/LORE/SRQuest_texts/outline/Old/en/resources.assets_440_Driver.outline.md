# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Time' [0..21060] тип=смерть
    старт: [435]
    [0..8640] {[p1] div (24*60)} days passed.<br>Time: {[p1] mod (24*60) div 60} hr. {[p1] mod 60} min.<br><br>YOU…
    [8641..14400] {[p1] div (24*60)} days passed.<br>Time: {[p1] mod (24*60) div 60} hr. {[p1] mod 60} min.<br><clr>Ro…
    [14401..21060] {[p1] div (24*60)} days passed.<br>Time: {[p1] mod (24*60) div 60} hr. {[p1] mod 60} min.<br>Rolan's…
    критическое: You spent so much time on the planet of <ToPlanet>, you became completely used to it. You simply cou…
- P2 'Actual player money' [0..2111222333] тип=обычный деньги
    старт: [1000]
    [0..2111222333] {[p1] div (24*60)} days passed.<br>Time: {[p1] mod (24*60) div 60} hr. {[p1] mod 60} min.<br><clr>Ro…
    критическое: Сообщение достижения критического значения параметром 8
- P3 'Energy' [0..100] тип=смерть
    старт: [100]
    [0..9] You are one foot in the grave!!!
    [10..19] You are awfully wounded!
    [20..29] You got some bad wounds
    [30..39] Multiple wounds
    [40..49] Wounded
    [50..59] You whole body is aching
    [60..69] Bruises and scratches
    [70..79] Slightly mushy
    [80..89] Almost OK
    [90..100] Totally fine
    критическое: Your wounds finally did it for you. You perished and with your demise another hope of the Galaxy has…
- P4 'Tiredness' [0..100000] тип=смерть
    старт: [100000]
    [0..9999] You are hearing voices!!!
    [10000..19999] You are falling off your feet!
    [20000..29999] Staggering
    [30000..39999] Very tired
    [40000..49999] Considerably tired
    [50000..59999] Tired
    [60000..69999] A little tired
    [70000..79999] Almost not tired
    [80000..89999] Quite lively
    [90000..100000] Never been better!
    критическое: You drove your grip firmly on the steering wheel, but your eyes kept closing. At last you subdued, l…
- P5 'Hunger' [0..100000] тип=смерть
    старт: [85000]
    [0..9999] Swelling of hunger!!!
    [10000..19999] You are terribly hungry!
    [20000..29999] Very hungry
    [30000..39999] You stomach's warbling
    [40000..49999] Slightly hungry
    [50000..59999] Could eat something
    [60000..69999] Could satisfy the inner man
    [70000..79999] Almost not hungry
    [80000..89999] Satiated
    [90000..100000] Stuffed
    критическое: You tried to cope with the overwhelming feeling of hunger, but to no avail. Exhausted you passed out…
- P6 'Money' [0..1000000] тип=обычный
    старт: [20]
    [0..1000000] Platinum-pieces: <>
    критическое: Сообщение достижения критического значения параметром 5
- P7 'Weapons' [0..1999] тип=обычный
    старт: [0]
    [0..999] Ammo: {[p7] mod 1000}
    [1000..1999] Shotgun: {[p7] mod 1000} rounds.
    критическое: Сообщение достижения критического значения параметром 6
- P8 'Tattoo, deposit, Peleng' [0..112] тип=обычный
    старт: [0]
    [0..2] "Scorpion" tattoo
    [3..10] You paid the ransom
    [11..12] "Scorpion" tattoo<br>You paid the ransom
    [13..100] The Peleng goes with you
    [101..102] "Scorpion" tattoo<br>The Peleng goes with you
    [103..110] You paid the ransom<br>The Peleng goes with you
    [111..112] "Scorpion" tattoo<br>You paid the ransom<br>The Peleng goes with you
    критическое: Сообщение достижения критического значения параметром 7
- P9 'Truck armour' [0..100] тип=смерть
    старт: [100]
    [0..100] TRUCK:
    критическое: The pungent smell of gasoline hit your nostrils and the next moment the truck went ablaze. Instant d…
- P10 'Spikes' [0..1] тип=обычный
    старт: [0]
    [0..0] Truck condition: [p9]%
    [1..1] Truck condition: [p9]% + spikes
    критическое: Сообщение достижения критического значения параметром 38
- P11 'Fuel tank' [0..100000] тип=смерть
    старт: [100000]
    [0..30000] Fuel: {[p11] div 1000} l. (!!!)
    [30001..100000] Fuel: {[p11] div 1000} l.
    критическое: Having run out of fuel, you left the truck and tried to make it to your spaceship on foot but failed…
- P12 'Speed' [0..100] тип=обычный
    старт: [60]
    [0..100] Parameter No 12: <>
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Hold (free space)' [0..20] тип=обычный
    старт: [10]
    [0..20] Space available: <> t.
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Spinach' [0..20] тип=обычный
    старт: [0]
    [0..20] Spinach: <> t.
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Coal' [0..20] тип=обычный
    старт: [0]
    [0..20] Coal: <> t.
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Scrap metal' [0..20] тип=обычный
    старт: [0]
    [0..20] Scrap metal: <> t.
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Buffer' [0..10000] тип=обычный
    старт: [1]
    [0..10000] Parameter No 17: <>
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Psychological state of the enemy' [0..100] тип=обычный
    старт: [100]
    [0..24] The enemy is afraid
    [25..49] The enemy is being careful
    [50..74] The enemy has certain doubts
    [75..100] The enemy is quite decisive
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Spinach reserve' [0..1000] тип=обычный
    старт: [35]
    [0..1000] Parameter No 19: <>
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Coal reserve' [0..1000] тип=обычный
    старт: [75]
    [0..1000] Parameter No 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Scrap metal reserve' [0..1000] тип=обычный
    старт: [50]
    [0..1000] Parameter No 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Gas per min.' [0..1000] тип=обычный
    старт: [100]
    [0..1000] Parameter No 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Hunger per min.' [0..100] тип=обычный
    старт: [35]
    [0..100] Parameter No 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Tiredness per min.' [0..100] тип=обычный
    старт: [60]
    [0..100] Parameter No 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Fellow-traveller' [0..10] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Fellow-traveller to Shpick
    [2..2] Fellow-traveller to Scorpion Bar
    [3..3] Fellow-traveller to the mines
    [4..4] Fellow-traveller to Shpick
    [5..5] Fellow-traveller to Shpick
    [6..6] Fellow-traveller to the farm
    [7..7] Fellow-traveller to the sheriff
    [8..10] Fellow-traveller to the mines
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Where from' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Where to' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 27
- P28 'Distance' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 28
- P29 'x' [0..20] тип=обычный
    старт: [0]
    [0..20] 
    критическое: Сообщение достижения критического значения параметром 29
- P30 'y' [0..999999] тип=обычный
    старт: [0]
    [0..999999] Parameter No 30: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'z' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Parameter No 31: <>
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Person' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter No 32: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'z2' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Parameter No 33: <>
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Spinach upgrade' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Parameter No 34: <>
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Scrap metal upgrade' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Parameter No 35: <>
    критическое: Сообщение достижения критического значения параметром 35
- P36 'Coal upgrade' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Parameter No 36: <>
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Fines' [0..20] тип=обычный
    старт: [0]
    [0..20] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Truck upgrades + swap trucks + automate use qty.' [0..200111] тип=обычный
    старт: [0]
    [0..28586] Parameter No 11: <>
    [28587..57173] Parameter No 11: <>
    [57174..85760] Parameter No 11: <>
    [85761..114347] Parameter No 11: <>
    [114348..142934] Parameter No 11: <>
    [142935..171521] Parameter No 11: <>
    [171522..200111] Parameter No 11: <>
    критическое: Сообщение достижения критического значения параметром 11
- P39 'new' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 39

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: At the main airport of <ToPlanet> you were given the directions to Rolan's place. As it turned out he was living on a remote island where spaceships almost neve…
    эффект: P1(Time) = {400 to 500} [показ]
    скрыт: P2,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P29,P30,P31,P32,P33,P34,P35,P36,P38
  -> Path2 => Loc2  вер=1 порядок=1
       текст: Go to Ramina's house and ask her a couple of questions
       эффект: P1(Time) +1
       эффект: P29(x) = 1
  -> Path17 => Loc4  вер=1 порядок=9
       текст: Alright, it's pretty clear. Time to mount the truck and go save Rolan
  -> Path386 => Loc125  вер=1 порядок=2
       текст: Examine the car

### Loc2 [обычная]
    выбор описания: {[p29]}
    Loc2-1: The insides of the cabin matched its outside - all of the furniture was ancient and looked like it was about t collapse. You looked at Ramina. /  / - Want to te…
    Loc2-2: - After the collapse of the bridge that led to the rubidium mines, things here got pretty tight. Then Rolan has got another of his crazy ideas, and he borrowed …
    Loc2-3: - Normally they would find everyone themselves... But if you are asking about their base, it is located <clr>in the east, right behind the Spinach farm<clrEnd>.…
    Loc2-4: - Dangers? This entire place is one big danger! The Scorpions and the Iroquois, collecting tolls control the roads. Plus there are all kinds of hoodlums here an…
    Loc2-5: - No, unfortunately not. At night my boys, - the woman nodded at the fluffy creatures at her feet, - tend to become aggressive - especially to strangers. They c…
    Loc2-6: - My husband used to be in trading. But I do not know whether you will be able to trade when you do not have the money... Although, somebody told me you could e…
    Loc2-7: - The climate is rather dry. Days are clear most of the time, and at nights it gets darker, but it never gets completely dark. Which is why many people here wou…
  -> Path3 => Loc3  вер=1 проходов<=1 порядок=2
       текст: Why was your husband kidnapped?
       эффект: P29(x) = 2
  -> Path4 => Loc3  вер=1 проходов<=1 порядок=8
       текст: Can I spend the night here?
       эффект: P29(x) = 5
  -> Path5 => Loc3  вер=1 проходов<=1 порядок=3
       текст: Where can I find the Iroquois?
       эффект: P29(x) = 3
  -> Path6 => Loc3  вер=1 проходов<=1 порядок=6
       текст: Where can I get some money?
       эффект: P29(x) = 6
  -> Path7 => Loc3  вер=1 проходов<=1 порядок=4
       текст: Any particular dangers I need to know about?
       эффект: P29(x) = 4
  -> Path9 => Loc5  вер=1 порядок=9
       текст: I think I'll go
  -> Path258 => Loc3  вер=1 проходов<=1 порядок=7
       текст: What is the climate here like?
       эффект: P29(x) = 7

### Loc3 [пустая]
    эффект: P1(Time) +1
  -> Path259 => Loc2  вер=1 порядок=5

### Loc4 [обычная]
    Loc4-1: Your steel horse stands at the <clr>airport<clrEnd> drive-in.  /  / The street sign reads:  / "East - <clr>Blue Rock - 28 km<clrEnd>"
    показ: P9,P10,P11,P13,P14,P15,P16
  -> Path10 => Loc5  вер=1 порядок=9
       текст: Drive into the territory of the airport
       эффект: P1(Time) +1
  -> Path18 => Loc149  вер=1 порядок=5
       текст: Go to the Blue Rocks
       эффект: P26(Where from) = {4}
       эффект: P27(Where to) = {9}
       эффект: P28(Distance) = {28}
  -> Path381 => Loc128  вер=1.00011e+06 порядок=9
       текст: Drive into the territory of the airport
       условия: логика {([p8] div 10 mod 10)=1}
       эффект: P1(Time) +1
  -> Path434 => Loc5  вер=1000 порядок=9
       текст: Drive into the territory of the airport
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: логика {[p25]>0}
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = {0}
  -> Path483 => Loc150  вер=1.00011e+06 порядок=9
       текст: Drive into the territory of the airport
       условия: логика {([p8] div 10 mod 10)=2}
       эффект: P1(Time) +1
  -> Path591 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {4}
       эффект: P28(Distance) = 0

### Loc5 [обычная]
    Loc5-1: Nothing has changed at the airport. Your spaceship, cabin, plateau...
  -> Path11 => Loc2  вер=1 порядок=5
       текст: Enter the cabin
       эффект: P29(x) = 1
  -> Path12 => Loc4  вер=1 порядок=9
       текст: Leave the airport
  -> Path13 => Loc6  вер=1 порядок=5
       текст: I am sick and tired of this. Time to get away from this planet

### Loc6 [пустая]
    скрыт: P1,P2
  -> Path14 => Loc7  вер=1 порядок=5

### Loc7 [пустая]
  -> Path15 => Loc8  вер=1 порядок=5
       условия: логика {[p1]<(24*60)}
  -> Path16 => Loc6  вер=1 порядок=5
       условия: логика {[p1]>=(24*60)}
       эффект: P1(Time) = {[p1]-(24*60)}

### Loc8 [ПРОВАЛ]
    Loc8-1: Finally you are airborne, flying away from here. Too bad the mission is failed, but this is not the biggest catastrophe of the century, is it?
    скрыт: P1

### Loc9 [обычная]
    Loc9-1: Your truck runs down the freeway. You can already see the <clr>Blue Rocks<clrEnd> distinctly.  /  / On the right you noticed a rust-eaten sign. Looks like it ha…
  -> Path19 => Loc149  вер=1 порядок=3
       текст: Go to the airport
       эффект: P26(Where from) = {9}
       эффект: P27(Where to) = {4}
       эффект: P28(Distance) = {28}
  -> Path20 => Loc149  вер=1 порядок=1
       текст: Go to the military base (or dumpsite?)
       эффект: P26(Where from) = {9}
       эффект: P27(Where to) = {10}
       эффект: P28(Distance) = {48}
  -> Path39 => Loc149  вер=1 порядок=2
       текст: Go to the mines
       эффект: P26(Where from) = {9}
       эффект: P27(Where to) = {16}
       эффект: P28(Distance) = 32
  -> Path592 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {9}
       эффект: P28(Distance) = 0

### Loc10 [обычная]
    Loc10-1: You drove up to a road. In the north-west you saw a <clr>huge dump site<clrEnd> looming above like a mountain. /  / The road sign with a skull on top read: / "N…
  -> Path21 => Loc149  вер=1 порядок=3
       текст: Go to the Blue Rocks
       эффект: P26(Where from) = {10}
       эффект: P27(Where to) = {9}
       эффект: P28(Distance) = {48}
  -> Path22 => Loc11  вер=1 порядок=9
       текст: Drive into the dumpsite
       эффект: P1(Time) +1
  -> Path147 => Loc149  вер=1 порядок=2
       текст: Go to the Big Gap
       эффект: P26(Where from) = {10}
       эффект: P27(Where to) = {51}
       эффект: P28(Distance) = {40}
  -> Path156 => Loc149  вер=1 порядок=1
       текст: Go to the "Scorpion Nest"
       эффект: P26(Where from) = {10}
       эффект: P27(Where to) = {54}
       эффект: P28(Distance) = {36}
  -> Path435 => Loc11  вер=1000 порядок=9
       текст: Drive into the dumpsite
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: логика {[p25]>0}
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = {0}
  -> Path590 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {10}
       эффект: P28(Distance) = 0

### Loc11 [пустая]
  -> Path24 => Loc13  вер=1 порядок=5
       эффект: P29(x) = {1}
  -> Path543 => Loc13  вер=1000 порядок=5
       условия: логика {[p1]>=([p35]+6*60)}
       эффект: P21(Scrap metal reserve) = {[p21]+([p35] div (6*60))+(0 to 1)}
       эффект: P29(x) = {1}
       эффект: P35(Scrap metal upgrade) = {[p1]}

### Loc12 [обычная]
    выбор описания: {[p29]}
    Loc12-1: - So what do you want to know, gringo?
    Loc12-2: - What weapons are you talking about, man! My brothers and me have found a couple of pieces at the dump site, but those are ours. I mean, in these parts, one ne…
    Loc12-3: - Thing is, back a long-long time ago there used to be a huge Maloq base here. It had been built even before the Interstellar Coalition was founded...  / The ou…
    Loc12-4: - Rolan, eh? I think he owes the Iroquois money and they keep him hostage. Asking for a ransom... But that all I know, I'm afraid, - Cromalione said.
    Loc12-5: - I am sure they will gladly buy it from you in Shpick. If you want to find it, go south to the miners' village and then turn to the east.
  -> Path30 => Loc13  вер=1 порядок=5
       текст: I would like to do some business with you
       эффект: P29(x) = {3}
  -> Path31 => Loc10  вер=1 порядок=9
       текст: Awright, laddies, I'm going
       эффект: P1(Time) +1
  -> Path33 => Loc15  вер=1 проходов<=1 порядок=2
       текст: Why do some of the road signs read "military base" instead of the dumpsite?
       эффект: P29(x) = 3
  -> Path34 => Loc15  вер=1 проходов<=1 порядок=1
       текст: I am looking for Rolan. Where is he?
       эффект: P29(x) = 4
  -> Path35 => Loc15  вер=1 проходов<=1 порядок=3
       текст: Have you any weapons?
       эффект: P29(x) = {2}
  -> Path36 => Loc15  вер=1 проходов<=1 порядок=4
       текст: Where can I sell scrap metal?
       эффект: P29(x) = 5

### Loc13 [обычная]
    выбор описания: {[p29]+([p21]=0)}
    Loc13-1: The truck quickly drove into the dump sight. You were just about to go into the garbage labyrinth, when a three-meter robot stepped in your way. Rusty as it was…
    Loc13-2: The truck quickly drove into the dump sight. You were just about to go into the garbage labyrinth, when a three-meter robot stepped in your way. Rusty as it was…
    Loc13-3: - Alrighteez. Right now , we have [p21] tons of scrap metal available now. <clr>10 platinum pieces per ton.<clrEnd> All compactly pressed and packed in containe…
    Loc13-4: - Sorry, gringo, not at the moment. . But if you come back here in, say, six hours, buy that time we will surely dig something for you. Promise.
  -> Path25 => Loc14  вер=1 [всегда видна] порядок=1
       текст: I will take a ton of scrap metal
       условия: логика {([p21]>0) and ([p13]>0) and ([p6]>=10)}
       эффект: P6(Money) = {[p6]-10}
       эффект: P13(Hold (free space)) -1
       эффект: P16(Scrap metal) +1
       эффект: P21(Scrap metal reserve) = {[p21]-1}
  -> Path26 => Loc14  вер=1 [всегда видна] порядок=2
       текст: I will take three tons of scrap metal
       условия: логика {([p21]>2) and ([p13]>2) and ([p6]>=3*10)}
       эффект: P6(Money) = {[p6]-(3*10)}
       эффект: P13(Hold (free space)) -3
       эффект: P16(Scrap metal) +3
       эффект: P21(Scrap metal reserve) = {[p21]-3}
  -> Path27 => Loc14  вер=1 [всегда видна] порядок=4
       текст: I will load with scrap metal to the brim
       условия: логика {([p21]>=[p13]) and ([p13]>0) and ([p6]>=([p13]*10))}
       эффект: P6(Money) = {[p6]-([p13]*10)}
       эффект: P13(Hold (free space)) = 0
       эффект: P16(Scrap metal) = {[p16]+[p13]}
       эффект: P21(Scrap metal reserve) = {[p21]-[p13]}
  -> Path28 => Loc14  вер=1 [всегда видна] порядок=3
       текст: I will take all the scrap metal that you have left
       условия: логика {([p13]>=[p21]) and ([p21]>0) and ([p6]>=([p21]*10))}
       эффект: P6(Money) = {[p6]-([p21]*10)}
       эффект: P13(Hold (free space)) = {[p13]-[p21]}
       эффект: P16(Scrap metal) = {[p16]+[p21]}
       эффект: P21(Scrap metal reserve) = {0}
  -> Path29 => Loc12  вер=1 порядок=5
       текст: I have a couple of questions
       эффект: P29(x) = 1
  -> Path32 => Loc10  вер=1 порядок=9
       текст: Awright, laddies, I'm going
       эффект: P1(Time) +1

### Loc14 [пустая]
    эффект: P1(Time) +1
    эффект: P29(x) = {3}
  -> Path38 => Loc13  вер=1 порядок=5

### Loc15 [пустая]
    эффект: P1(Time) +1
  -> Path37 => Loc12  вер=1 порядок=5

### Loc16 [обычная]
    Loc16-1: Your truck is standing on the broad asphalt road. A huge mountain is looming nearby, and at the foot of it you can see a <clr> small miners' village<clrEnd>.  /…
  -> Path40 => Loc149  вер=1 порядок=1
       текст: Go to the Blue Rocks
       эффект: P26(Where from) = {16}
       эффект: P27(Where to) = {9}
       эффект: P28(Distance) = {32}
  -> Path106 => Loc149  вер=1 порядок=2
       текст: Go to Mow's Gas Station
       эффект: P26(Where from) = {16}
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = {20}
  -> Path391 => Loc17  вер=1 порядок=9
       текст: Turn to the miners' village
       эффект: P1(Time) +1
  -> Path440 => Loc138  вер=1000 порядок=9
       текст: Turn to the miners' village
       условия: логика {[p25]>0}
  -> Path593 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {16}
       эффект: P28(Distance) = 0

### Loc17 [обычная]
    Loc17-1: You are standing on the sand. Around you are only <clr>barracks<clrEnd>, and coal-stained folks. At a closer look, you noticed a <clr>small kiosk<clrEnd>, in wh…
    эффект: P1(Time) +1
  -> Path42 => Loc19  вер=1 порядок=3
       текст: Go over to the kiosk
       эффект: P29(x) = 1
  -> Path47 => Loc21  вер=1 порядок=2
       текст: Enter one of the barracks
  -> Path52 => Loc25  вер=1 порядок=1
       текст: Go to the trading house
  -> Path70 => Loc16  вер=1 порядок=9
       текст: Leave the village
       эффект: P1(Time) +1
  -> Path71 => Loc27  вер=1 порядок=4
       текст: To the mines
  -> Path422 => Loc133  вер=0.2 проходов<=3 порядок=9
       текст: Leave the village
       ответ: You were about to go off when a grimy miner ran u to your truck: / - Hey, chief! Can you give me a lift to <clr>Shpick<clrEnd>? I'll pay you <clr>40 platinum pi…
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = 1 [скрыт]
  -> Path425 => Loc133  вер=0.2 проходов<=2 порядок=9
       текст: Leave the village
       ответ: You started the engine and drove to the exit, when you noticed a guy waving his hand by the road and stopped. A strong-knit miner walked up to your truck: / - H…
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = 2 [скрыт]
  -> Path542 => Loc25  вер=1000 порядок=1
       текст: Go to the trading house
       условия: логика {[p1]>=([p36]+3*60)}
       эффект: P20(Coal reserve) = {[p20]+([p36] div (3*60))+(0 to 1)}
       эффект: P36(Coal upgrade) = {[p1]}

### Loc19 [обычная]
    выбор описания: {[p29]}
    Loc19-1: The Peleng is giving the food to the miners in silence all of his four hands busy. At the bottom of the kiosk you noticed a sign - "<clr>A portion of nutritious…
    Loc19-2: The Peleng took the coin from your hand, pushed a lever on some weird-looking unit, and thirty seconds later the unit belched out a portion of green mesh. Throw…
    Loc19-3: The Peleng took the coin from your hand, pushed a lever on some weird-looking unit, and thirty seconds later the unit belched out a portion of green mesh. The t…
  -> Path43 => Loc20  вер=1 [всегда видна] порядок=3
       текст: Buy a portion
       условия: логика {([p6]>0) and ([p5]<40000)}
       эффект: P5(Hunger) = {[p5]+[20000..30000]}
       эффект: P6(Money) -1
       эффект: P29(x) = 3
  -> Path44 => Loc20  вер=1 [всегда видна] порядок=3
       текст: Buy a portion
       условия: логика {([p6]>0) and ([p5]>=40000)}
       эффект: P6(Money) -1
       эффект: P29(x) = 2
  -> Path46 => Loc145  вер=1 порядок=5
       текст: Walk away from the kiosk

### Loc20 [пустая]
    эффект: P1(Time) +2
  -> Path45 => Loc19  вер=1 порядок=5

### Loc21 [обычная]
    Loc21-1: Having entered one of the barracks you found a multitude of two-story cots. The miners occupied almost all of them, but you did manage to find one that was free…
  -> Path48 => Loc145  вер=1 порядок=9
       текст: Leave the barracks
  -> Path124 => Loc44  вер=1 порядок=5
       текст: Go to sleep
       условия: логика {[p4]<100000}

### Loc22 [пустая]
  -> Path51 => Loc145  вер=1 порядок=9
       текст: Go outside
  -> Path84 => Loc44  вер=1 [всегда видна] порядок=5
       текст: Looks for another free cot
       условия: логика {[p4]<100000}
       эффект: P1(Time) = {[p1]+[3..5]}

### Loc23 [обычная]
    выбор описания: {[p29]}
    Loc23-1: - Alright, ask your questions. But stick to the point. I am not answering any other questions, - said the man.
    Loc23-2: - Where? Back at the Digsons' farm. If you want to find it, go north from Shpick, - the man responded.
    Loc23-3: - In Shpick - a town in the east, - the man answered.
    Loc23-4: - Oh yeah?! You've come to the right place then. Our mines are always in need of fresh manpower. While working here, you can earn as much as three platinum piec…
  -> Path54 => Loc24  вер=1 проходов<=1 порядок=1
       текст: Where can I sell coal?
       эффект: P29(x) = 3
  -> Path55 => Loc24  вер=1 проходов<=1 порядок=2
       текст: I need money. How can I earn some?
       эффект: P29(x) = 4
  -> Path57 => Loc17  вер=1 порядок=9
       текст: Thanks. No questions
  -> Path58 => Loc25  вер=1 порядок=8
       текст: Let's trade!
  -> Path59 => Loc24  вер=1 проходов<=1 порядок=1
       текст: Where can I buy spinach?
       эффект: P29(x) = 2

### Loc24 [пустая]
    эффект: P1(Time) +1
  -> Path60 => Loc23  вер=1 порядок=5

### Loc25 [обычная]
    выбор описания: {1+([p20]=0)}
    Loc25-1: You are standing in the middle of the room packed with coal-bags. There is a guy in a hard hat sitting on a small chair at the exit.  /  / - Listen here. We are…
    Loc25-2: You are standing in the middle of the room packed with coal-bags. There is a guy in a hard hat sitting on a small chair at the exit.  /  / - Unfortunately we've…
  -> Path62 => Loc23  вер=1 порядок=8
       текст: Ask a couple of questions
       эффект: P29(x) = 1
  -> Path63 => Loc145  вер=1 порядок=9
       текст: Say good bye
  -> Path64 => Loc26  вер=1 [всегда видна] порядок=1
       текст: Buy a ton of coal
       условия: логика {([p20]>0) and ([p13]>0) and ([p6]>=5)}
       эффект: P6(Money) = {[p6]-5}
       эффект: P13(Hold (free space)) -1
       эффект: P15(Coal) +1
       эффект: P20(Coal reserve) = {[p20]-1}
  -> Path65 => Loc26  вер=1 [всегда видна] порядок=2
       текст: Buy three tons of coal
       условия: логика {([p20]>2) and ([p13]>2) and ([p6]>=(3*5))}
       эффект: P6(Money) = {[p6]-(3*5)}
       эффект: P13(Hold (free space)) -3
       эффект: P15(Coal) +3
       эффект: P20(Coal reserve) = {[p20]-3}
  -> Path66 => Loc26  вер=1 [всегда видна] порядок=4
       текст: Load the coal to the brim
       условия: логика {([p20]>=[p13]) and ([p13]>0) and ([p6]>=([p13]*5))}
       эффект: P6(Money) = {[p6]-([p13]*5)}
       эффект: P13(Hold (free space)) = 0
       эффект: P15(Coal) = {[p15]+[p13]}
       эффект: P20(Coal reserve) = {[p20]-[p13]}
  -> Path67 => Loc26  вер=1 [всегда видна] порядок=3
       текст: Take all the coal they have left
       условия: логика {([p13]>=[p20]) and ([p21]>0) and ([p6]>=([p21]*5))}
       эффект: P6(Money) = {[p6]-([p21]*5)}
       эффект: P13(Hold (free space)) = {[p13]-[p20]}
       эффект: P15(Coal) = {[p15]+[p20]}
       эффект: P20(Coal reserve) = {0}
  -> Path68 => Loc26  вер=1 [всегда видна] порядок=5
       текст: Sell all spinach
       условия: логика {[p14]>0}
       эффект: P6(Money) = {[p6]+(45*[p14])}
       эффект: P13(Hold (free space)) = {[p13]+[p14]}
       эффект: P14(Spinach) = {0}

### Loc26 [пустая]
    эффект: P1(Time) +1
  -> Path69 => Loc25  вер=1 порядок=5

### Loc27 [обычная]
    Loc27-1: It was very dark in the mine, but soon you got used to it. The light from several lamps allowed to see what was going on inside. A whole bunch of folks in hard-…
  -> Path72 => Loc17  вер=1 порядок=9
       текст: I was just dropping by, in fact. I am not a worker
       ответ: - What?! A trespasser in the shaft! - The Maloq gave you a sound kick - launching you out of the shaft like a projectile. Reactionary guy.
  -> Path73 => Loc28  вер=1 порядок=5
       текст: Take a pickaxe and start working

### Loc28 [пустая]
  -> Path76 => Loc29  вер=1 порядок=5
       ответ: - That's it! You've been here an hour, - the Maloq barked behind your back. - Name! / - <Ranger>. / The Maloq wrote your name on the sack, put it on the loader …
       условия: логика {[p4]>55000}
       эффект: P1(Time) = {[p1]+[63..67]}
       эффект: P4(Tiredness) = {[p4]-[10000..15000]}
       эффект: P5(Hunger) = {[p5]-[p23]*100}
       эффект: P6(Money) +3
  -> Path77 => Loc29  вер=1 порядок=5
       ответ: - That's it! You've been here an hour, - the Maloq barked behind your back. - Name! / - <Ranger>. / The Maloq wrote your name on the sack, put it on the loader …
       условия: логика {[p4]<40000}
       эффект: P1(Time) = {[p1]+[63..67]}
       эффект: P4(Tiredness) = {[p4]-[10000..15000]}
       эффект: P5(Hunger) = {[p5]-[p23]*100}
       эффект: P6(Money) +1
  -> Path78 => Loc29  вер=1 порядок=5
       ответ: - That's it! You've been here an hour, - the Maloq barked behind your back. - Name! / - <Ranger>. / The Maloq wrote your name on the sack, put it on the loader …
       условия: логика {([p4]>25000) and ([p4]<70000)}
       эффект: P1(Time) = {[p1]+[63..67]}
       эффект: P4(Tiredness) = {[p4]-[10000..15000]}
       эффект: P5(Hunger) = {[p5]-[p23]*100}
       эффект: P6(Money) +2
  -> Path81 => Loc17  вер=1000 порядок=5
       ответ: You worked for all you were worth, but you were running out of strength. Suddenly your feet swam, and you sank down onto the ground. /  / - Is this one dead? - …
       условия: логика {[p4]<=15000}
       эффект: P1(Time) = {[p1]+[90..120]}
       эффект: P4(Tiredness) = {[p4]+[5000..7000]}
  -> Path82 => Loc30  вер=0.15 порядок=5
       эффект: P3(Energy) = {[p3]-[20..30]}

### Loc29 [пустая]
  -> Path79 => Loc28  вер=1 порядок=5
       текст: Yes
  -> Path80 => Loc17  вер=1 порядок=5
       текст: No

### Loc30 [обычная]
    Loc30-1: You were peacefully extracting coal, when suddenly a pile of stones fell down upon you from somewhere above. The miners rushed to dig you out... /  / When you c…
  -> Path83 => Loc17  вер=1 порядок=5
       текст: Try to get up
       ответ: Hurray! You managed to get up. Moreover you did not even break anything. Looks like you got away with it fairly unharmed...

### Loc31 [пустая]
    эффект: P18(Psychological state of the enemy) = {100} [показ]
  -> Path85 => Loc32  вер=1 порядок=5
       эффект: P17(Buffer) = {(10 to 20)+2*([p14]+[p15]+[p16])}
       эффект: P29(x) = 1

### Loc32 [обычная]
    выбор описания: {[p29]}
    Loc32-1: You were peacefully going down the road, when you spotted a SUV with two tatted guys inside gaining upon you.  /  / - Pull over! - one of them shouted to you.
    Loc32-2: You heard a whizzing sound followed by a jolt of pain. Crap! <clr>You got hit by a crossbow arrow!!!<clrEnd> Horrible! What wild traditions are these!  /  / On …
    Loc32-3: You noticed one of the bandits' aim a crossbow at you. Out of pure instinct you ducked forward - <clr>the arrow shot over your head<clrEnd>. That was close...  …
    Loc32-4: On your side you saw a SUV with two tatted guys inside. Looks like they are not going to leave you alone.  /  /  - Hey you, moron! Pull over, - one of them shou…
    Loc32-5: You noticed one of the bandits' aim a crossbow at you. Out of pure instinct you ducked forward, but were not quick enough. <clr>The arrow scratched you slightly…
  -> Path86 => Loc181  вер=1 порядок=2
       текст: Hit the SUV with your truck-side
       ответ: You hit the SUV good! Sparks all around!
       условия: логика {([p38] div 10 mod 10)=0}
       эффект: P9(Truck armour) = {[p9]-(10 to 16)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(30 to 40)-1,1*([p14]+[p15]+[p16])}
  -> Path87 => Loc181  вер=1 порядок=2
       текст: Hit the SUV with your truck-side
       ответ: With your eyes flaming you snapped the steering wheel to the side, skidding the truck onto the chasers. The spikes on your wheels caught the SUV damaging it bad…
       условия: логика {([p38] div 10 mod 10)=1}
       эффект: P9(Truck armour) = {[p9]-(5 to 10)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(50 to 65)-1,5*([p14]+[p15]+[p16])}
  -> Path88 => Loc33  вер=1.2 порядок=3
       текст: Shoot at the car from the shotgun
       ответ: You shot at the SUV, but the villains were not going to let you go that easily. Still your move did have a certain effect on the enemy.
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P7(Weapons) -1
       эффект: P18(Psychological state of the enemy) = {[p18]-(25 to 33)}
  -> Path89 => Loc34  вер=1 порядок=3
       текст: Shoot at the car from the shotgun
       ответ: Apparently your response scared the guys in the SUV, since the driver started making some sort of signs and reduce the speed. Jeep was falling behind more and m…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0) and ([p18]<(30 to 60))}
       эффект: P7(Weapons) -1
  -> Path90 => Loc34  вер=1 порядок=4
       текст: Shoot at them three times
       ответ: - Hasta la vista, baby, - you said in a deliberately serious tone, sneered, and started shooting at the SUV. Bang-bang-bang! /  / The SUV driver went skidding a…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>2)}
       эффект: P7(Weapons) -3
  -> Path91 => Loc33  вер=1 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator. The engine roared, and literally started scoffing the gasoline. But to no avail. Looks like the villains are not going top let you …
       эффект: P1(Time) +10
       эффект: P11(Fuel tank) = {[p11]-30*[p22]}
  -> Path92 => Loc34  вер=1000 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator and felt you were getting a breakaway. Hurray! Soon the guys in the SUV disappeared out of sight.
       условия: логика {(1 to 100)<=((([p14]+[p15]+[p16])=0)*80+(([p14]+[p15]+[p16])=1)*70+(([p14]+[p15]+[p16])=2)*50+(([p14]+[p15]+[p16])=3)*33+(([p14]+[p15]+[p16])=4)*20+1.5*(100-[p18]))}
       эффект: P1(Time) +20
       эффект: P11(Fuel tank) = {[p11]-60*[p22]}
  -> Path93 => Loc33  вер=1 [всегда видна] порядок=1
       текст: Drop the load on the enemy
       ответ: You moved in front of the SUV, pushed the red button, and dumped your entire load on the enemy. For some time the only thing you could see in your rear-view mir…
       условия: логика {([p14]+[p15]+[p16])>0}
       эффект: P13(Hold (free space)) = {[p13]+[p14]+[p15]+[p16]}
       эффект: P14(Spinach) = {0}
       эффект: P15(Coal) = {0}
       эффект: P16(Scrap metal) = {0}
       эффект: P18(Psychological state of the enemy) = {[p18]-(18*([p14]+[p15]+[p16]))}
  -> Path94 => Loc34  вер=1 [всегда видна] порядок=1
       текст: Drop the load on the enemy
       ответ: You moved in front of the SUV, pushed the red button, and dumped your entire load on the enemy. The load was falling out of the truck like from a cornucopia. Th…
       условия: логика {([p14]+[p15]+[p16])>(3 to 5)}
       эффект: P13(Hold (free space)) = {[p13]+[p14]+[p15]+[p16]}
       эффект: P14(Spinach) = {0}
       эффект: P15(Coal) = {0}
       эффект: P16(Scrap metal) = {0}
       эффект: P18(Psychological state of the enemy) = {[p18]-(5*([p14]+[p15]+[p16]))}
  -> Path101 => Loc37  вер=1 порядок=9
       текст: Stop
  -> Path343 => Loc33  вер=1.00011e+06 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator. The engine roared scoffing the gasoline, but to no avail. Looks like, <clr>you are too overloaded<clrEnd>, to break away from the c…
       условия: логика {([p14]+[p15]+[p16])>=5}
       эффект: P1(Time) +10
       эффект: P11(Fuel tank) = {[p11]-30*[p22]}

### Loc33 [пустая]
  -> Path95 => Loc35  вер=1.7 порядок=5
       условия: логика {[p4]>(60000 to 70000)}
       эффект: P4(Tiredness) = {[p4]-(2500 to 5000)}
       эффект: P29(x) = 3
  -> Path96 => Loc35  вер=1.4 порядок=5
       эффект: P3(Energy) = {[p3]-(15 to 25)}
       эффект: P29(x) = 2
  -> Path97 => Loc35  вер=1 порядок=5
       эффект: P29(x) = 4
  -> Path98 => Loc34  вер=1000 порядок=5
       ответ: The SUV started slowing down. You were driving further and further away from the villains. Finally they are out of your sight. Looks like the decided to leave y…
       условия: логика {[p18]<(10 to 25)}
  -> Path576 => Loc35  вер=1.8 порядок=5
       условия: логика {[p4]>(50000 to 70000)}
       эффект: P3(Energy) = {[p3]-(10 to 15)}
       эффект: P4(Tiredness) = {[p4]-(2500 to 5000)}
       эффект: P29(x) = 5

### Loc34 [пустая]
  -> Path100 => Loc148  вер=1 порядок=5
       скрыт: P18

### Loc35 [пустая]
  -> Path99 => Loc32  вер=1 порядок=5

### Loc37 [обычная]
    выбор описания: {1+([p18]<100)}
    Loc37-1: You pulled over, and the SUV stopped right in front of you. Two bandits each aiming a crossbow at you climbed out. /  / - Hey, chief! This is our territory, so …
    Loc37-2: You pulled over, and the SUV stopped right in front of you. Two bandits each aiming a crossbow at you climbed out. /  / - Hey you, nitwit! You think you're so t…
  -> Path102 => Loc34  вер=1 порядок=9
       текст: Pay
       ответ: You went out of the truck and cautiously paid the villains what they asked.  /  / - That's better, - one of them said, putting the money in his pocket. - You ca…
       условия: логика {[p6]>=([p17]+((100-[p18]) div 3))}
       эффект: P6(Money) = {[p6]-([p17]+((100-[p18]) div 3))}
  -> Path103 => Loc34  вер=3 порядок=2
       текст: Fire from a shotgun and split
       ответ: Sticking the shotgun out of the window you fired at the cut-throats and started retreating quickly. But these guys knew what they were doing and started shootin…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P3(Energy) = {[p3]-(13 to 18)}
       эффект: P7(Weapons) -1
  -> Path104 => Loc34  вер=1 порядок=1
       текст: Try to move back and dash forward down the road
       ответ: You quickly ignited the truck and started steering back onto the road. But the cut-throats were not about to let this happen hat easily - shooting at you from t…
       эффект: P3(Energy) = {[p3]-(35 to 50)}
  -> Path105 => Loc34  вер=1 порядок=8
       текст: Show them your tat
       ответ: You went out of the truck and showed them your tat. /  / - Hey guys, I'm a Scorpion! What's up with that? / - Hmm. I don't seem to remember your face, - one of …
       условия: логика {([p8] mod 10)=1}
       эффект: P8(Tattoo, deposit, Peleng) +1
  -> Path415 => Loc34  вер=1 порядок=3
       текст: Fire three shot from the shotgun and split
       ответ: You fired three shot from the shotgun. One of the villains took to his heels immediately. The second one hid behind the SUV. And you drove out onto the freeway …
       условия: логика {([p7]>1000) and (([p7] mod 1000)>2)}
       эффект: P7(Weapons) -3
  -> Path482 => Loc34  вер=1 порядок=2
       текст: Fire from a shotgun and split
       ответ: You fired at the cut-throats from the shotgun and started retreating. The villains however were not of most cowardice type and began shooting back from their cr…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P7(Weapons) -1
  -> Path485 => Loc151  вер=1 порядок=9
       текст: I'd gladly pay you but I don't have the money. Maybe we can resolve this issue amicably... I mean - diplomatically. No?
       условия: логика {[p6]<([p17]+((100-[p18]) div 3))}

### Loc38 [обычная]
    Loc38-1: You stopped at the crossroads, thinking where to go next. Taking a look around you saw a rather large building that read "<clr>Mow's Gas Station<clrEnd>". Altho…
  -> Path107 => Loc149  вер=1 порядок=3
       текст: Go to the mines
       эффект: P26(Where from) = {38}
       эффект: P27(Where to) = {16}
       эффект: P28(Distance) = {20}
  -> Path114 => Loc41  вер=1 порядок=9
       текст: Pull over at the gas station
       эффект: P1(Time) +1
       эффект: P29(x) = 1
  -> Path126 => Loc149  вер=1 порядок=1
       текст: Go to the sheriff's "estate"
       эффект: P26(Where from) = {38}
       эффект: P27(Where to) = {45}
       эффект: P28(Distance) = {24}
  -> Path286 => Loc149  вер=1 порядок=2
       текст: Go to Shpick
       эффект: P17(Buffer) = {1}
       эффект: P26(Where from) = {38}
       эффект: P27(Where to) = {93}
       эффект: P28(Distance) = {44}
  -> Path594 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = 0

### Loc41 [обычная]
    выбор описания: {[p29]}
    Loc41-1: A steal building with cannon barrels protruding from everywhere - that's one serious structure. /  / - <clr>1 litre of gas costs 1 platinum piece <clrEnd>, - a …
    Loc41-2: Lou got down to work: welding something, screwing and unscrewing stuff... /  / - All set, - the mechanic said after some time. - Ready. /  / You drove the truck…
    Loc41-3: - Go over to the garage. Lou will take a look at your flivver, - the woman said. /  / A second later the gates of the garage started rising. You drove over. Ins…
    Loc41-4: - Not your business, - the answer came.
    Loc41-5: - Right, another tradesman on my head! How many times do I have to say it - We got it all. We do not need a-ny-thing!!!
    Loc41-6: You bought <clr>10 litres<clrEnd> of fuel.  /  / - <clr>1 litre of gas costs 1 platinum piece <clrEnd>, - a metallic voice said. - Give the money to the robot a…
    Loc41-7: You bought <clr>25 litres<clrEnd> of fuel.  /  / - <clr>1 litre of gas costs 1 platinum piece <clrEnd>, - a metallic voice said. - Give the money to the robot a…
    Loc41-8: You filled your tank to the brim. Looks like you can go now.
    эффект: P1(Time) +1
  -> Path115 => Loc42  вер=1 [всегда видна] порядок=2
       текст: Buy 10 litres of fuel
       условия: логика {([p11]<100000) and ([p6]>=10)}
       эффект: P11(Fuel tank) = {[p11]+10000}
       эффект: P6(Money) = {[p6]-10}
       эффект: P29(x) = 6
  -> Path116 => Loc42  вер=1 проходов<=1 порядок=4
       текст: Ask, where they get gasoline from in this hole
       эффект: P29(x) = 4
  -> Path117 => Loc42  вер=1 порядок=3
       текст: Ask them to repair your truck
       условия: логика {[p9]>75}
       эффект: P1(Time) = {[p1]+15}
       эффект: P29(x) = 3
  -> Path118 => Loc42  вер=1 проходов<=1 порядок=5
       текст: Offer trade
       эффект: P29(x) = 5
  -> Path120 => Loc43  вер=1 порядок=3
       текст: Ask them to repair your truck
       условия: логика {[p9]<=75}
  -> Path123 => Loc38  вер=1 порядок=9
       текст: Leave the gas station
       эффект: P1(Time) +1
  -> Path584 => Loc42  вер=1 [всегда видна] порядок=1
       текст: Give me 25 litres
       условия: логика {([p11]<100000) and ([p6]>=25)}
       эффект: P11(Fuel tank) = {[p11]+25000}
       эффект: P6(Money) = {[p6]-25}
       эффект: P29(x) = 7
  -> Path586 => Loc42  вер=1 [всегда видна]
       текст: Fill the tank to the brim
       условия: логика {([p11]<100000) and ([p6]>=(100-([p11]) div 1000))}
       эффект: P11(Fuel tank) = {100000}
       эффект: P6(Money) = {[p6]-100+([p11] div 1000)}
       эффект: P29(x) = 8

### Loc42 [пустая]
  -> Path119 => Loc41  вер=1 порядок=5

### Loc43 [обычная]
    Loc43-1: - Go over to the garage. Lou will take a look at your flivver, - the woman said. /  / A second later the gates of the garage started rising. You drove over. Ins…
    эффект: P1(Time) = {[p1]+15}
  -> Path121 => Loc41  вер=1 порядок=9
       текст: No, not so far
       эффект: P29(x) = 1
  -> Path122 => Loc41  вер=1 [всегда видна] порядок=3
       текст: No problem - here's the money
       условия: логика {[p6]>=((((75-[p9]) div 7)+1)*5)}
       эффект: P1(Time) = {[p1]+(30 to 45)+(75-[p9])}
       эффект: P9(Truck armour) = {75}
       эффект: P6(Money) = {[p6]-((((75-[p9]) div 7)+1)*5)}
       эффект: P29(x) = {1}

### Loc44 [пустая]
  -> Path49 => Loc22  вер=1 порядок=5
       ответ: Surprisingly enough, but the <clr>moment you lied down on the cot you fell fast asleep <clrEnd>... /  / - Hey you! Get off from there! - you heard somebody's vo…
       условия: логика {[p4]<60000}
       эффект: P1(Time) = {[p1]+180}
       эффект: P4(Tiredness) = {[p4]+[15000..20000]}
  -> Path50 => Loc22  вер=1 порядок=5
       ответ: <clr>You weren't very tired so it was pretty tired to go to sleep...<clrEnd> /  / - Hey you! It off from there! - you heard somebody's voice. - You been sleepin…
       условия: логика {[p4]>60000}
       эффект: P1(Time) = {[p1]+180}
       эффект: P4(Tiredness) = {[p4]+[5000..9000]}

### Loc45 [обычная]
    Loc45-1: Your truck was standing in the middle of a very picturesque location. In the north you saw a large ground gap, green cactuses all around, and a white two-story …
  -> Path127 => Loc149  вер=1 порядок=2
       текст: Go to Mow's Gas Station
       эффект: P26(Where from) = {45}
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = 24
  -> Path145 => Loc149  вер=1 порядок=3
       текст: Go to the Big Gap
       эффект: P26(Where from) = {45}
       эффект: P27(Where to) = {51}
       эффект: P28(Distance) = 20
  -> Path230 => Loc149  вер=1 порядок=1
       текст: Go to the repair shop
       эффект: P26(Where from) = {45}
       эффект: P27(Where to) = {76}
       эффект: P28(Distance) = {64}
  -> Path444 => Loc139  вер=1 порядок=5
       текст: Drive over to the house
       эффект: P1(Time) +1
  -> Path445 => Loc140  вер=1000 порядок=5
       текст: Drive over to the house
       условия: логика {[p25]>0}
       эффект: P1(Time) +1
  -> Path597 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {45}
       эффект: P28(Distance) = 0

### Loc46 [обычная]
    выбор описания: {[p29]}
    Loc46-1: - Looking for something? - the sheriff asked, his hand next to his gun-holster.
    Loc46-2: - The Iroquois? You really think I will start messing with them because of some Rolan? I don't even know who he is. In any case, the Iroquois are always dead se…
    Loc46-3: - Is that so? - said the sheriff and burst out laughing. - Listen here, lad, I bet you are not local in this parts. The Scorpions and the Iroquois have been col…
    Loc46-4: - Why did you say you understood in chemistry in the first place then?! Alright. Let's get out of here, - the sheriff told you.
    эффект: P1(Time) +1
  -> Path130 => Loc47  вер=1 проходов<=1 порядок=5
       текст: I need weapons. You have any?
  -> Path141 => Loc45  вер=1 порядок=9
       текст: Go back to the fortification
       эффект: P1(Time) +1
  -> Path143 => Loc50  вер=1 проходов<=1 порядок=3
       текст: The Iroquois have kidnapped Rolan. Please help me find him...
       эффект: P29(x) = 2
  -> Path144 => Loc50  вер=1 проходов<=1 порядок=4
       текст: Some cut-throats are attacking honest folks on the road. I think you - being a sheriff - should be aware of this...
       эффект: P29(x) = 3
  -> Path448 => Loc141  вер=0.4 проходов<=2 порядок=9
       текст: Go back to the fortification
       ответ: You truck was slowly rolling out onto the freeway, when you heard somebody knock on the window. It was one of the sheriff's assistants: / - I need to go to <clr…
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = {5} [скрыт]
  -> Path451 => Loc141  вер=0.2 проходов<=1 порядок=9
       текст: Go back to the fortification
       ответ: You truck was slowly rolling out onto the freeway, when you heard somebody knock on the window. It was one of the sheriff's assistants: - I got to go to the Dig…
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = {6} [скрыт]

### Loc47 [обычная] визитов<=1
    Loc47-1: - You think I am as stupid as to give a to give a shotgun to a hoodlum like yourself? Just how arrogant you exactly are?! Then again... If you helped us, I migh…
  -> Path131 => Loc46  вер=1 порядок=9
       текст: No
       эффект: P29(x) = 1
  -> Path132 => Loc48  вер=1 порядок=5
       текст: Well... Just a little bit
       эффект: P1(Time) = {[p1]+10}
       эффект: P17(Buffer) = {1 to 4}

### Loc48 [обычная]
    выбор описания: {[p17]}
    Loc48-1: - Excellent! - the sheriff exclaimed and waved you to follow him. /  / You went past the cells and some shabby-looking rooms, trying not to lose sight of the sh…
    Loc48-2: - Excellent! - the sheriff exclaimed and waved you to follow him. /  / You went past the cells and some shabby-looking rooms, trying not to lose sight of the sh…
    Loc48-3: - Excellent! - the sheriff exclaimed and waved you to follow him. /  / You went past the cells and some shabby-looking rooms, trying not to lose sight of the sh…
    Loc48-4: - Excellent! - the sheriff exclaimed and waved you to follow him. /  / You went past the cells and some shabby-looking rooms, trying not to lose sight of the sh…
  -> Path133 => Loc46  вер=1 порядок=9
       текст: Helios-schmelios, who cares! To be honest with you it's all Greek to me, so I'm afraid I can't help you
       эффект: P1(Time) = {[p1]+10}
       эффект: P29(x) = 4
  -> Path134 => Loc49  вер=1 порядок=5
       текст: 2 grams
  -> Path135 => Loc49  вер=1 порядок=3
       текст: 1 gram
  -> Path136 => Loc49  вер=1 порядок=6
       текст: 3,5 grams
  -> Path137 => Loc49  вер=1 порядок=4
       текст: 1,5 grams
  -> Path138 => Loc49  вер=1 порядок=7
       текст: 9 grams
  -> Path139 => Loc49  вер=1 порядок=1
       текст: 0,33 grams
  -> Path142 => Loc129  вер=1000 порядок=4
       текст: 1,5 grams
       условия: логика {[p17]=2}
       эффект: P1(Time) = {[p1]+15}
  -> Path394 => Loc49  вер=1 порядок=2
       текст: 0,66 grams
  -> Path396 => Loc129  вер=1000 порядок=7
       текст: 9 grams
       условия: логика {[p17]=3}
       эффект: P1(Time) = {[p1]+15}
  -> Path397 => Loc129  вер=1000 порядок=2
       текст: 0,66 grams
       условия: логика {[p17]=1}
       эффект: P1(Time) = {[p1]+15}
  -> Path398 => Loc129  вер=1000 порядок=5
       текст: 2 grams
       условия: логика {[p17]=4}
       эффект: P1(Time) = {[p1]+15}

### Loc49 [обычная]
    Loc49-1: The chemist added the amount of Helios you specified, stirred the mixture and poured it in a thin line around the safe-door perimeter. Once in contact with meta…
    эффект: P1(Time) = {[p1]+15}
    эффект: P3(Energy) = {[p3]-(25 to 35)}
  -> Path140 => Loc127  вер=1 порядок=5
       текст: Next
       эффект: P29(x) = 1

### Loc50 [пустая]
  -> Path155 => Loc46  вер=1 порядок=5

### Loc51 [обычная]
    Loc51-1: You standing in the middle of a <clr>large gap<clrEnd>, that looks more like a huge crater left by an enormous bomb. The fork in the road goes in three directio…
  -> Path146 => Loc149  вер=1 порядок=2
       текст: Go to the sheriff
       эффект: P26(Where from) = {51}
       эффект: P27(Where to) = {45}
       эффект: P28(Distance) = {20}
  -> Path148 => Loc149  вер=1 порядок=3
       текст: Go to the dumpsite
       эффект: P26(Where from) = {51}
       эффект: P27(Where to) = {10}
       эффект: P28(Distance) = {40}
  -> Path224 => Loc149  вер=1 порядок=1
       текст: Go to Stilt's gas station
       эффект: P26(Where from) = {51}
       эффект: P27(Where to) = {73}
       эффект: P28(Distance) = {36}
  -> Path598 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {51}
       эффект: P28(Distance) = 0

### Loc54 [обычная]
    Loc54-1: You stopped in the middle of the road. The engine is stubbornly knocking some serious jazz beat under the hood. On both sides of the road you saw piles of empty…
  -> Path159 => Loc149  вер=1 порядок=2
       текст: Go to the dumpsite
       эффект: P26(Where from) = {54}
       эффект: P27(Where to) = {10}
       эффект: P28(Distance) = {36}
  -> Path160 => Loc55  вер=1 порядок=9
       текст: To the bar
  -> Path214 => Loc149  вер=1 порядок=1
       текст: Go to Stilt's gas station
       эффект: P26(Where from) = {54}
       эффект: P27(Where to) = {73}
       эффект: P28(Distance) = {40}
  -> Path426 => Loc134  вер=1000 порядок=9
       текст: To the bar
       условия: логика {[p25]>0}
  -> Path589 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {54}
       эффект: P28(Distance) = 0

### Loc55 [обычная]
    выбор описания: {1+(([p7]>=1000) or ([p8] div 100 mod 10)=1)}
    Loc55-1: The air in the bar was stuffed, awfully and irresistibly stuffed. Plus the cigarette smoke... However the atmosphere was rather jolly. At the bar there stood a …
    Loc55-2: The air in the bar was stuffed, awfully and irresistibly stuffed. Plus the cigarette smoke... However the atmosphere was rather jolly. At the bar there stood a …
    эффект: P1(Time) +1
  -> Path161 => Loc56  вер=1 порядок=5
       текст: Go to the bartender
  -> Path176 => Loc54  вер=1 порядок=9
       текст: Go back to the road
  -> Path203 => Loc69  вер=1 порядок=5
       текст: Approach the company of bikers
       ответ: - Hello! - you said friendly. / - Get lost, scum! - a huge guy with a Scorpion tattoo on his forehead barked. /  / Right... These boys are not that easygoing.
       условия: логика {([p8] mod 10)=0}
  -> Path205 => Loc70  вер=1 порядок=5
       текст: Approach the company of bikers
       условия: логика {([p8] mod 10)=1}
       эффект: P29(x) = 1
  -> Path212 => Loc72  вер=1 порядок=5
       текст: Go to the sleeping Peleng
       условия: логика {([p7]<1000) and (([p8] div 100 mod 10)=0)}
  -> Path406 => Loc130  вер=1 [всегда видна] порядок=5
       текст: Head back to the slot machine
       условия: логика {([p38] div 1000 mod 100)<99}
  -> Path436 => Loc137  вер=0.2 проходов<=1 порядок=9
       текст: Go back to the road
       ответ: A slightly drunken lad clad in a miner's hard hat ran up to your truck: / - Hick... Chief can you give me a lift to the <clr>mines<clrEnd>? - he blurted out gra…
       эффект: P25(Fellow-traveller) = {3} [скрыт]
  -> Path439 => Loc137  вер=0.2 проходов<=1 порядок=9
       текст: Go back to the road
       ответ: The moment you started up the engine some completely drunken guy climbed into the cabin and said: / - Let's get moving, chief. The next stop is <clr>Shpick<clrE…
       эффект: P25(Fellow-traveller) = {4} [скрыт]

### Loc56 [обычная]
    выбор описания: {1+(([p8] mod 10)>0)}
    Loc56-1: - Wanted something? - the bartender asked. /  / Behind his back you noticed a list:  / "<clr>Roast with 'shrooms - 6 platinum pieces<clrEnd>, / <clr>Bed for 6 h…
    Loc56-2: - Wanted something, little scorpion? - the barmen asked with an ear-to-ear grin.  /  / Behind his back you noticed a list:  / "<clr>Roast with 'shrooms - 6 plat…
  -> Path162 => Loc146  вер=1 порядок=9
       текст: Step away from the bar
  -> Path163 => Loc57  вер=1 порядок=1
       текст: I wanted to ask a few questions...
       эффект: P29(x) = 1
  -> Path169 => Loc59  вер=1 [всегда видна] порядок=3
       текст: I am hungry. Can you make me that 'shroom roast of yours...
       ответ: - There you go, - said the bartender and put an iron sheet in front of you with a roast and some mushrooms. No utensils were provided so you had to eat with you…
       условия: логика {([p6]>=6) and ([p5]<100000)}
       эффект: P1(Time) = {[p1]+(7 to 10)}
       эффект: P5(Hunger) = {[p5]+(35000 to 45000)}
       эффект: P6(Money) -6
  -> Path171 => Loc146  вер=1 [всегда видна] порядок=4
       текст: I need rest. You have a bed...
       ответ: - Sure. Hey, kid, show our guest to his room, will you, - the bartender said to a boy in the corner. / The lad led you to the second floor, and opened one of th…
       условия: логика {(([p8] mod 10)=0) and ([p6]>=10)}
       эффект: P1(Time) = {[p1]+(300 to 350)}
       эффект: P3(Energy) = {[p3]+(20 to 25)}
       эффект: P4(Tiredness) = {[p4]+(45000 to 60000)}
       эффект: P5(Hunger) = {[p5]-[p23]*325}
       эффект: P6(Money) = {[p6]-10}
  -> Path172 => Loc146  вер=1 [всегда видна] порядок=4
       текст: I need rest. You have a bed...
       ответ: - Sure. <clr>5<clrEnd> platinum pieces for the Scorpions as usual... Hey, kid, show our guest to his room, will you, - the bartender said to a boy in the corner…
       условия: логика {(([p8] mod 10)>0) and ([p6]>=5)}
       эффект: P1(Time) = {[p1]+(300 to 350)}
       эффект: P3(Energy) = {[p3]+(20 to 25)}
       эффект: P4(Tiredness) = {[p4]+(45000 to 60000)}
       эффект: P5(Hunger) = {[p5]-[p23]*325}
       эффект: P6(Money) = {[p6]-5}
  -> Path174 => Loc60  вер=1 порядок=2
       текст: What drinks do you have?
       эффект: P29(x) = 1

### Loc57 [обычная]
    выбор описания: {[p29]}
    Loc57-1: - So what did you want to ask me?
    Loc57-2: - Right, lad, what's that kind of a question! It's a bar, a pub, or whatever you want to call it. It's a Scorpion place.
    Loc57-3: - We?! We sell booze, roasted meat. That's it. And if you wanted to sell anything to us, we do not buy.
    Loc57-4: - Oh, that's Yoizolly. He drank all his money away, and now he cannot go back to Shpick. But he's a good lad. Very rare for a Peleng kin!
    Loc57-5: - These are the Scorpions. Don't you see yourself?
    Loc57-6: - Rrrrright, lad! You don't wanna know...
    Loc57-7: - Ha-ha-ha!!! Any place but here...
  -> Path164 => Loc56  вер=1 порядок=9
       текст: No more questions
  -> Path165 => Loc58  вер=1 проходов<=1 порядок=1
       текст: What is this place?
       эффект: P29(x) = 2
  -> Path166 => Loc58  вер=1 проходов<=1 порядок=6
       текст: Where can I find the Iroquois?
       эффект: P29(x) = 7
  -> Path167 => Loc58  вер=1 проходов<=1 порядок=3
       текст: Are you trading?
       эффект: P29(x) = 3
  -> Path168 => Loc58  вер=1 проходов<=1 порядок=8
       текст: What is this meat you are serving?
       эффект: P29(x) = 6
  -> Path283 => Loc58  вер=1 проходов<=1 порядок=7
       текст: Who is this guy sleeping on the table in the corner?
       условия: логика {(([p7]<1000) and ([p8] div 100 mod 10)=0)}
       эффект: P29(x) = 4
  -> Path404 => Loc58  вер=1 проходов<=1 порядок=5
       текст: What's up with that company at the bar?
       эффект: P29(x) = 5

### Loc58 [пустая]
    эффект: P1(Time) +1
  -> Path405 => Loc57  вер=1 порядок=5

### Loc59 [пустая]
  -> Path173 => Loc56  вер=1 порядок=5

### Loc60 [обычная]
    выбор описания: {[p29]}
    Loc60-1: - Booze we have: / shot of port wine - 3 platinum pieces, / glass of Rartan kinza (non-alcohol) - 4 platinum pieces. / What will it be?
    Loc60-2: The bartender filled your glass with some claret liquid. It tasted quite good and apparently had a toning effect to it. Killing the drink you put the glass back…
    Loc60-3: - No, lad, you look like you've had enough, - the bartender said. Looks like it's no more port wine for you. Maybe he thinks you are underage? Nah. Must have so…
    Loc60-4: The bartender poured you a shot of amber-coloured liquid. You killed the shot in one swing, it felt like a fire bolt shot through your stomach. You felt warmth …
  -> Path175 => Loc56  вер=1 порядок=9
       текст: No I don't want any drinks, thanks
  -> Path177 => Loc61  вер=1 порядок=5
       текст: I want to order a round for everyone!
  -> Path179 => Loc62  вер=1 [всегда видна] порядок=4
       текст: Take the kinza (4 platinum pieces)
       условия: логика {[p6]>=4}
       эффект: P1(Time) +1
       эффект: P4(Tiredness) = {[p4]+(1000 to 2000)}
       эффект: P5(Hunger) = {[p5]+(2000 to 4000)}
       эффект: P6(Money) -4
       эффект: P29(x) = 2
  -> Path180 => Loc62  вер=1 [всегда видна] порядок=2
       текст: Have a shot of port wine (3 platinum pieces)
       условия: логика {[p6]>=3}
       эффект: P1(Time) +1
       эффект: P4(Tiredness) = {[p4]-(10000 to 12000)}
       эффект: P6(Money) -3
       эффект: P29(x) = 4
  -> Path181 => Loc62  вер=1 [всегда видна] порядок=2
       текст: Have a shot of port wine (3 platinum pieces)
       условия: логика {([p6]>=3) and ([p4]<=30000)}
       эффект: P29(x) = 3

### Loc61 [обычная]
    Loc61-1: - The king of roads wants to celebrate some lucky trip or is it just a gesture of good will? In any event, <clr>it is going to cost you 50 platinum pieces<clrEn…
  -> Path178 => Loc56  вер=1 порядок=9
       текст: No, I think I'll skip on that
  -> Path199 => Loc67  вер=1000 [всегда видна] проходов<=1 порядок=5
       текст: Alright, I'm buying for everyone!
       условия: логика {[p6]>=50}
       эффект: P6(Money) = {[p6]-50}
  -> Path201 => Loc146  вер=1 [всегда видна] порядок=5
       текст: Alright, I'm buying for everyone!
       ответ: - We are not drinking port wine, ordered by losers! - the Scorpions standing at the bar said. / - But I do! - said a toothless geezer, who appeared from out of …
       условия: логика {([p6]>=50) and (([p8] mod 10)=0)}
       эффект: P1(Time) +1
       эффект: P6(Money) = {[p6]-50}
  -> Path202 => Loc146  вер=1 [всегда видна] порядок=5
       текст: Alright, I'm buying for everyone!
       ответ: - Our newbie, <Ranger>, is throwing a party! - one of Scorpions yelled, his voice joined by loud cheering, and then it was a total mayhem. You know as it always…
       условия: логика {([p6]>=50) and (([p8] mod 10)=1)}
       эффект: P1(Time) = {[p1]+(120 to 150)}
       эффект: P4(Tiredness) = {(25000 to 35000)}
       эффект: P6(Money) = {[p6]-50}

### Loc62 [пустая]
  -> Path182 => Loc60  вер=1 порядок=5

### Loc63 [обычная]
    Loc63-1: You are standing in front of a drunken biker. And apparently he is not that friendly. If you feel strong enough, punching his arrogant biker face would be quite…
  -> Path185 => Loc64  вер=1 порядок=5
       текст: Hit the biker on the head
       ответ: Luckily enough you were in good shape, and punched your opponent right in the face. Good jab!
       условия: логика {[p4]>30000}
       эффект: P4(Tiredness) = {[p4]-(6000 to 10000)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(40 to 55)}
  -> Path186 => Loc64  вер=1 [всегда видна] порядок=5
       текст: Hit the biker on the head
       ответ: You tried to hit your opponent, but by this time your body was not quite under your command anymore. Your hand flew right past his ear, and you fell forward ont…
       условия: логика {[p4]>5000}
       эффект: P3(Energy) = {[p3]-(5 to 10)}
       эффект: P4(Tiredness) = {[p4]-(3000 to 5000)}
  -> Path187 => Loc64  вер=1 [всегда видна] порядок=5
       текст: Punch him in the gut
       ответ: You punched the biker right in the stomach. Maybe not as efficient as a head-knock, but then again, it's harder to miss that one.
       условия: логика {[p4]>5000}
       эффект: P4(Tiredness) = {[p4]-(2000 to 3500)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(20 to 30)}
  -> Path188 => Loc64  вер=1 порядок=5
       текст: Do nothing
  -> Path196 => Loc54  вер=1 порядок=5
       текст: Hey, guys, come on! No kidding. I don't want to fight anymore!
       ответ: - Loser, - your opponent shook his head and spat right on your clothes. The rest of the crowd did the same... /  / Having rubbed the spit off your glorious rang…
       эффект: P1(Time) = {[p1]+(5 to 10)}
       скрыт: P18

### Loc64 [пустая]
    эффект: P1(Time) -1
    эффект: P4(Tiredness) = {[p4]+([p4]<40000)*(1000 to 2500)} [показ]
  -> Path189 => Loc147  вер=1000 порядок=5
       ответ: Tired you sank down onto the dusty surface of the planet.  / "Loser", - you heard somebody's voice. /  / When you came to, you shook the dust off yourself and d…
       условия: логика {[p4]<=5000}
       эффект: P1(Time) = {[p1]+30}
       эффект: P4(Tiredness) = {[p4]+6000}
       скрыт: P18
  -> Path190 => Loc65  вер=1 порядок=5
       ответ: The Biker knocked you right on the head sending a fan of sparks out of your eyes. The crowd cheered loudly and whistled.
       условия: логика {[p18]>50}
       эффект: P3(Energy) = {[p3]-(20 to 30)}
  -> Path191 => Loc65  вер=1 порядок=5
       ответ: The biker punched you a couple of times in the gut. For a moment you couldn't catch your breath back. An evil snarl appeared on the face of your opponent, but h…
       эффект: P3(Energy) = {[p3]-(15 to 20)}
  -> Path192 => Loc65  вер=1 порядок=5
       ответ: Your opponent didn't do anything waiting for you to make the first move.
       условия: логика {[p18]<=50}
  -> Path195 => Loc147  вер=1000 порядок=5
       ответ: - Alright, alright, there's a good lad, - said the biker raising his hands. /  The spectators rushed forward to you and started rocking you up in the air. Sudde…
       условия: логика {[p18]<(1 to 5)}
       эффект: P1(Time) = {[p1]+(45 to 60)}
       эффект: P4(Tiredness) = {[p4]+(5000 to 7000)}
       эффект: P8(Tattoo, deposit, Peleng) +1
       скрыт: P18

### Loc65 [пустая]
  -> Path193 => Loc63  вер=1 порядок=5

### Loc67 [пустая] визитов<=1
  -> Path197 => Loc63  вер=1 порядок=5
       ответ: The bartender put a case of port wine bottle on the bar. /  / - Say! The brave driver is buying! - one of the tatted guys yelled. /  / The rest of it was a blur…
       условия: логика {[p4]>60000}
       эффект: P1(Time) = {[p1]+(90 to 110)}
       эффект: P4(Tiredness) = {[p4]-(40000 to 50000)}
       эффект: P18(Psychological state of the enemy) = {100} [показ]
  -> Path198 => Loc68  вер=1 порядок=5
       ответ: The bartender put a case of port wine bottle on the bar.  / - Say! The brave driver is buying! - one of the tatted guys yelled. /  / The rest of it was a blur. …
       условия: логика {[p4]<=60000}
       эффект: P1(Time) = {[p1]+(120 to 150)}
       эффект: P4(Tiredness) = {(15000 to 25000)}

### Loc68 [пустая]
  -> Path200 => Loc54  вер=1 порядок=5

### Loc69 [пустая]
  -> Path204 => Loc147  вер=1 порядок=5

### Loc70 [обычная]
    выбор описания: {[p29]}
    Loc70-1: - <Ranger>, our young scorpion. What is it? - a biker with "Croc" tattooed across his chin asked. It was him you had a brawl with the other day.
    Loc70-2: - We are just back from a business trip. Got us some cash. So we gonna spend the next week or two here. So I say hang in here with us for a while. Have some por…
    Loc70-3: Croc even choked on his swill: /  - Are you outta ya mind? These guys will slice your head off and wipe out the entire Scorpion gang too? No, no, no, there's no…
    Loc70-4: - Each Scorpion makes himself a crossbow and keeps it forever. A Scorpion who has sold his crossbow is a dropout who must be killed on sight... And we despise a…
  -> Path206 => Loc71  вер=1 проходов<=1 порядок=3
       текст: Let's go have some fun. Scare them geezers. Pad'em all!!!
       эффект: P29(x) = 2
  -> Path207 => Loc71  вер=1 проходов<=1 порядок=4
       текст: Let's go kill some Iroquois!
       эффект: P29(x) = 3
  -> Path208 => Loc71  вер=1 проходов<=1 порядок=2
       текст: Do you have any serious weapons? I'd buy some from you...
       эффект: P29(x) = 4
  -> Path210 => Loc147  вер=1 порядок=5
       текст: Just chat
       ответ: For the next ten minutes you and the bikers were talking engines, crossbows, and drinking. Nothing interesting. Finally you had enough of it and decided to take…
       эффект: P1(Time) = {[p1]+10}
  -> Path211 => Loc147  вер=1 порядок=9
       текст: Leave the noisy company

### Loc71 [пустая]
  -> Path209 => Loc70  вер=1 порядок=5

### Loc72 [обычная]
    Loc72-1: - Er? Wha'? - the Peleng looked startled. - Say. I see you look like a driver. Can you give me a lift to Shpick. I'd be much obliged! Fear not. I am going throu…
  -> Path213 => Loc146  вер=1 порядок=9
       текст: Sorry I am a bit busy now
  -> Path282 => Loc146  вер=1 порядок=5
       текст: Sure, no sweat!
       ответ: - Thanks, bro. Don't be afraid. Once I'm in the cabin I'll fall asleep straight away and you won't even notice me. /  / You led the Peleng to the truck and lock…
       эффект: P1(Time) +4
       эффект: P8(Tattoo, deposit, Peleng) = {[p8]+100}

### Loc73 [обычная]
    Loc73-1: Your truck stopped at a crossroads. The asphalt here was especially cracked, but you cared little about it. In the distance you spotted an old <clr>gas station<…
  -> Path215 => Loc149  вер=1 порядок=4
       текст: Go to the "Scorpion Nest"
       эффект: P26(Where from) = {73}
       эффект: P27(Where to) = {54}
       эффект: P28(Distance) = {40}
  -> Path216 => Loc74  вер=1 порядок=9
       текст: Turn to the gas station
       эффект: P1(Time) +1
       эффект: P29(x) = 1
  -> Path223 => Loc149  вер=1 порядок=3
       текст: Go to the Big Gap
       эффект: P26(Where from) = {73}
       эффект: P27(Where to) = {51}
       эффект: P28(Distance) = {36}
  -> Path225 => Loc149  вер=1 порядок=2
       текст: Go to the repair shop
       эффект: P26(Where from) = {73}
       эффект: P27(Where to) = {76}
       эффект: P28(Distance) = {60}
  -> Path344 => Loc108  вер=1 порядок=1
       текст: Go to the rubidium mines
       эффект: P1(Time) = {[p1]+((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((36*60)/([p12]+([p13]*[p12])/50))}
  -> Path599 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {73}
       эффект: P28(Distance) = 0

### Loc74 [обычная]
    выбор описания: {[p29]}
    Loc74-1: You went down the access road and stopped right at the entrance to the building. A small man with an assault rifle hanging over his shoulder appeared from the i…
    Loc74-2: You bought <clr>5 litres<clrEnd> of gasoline. /  / - You are at Stilt's Gas Station. We charge <clr> 7 platinum pieces for 5 litres of gas<clrEnd>. Need more?
    Loc74-3: - Yeah, we sure got'em, - the guy chuckled. - But if you are asking for yourself, I suggest you look some place else. Everybody wants a piece in these parts.
    Loc74-4: - Our gas station is stranding on an oil field. We pump the oil out of the well, and then make gasoline out of it right here. Everybody knows that. But if they …
    Loc74-5: - No we do not mend cars here. Better go south-east. There's Screw's shop he is the best car mechanic in these parts. He'll fix your darling here in a flick of …
    Loc74-6: - Old Stoltz does not run about with the hose himself. He is busy with issues of a more global nature. That's it.
    Loc74-7: You bought yourself <clr>15 litres<clrEnd> of gas. /  /  - You are at Stilt's Gas Station. We charge <clr> 7 platinum pieces for 5 litres of gas<clrEnd>. Need m…
  -> Path217 => Loc75  вер=1 проходов<=1 порядок=6
       текст: Where do you get gasoline from?
       эффект: P29(x) = 4
  -> Path218 => Loc75  вер=1 проходов<=1 порядок=5
       текст: Have you any weapons?
       эффект: P29(x) = 3
  -> Path219 => Loc75  вер=1 проходов<=1 порядок=3
       текст: I need to repair my flivver. Can you help?
       эффект: P29(x) = 5
  -> Path220 => Loc75  вер=1 [всегда видна]
       текст: Get me five litres
       условия: P11(Fuel tank) 1..99999; логика {([p11]<100000) and ([p6]>=7)}
       эффект: P11(Fuel tank) = {[p11]+5000}
       эффект: P6(Money) = {[p6]-7}
       эффект: P29(x) = 2
  -> Path222 => Loc73  вер=1 порядок=9
       текст: Leave the gas station
       эффект: P1(Time) +1
  -> Path227 => Loc75  вер=1 проходов<=1 порядок=7
       текст: If this is Stilt's Gas Station, where's Stoltz?
       эффект: P29(x) = 6
  -> Path585 => Loc75  вер=1 [всегда видна] порядок=1
       текст: Give me 15 litres
       условия: P11(Fuel tank) 1..99999; логика {([p11]<100000) and ([p6]>=21)}
       эффект: P11(Fuel tank) = {[p11]+15000}
       эффект: P6(Money) = {[p6]-21}
       эффект: P29(x) = 7

### Loc75 [пустая]
    эффект: P1(Time) +1
  -> Path228 => Loc74  вер=1 порядок=5

### Loc76 [обычная]
    Loc76-1: A very strange place. All kinds of car junk scattered all over the place. In the distance there stands a wooden cabin with a garage. Looks like this is the <clr…
  -> Path226 => Loc149  вер=1 порядок=4
       текст: Go to Stilt's gas station
       эффект: P26(Where from) = {76}
       эффект: P27(Where to) = {73}
       эффект: P28(Distance) = {60}
  -> Path229 => Loc149  вер=1 порядок=3
       текст: Go to the sheriff
       эффект: P26(Where from) = {76}
       эффект: P27(Where to) = {45}
       эффект: P28(Distance) = {64}
  -> Path231 => Loc77  вер=1 порядок=9
       текст: Turn to the house
       эффект: P1(Time) +1
       эффект: P29(x) = 1
  -> Path243 => Loc149  вер=1 порядок=2
       текст: Go to Shpick
       эффект: P26(Where from) = {76}
       эффект: P27(Where to) = {81}
       эффект: P28(Distance) = {24}
  -> Path346 => Loc149  вер=1 порядок=1
       текст: Go to the farm
       эффект: P26(Where from) = {76}
       эффект: P27(Where to) = {109}
       эффект: P28(Distance) = {36}
  -> Path447 => Loc77  вер=1000 порядок=9
       текст: Turn to the house
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: логика {[p25]>0}
       эффект: P1(Time) +1
       эффект: P25(Fellow-traveller) = {0}
       эффект: P29(x) = 1
  -> Path600 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {76}
       эффект: P28(Distance) = 0

### Loc77 [обычная]
    выбор описания: {[p29]}
    Loc77-1: You truck is parked out in front of a garage, in which there stands another - passenger vehicle. In front of the hood of your truck stands a man who has just co…
    Loc77-2: You paid the price you agreed upon. The screw drove the truck into the garage, lifted it on a crane and started working.  /  / He indeed was a brilliant mechani…
    Loc77-3: Using a magnet loader the Screw easily picked up 5 tons of scrap metal from your truck, piled it up nearby and got down to work. The mechanic took metal rods an…
    Loc77-4: Having took the money from you, the Screw headed back to the garage. You heard some noise, scrapping and hissing come from the inside. What on earth is he doing…
    Loc77-5: - Why? I am a car mechanic and I like what I do. If I need something I go to Shpick or visit the Cromalione brothers.
    Loc77-6: - No, I am not going to mess about with the Iroquois, sorry.
  -> Path232 => Loc78  вер=1 [всегда видна] порядок=2
       текст: I need to get my truck fixed...
       условия: логика {[p9]<100}
  -> Path235 => Loc76  вер=1 порядок=9
       текст: I need to go
       эффект: P1(Time) +1
  -> Path236 => Loc80  вер=1 порядок=3
       текст: I see you are truly an enthusiast of your own trade. Can you upgrade my truck somehow?
  -> Path240 => Loc79  вер=1 проходов<=1 порядок=5
       текст: Are you selling anything? Or maybe you're interested in buying something?
       эффект: P29(x) = 5
  -> Path241 => Loc79  вер=1 проходов<=1 порядок=4
       текст: The Iroquois have kidnapped this guy called Rolan. Can you help me save him?
       эффект: P29(x) = 6

### Loc78 [обычная]
    Loc78-1: The Screw quickly examined the truck and said: / - Listen here. To repair this baby it is going to cost you {(( ((100-[p9]) div 6)+1 )*5)} platinum pieces. I me…
    эффект: P1(Time) +5
  -> Path233 => Loc77  вер=1 порядок=9
       текст: No I can't afford it, I'm afraid...
       эффект: P29(x) = 1
  -> Path234 => Loc77  вер=1 [всегда видна] порядок=5
       текст: Alright, start working
       условия: логика {[p6]>=((((100-[p9]) div 6)+1)*5)}
       эффект: P1(Time) = {[p1]+(20 to 35)+(100-[p9])}
       эффект: P9(Truck armour) = {100}
       эффект: P6(Money) = {[p6]-((((100-[p9]) div 6)+1)*5)}
       эффект: P29(x) = 2

### Loc79 [пустая]
  -> Path242 => Loc77  вер=1 порядок=5

### Loc80 [обычная]
    выбор описания: {1+(([p38] mod 10)=1)+2*(([p38] div 10 mod 10)=1)}
    Loc80-1: The Screw walked around you truck, examined it carefully and said: / - Alright. I can make two steel holds and weld them onto the truck's body. This will increa…
    Loc80-2: The Screw walked around you truck, examined it carefully and said: / - Alright. I could make <clr>spikes<clrEnd> for your wheels instead of disks. / For those I…
    Loc80-3: The Screw walked around you truck, examined it carefully and said: / - Alright. I can make two steel holds and weld them onto the truck's body. This will increa…
    Loc80-4: The Screw went around the car, examined everything carefully and said:  / - Man, your truck is pretty good as it is. I don't think there's anything I can do for…
    эффект: P1(Time) = {[p1]+2}
  -> Path237 => Loc77  вер=1 порядок=9
       текст: I see. Let's discuss some other issues
       эффект: P29(x) = 1
  -> Path238 => Loc77  вер=1 [всегда видна] порядок=2
       текст: I have 5 tons of scrap metal on me right now. Take it and get down to business
       условия: логика {(([p38] div 10 mod 10)=0) and ([p16]>=5)}
       эффект: P1(Time) = {[p1]+(120 to 180)}
       эффект: P10(Spikes) = 1
       эффект: P13(Hold (free space)) = {[p13]+5}
       эффект: P16(Scrap metal) = {[p16]-5}
       эффект: P29(x) = 3
       эффект: P38(Truck upgrades + swap trucks + automate use qty.) = {[p38]+10}
  -> Path239 => Loc77  вер=1 [всегда видна] порядок=1
       текст: Deal. I'm paying and you increase my truck's carrying capacity
       условия: логика {(([p38] mod 10)=0) and ([p6]>=50)}
       эффект: P1(Time) = {[p1]+(90 to 150)}
       эффект: P6(Money) = {[p6]-50}
       эффект: P13(Hold (free space)) = {[p13]+2}
       эффект: P29(x) = 4
       эффект: P38(Truck upgrades + swap trucks + automate use qty.) = {[p38]+1}

### Loc81 [обычная]
    Loc81-1: You are standing at the outskirts of a rather large town (by local standards), surrounded with a fence. There's a good asphalt road leading from the freeway to …
  -> Path244 => Loc149  вер=1 порядок=1
       текст: Go to the repair shop
       эффект: P26(Where from) = {81}
       эффект: P27(Where to) = {76}
       эффект: P28(Distance) = {24}
  -> Path245 => Loc82  вер=1 порядок=9
       текст: To the city
       эффект: P1(Time) +2
  -> Path285 => Loc82  вер=1000 порядок=9
       текст: To the city
       ответ: Stopping in the middle of the square you tried to wake the Peleng up. As if it was that easy! You had to shake him for a good five minutes, until he finally ope…
       условия: логика {([p8] div 100 mod 10)=1}
       эффект: P1(Time) +5
       эффект: P7(Weapons) = {[p7]+1006}
       эффект: P8(Tattoo, deposit, Peleng) = {[p8]-100}
  -> Path290 => Loc149  вер=1 порядок=2
       текст: Go to Mow's Gas Station
       эффект: P17(Buffer) = {2}
       эффект: P26(Where from) = {81}
       эффект: P27(Where to) = {93}
       эффект: P28(Distance) = {52}
  -> Path429 => Loc135  вер=1.00011e+06 порядок=9
       текст: To the city
       условия: логика {[p25]>0}
       эффект: P1(Time) +2
  -> Path596 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {81}
       эффект: P28(Distance) = 0

### Loc82 [обычная]
    Loc82-1: You are standing at a large but dirty square. In fact nearly all of the buildings in this town are dirty and shabby. Only four of them look like they are worth …
  -> Path246 => Loc84  вер=1 порядок=1
       текст: Go to the plant's checkpoint
       эффект: P1(Time) +3
       эффект: P29(x) = 1
  -> Path254 => Loc87  вер=1 проходов<=1 порядок=5
       текст: Enter the building with a flag
       ответ: You opened a massive wooden door and went inside of the white house. To the left of the door there stood a solid table. A girl was sitting at the table and typi…
       эффект: P1(Time) = {[p1]+4}
  -> Path255 => Loc87  вер=1 порядок=7
       текст: Walk about the town looking for other places of interest
       ответ: You walked about the town for some time but found nothing aside from shabby old residential buildings. Looks like all the necessary stuff is located in the main…
       эффект: P1(Time) = {[p1]+(50 to 70)}
       эффект: P5(Hunger) = {[p5]-[p23]*60}
  -> Path256 => Loc87  вер=1 порядок=7
       текст: Walk about the town looking for other places of interest
       ответ: You walked about the town for some time but found nothing aside from shabby old residential buildings. Looks like all the necessary stuff is located in the main…
       условия: логика {[p6]>0}
       эффект: P1(Time) = {[p1]+(50 to 70)}
       эффект: P5(Hunger) = {[p5]-[p23]*60}
       эффект: P6(Money) = {[p6]-(4 to 7)}
  -> Path257 => Loc87  вер=1 порядок=7
       текст: Walk about the town looking for other places of interest
       ответ: You walked about the town for some time but found nothing aside from shabby old residential buildings. Looks like all the necessary stuff is located in the main…
       условия: логика {(([p1] mod (24*60) div 60)>22) or (([p1] mod (24*60) div 60)<6)}
       эффект: P1(Time) = {[p1]+(50 to 70)}
       эффект: P5(Hunger) = {[p5]-[p23]*60}
       эффект: P6(Money) = {[p6]-(4 to 7)}
  -> Path260 => Loc88  вер=2 порядок=7
       текст: Walk about the town looking for other places of interest
       эффект: P1(Time) = {[p1]+(40 to 50)}
       эффект: P5(Hunger) = {[p5]-[p23]*45}
  -> Path263 => Loc81  вер=1 порядок=9
       текст: Leave the town
       эффект: P1(Time) +2
  -> Path264 => Loc89  вер=1e+06 порядок=5
       текст: Go to the restaurant
       условия: логика {(([p1] mod (24*60) div 60)<9)}
       эффект: P1(Time) +1
       эффект: P29(x) = {1+([p5]=100000)}
  -> Path266 => Loc90  вер=1000 проходов<=1 порядок=5
       текст: Go to the restaurant
       ответ: You took the door handle and noticed a plate that read: / "<clr>Open<clrEnd>. / Restaurant open daily: / from 9:00 and to the last client after 23:59" /  / Taki…
       эффект: P1(Time) +1
       эффект: P29(x) = {1+([p5]=100000)}
  -> Path274 => Loc90  вер=1 порядок=5
       текст: Go to the restaurant
       эффект: P1(Time) +1
       эффект: P29(x) = {1+([p5]=100000)}
  -> Path277 => Loc92  вер=1 порядок=4
       текст: Go to the hotel
  -> Path389 => Loc87  вер=1 порядок=8
       текст: Sleep in the car
       ответ: Cleaning yourself some space from all kinds of junk, you made yourself a bed in the backseat. And although your sleep wasn't that long - folks coming back forth…
       эффект: P1(Time) = {[p1]+(180 to 240)}
       эффект: P4(Tiredness) = {[p4]+([p4]<=70000)*(15000 to 20000)}
       эффект: P5(Hunger) = {[p5]-[p23]*210}
  -> Path402 => Loc87  вер=1 порядок=8
       текст: Sleep in the car
       ответ: Cleaning yourself some space from all kinds of junk, you made yourself a bed in the backseat. When suddenly the spell of your dream was broke with some strange …
       условия: логика {(([p1] mod (24*60) div 60)<6)}
       эффект: P1(Time) = {[p1]+(120 to 150)}
       эффект: P4(Tiredness) = {[p4]+([p4]<=60000)*(7500 to 10000)}
       эффект: P5(Hunger) = {[p5]-[p23]*145}
       эффект: P9(Truck armour) = {[p9]-(15 to 25)}
  -> Path456 => Loc143  вер=0.1 проходов<=1 порядок=9
       текст: Leave the town
       ответ: You were just about to go off, when a man in business suit ran over to the truck: / - Excuse me. I need to see the <clr>sheriff<clrEnd>, to settle certain red t…
       эффект: P1(Time) +2
       эффект: P25(Fellow-traveller) = {7} [скрыт]
  -> Path459 => Loc143  вер=0.4 проходов<=1 порядок=9
       текст: Leave the town
       ответ: You were just about to go off, when this lad ran over up to your truck: / - Chief! Are you heading for the <clr>mines<clrEnd> by any chance? I hear one could ea…
       эффект: P1(Time) +2
       эффект: P25(Fellow-traveller) = {8} [скрыт]
  -> Path491 => Loc155  вер=1 порядок=3
       текст: Direct your steps to the medical station
       эффект: P1(Time) +1
       эффект: P29(x) = {1}

### Loc84 [обычная]
    выбор описания: {[p29]}
    Loc84-1: A dirty guy handing out of the booth window is looking at you intensely: / - As usual, we are not selling anything, but we sure do buy stuff. The prices are the…
    Loc84-2: - Right now we are mainly producing metal rolls. But already in a month we will be switching to other products, and in six months we will probably be making car…
  -> Path247 => Loc144  вер=1 порядок=9
       текст: Back to the square
       эффект: P1(Time) +3
  -> Path250 => Loc85  вер=1 [всегда видна] порядок=5
       текст: Sell all the scrap metal
       условия: логика {[p16]>0}
       эффект: P6(Money) = {[p6]+23*[p16]}
       эффект: P13(Hold (free space)) = {[p13]+[p16]}
       эффект: P16(Scrap metal) = {0}
  -> Path251 => Loc85  вер=1 [всегда видна] порядок=5
       текст: Sell all the coal
       условия: логика {[p15]>0}
       эффект: P6(Money) = {[p6]+12*[p15]}
       эффект: P13(Hold (free space)) = {[p13]+[p15]}
       эффект: P15(Coal) = {0}
  -> Path252 => Loc86  вер=1 проходов<=1 порядок=5
       текст: Ask what the plant is producing
       эффект: P29(x) = 2

### Loc85 [пустая]
    эффект: P29(x) = 1
  -> Path305 => Loc84  вер=1 порядок=5

### Loc86 [пустая] визитов<=1
  -> Path253 => Loc84  вер=1 проходов<=1 порядок=5

### Loc87 [пустая]
  -> Path403 => Loc82  вер=1 порядок=5

### Loc88 [обычная]
    Loc88-1: You have been roaming about the streets for quite some time now but found nothing aside from the old residential buildings. Looks like all of the interesting st…
  -> Path261 => Loc144  вер=1 порядок=5
       текст: Go back to the square
  -> Path262 => Loc82  вер=1 [всегда видна] порядок=5
       текст: Throw a couple of platinum pieces to the old man
       ответ: - Thanks, son, - the beggar said. - I see you are a traveller. Let me give you this advice. If you go down the road from here to Mow's Gas Station you will see …
       условия: логика {[p6]>=2}
       эффект: P1(Time) = {[p1]+(12 to 22)}
       эффект: P6(Money) = {[p6]-2}

### Loc89 [обычная]
    Loc89-1: The plate on the door reads: / "<clr>Closed<clrEnd>. / Restaurant open daily  / from 9:00 and to the last client after 23:00"
  -> Path275 => Loc82  вер=1 порядок=9
       текст: Go back to the square
  -> Path276 => Loc90  вер=1 порядок=5
       текст: Wait for the restaurant to open
       ответ: You stood there waiting for the restaurant to open. Finally it happened! At about 9:00 the restaurant opened, you went inside and sat at one of the tables. Look…
       эффект: P1(Time) = {[p1]+((9*60)-([p1] mod (24*60)))}
       эффект: P5(Hunger) = {[p5]-[p23]*((9*60)-([p1] mod (24*60)))}
       эффект: P29(x) = {1+([p5]=100000)}

### Loc90 [обычная]
    выбор описания: {[p29]}
    Loc90-1: - Anything to order, sir? - a waiter clad in a clean suit asked you, handing over the menu. / You quickly ran through the list, making a mental note of what you…
    Loc90-2: - Anything to order, sir? - a waiter clad in a clean suit asked you, handing over the menu. / You were <clr>stuffed to the brim<clrEnd>, and could only take som…
    Loc90-3: You stubbornly chewed on your meal, but still failed to understand what was so special about it. Looks like this junk is only good for the locals. Not able to f…
    Loc90-4: You quickly ate the potatoes. Not as good as the ones you tried back on Earth, but not half that bad either. Too bad their portions are small, though...
    Loc90-5: The dish turned out to be surprisingly tasty. Especially the back legs. Yummy!
    Loc90-6: The beaver turned out to be not that good and somehow had a slight taste of gasoline to it. However there was one additional bonus about this dish - it was plen…
    Loc90-7: They brought you a glass of wine. Silly you, you were expecting a whole bottle! Still you did not argue and tried a small sip. Not bad. You kind of expected the…
  -> Path267 => Loc91  вер=1 [всегда видна] порядок=4
       текст: Lizard with greens - 10 platinum pieces
       условия: логика {([p5]<100000) and ([p6]>=10)}
       эффект: P1(Time) = {[p1]+(7 to 10)}
       эффект: P5(Hunger) = {[p5]+(25000 to 30000)}
       эффект: P6(Money) = {[p6]-10}
       эффект: P29(x) = 5
  -> Path268 => Loc91  вер=1 [всегда видна] порядок=2
       текст: French fries - 7 platinum pieces
       условия: логика {([p5]<100000) and ([p6]>=7)}
       эффект: P1(Time) = {[p1]+(7 to 10)}
       эффект: P5(Hunger) = {[p5]+(15000 to 20000)}
       эффект: P6(Money) = {[p6]-7}
       эффект: P29(x) = 4
  -> Path269 => Loc91  вер=1 [всегда видна] порядок=5
       текст: Beaver in pears - 20 platinum pieces
       условия: логика {([p5]<100000) and ([p6]>=20)}
       эффект: P1(Time) = {[p1]+(10 to 15)}
       эффект: P5(Hunger) = {[p5]+(60000 to 70000)}
       эффект: P6(Money) = {[p6]-20}
       эффект: P29(x) = 6
  -> Path270 => Loc91  вер=1 [всегда видна] порядок=7
       текст: Chef's special: cactuses in kinza sauce - 23 platinum pieces
       условия: логика {([p5]<100000) and ([p6]>=23)}
       эффект: P1(Time) = {[p1]+(7 to 10)}
       эффект: P4(Tiredness) = {[p4]+(15000 to 20000)}
       эффект: P5(Hunger) = {[p5]+(10000 to 15000)}
       эффект: P6(Money) = {[p6]-23}
       эффект: P29(x) = {3}
  -> Path271 => Loc91  вер=1 [всегда видна] порядок=3
       текст: Chateau-Chpique wine - 9 platinum pieces
       условия: логика {([p6]>=9)}
       эффект: P1(Time) = {[p1]+(3 to 5)}
       эффект: P5(Hunger) = {[p5]+(5000 to 7000)}
       эффект: P6(Money) = {[p6]-9}
       эффект: P29(x) = 7
  -> Path273 => Loc82  вер=1 порядок=9
       текст: Thanks for your hospitality. I think I'll go now
       эффект: P1(Time) +1

### Loc91 [пустая]
  -> Path272 => Loc90  вер=1 порядок=5

### Loc92 [обычная]
    Loc92-1: Inside of the inn it was quite clean.  / - Want to have some rest, cowboy? - a woman with a plastered face asked you at the reception desk. - 8 hours in a singl…
  -> Path278 => Loc82  вер=1 порядок=9
       текст: Thank you I don't want anything
  -> Path280 => Loc144  вер=1 [всегда видна] порядок=1
       текст: Just the bed. No girls
       ответ: The room turned out to be quite cosy. And there wasn't anyone else there, so you really had yourself a good rest. Some time later you went back into the square.
       условия: логика {([p6]>=20) and ([p4]<100000)}
       эффект: P1(Time) = {[p1]+(420 to 480)}
       эффект: P3(Energy) = {[p3]+(15 to 20)}
       эффект: P4(Tiredness) = {[p4]+(70000 to 80000)}
       эффект: P5(Hunger) = {[p5]-[p23]*450}
       эффект: P6(Money) = {[p6]-20}
  -> Path281 => Loc144  вер=1 [всегда видна] порядок=2
       текст: Girls sound like a good idea. So yes, please, full service
       ответ: The woman at the reception desk found you a proper girl and sent her to your room. /  / Everything went great. Even the plaster fell off the ceiling in several …
       условия: логика {([p6]>=40)}
       эффект: P1(Time) = {[p1]+(420 to 480)}
       эффект: P3(Energy) = {[p3]+(20 to 25)}
       эффект: P4(Tiredness) = {[p4]+(60000 to 70000)}
       эффект: P5(Hunger) = {[p5]-[p23]*450}
       эффект: P6(Money) = {[p6]-40}

### Loc93 [обычная]
    выбор описания: {1+[p17]}
    Loc93-1: Finally you made it to the freeway. Intuition told you that if you took a left turn, you'd come to Mow's Gas Station, and the road on the right would eventually…
    Loc93-2: You are driving down the freeway to Shpick. The freeway runs further and further ahead. On the right there's also a narrow rural road going in an unknown direct…
    Loc93-3: You are driving down the freeway to Shpick. The freeway runs further and further ahead. On the left there's also a narrow rural road going in an unknown directi…
  -> Path287 => Loc149  вер=1 порядок=2
       текст: Turn back (to Mow)
       условия: логика {[p17]=1}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = {44}
  -> Path288 => Loc149  вер=1 порядок=1
       текст: Go further (to Mow)
       условия: логика {[p17]=2}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = {44}
  -> Path289 => Loc149  вер=1 порядок=2
       текст: Go to Mow's Gas Station
       условия: логика {[p17]=0}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {38}
       эффект: P28(Distance) = {44}
  -> Path291 => Loc149  вер=1 порядок=1
       текст: Go further (to Shipck)
       условия: логика {[p17]=1}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {81}
       эффект: P28(Distance) = {52}
  -> Path292 => Loc149  вер=1 порядок=2
       текст: Turn back (to Shpick)
       условия: логика {[p17]=2}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {81}
       эффект: P28(Distance) = {52}
  -> Path293 => Loc149  вер=1 порядок=1
       текст: Go to Shpick
       условия: логика {[p17]=0}
       эффект: P26(Where from) = {93}
       эффект: P27(Where to) = {81}
       эффект: P28(Distance) = {52}
  -> Path294 => Loc94  вер=1 порядок=3
       текст: Turn down the rut-road
       эффект: P1(Time) = {[p1]+((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((14*60)/([p12]+([p13]*[p12])/50))}
  -> Path595 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {93}
       эффект: P28(Distance) = 0

### Loc94 [обычная]
    Loc94-1: You drove down the road and soon reached a small muddy lake. It seemed like it took you <clr>some 15 kilometres<clrEnd> to get here.
  -> Path296 => Loc95  вер=1 порядок=1
       текст: Swim for some five minutes
       эффект: P17(Buffer) = {0}
  -> Path298 => Loc93  вер=1 порядок=9
       текст: Go back
       эффект: P1(Time) = {[p1]+((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P17(Buffer) = {0}
  -> Path299 => Loc93  вер=1 порядок=2
       текст: Take a quick dive in the lake and go back
       ответ: A short water constitutional refreshed you a bit. Now you could go back to the road.
       эффект: P1(Time) = {[p1]+5+((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]+(7000 to 12000)-[p24]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P17(Buffer) = {0}

### Loc95 [пустая]
  -> Path297 => Loc96  вер=1 порядок=5
       эффект: P1(Time) = {[p1]+5}
       эффект: P4(Tiredness) = {[p4]-(7000 to 10000)}
       эффект: P17(Buffer) +1

### Loc96 [обычная]
    Loc96-1: You swam for some five minutes, but with a water like this you did not really gain much pleasure out of it. In fact you felt even more tired than you had before…
  -> Path300 => Loc95  вер=1 порядок=5
       текст: Swim for another five minutes
       условия: логика {[p17]<2}
  -> Path301 => Loc93  вер=1 порядок=9
       текст: Get out of the water, dry up and return back to the road.
       эффект: P1(Time) = {[p1]+2+((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((14*60)/([p12]+([p13]*[p12])/50))}
       эффект: P17(Buffer) = {0}
  -> Path302 => Loc93  вер=1 порядок=5
       текст: Swim for another five minutes
       ответ: You continued swimming. Suddenly you felt <clr>your body fill with energy<clrEnd>, and your wounds skin over. Looks like this lake has some healing effect to it…
       условия: логика {([p17]>=2) and ([p3]<70)}
       эффект: P1(Time) = {[p1]+7}
       эффект: P3(Energy) = {70}
       эффект: P17(Buffer) = {0}
  -> Path303 => Loc93  вер=1 порядок=5
       текст: Swim for another five minutes
       ответ: You continued swimming. Mosquitoes buzzing over your head, gleet filling your mouth. For crying out loud! Finally you got completely sick and tired of this, cli…
       условия: логика {([p17]>=2) and ([p3]>=70)}
       эффект: P1(Time) = {[p1]+5}
       эффект: P17(Buffer) = {0}
  -> Path304 => Loc97  вер=1000 порядок=5
       текст: Swim for another five minutes
       условия: логика {[p4]<=1000}

### Loc97 [СМЕРТЬ]
    Loc97-1: You were swimming slowly in the water, but tiredness couldn't but affect you. Suddenly your left leg was cramped. Then the right. You started paddling with your…

### Loc98 [пустая]
    эффект: P18(Psychological state of the enemy) = {100} [показ]
  -> Path306 => Loc99  вер=1 порядок=5
       эффект: P17(Buffer) = {(15 to 25)+3*([p14]+[p15]+[p16])}
       эффект: P29(x) = 1

### Loc99 [обычная]
    выбор описания: {[p29]}
    Loc99-1: You were driving along quietly when suddenly you saw an armoured passenger vehicle gaining on you. Instead of windows it had steel sheets with narrow slits. The…
    Loc99-2: On your side there is an armoured passenger vehicle... Looks like getting rid of the chasers will not be that easy. /  / - Hey you, tough guy! Pull over, - you …
    Loc99-3: The car rushed forward to you. Noticing this you steered to the side of the road that padded the hit.  /  / Looks like getting rid of the chasers will not be th…
    Loc99-4: The enemy steered sharply towards you, hitting you truck with its side and damaging it considerably. /  / There is an armoured passenger vehicle on your side, w…
  -> Path307 => Loc100  вер=1 порядок=9
       текст: Stop
  -> Path310 => Loc101  вер=1000 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator and felt that you were making breakaway. Hurray! Soon the armoured car disappeared out of sight altogether.
       условия: логика {(1 to 100)<=((([p14]+[p15]+[p16])=0)*85+(([p14]+[p15]+[p16])=1)*75+(([p14]+[p15]+[p16])=2)*66+(([p14]+[p15]+[p16])=3)*43+(([p14]+[p15]+[p16])=4)*28+(([p14]+[p15]+[p16])=5)*15+1.2*(100-[p18]))}
       эффект: P1(Time) +20
       эффект: P11(Fuel tank) = {[p11]-60*[p22]}
  -> Path311 => Loc101  вер=1 [всегда видна] порядок=1
       текст: Drop the load on the enemy
       ответ: You moved in front of the opponent, pushed the red button, and dumped your entire load on the enemy. The load was falling out of the truck like from a cornucopi…
       условия: логика {([p14]+[p15]+[p16])>(3 to 5)}
       эффект: P13(Hold (free space)) = {[p13]+[p14]+[p15]+[p16]}
       эффект: P14(Spinach) = {0}
       эффект: P15(Coal) = {0}
       эффект: P16(Scrap metal) = {0}
       эффект: P18(Psychological state of the enemy) = {[p18]-(5*([p14]+[p15]+[p16]))}
  -> Path317 => Loc180  вер=1 порядок=2
       текст: Hit the other car with your truck
       ответ: You jolted the steering wheel sending the truck sideways onto the enemy, but their car was well-armoured and your attack attempt did not cause much damage.
       условия: логика {([p38] div 10 mod 10)=0}
       эффект: P9(Truck armour) = {[p9]-(15 to 17)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(20 to 25)-([p14]+[p15]+[p16])}
  -> Path318 => Loc180  вер=1 порядок=2
       текст: Hit the other car with your truck
       ответ: Despite their car being well-armoured you still managed to inflict a lot of damage on it with your spikes.
       условия: логика {([p38] div 10 mod 10)=1}
       эффект: P9(Truck armour) = {[p9]-(8 to 13)}
       эффект: P18(Psychological state of the enemy) = {[p18]-(30 to 40)-([p14]+[p15]+[p16])}
  -> Path319 => Loc103  вер=1.2 порядок=3
       текст: Shoot at the car from the shotgun
       ответ: And shoot you did. But what's the point? They are armoured. Your small shots are nothing to it.
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P7(Weapons) -1
  -> Path320 => Loc103  вер=2 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator but still couldn't make a breakaway. Looks like your chasers are not going to give it up that easily. Maybe you should try to cool o…
       эффект: P1(Time) +10
       эффект: P11(Fuel tank) = {[p11]-30*[p22]}
  -> Path321 => Loc103  вер=1 [всегда видна] порядок=1
       текст: Drop the load on the enemy
       ответ: You moved in front of the opponent, pushed the red button, and dumped your entire load on the enemy. But this was pretty useless - your load was too small to st…
       условия: логика {([p14]+[p15]+[p16])>0}
       эффект: P13(Hold (free space)) = {[p13]+[p14]+[p15]+[p16]}
       эффект: P14(Spinach) = {0}
       эффект: P15(Coal) = {0}
       эффект: P16(Scrap metal) = {0}
       эффект: P18(Psychological state of the enemy) = {[p18]-(15*([p14]+[p15]+[p16]))}
  -> Path327 => Loc103  вер=1 порядок=4
       текст: Shoot at them three times
       ответ: You shot at the enemy's car three times, but what good it was. They got armour.
       условия: логика {([p7]>1000) and (([p7] mod 1000)>2)}
       эффект: P7(Weapons) -3
  -> Path342 => Loc103  вер=1.00011e+06 порядок=8
       текст: Try to break away from them
       ответ: You floored the accelerator but could not shake the chase off. Your <clr>truck is overloaded<clrEnd>, which is why you cannot make it.
       условия: логика {([p14]+[p15]+[p16])>=6}
       эффект: P1(Time) +10
       эффект: P11(Fuel tank) = {[p11]-30*[p22]}

### Loc100 [обычная]
    выбор описания: {1+([p18]<100)}
    Loc100-1: You started slowing down and pulled over to the side of the road. When your truck has almost stopped, a huge bandit jumped out of the passenger vehicle, swung o…
    Loc100-2: You started slowing down and pulled over to the side of the road. When your truck has almost stopped, a huge bandit jumped out of the passenger vehicle, swung o…
  -> Path312 => Loc101  вер=1 порядок=9
       текст: Pay
       ответ: You went out of the truck and cautiously paid the villains what they asked.  /  / - That's better, - one of them said, putting the money in his pocket. - You ca…
       условия: логика {[p6]>=([p17]+((100-[p18]) div 3))}
       эффект: P6(Money) = {[p6]-([p17]+((100-[p18]) div 3))}
  -> Path313 => Loc101  вер=1 порядок=2
       текст: Fire from the shotgun
       ответ: You took your shotgun and fired at the cut-throats. Scared of what they thought could follow, they went running. And you climbed back into the truck and continu…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P7(Weapons) -1
  -> Path314 => Loc101  вер=1 порядок=1
       текст: Rush back to the truck and run away
       ответ: You rushed back to your truck but one of the cut-throats jumped upon you. You fell on the ground struggling... The other villain did not interfere and watched, …
       эффект: P3(Energy) = {[p3]-(30 to 40)}
  -> Path315 => Loc105  вер=1 порядок=8
       текст: Show them your tat
       условия: логика {([p8] mod 10)>0}
  -> Path332 => Loc106  вер=2 порядок=1
       текст: Rush back to the truck and run away
       условия: логика {[p4]<40000}
       эффект: P29(x) = 3
  -> Path333 => Loc101  вер=2 порядок=2
       текст: Fire from the shotgun
       ответ: You took out your shotgun and fired at the cut-throats. One of them took to his heels, but the other one seemed to be of a braver lot. However, one blow with th…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>0)}
       эффект: P3(Energy) = {[p3]-(15 to 25)}
       эффект: P7(Weapons) -1
  -> Path334 => Loc101  вер=1 порядок=3
       текст: Shoot at them three times
       ответ: You aimed the shotgun - bang! Bang! Bang!... One of the cut-throats went a-running into the field, while the second one remained lying wounded on the asphalt. W…
       условия: логика {([p7]>1000) and (([p7] mod 1000)>2)}
       эффект: P7(Weapons) -3
  -> Path489 => Loc154  вер=1 порядок=9
       текст: Wait, but I don't have that money! Maybe we can resolve this issue in some other way?
       условия: логика {[p6]<([p17]+((100-[p18]) div 3))}

### Loc101 [пустая]
  -> Path316 => Loc148  вер=1 порядок=5
       скрыт: P18

### Loc103 [пустая]
  -> Path322 => Loc104  вер=1.5 порядок=5
       условия: логика {[p4]>(50000 to 60000)}
       эффект: P9(Truck armour) = {[p9]-(10 to 15)+([p38] div 10 mod 10)*5}
       эффект: P18(Psychological state of the enemy) = {[p18]-([p38] div 10 mod 10)*10}
       эффект: P29(x) = 3
  -> Path324 => Loc104  вер=1 порядок=5
       эффект: P29(x) = 2
  -> Path326 => Loc101  вер=1000 порядок=5
       ответ: The armoured passenger vehicle started reducing its speed. The distance between you and the gangsters was increasing more and more. Finally you lost sight of th…
       условия: логика {[p18]<(5 to 15)}
  -> Path341 => Loc104  вер=1 порядок=5
       эффект: P9(Truck armour) = {[p9]-(20 to 25)+([p38] div 10 mod 10)*8}
       эффект: P18(Psychological state of the enemy) = {[p18]-([p38] div 10 mod 10)*10}
       эффект: P29(x) = 4

### Loc104 [пустая]
  -> Path325 => Loc99  вер=1 порядок=5

### Loc105 [обычная]
    Loc105-1: Suddenly the expression on the villains' faces changed. / - He's a bloody Scorpion! - one of them exclaimed and stuck a knife to your throat, - The bastards are…
  -> Path328 => Loc101  вер=1 [всегда видна] порядок=9
       текст: Pay
       ответ: - That's right, you weak pathetic Scorpion! - the cut-throat threw you on the ground, climbed back into his car, and they took off.  /  / Phew, that was close. …
       условия: логика {[p6]>=2*([p17]+((100-[p18]) div 3))}
       эффект: P6(Money) = {[p6]-(2*([p17]+((100-[p18]) div 3)))}
  -> Path329 => Loc106  вер=5 порядок=1
       текст: Fight
       эффект: P29(x) = 1
  -> Path330 => Loc106  вер=1 порядок=2
       текст: You bastards!!! Alright, come on, come on! Kill me! And let the Scorpions avenge my death!!!
       эффект: P29(x) = 2
  -> Path331 => Loc101  вер=1 порядок=1
       текст: Fight
       ответ: Incredible!!! You managed to catch him under celiac plexus. The Iroquois who was holding you bent in half. The second one was too surprised to do anything. Usin…

### Loc106 [СМЕРТЬ]
    выбор описания: {[p29]}
    Loc106-1: You elbowed the villain in the gut, but he was expecting this. Two knife stabs and you were on your knees. You were still breathing but the third blow finished …
    Loc106-2: The villain acted quick - one move and that was it. The robbers got back into their vehicle and took off. And your dead body remained lying still on the road. T…
    Loc106-3: You rushed back to your truck but one of the cut-throats jumped upon you. You fell on the ground struggling... The other villain did not interfere and watched, …

### Loc108 [обычная]
    выбор описания: {1+(([p38] div 100 mod 10)=1)}
    Loc108-1: You stopped in front of a huge T-shaped canyon, with a small river running down its bottom. <clr>The two bridges leading to the northern and eastern sides of th…
    Loc108-2: You stopped in front of a huge T-shaped canyon, with a small river running down to the bottom and a crooked carcass of a vehicle which reminded you of your form…
  -> Path345 => Loc73  вер=1 порядок=5
       текст: Go back
       эффект: P1(Time) = {[p1]+((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((36*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((36*60)/([p12]+([p13]*[p12])/50))}

### Loc109 [обычная]
    Loc109-1: You stopped the vehicle in the middle of the road to take a look around. In the distance there was a huge field with some green cultures. One the edge of the fi…
  -> Path348 => Loc111  вер=1 порядок=3
       текст: Go to the rubidium mines
       эффект: P1(Time) = {[p1]+((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((60*60)/([p12]+([p13]*[p12])/50))}
  -> Path354 => Loc173  вер=1 порядок=5
       текст: Drive over to the farm
       эффект: P1(Time) +1
  -> Path371 => Loc149  вер=1 порядок=1
       текст: Go to the Iroquois
       эффект: P26(Where from) = {109}
       эффект: P27(Where to) = {118}
       эффект: P28(Distance) = {28}
  -> Path372 => Loc149  вер=1 порядок=3
       текст: Go to the repair shop
       эффект: P26(Where from) = {109}
       эффект: P27(Where to) = {76}
       эффект: P28(Distance) = {36}
  -> Path453 => Loc142  вер=1000 порядок=5
       текст: Drive over to the farm
       условия: логика {[p25]>0}
       эффект: P1(Time) +1
  -> Path602 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {109}
       эффект: P28(Distance) = 0

### Loc111 [обычная]
    выбор описания: {1+(([p38] div 100 mod 10)=1)}
    Loc111-1: You stopped in front of a huge T-shaped canyon, with a small river running down its bottom. <clr>The two bridges leading to the northern and eastern sides of th…
    Loc111-2: You stopped in front of a huge T-shaped canyon, with a small river running down its bottom. <clr>The two bridges leading to the northern and eastern sides of th…
  -> Path349 => Loc109  вер=1 порядок=9
       текст: Go to the farm
       эффект: P1(Time) = {[p1]+((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((60*60)/([p12]+([p13]*[p12])/50))}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((60*60)/([p12]+([p13]*[p12])/50))}
  -> Path350 => Loc112  вер=1 порядок=5
       текст: Examine the truck
       условия: логика {([p38] div 100 mod 10)=0}

### Loc112 [обычная]
    Loc112-1: You started examining the vehicle. Checked the steer, looked under the hood, inspected the wheels - of course this vehicle was in a very a poor shape, but it se…
    эффект: P1(Time) +5
  -> Path351 => Loc111  вер=1 порядок=5
       текст: Go back to your truck
  -> Path353 => Loc109  вер=1 порядок=5
       текст: Repair the truck, using the parts of your old truck
       ответ: You spent a lot of time with the truck mending it here and there. Finally you started all of the fuel form the old truck into your new steel buffalo. You starte…
       эффект: P1(Time) = {[p1]+(180 to 240)+((22*60)/([p12]+([p13]*[p12])/50))}
       эффект: P4(Tiredness) = {[p4]-[p24]*((22*60)/([p12]+([p13]*[p12])/50))}
       эффект: P5(Hunger) = {[p5]-[p23]*((22*60)/([p12]+([p13]*[p12])/50))}
       эффект: P9(Truck armour) = {50}
       эффект: P11(Fuel tank) = {[p11]-[p22]*((22*60)/([p12]+([p13]*[p12])/50))}
       эффект: P10(Spikes) = 0
       эффект: P12(Speed) = {50}
       эффект: P13(Hold (free space)) = {[p13]+6-2*([p38] mod 10)}
       эффект: P38(Truck upgrades + swap trucks + automate use qty.) = {([p38] div 1000)+100}

### Loc113 [обычная]
    выбор описания: {[p29]}
    Loc113-1: - So what questions did you have? - the large guy asked.
    Loc113-2: - We are coping by ourselves. Besides, we do not need anything now...
    Loc113-3: - Some would consider a rake a good enough weapon, - he answered. - You want one? /  / You did not say anything.
  -> Path355 => Loc114  вер=1 порядок=8
       текст: Let's go back to trade
  -> Path362 => Loc109  вер=1 порядок=9
       текст: I think - I'll be going...
       эффект: P1(Time) +1
  -> Path363 => Loc116  вер=1 проходов<=1 порядок=5
       текст: Have you got any weapons? I think I could buy some
       эффект: P29(x) = 3
  -> Path364 => Loc116  вер=1 проходов<=1 порядок=6
       текст: I need money. Could I work a little on your farm?
       эффект: P29(x) = 2

### Loc114 [обычная]
    выбор описания: {1+([p19]=0)}
    Loc114-1: Your vehicle pulled up right at the gate of the farmhouse. A young lad in a hat and a straw between his teeth was studying you through the window: /  / - Right …
    Loc114-2: - Say, chap, we've run out of everything. But this is not fatal. It's harvesting time, and in 24 hours we are surely going to have a couple of tons of freshly c…
  -> Path356 => Loc113  вер=1 порядок=8
       текст: Ask a couple of questions
       эффект: P29(x) = 1
  -> Path357 => Loc115  вер=1 [всегда видна] порядок=1
       текст: Take one barrel of spinach
       условия: логика {([p13]>0) and ([p6]>=25) and ([p19]>0)}
       эффект: P6(Money) = {[p6]-25}
       эффект: P13(Hold (free space)) -1
       эффект: P14(Spinach) +1
       эффект: P19(Spinach reserve) -1
  -> Path358 => Loc115  вер=1 [всегда видна] порядок=2
       текст: Buy three barrels of spinach
       условия: логика {([p13]>2) and ([p6]>=(3*25)) and ([p19]>2)}
       эффект: P6(Money) = {[p6]-(3*25)}
       эффект: P13(Hold (free space)) -3
       эффект: P14(Spinach) +3
       эффект: P19(Spinach reserve) -3
  -> Path359 => Loc115  вер=1 [всегда видна] порядок=3
       текст: Fill the truck with spinach to the brim
       условия: логика {([p19]>=[p13]) and ([p6]>=([p13]*25)) and ([p13]>0)}
       эффект: P6(Money) = {[p6]-([p13]*25)}
       эффект: P13(Hold (free space)) = {0}
       эффект: P14(Spinach) = {[p13]+[p14]}
       эффект: P19(Spinach reserve) = {[p19]-[p13]}
  -> Path360 => Loc115  вер=1 [всегда видна] порядок=4
       текст: Take all the remaining spinach
       условия: логика {([p13]>=[p19]) and ([p6]>=([p19]*25)) and ([p19]>0)}
       эффект: P6(Money) = {[p6]-([p19]*25)}
       эффект: P13(Hold (free space)) = {[p13]-[p19]}
       эффект: P14(Spinach) = {[p19]+[p14]}
       эффект: P19(Spinach reserve) = {0}
  -> Path385 => Loc109  вер=1 порядок=9
       текст: Go back to the road
       эффект: P1(Time) +1

### Loc115 [пустая]
  -> Path361 => Loc114  вер=1 порядок=5

### Loc116 [пустая]
  -> Path365 => Loc113  вер=1 порядок=5

### Loc118 [обычная]
    выбор описания: {[p29]}
    Loc118-1: You are standing in front of a large base surrounded with a tall iron wall. On the wall there is a man dressed in a leather jacket and welding a spear: /  / - Y…
    Loc118-2: Three villains climbed down the wall by a rope ladder and walked to your truck. One of them took the money from you and said: /  / - Rolan is going to be back a…
    Loc118-3: - Too late, - the guard said. - We did set you a term, the money was not here, so Rolan is no more. The Iroquois always keep their word - so it shall be written…
    Loc118-4: - WE are not giving out dead bodies, - the guard cut off. - And now I strongly suggest that go back to where you came from.
    Loc118-5: - Who the hell are you, to threaten us, nitwit?! Rolan owes us money and we estimated the compensation at <clr>900 platinum pieces<clrEnd>. And he has about {10…
  -> Path375 => Loc149  вер=1 порядок=9
       текст: Return back to the car
       эффект: P26(Where from) = {118}
       эффект: P27(Where to) = {109}
       эффект: P28(Distance) = {28}
  -> Path376 => Loc126  вер=1000 проходов<=1 порядок=5
       текст: Let Rolan go now!
       условия: логика {(([p8] div 10 mod 10)=0)}
  -> Path377 => Loc119  вер=1000 проходов<=1 порядок=5
       текст: I want to pay the ransom for Rolan!
       условия: логика {([p6]>=900) and (([p1] div (24*60))<10)}
       эффект: P6(Money) = {[p6]-900}
       эффект: P8(Tattoo, deposit, Peleng) = {[p8]+10}
       эффект: P29(x) = 2
       скрыт: P1
       показ: P2
  -> Path378 => Loc119  вер=1 проходов<=1 порядок=5
       текст: I want to pay the ransom for Rolan!
       условия: логика {([p6]>=900) and (([p8] div 10 mod 10)=0) and (([p1] div (24*60))>=10)}
       эффект: P8(Tattoo, deposit, Peleng) = {[p8]+20}
       эффект: P29(x) = 3
  -> Path601 => Loc184  вер=1
       текст: Study the map
       эффект: P27(Where to) = {118}
       эффект: P28(Distance) = 0

### Loc119 [пустая]
  -> Path380 => Loc118  вер=1 порядок=5

### Loc120 [пустая]
    скрыт: P1,P2
  -> Path382 => Loc121  вер=1 порядок=5

### Loc121 [пустая]
  -> Path383 => Loc120  вер=1000 порядок=5
       условия: логика {[p1]>=(24*60)}
       эффект: P1(Time) = {[p1]-(24*60)}
  -> Path384 => Loc122  вер=1 порядок=5

### Loc122 [УСПЕХ]
    выбор описания: {[p29]}
    Loc122-1: Not waiting for her to repeat the offer you gave all you platinum pieces to her. These were completely useless anywhere else in the Galaxy. In return Ramina gav…
    Loc122-2: - Unfortunately I spent all of my money, - you said and headed back to your ship. You sank in the pilot seat and fired up the engines. /  / Soon you were airbor…
    скрыт: P1,P6

### Loc125 [обычная]
    Loc125-1: The truck was in excellent condition, judging by the figures on the front panel the fuel tank was full - all <clr>100<clrEnd> litres. The capacity of the body w…
    эффект: P1(Time) +3
    показ: P9,P11,P13,P14,P15,P16
  -> Path387 => Loc4  вер=1 порядок=9
       текст: Alright, it's pretty clear. Time to mount the truck and go save Rolan
  -> Path388 => Loc2  вер=1 порядок=5
       текст: Go to Ramina's house and ask her a couple of questions
       эффект: P29(x) = 1

### Loc126 [пустая] визитов<=1
  -> Path392 => Loc118  вер=1 порядок=5
       условия: логика {(([p1] div (24*60))<10)}
       эффект: P29(x) = 5
  -> Path393 => Loc118  вер=1 порядок=5
       условия: логика {(([p1] div (24*60))>=10)}
       эффект: P29(x) = 4

### Loc127 [пустая]
  -> Path395 => Loc46  вер=1 порядок=5

### Loc128 [обычная]
    Loc128-1: As soon as you drove into the airfield you saw Ramina who was waving her hand at you. You stopped the truck and walked over. /  / - The Iroquois have just broug…
  -> Path399 => Loc120  вер=1 [всегда видна] порядок=5
       текст: Exchange platinum pieces
       условия: логика {[p6]>0}
       эффект: P2(Actual player money) = {[p2]+(([p6]>300)*1500+([p6]<=300)*[p6]*5)}
       эффект: P29(x) = 1
  -> Path400 => Loc120  вер=1 порядок=5
       текст: Refuse to exchange and go back to your ship
       условия: логика {[p6]=0}
       эффект: P29(x) = 2

### Loc129 [обычная]
    Loc129-1: The chemist added the amount of Helios you specified, stirred the mixture and poured it in a thin line around the safe-door perimeter. Once in contact with meta…
    эффект: P7(Weapons) = {[p7]+15}
  -> Path401 => Loc46  вер=1 порядок=5
       текст: Follow the sheriff
       эффект: P29(x) = 1

### Loc130 [обычная]
    Loc130-1: There was an iron plate on the slot machine: / "Drop <clr>1 platinum piece<clrEnd> and pull the handle. / Two numbers - 2 platinum pieces, / Three numbers - 25 …
  -> Path407 => Loc147  вер=1 порядок=9
       текст: Go away from the slot machine
  -> Path408 => Loc131  вер=1 [всегда видна] порядок=5
       текст: Play
       условия: логика {[p6]>0}

### Loc131 [пустая]
    эффект: P1(Time) +1
    эффект: P4(Tiredness) = {[p4]-[p24]}
    эффект: P5(Hunger) = {[p5]-[p23]}
    эффект: P6(Money) -1
    эффект: P17(Buffer) = {(1 to 7)*100+(1 to 7)*10+(1 to 7)}
    эффект: P38(Truck upgrades + swap trucks + automate use qty.) = {[p38]+1000}
  -> Path409 => Loc132  вер=1 порядок=5
       ответ: The drums started spinning in a blur and stopped at: /  / {[p17] div 100 mod 10} -==- {[p17] div 10 mod 10} -==- {[p17] mod 10} /  / <clr>You lost.<clrEnd>
  -> Path410 => Loc132  вер=1000 порядок=5
       ответ: The drums started spinning in a blur and stopped at: /  / {[p17] div 100 mod 10} -==- {[p17] div 10 mod 10} -==- {[p17] mod 10} /  / <clr>a double!<clrEnd> <clr…
       условия: логика {(([p17] div 100)=([p17] div 10 mod 10)) or (([p17] div 100)=([p17] mod 10)) or (([p17] div 10 mod 10)=([p17] mod 10))}
       эффект: P6(Money) = {[p6]+2}
  -> Path411 => Loc132  вер=1e+06 порядок=5
       ответ: The drums started spinning in a blur and stopped at: /  / {[p17] div 100 mod 10} -==- {[p17] div 10 mod 10} -==- {[p17] mod 10} /  / <clr>A triple!!!<clrEnd> Pl…
       условия: логика {(([p17] div 100)=([p17] div 10 mod 10)) and (([p17] div 100)=([p17] mod 10))}
       эффект: P6(Money) = {[p6]+25}
  -> Path414 => Loc132  вер=1e+09 порядок=5
       ответ: You dropped a platinum piece into the slot, pulled the lever, and... broke it off. Damn! <clr>You broke the slot machine.<clrEnd> But apparently so far no one n…
       условия: логика {([p38] div 1000 mod 100)>=99}

### Loc132 [пустая]
  -> Path412 => Loc131  вер=1 [всегда видна] порядок=1
       текст: Play again
       условия: логика {([p6]>0) and (([p38] div 1000 mod 100)<99)}
  -> Path413 => Loc147  вер=1 порядок=9
       текст: Go away from the slot machine

### Loc133 [пустая]
    эффект: P39(new) = 1
  -> Path423 => Loc16  вер=1 порядок=1
       текст: Get in!
       показ: P25
  -> Path424 => Loc16  вер=1 порядок=5
       текст: I got different plans right now, sorry
       эффект: P25(Fellow-traveller) = 0

### Loc134 [пустая]
  -> Path427 => Loc55  вер=1 порядок=5
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 0..0
       эффект: P25(Fellow-traveller) = 0
  -> Path428 => Loc55  вер=1000 порядок=5
       ответ: - Thanks, bro! The miner gave you <clr>60 platinum pieces<clrEnd> and trotted off to the bar.
       условия: логика {[p25]=2}
       эффект: P6(Money) = {[p6]+60}
       эффект: P25(Fellow-traveller) = 0
  -> Path604 => Loc55  вер=1 порядок=5
       ответ: - Yikes! Where the hell are we! - your fellow traveller was outraged. - I should of found me a proper driver in the first place. /  / You tried to explain it to…
       условия: P39(new) 1..1
       эффект: P25(Fellow-traveller) = 0

### Loc135 [пустая]
  -> Path430 => Loc136  вер=1 порядок=5
       ответ: - Damn! John Long the carrier! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 1..1
       эффект: P25(Fellow-traveller) = 0
  -> Path431 => Loc136  вер=1000 порядок=5
       ответ: - Home at last! - your travelling companion exclaimed, gave you the promised <clr>40<clrEnd> platinum pieces and disappeared down one of the streets.
       условия: логика {[p25]=1}
       эффект: P6(Money) = {[p6]+40}
       эффект: P25(Fellow-traveller) = 0
  -> Path443 => Loc136  вер=1000 порядок=5
       ответ: - Watch it go! Let the madness continue. Now let us spend some money here in Shpick. Hey, chief, here's your <clr>100<clrEnd> platinum pieces, - you travelling …
       условия: логика {[p25]=4}
       эффект: P6(Money) = {[p6]+100}
       эффект: P25(Fellow-traveller) = 0
  -> Path452 => Loc136  вер=1000 порядок=5
       ответ: - On behalf of Law Enforcement Department No3 I express my gratitude, driver! - the guy in uniform barked and jumped out into the street. / - Hey, are you gonna…
       условия: логика {[p25]=5}
       эффект: P7(Weapons) = {[p7]+8}
       эффект: P25(Fellow-traveller) = 0
  -> Path606 => Loc136  вер=1 порядок=5
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 0..0
       эффект: P25(Fellow-traveller) = 0

### Loc136 [пустая]
  -> Path432 => Loc82  вер=1000 порядок=9
       текст: Next
       ответ: Stopping in the middle of the square you tried to wake the Peleng up. As if it was that easy! You had to shake him for a good five minutes, until he finally ope…
       условия: логика {([p8] div 100 mod 10)=1}
       эффект: P1(Time) +5
       эффект: P7(Weapons) = {[p7]+1006}
       эффект: P8(Tattoo, deposit, Peleng) = {[p8]-100}
  -> Path433 => Loc82  вер=1 порядок=5

### Loc137 [пустая]
    эффект: P39(new) = 1
  -> Path437 => Loc54  вер=1 порядок=1
       текст: Sure!
       показ: P25
  -> Path438 => Loc54  вер=1 порядок=5
       текст: I got different plans right now, sorry
       эффект: P25(Fellow-traveller) = 0

### Loc138 [пустая]
  -> Path441 => Loc17  вер=1 порядок=9
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 0..0
       эффект: P25(Fellow-traveller) = {0}
  -> Path442 => Loc17  вер=1000 порядок=9
       ответ: - Thanks, chap! I owe you bigtime - said your travel companion, gave you all of his coins (it was exactly <clr>38 platinum pieces<clrEnd>) and walked off to the…
       условия: логика {[p25]=3}
       эффект: P6(Money) = {[p6]+38}
       эффект: P25(Fellow-traveller) = {0}
  -> Path461 => Loc17  вер=1000 порядок=9
       ответ: - Here we go, baby! Soon I will become rich, - the boy cried out, jumping out of the car. - Hey, chap, here're are your <clr>30 platinum pieces<clrEnd>. And! Do…
       условия: логика {[p25]=8}
       эффект: P6(Money) = {[p6]+30}
       эффект: P25(Fellow-traveller) = {0}
  -> Path605 => Loc17  вер=1 порядок=9
       ответ: - Damn! John Long the carrier! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 1..1
       эффект: P25(Fellow-traveller) = {0}

### Loc139 [пустая]
    эффект: P29(x) = 1
  -> Path128 => Loc46  вер=1 порядок=9
  -> Path129 => Loc46  вер=1000 проходов<=1 порядок=9
       ответ: You entered the rut-road and drove to the building. A minute later you were already at the building. The door opened, and a man with a sheriff's star on the che…

### Loc140 [пустая]
  -> Path446 => Loc139  вер=1 порядок=9
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 0..0
       эффект: P25(Fellow-traveller) = {0}
  -> Path460 => Loc139  вер=1000 порядок=5
       ответ: - Thanks for the lift, - the man said brushing the dust off his suit. Here's your <clr>50<clrEnd> platinum pieces. Oh yes, should you have any problems with tap…
       условия: логика {[p25]=7}
       эффект: P6(Money) = {[p6]+50}
       эффект: P25(Fellow-traveller) = 0
  -> Path607 => Loc139  вер=1 порядок=9
       ответ: - Damn! John Long the carrier! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       условия: P39(new) 1..1
       эффект: P25(Fellow-traveller) = {0}

### Loc141 [пустая]
    эффект: P39(new) = 1
  -> Path449 => Loc45  вер=1 порядок=1
       текст: Get in!
       показ: P25
  -> Path450 => Loc45  вер=1 порядок=5
       текст: I got different plans right now, sorry
       эффект: P25(Fellow-traveller) = 0

### Loc142 [пустая]
  -> Path454 => Loc173  вер=1 порядок=9
       ответ: - Shit! Where the hell are we! - your travelling companion was outraged. - I should have found me a proper driver in the first place. /  / You tried to explain …
       эффект: P25(Fellow-traveller) = {0}
  -> Path455 => Loc173  вер=1000 порядок=5
       ответ: You stopped right at the farmer's house to drop off your travelling companion. /  / - Excellent. Just where I wanted it. Now our the lads back art the departmen…
       условия: логика {[p25]=6}
       эффект: P6(Money) = {[p6]+50}
       эффект: P25(Fellow-traveller) = 0

### Loc143 [пустая]
    эффект: P39(new) = 1
  -> Path457 => Loc81  вер=1 порядок=1
       текст: Get in!
       показ: P25
  -> Path458 => Loc81  вер=1 порядок=5
       текст: I got different plans right now, sorry
       эффект: P25(Fellow-traveller) = 0

### Loc144 [пустая]
  -> Path462 => Loc82  вер=1 порядок=5

### Loc145 [пустая]
  -> Path463 => Loc17  вер=1 порядок=5

### Loc146 [пустая]
  -> Path464 => Loc55  вер=1 порядок=5

### Loc147 [пустая]
  -> Path465 => Loc55  вер=1 порядок=5

### Loc148 [пустая]
    эффект: P1(Time) = {[p1]+(([p28]*60)/([p12]+([p13]*[p12])/50))}
    эффект: P4(Tiredness) = {[p4]-[p24]*(([p28]*60)/([p12]+([p13]*[p12])/50))}
    эффект: P5(Hunger) = {[p5]-[p23]*(([p28]*60)/([p12]+([p13]*[p12])/50))}
    эффект: P11(Fuel tank) = {[p11]-[p22]*(([p28]*60)/([p12]+([p13]*[p12])/50))}
  -> Path466 => Loc45  вер=1 порядок=5
       условия: P27(Where to) ∈[45]; P37(Fines) ∈[0]
  -> Path467 => Loc81  вер=1 порядок=5
       условия: P27(Where to) ∈[81]
  -> Path468 => Loc93  вер=1 порядок=5
       условия: P27(Where to) ∈[93]
  -> Path469 => Loc38  вер=1 порядок=5
       условия: P27(Where to) ∈[38]
  -> Path470 => Loc16  вер=1 порядок=5
       условия: P27(Where to) ∈[16]
  -> Path471 => Loc9  вер=1 порядок=5
       условия: P27(Where to) ∈[9]
  -> Path472 => Loc4  вер=1 порядок=5
       условия: P27(Where to) ∈[4]
  -> Path473 => Loc10  вер=1 порядок=5
       условия: P27(Where to) ∈[10]
  -> Path474 => Loc51  вер=1 порядок=5
       условия: P27(Where to) ∈[51]
  -> Path475 => Loc54  вер=1 порядок=5
       условия: P27(Where to) ∈[54]
  -> Path476 => Loc73  вер=1 порядок=5
       условия: P27(Where to) ∈[73]
  -> Path477 => Loc109  вер=1 порядок=5
       условия: P27(Where to) ∈[109]
  -> Path478 => Loc118  вер=1 порядок=5
       условия: P27(Where to) ∈[118]
       эффект: P29(x) = 1
  -> Path479 => Loc76  вер=1 порядок=5
       условия: P27(Where to) ∈[76]
  -> Path580 => Loc183  вер=1 порядок=5
       условия: P27(Where to) ∈[45]; P37(Fines) 1..20
       эффект: P37(Fines) = {0}

### Loc149 [пустая]
    эффект: P39(new) = 0
  -> Path112 => Loc31  вер=8 порядок=5
       условия: P26(Where from) ∈[10, 16, 38, 51]; P27(Where to) ∈[10, 16, 38, 51]; логика {([p8] mod 10)<>2}
  -> Path369 => Loc98  вер=10 порядок=5
       условия: P26(Where from) ∈[76, 109]; P27(Where to) ∈[76, 109]
  -> Path480 => Loc148  вер=10 порядок=5
       эффект: P37(Fines) = 0
  -> Path481 => Loc98  вер=7 порядок=5
       условия: P26(Where from) ∈[73, 76]; P27(Where to) ∈[73, 76]
  -> Path496 => Loc157  вер=1.5 порядок=5
       эффект: P29(x) = {1 to 8}
  -> Path569 => Loc31  вер=8 порядок=5
       условия: P26(Where from) ∈[10, 16, 38, 51]; P27(Where to) ∈[10, 16, 38, 51]; логика {(([p8] mod 10)<>2) and ((1 to 3)<([p14]+[p15]+[p16]))}
  -> Path570 => Loc98  вер=10 порядок=5
       условия: P26(Where from) ∈[76, 109]; P27(Where to) ∈[76, 109]; логика {((1 to 3)<([p14]+[p15]+[p16]))}
  -> Path571 => Loc98  вер=7 порядок=5
       условия: P26(Where from) ∈[73, 76]; P27(Where to) ∈[73, 76]; логика {((1 to 3)<([p14]+[p15]+[p16]))}
  -> Path577 => Loc182  вер=5 порядок=5
       условия: P25(Fellow-traveller) ∉[7]; P27(Where to) ∈[45]
       эффект: P37(Fines) = {[5..15]}

### Loc150 [обычная]
    Loc150-1: Stopping the car toy stepped outside and headed for the shabby cabin. Having informed Ramina on the untimely demise of her husband, you took off. That's it... M…
  -> Path484 => Loc6  вер=1 порядок=5
       текст: Let's go

### Loc151 [пустая]
  -> Path486 => Loc152  вер=1 порядок=5
       ответ: One of the villains walked over to your truck, swung the door open and pulled you out on the ground. He searched your pockets and called out to his comrade: / -…
       условия: логика {([p14]+[p15]+[p16])>0}
       эффект: P1(Time) = {[p1]+(45 to 60)}
       эффект: P14(Spinach) = {[p14]-([p15]<1)}
       эффект: P15(Coal) = {[p15]-2-([p14]<1)-([p16]<1)}
       эффект: P16(Scrap metal) = {[p16]-1-([p15]<2)-([p14]<1)*(1 to 2)}
       эффект: P29(x) = {[p14]}
       эффект: P30(y) = {[p15]}
       эффект: P31(z) = {[p16]}
  -> Path487 => Loc153  вер=1000 порядок=5
       условия: логика {([p14]+[p15]+[p16])=0}

### Loc152 [пустая]
    эффект: P13(Hold (free space)) = {[p13]+[p29]-[p14]+[p30]-[p15]+[p31]-[p16]}
  -> Path488 => Loc34  вер=1 порядок=5

### Loc153 [СМЕРТЬ]
    Loc153-1: One of the villains walked over to your truck, swung the door open and pulled you out on the ground. He searched your pockets and called out to his comrade: / -…

### Loc154 [обычная]
    Loc154-1: - No money, you say? Well let us have a closer look... - with these words the two villains started searching you, but only found [p6]. / - Check this out, this …
  -> Path490 => Loc101  вер=1 порядок=5
       текст: Next
       ответ: When you came to you were lying in the gutter. Your sides were aching badly but at least you could move. You staggered back to the truck, climbed in your seat, …
       эффект: P3(Energy) = {[p3]-(20 to 30)}
       эффект: P6(Money) = {0}

### Loc155 [обычная]
    выбор описания: {[p29]}
    Loc155-1: The entire house was packed with all kinds of equipment. On the right there was a row of some medical (or so they looked) devices of all shapes and kinds. There…
    Loc155-2: - Energy treatment, eh? No problemo, - the doctor took the money from you. Quickly he had you seated in the tough chair of the unit, put a helmet on your head, …
    Loc155-3: - In addition to that we perform operation on brain transplantation, remove hair from heels and fins (for Maloqs and Pelengs respectively), and, - the doctor ca…
  -> Path492 => Loc156  вер=1 [всегда видна] порядок=1
       текст: I really do not feel well. I could use some energy treatment...
       условия: логика {([p3]<100) and ([p6]>=50)}
       эффект: P1(Time) = {[p1]+(4*60+6*60)}
       эффект: P3(Energy) = {100}
       эффект: P4(Tiredness) = {[p4]+(5000 to 10000)}
       эффект: P6(Money) = {[p6]-50}
       эффект: P29(x) = {2}
  -> Path493 => Loc156  вер=1 проходов<=1 порядок=2
       текст: What other procedure can you offer?
       эффект: P29(x) = {3}
  -> Path495 => Loc82  вер=1 порядок=9
       текст: Take your leave
       эффект: P1(Time) +1

### Loc156 [пустая]
  -> Path494 => Loc155  вер=1 порядок=5

### Loc157 [пустая]
  -> Path497 => Loc174  вер=1 порядок=5
       эффект: P32(Person) = {1 to 7}

### Loc158 [обычная]
    выбор описания: {1 to 4}
    Loc158-1: There is a small truck running down the opposite lane, flashing its headlights. Looks like the driver suggests that you pull over.
    Loc158-2: There is small truck with wooden board bodywork running down the opposite line. What an agricultural relic? Taking a better look you also noticed that the truck…
    Loc158-3: Down the opposite lane there ran a sizeable freight train with a flat front and a gleaming windshield. The driver of the "mustang" looked out of the cabin and w…
    Loc158-4: There's a shabby and seriously beaten truck running down the opposite lane. Looks like this guy has seen a lot on these cruel roads. As you took a better look y…
  -> Path498 => Loc159  вер=1 порядок=1
       текст: Stop
  -> Path500 => Loc160  вер=1 порядок=2
       текст: Don't stop. Keep going

### Loc159 [пустая]
  -> Path501 => Loc161  вер=1 порядок=5
       условия: логика {[p32]<=5}
       эффект: P29(x) = {1}
       эффект: P30(y) = {0}
       эффект: P31(z) = {0}
       эффект: P33(z2) = {0}

### Loc160 [пустая]
  -> Path499 => Loc148  вер=1 порядок=5

### Loc161 [обычная]
    выбор описания: {[p29]}
    Loc161-1: - Hey, wheeler, 'sup? - the truck driver called out leaning from the side window of his vehicle.
    Loc161-2: The driver watches you with a big smile, waiting for you to say something.
  -> Path502 => Loc162  вер=1 порядок=1
       текст: Any news?
       условия: логика {([p32]<>2) and ([p32]<>3) and (([p30] mod 10)=0)}
       эффект: P30(y) = {[p30]+1}
  -> Path504 => Loc163  вер=1 порядок=1
       текст: Any news?
       условия: логика {([p32]=3) and (([p30] mod 10)=0)}
       эффект: P30(y) = {[p30]+1}
  -> Path507 => Loc164  вер=1 порядок=1
       текст: Any news?
       условия: логика {([p32]=2) and (([p30] mod 10)=0)}
       эффект: P29(x) = {1}
       эффект: P30(y) = {[p30]+1}
       эффект: P33(z2) = {30}
  -> Path513 => Loc166  вер=2 порядок=2
       текст: What is that you're carrying?
       ответ: - What am I carrying? Nothing really. I'm empty, - the driver responded.
       условия: логика {(([p30] div 10 mod 10)=0) and ([p32]<4)}
       эффект: P30(y) = {[p30]+10}
  -> Path515 => Loc167  вер=1 порядок=2
       текст: What is that you're carrying?
       условия: логика {(([p30] div 10 mod 10)=0) and ([p32]>=4)}
  -> Path520 => Loc166  вер=1 порядок=3
       текст: Say, friend. Could you sell me about 15 litres of gas? I'm running out.
       ответ: - Sorry, I barely got enough myself to make it. Sorry.
       условия: логика {(([p30] div 100 mod 10)=0) and ([p32]=2) and ([p11]<100000)}
       эффект: P30(y) = {[p30]+100}
  -> Path521 => Loc168  вер=1 порядок=3
       текст: Say, friend. Could you sell me about 15 litres of gas? I'm running out.
       условия: логика {(([p30] div 100 mod 10)=0) and ([p32]<>2) and ([p11]<100000)}
       эффект: P31(z) = {[p31]+([p31]=0)*(18 to 30)}
  -> Path525 => Loc170  вер=1 порядок=4
       текст: Need you some coal? I got a little back here?
       условия: логика {(([p30] div 1000 mod 10)=0) and ([p15]>0)}
       эффект: P30(y) = {[p30]+1000}
       эффект: P33(z2) = {6 to 14}
  -> Path526 => Loc166  вер=1 порядок=4
       текст: Need you some coal? I got a little back here?
       ответ: - Thanks, bro. Not interested.
       условия: логика {(([p30] div 1000 mod 10)=0) and ([p15]>0)}
       эффект: P30(y) = {[p30]+1000}
  -> Path531 => Loc171  вер=1 порядок=5
       текст: Say, partner, I got me some scrap metal back there. Wanna buy?
       условия: логика {(([p30] div 10000 mod 10)=0) and ([p16]>0)}
       эффект: P30(y) = {[p30]+10000}
       эффект: P33(z2) = {14 to 26}
  -> Path536 => Loc166  вер=1 порядок=4
       текст: Say, partner, I got me some scrap metal back there. Wanna buy?
       ответ: - Nah. I don't need scrap metal.
       условия: логика {(([p30] div 10000 mod 10)=0) and ([p16]>0)}
       эффект: P30(y) = {[p30]+10000}
       эффект: P33(z2) = {14 to 26}
  -> Path537 => Loc172  вер=1 порядок=6
       текст: Hey, chief, I got some spinach back there. Wanna buy?
       условия: логика {(([p30] div 100000 mod 10)=0) and ([p14]>0)}
       эффект: P30(y) = {[p30]+100000}
       эффект: P33(z2) = {22 to 52}
  -> Path540 => Loc160  вер=1 порядок=9
       текст: Say goodbye to the trucker and take off
  -> Path541 => Loc166  вер=1 порядок=6
       текст: Hey, chief, I got some spinach back there. Wanna buy?
       ответ: - Hmm... No. I don't need it.
       условия: логика {(([p30] div 100000 mod 10)=0) and ([p14]>0)}
       эффект: P30(y) = {[p30]+100000}
       эффект: P33(z2) = {22 to 52}
  -> Path564 => Loc166  вер=1000 порядок=6
       текст: Hey, chief, I got some spinach back there. Wanna buy?
       ответ: - Nah, thanks. Got a truckload of it myself! - the trucker replied.
       условия: логика {(([p30] div 100000 mod 10)=0) and ([p14]>0) and ([p32]=4)}
       эффект: P30(y) = {[p30]+100000}
       эффект: P33(z2) = {22 to 52}
  -> Path565 => Loc166  вер=1000 порядок=5
       текст: Say, partner, I got me some scrap metal back there. Wanna buy?
       ответ: - No way! I got a full truckload of this stuff myself.
       условия: логика {(([p30] div 10000 mod 10)=0) and ([p16]>0) and ([p32]=5)}
       эффект: P30(y) = {[p30]+10000}
       эффект: P33(z2) = {14 to 26}
  -> Path566 => Loc166  вер=1 порядок=2
       текст: What is that you're carrying?
       ответ: - Some coal, some scrap metal, - the trucker replied.
       условия: логика {(([p30] div 10 mod 10)=0) and ([p32]<4)}
       эффект: P30(y) = {[p30]+10}
  -> Path567 => Loc166  вер=1 порядок=2
       текст: What is that you're carrying?
       ответ: - Wine, port wine, kinza, - the driver responded. - And wipe that grin off your face now, I am not selling you anything. It's a purchase order, so go figure.
       условия: логика {(([p30] div 10 mod 10)=0) and ([p32]<4)}
       эффект: P30(y) = {[p30]+10}
  -> Path568 => Loc166  вер=2 порядок=2
       текст: What is that you're carrying?
       ответ: - Err, I don't like these questions, - the trucker mumbled.  / - Well, don't answer then.
       условия: логика {(([p30] div 10 mod 10)=0) and ([p32]<4)}
       эффект: P30(y) = {[p30]+10}

### Loc162 [обычная]
    выбор описания: {1 to 10}
    Loc162-1: - Oh you know. Just the other day I was going back from the mines to Mow's Gas Station when I saw a Scorpion SUV. Well, you know they would often patrol that ar…
    Loc162-2: - News... Nothing much really. The Iroquois bastards are going to kill me some day. The roads from the Screw's repair shop and all the way to the farm and Stilt…
    Loc162-3: - News? The only thing worth mentioning that happened lately was the trucker's day. Was a month ago that we celebrated it. I tell you, that was something really…
    Loc162-4: - No news, really. The only thing I can think of at the moment is that old magazine I found the other day, all in machine oil. Anyway, according to the magazine…
    Loc162-5: - News? Well, I don't know - I do not think we have any. I'll tell you this, though - a lot of people keep wondering what kind of meat are they serving at the S…
    Loc162-6: - Say! I was going down from Shpick to Mow's Gas Station, when I suddenly felt very thirsty. So I turned to that lake over there. Drank some water from there, a…
    Loc162-7: - Say, chap, you remember this tricky-eyed driver named Rolan? They say, the Iroquois kidnapped him and demand that his wife returns the debt. I wouldn't care m…
    Loc162-8: - Let me yell you this one! This Peleng comes over to the Scorpion bar and drinks away all of his money there. And I mean he had at least 500! So - now he wants…
    Loc162-9: - I got some excellent news. The girls at Momma's Inn now - man, are they good! Super! You don't believe me? Go and see for yourself. You won't regret it I can …
    Loc162-10: - Hmmmm. News, you say? I can't think of anything right now. I'll tell you what, though. Just recently I had to invest all of my money into repairing my truck. …
    эффект: P29(x) = {2}
  -> Path503 => Loc161  вер=1 порядок=5
       текст: I see

### Loc163 [обычная]
    Loc163-1: - Glad that you asked! Just recently I found this cartridge. Looks like the one for a shotgun. Want to buy it from me for one gold piece?
    эффект: P29(x) = {2}
  -> Path505 => Loc161  вер=1 [всегда видна] порядок=1
       текст: He-he. Well come on, shoot!
       ответ: Completing the deal, you put the cartridge into your pocket, all proud of yourself.
       условия: логика {[p6]>0}
       эффект: P6(Money) = {[p6]-1}
       эффект: P7(Weapons) = {[p7]+1}
  -> Path506 => Loc161  вер=1 порядок=2
       текст: No, thank you

### Loc164 [обычная]
    выбор описания: {[p29]}
    Loc164-1: - What news are you talking about, man... - the trucker waved his hand. - I'm almost out of fuel. I don't even know how I will get to the point of destination. …
    Loc164-2: - That's robbery it is! Argh, whatever. I'll pay you [p33].
  -> Path508 => Loc161  вер=1 порядок=9
       текст: Sorry, comrade. I 'm afraid I can't afford it. Haven't got enough gas for myself.
       эффект: P29(x) = {2}
  -> Path509 => Loc161  вер=1 [всегда видна] порядок=1
       текст: Deal!
       ответ: You took the money, pumped off some gas from you truck and fuelled the trucker.
       условия: логика {[p11]>20000}
       эффект: P1(Time) +3
       эффект: P11(Fuel tank) = {[p11]-20000}
       эффект: P6(Money) = {[p6]+[p33]}
       эффект: P29(x) = {2}
  -> Path510 => Loc165  вер=100 [всегда видна] порядок=2
       текст: You are pulling my leg, right! I am not going to sell fuel for as little as {[p33]}
       условия: логика {([p11]>20000) and ((1 to 100)>(2*([p33]-20)))}
       эффект: P33(z2) = {[p33]+10}
  -> Path512 => Loc160  вер=1 [всегда видна] порядок=2
       текст: You are pulling my leg, right! I am not going to sell fuel for as little as {[p33]}
       ответ: Not wanting to bargain the driver stomped the accelerator, leaving a cloud of exhaust smoke behind him. One should not be too greedy - fact. With these thought …
       условия: логика {[p11]>20000}

### Loc165 [пустая]
  -> Path511 => Loc164  вер=1 порядок=5

### Loc166 [пустая]
    эффект: P29(x) = {2}
  -> Path514 => Loc161  вер=1 порядок=5
       текст: Next
       эффект: P29(x) = {2}

### Loc167 [обычная]
    выбор описания: {1+([p32]=5)}
    Loc167-1: - I am carrying a load of spinach. By the way, I could sell you a container for <clr>20<clrEnd> platinum pieces. Only, I hope this will remain between you and I…
    Loc167-2: - I am carrying a load of scrap metal. Oh, if you fell like it, I could sell you a couple of tons, at <clr>14<clrEnd> platinum pieces for each? I have this feel…
  -> Path516 => Loc169  вер=1 порядок=9
       текст: Not just now, thanks
  -> Path517 => Loc169  вер=1 порядок=1
       текст: Alright. Get that spinach over here
       условия: логика {([p32]=4) and ([p13]>=1) and ([p6]>=20)}
       эффект: P1(Time) +3
       эффект: P6(Money) = {[p6]-20}
       эффект: P13(Hold (free space)) -1
       эффект: P14(Spinach) +1
       эффект: P30(y) = {[p30]+10}
  -> Path518 => Loc169  вер=1 порядок=1
       текст: Two tons of scrap metal? Sure!
       условия: логика {([p32]=5) and ([p13]>=2) and ([p6]>=28)}
       эффект: P1(Time) +4
       эффект: P6(Money) = {[p6]-28}
       эффект: P13(Hold (free space)) -2
       эффект: P16(Scrap metal) +2
       эффект: P30(y) = {[p30]+10}
  -> Path519 => Loc169  вер=1 порядок=2
       текст: I'm good with just one ton
       условия: логика {([p32]=5) and ([p13]>=1) and ([p6]>=14)}
       эффект: P1(Time) +3
       эффект: P6(Money) = {[p6]-14}
       эффект: P13(Hold (free space)) -1
       эффект: P16(Scrap metal) +1
       эффект: P30(y) = {[p30]+10}

### Loc168 [обычная]
    Loc168-1: - Why not help a good lad? I could easily sell you some 15 litres for [p31].
    эффект: P29(x) = {2}
  -> Path523 => Loc161  вер=1 [всегда видна] порядок=1
       текст: Alright. Here's your [p31]
       ответ: You quickly pumped the gas into your fuel tank.
       условия: логика {[p6]>=[p31]}
       эффект: P1(Time) +3
       эффект: P11(Fuel tank) = {[p11]+15000}
       эффект: P6(Money) = {[p6]-[p31]}
       эффект: P30(y) = {[p30]+100}
  -> Path524 => Loc161  вер=1 порядок=9
       текст: That's kind of steep
       ответ: - Whatever, - the driver responded.

### Loc169 [пустая]
  -> Path522 => Loc161  вер=1 порядок=5
       эффект: P29(x) = {2}

### Loc170 [обычная]
    Loc170-1: - Well, I could take, say, three tons, [p33] for each.
    эффект: P29(x) = {2}
  -> Path528 => Loc161  вер=1 [всегда видна] порядок=2
       текст: Two tons, you're taking?
       ответ: - Sure! Bring'em on.
       условия: логика {[p15]>1}
       эффект: P1(Time) +4
       эффект: P6(Money) = {[p6]+2*[p33]}
       эффект: P13(Hold (free space)) +2
       эффект: P15(Coal) -2
  -> Path529 => Loc161  вер=1 [всегда видна] порядок=1
       текст: Alright. Take them three tons
       условия: логика {[p15]>2}
       эффект: P1(Time) +4
       эффект: P6(Money) = {[p6]+3*[p33]}
       эффект: P13(Hold (free space)) +3
       эффект: P15(Coal) -3
  -> Path530 => Loc161  вер=1 [всегда видна] порядок=3
       текст: I can only sell one ton
       ответ: - Deal.
       условия: логика {[p15]>0}
       эффект: P1(Time) +4
       эффект: P6(Money) = {[p6]+[p33]}
       эффект: P13(Hold (free space)) +1
       эффект: P15(Coal) -1
  -> Path533 => Loc161  вер=1 порядок=5
       текст: I reconsidered. I am not selling anything
       ответ: - Up to you, - the trucker answered.

### Loc171 [обычная]
    Loc171-1: - You know, I'd gladly by 2 tons of scrap metal, {[p33]} for each.
  -> Path532 => Loc161  вер=1 [всегда видна] порядок=1
       текст: I can only agree to one ton. Is that alright with you?
       ответ: - Well, whatever. Deal.
       условия: логика {[p16]>0}
       эффект: P1(Time) +4
       эффект: P6(Money) = {[p6]+[p33]}
       эффект: P13(Hold (free space)) +1
       эффект: P16(Scrap metal) -1
  -> Path534 => Loc161  вер=1 [всегда видна] порядок=2
       текст: Okay. Take them two tons
       условия: логика {[p16]>1}
       эффект: P1(Time) +5
       эффект: P6(Money) = {[p6]+2*[p33]}
       эффект: P13(Hold (free space)) +2
       эффект: P16(Scrap metal) -2
  -> Path535 => Loc161  вер=1 порядок=9
       текст: I reconsidered. I am not selling anything
       ответ: - Up to you, - the trucker answered.

### Loc172 [обычная]
    Loc172-1: - Hmmm. Spinach... I think I could buy one from you for, say, {[p33]}.
  -> Path538 => Loc161  вер=1 порядок=5
       текст: Deal. Take'em
       эффект: P1(Time) +3
       эффект: P6(Money) = {[p6]+[p33]}
       эффект: P13(Hold (free space)) +1
       эффект: P14(Spinach) -1
  -> Path539 => Loc161  вер=1 порядок=5
       текст: I changed my mind. No spinach sales

### Loc173 [пустая]
  -> Path544 => Loc114  вер=1 порядок=5
  -> Path545 => Loc114  вер=1000 порядок=5
       условия: логика {[p1]>=([p36]+12*60)}
       эффект: P19(Spinach reserve) = {[p19]+([p36] div (12*60))+(0 to 1)}
       эффект: P34(Spinach upgrade) = {[p1]}

### Loc174 [пустая]
  -> Path546 => Loc158  вер=1 порядок=5
       условия: логика {[p32]<=5}
  -> Path547 => Loc175  вер=1 порядок=5
       условия: логика {[p32]=6}
  -> Path552 => Loc177  вер=1 порядок=5
       условия: логика {[p32]=7}

### Loc175 [обычная]
    Loc175-1: There is a slightly rusted orange <clr>fuel-truck<clrEnd> running down the opposite lane. The truck is flashing its headlights, looks like the driver wants you …
  -> Path548 => Loc160  вер=1 порядок=2
       текст: Don't stop. Keep going
  -> Path549 => Loc176  вер=1 порядок=1
       текст: Stop
       эффект: P33(z2) = {10 to 16}

### Loc176 [обычная]
    Loc176-1: An unshaven face appeared from the window of the fuel-truck: /  / - Say, chief, I got some excess gasoline here - about {[p33]} l. I could sell it to you for 8 …
  -> Path550 => Loc160  вер=1 порядок=9
       текст: Not interested, understand. End of story!
       ответ: - Well, up to you. This was a good proposal, - with these words the fuel truck took off, and you continued about your business.
       эффект: P1(Time) +1
  -> Path551 => Loc160  вер=1 [всегда видна] порядок=1
       текст: Sure get that gas here now!
       ответ: Quickly pouring the oily liquid into your gas tank, the fuel truck driver took the money and waved you good bye. You started up the engine and went off too. Loo…
       условия: логика {([p6]>=8) and ([p11]<100000)}
       эффект: P1(Time) +3
       эффект: P11(Fuel tank) = {[p11]+[p33]*1000}
       эффект: P6(Money) = {[p6]-8}

### Loc177 [обычная]
    Loc177-1: You spotted a weird shaped vehicle drag along the opposite lane. <clr>It's appearance reminded you of a mid-sized baobab.<clrEnd> Only that it had wheels and a …
  -> Path553 => Loc160  вер=1 порядок=2
       текст: Don't stop. Keep going
  -> Path554 => Loc178  вер=1 порядок=1
       текст: Stop
       эффект: P29(x) = {1}

### Loc178 [обычная]
    выбор описания: {[p29]}
    Loc178-1: You quickly pulled over on the side of the road, but it still took the wheeled baobab a while to drag itself to your location. Finally he made it, and the monst…
    Loc178-2: The healer gave you a couple of tiny stumps. Having gnawed both of them, you felt an avalanche of energy run right through you. Your head started spinning, and …
    Loc178-3: The self-made Aesculapius produced a three litre jar and took out huge bluish eye, gel substance drooping from it. Without giving it a second thought you picked…
    Loc178-4: The stew was very thick and it took you some time to finish the cup. But it was indeed very satiating and livening.  / - Anything else? - the geezer asked. /  /…
    Loc178-5: Having eaten the fly you did not fell anything. / - What the hell was that! - you shouted in proper rage. / - What did you expect, wheeler? - the healer answere…
    эффект: P1(Time) +1
  -> Path555 => Loc179  вер=1 [всегда видна] порядок=1
       текст: Hmmmm.... I think I'll take the Snatcher legs
       условия: логика {([p6]>=30) and ([p3]<100)}
       эффект: P3(Energy) = {[p3]+(45 to 60)}
       эффект: P6(Money) = {[p6]-30}
       эффект: P29(x) = {2}
  -> Path556 => Loc179  вер=1 [всегда видна] порядок=2
       текст: Alright, gimme that eye
       условия: логика {([p6]>=15) and ([p4]<100000)}
       эффект: P1(Time) +10
       эффект: P3(Energy) = {[p3]-(7 to 13)}
       эффект: P4(Tiredness) = {100000}
       эффект: P6(Money) = {[p6]-15}
       эффект: P29(x) = {3}
  -> Path557 => Loc179  вер=1 [всегда видна] порядок=3
       текст: Well, whatever, let me try the stew
       условия: логика {([p6]>=20) and ([p5]<100000)}
       эффект: P3(Energy) = {[p3]+(7 to 13)}
       эффект: P4(Tiredness) = {[p4]+(20000 to 30000)}
       эффект: P5(Hunger) = {100000}
       эффект: P6(Money) = {[p6]-20}
       эффект: P29(x) = {4}
  -> Path558 => Loc179  вер=1 [всегда видна] порядок=4
       текст: Give me that Zhbanish fly!
       условия: логика {([p6]>=5)}
       эффект: P5(Hunger) = {[p5]+5000}
       эффект: P6(Money) = {[p6]-5}
       эффект: P29(x) = {5}
  -> Path560 => Loc160  вер=1 порядок=9
       текст: Say goodbye to the healer and go off

### Loc179 [пустая]
  -> Path559 => Loc178  вер=1 порядок=5

### Loc180 [пустая]
  -> Path572 => Loc101  вер=1000 порядок=5
       ответ: Your mighty hit threw the assailant's car to the side, one of his wheels broke off, the vehicle skidded and hurled over three times. After which the iron tin of…
       условия: логика {[p18]=0}
  -> Path573 => Loc103  вер=1 порядок=5

### Loc181 [обычная]
  -> Path574 => Loc34  вер=1000 порядок=5
       ответ: Your mighty hit threw the assailant's car to the side. The unsteady SUV ran on two wheels for some time, and for a second it even looked that they just might ma…
       условия: логика {[p18]=0}
  -> Path575 => Loc33  вер=1 порядок=5

### Loc182 [обычная]
    Loc182-1: Not far from the sheriff's estate you spotted two cars standing across the road and blocking it completely. Well, looks like you do not have any other choice bu…
    Loc182-2: Not far from the sheriff's estate you spotted two cars standing across the road and blocking it completely. Well, looks like you do not have any other choice bu…
    Loc182-3: Not far from the sheriff's estate you spotted two cars standing across the road and blocking it completely. Well, looks like you do not have any other choice bu…
    Loc182-4: Not far from the sheriff's estate you spotted two cars standing across the road and blocking it completely. Well, looks like you do not have any other choice bu…
    Loc182-5: Not far from the sheriff's estate you spotted two cars standing across the road and blocking it completely. Well, looks like you do not have any other choice bu…
  -> Path578 => Loc148  вер=1 [всегда видна] порядок=5
       текст: Pay a fine of [p37] platinum pieces
       условия: логика {[p6]>=[p37]}
       эффект: P6(Money) = {[p6]-[p37]}
       эффект: P37(Fines) = 0
  -> Path579 => Loc148  вер=1 порядок=6
       текст: Go to the penalty lot

### Loc183 [пустая]
  -> Path581 => Loc45  вер=2 порядок=5
       ответ: Leaving your truck at the penalty lot you went off to talk to the sheriff. The sheriff spent a long time reviewing the reports of his subordinates, heard your s…
       условия: P16(Scrap metal) 1..20
       эффект: P1(Time) = {[p1]+[45..75]}
       эффект: P4(Tiredness) = {[p4]-[p24]*60}
       эффект: P5(Hunger) = {[p5]-[p23]*60}
       эффект: P16(Scrap metal) -1
       эффект: P13(Hold (free space)) +1
  -> Path582 => Loc45  вер=1 порядок=5
       ответ: Leaving your truck at the penalty lot you went off to talk to the sheriff. Unfortunately the sheriff was too busy and could only receive you <clr>in two hours<c…
       эффект: P1(Time) = {[p1]+[165..175]}
       эффект: P4(Tiredness) = {[p4]-[p24]*170}
       эффект: P5(Hunger) = {[p5]-[p23]*170}
  -> Path583 => Loc45  вер=1 порядок=5
       ответ: Leaving your truck at the penalty lot you went off to talk to the sheriff. The sheriff decided to be serious about it: he studied the detailed reports of his su…
       условия: P9(Truck armour) 70..100
       эффект: P1(Time) = {[p1]+[105..135]}
       эффект: P4(Tiredness) = {[p4]-[p24]*120}
       эффект: P5(Hunger) = {[p5]-[p23]*120}
       эффект: P9(Truck armour) = {[p9]-[10..15]}
  -> Path588 => Loc45  вер=2 порядок=5
       ответ: Leaving your truck at the penalty lot you went off to talk to the sheriff. Fortunately enough, the sheriff was free, and the entire investigation took <clr>less…
       условия: P14(Spinach) 1..20
       эффект: P1(Time) = {[p1]+[35..55]}
       эффект: P4(Tiredness) = {[p4]-[p24]*40}
       эффект: P5(Hunger) = {[p5]-[p23]*40}
       эффект: P14(Spinach) -1
       эффект: P13(Hold (free space)) +1

### Loc184 [обычная]
    Loc184-1: You took the map out of the glove compartment and studied it. Right, where are we now? /  / LEGEND: / 1) Scorpion Bar / 2) Abandoned rubidium mines / 3) Dump Si…
    Loc184-2: Time to take a look at the map! You took it out of the glove compartment and tried to find out where you were at the moment. /  / LEGEND: / 1) Scorpion Bar / 2)…
    Loc184-3: Good that you had a map in the glove compartment! Otherwise you would have gotten lost in this place... /  / LEGEND: / 1) Scorpion Bar / 2) Abandoned rubidium m…
    Loc184-4: You took out the map - gotta clear out some geographic nuances! /  / LEGEND: / 1) Scorpion Bar / 2) Abandoned rubidium mines / 3) Dump Site (ex-military base) /…
    Loc184-5: You took out the map and quickly found your current location. So where do we go from here? /  / LEGEND: / 1) Scorpion Bar / 2) Abandoned rubidium mines / 3) Dum…
    эффект: P1(Time) +1
  -> Path603 => Loc148  вер=1 порядок=5
       текст: Next

## Анализ
- стартовых: [1]
- концовки: {8: 'ПРОВАЛ', 97: 'СМЕРТЬ', 106: 'СМЕРТЬ', 122: 'УСПЕХ', 153: 'СМЕРТЬ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
