# Квест (формат 1111111126)
Сложность 20; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'time' [1..60] тип=смерть
    старт: [25]
    [1..10] Morning
    [11..20] Day
    [21..30] Evening
    [31..40] Night
    [41..50] Night (you feel sleepy)
    [51..60] Night (<clr>you feel very sleepy!!!<clrEnd>)
    критическое: You were so tired, that you fell asleep right where you were standing. The guards thought you were a…
- P2 'Fest' [0..3] тип=обычный
    старт: [3]
    [0..0] The gig is today
    [1..1] <> days left till the gig
    [2..3] <> days left till the gig
    критическое: Не знаю, где вы шлялись, но концерт уже прошел. Вы не оправдали возложенных на вас надежд и теперь с…
- P3 'Money' [0..5000] тип=обычный
    старт: [1200]
    [0..0] No money
    [1..5000] Money: <> rockarollars
    критическое: Сообщение достижения критического значения параметром 1
- P4 'Mood' [0..20] тип=обычный
    старт: [5]
    [0..2] Your mood sucks big time
    [3..5] Your mood sucks
    [6..10] You are not in your best mood
    [11..15] You are in a good mood
    [16..20] Your mood is killer
    критическое: У вас совершенно не было настроения, для каких-либо действий. Оставшиеся дни вы просто провалялись в…
- P5 'Drunkenness' [0..5] тип=смерть
    старт: [0]
    [0..0] You're sober
    [1..1] You are a bit tipsy
    [2..2] You are a bit drunk
    [3..3] You're drunk
    [4..4] You're hammered
    [5..5] You passed out
    критическое: You got drunk and went for a walk about the city. Maybe, if you had not been screaming something lik…
- P6 'Dragon tattoo' [0..3] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You don't have a Dragon tat
    [2..2] You have a guitar tat
    [3..3] You have dragon and guitar tats
    критическое: Вы так устали, что уснули прямо здесь. Наутро вас подобрала полиция и привела вас в участок, с прось…
- P7 'Piercing' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You ear is pierced
    критическое: Сообщение достижения критического значения параметром 4
- P8 'Line' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 12
- P9 'Singer' [0..3] тип=обычный
    старт: [1]
    [0..0] You suck as a singer
    [1..1] You are an average singer
    [2..2] You're a good singer
    [3..3] You're a killer singer
    критическое: Сообщение достижения критического значения параметром 7
- P10 'Guitarist' [0..4] тип=обычный
    старт: [0]
    [0..0] NO Guitarist
    [1..1] The guitarist sucks
    [2..2] The guitarist is average
    [3..3] The guitarist is good
    [4..4] The guitarist is killer
    критическое: Сообщение достижения критического значения параметром 8
- P11 'Keyboardist' [0..4] тип=обычный
    старт: [0]
    [0..0] NO keyboardist
    [1..1] The keyboardist sucks
    [2..2] The keyboardist is average
    [3..3] The keyboardist is good
    [4..4] The keyboardist is killer
    критическое: Сообщение достижения критического значения параметром 9
- P12 'Bass-player' [0..4] тип=обычный
    старт: [0]
    [0..0] NO bass-player
    [1..1] The bass-player sucks
    [2..2] The bass-player is average
    [3..3] The bass-player is good
    [4..4] The bass-player is killer
    критическое: Сообщение достижения критического значения параметром 10
- P13 'Drummer' [0..4] тип=обычный
    старт: [0]
    [0..0] NO drummer
    [1..1] The drummer sucks
    [2..2] The drummer is average
    [3..3] The drummer is good
    [4..4] The drummer is killer
    критическое: Сообщение достижения критического значения параметром 18
- P14 'Band skill' [0..140] тип=обычный
    старт: [0]
    [0..20] Band sound: sucks
    [21..50] Band sound: average
    [51..80] Band sound: good
    [81..100] Band sound: killer
    [101..139] Band sound: super
    [140..140] Band sound: unique!!!
    критическое: Сообщение достижения критического значения параметром 6
- P15 'rehearsal in the studio' [0..18] тип=обычный
    старт: [0]
    [0..18] You have:
    критическое: Сообщение достижения критического значения параметром 13
- P16 'Sticks' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Drumsticks
    [2..2] 
- P17 'Strings' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Guitar strings
    [2..2] 
    критическое: Сообщение достижения критического значения параметром 14
- P18 'Book as a present' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Book of poems
    [2..2] 
    критическое: Сообщение достижения критического значения параметром 3
- P19 'A song order' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Three minute song
    [2..2] Five minute song
    [3..3] Six minute song
    [4..4] Seven minute song
    критическое: Сообщение достижения критического значения параметром 11
- P20 'Participation request' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 23
- P21 'A book on "Good Manners"' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You know the rules of etiquette
    критическое: Сообщение достижения критического значения параметром 22
- P22 'Keyboardist (you know about him)' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] The keyboardist frequents the pool room
    критическое: Сообщение достижения критического значения параметром 2
- P25 'Pool skills' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] You know how to play pool
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Flags' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..4] 
    критическое: Сообщение достижения критического значения параметром 27
- P29 'Time on stage' [0..420] тип=обычный
    старт: [0]
    [0..420] {[p29] div 60} min. {[p29] mod 60} sec. left
    критическое: Сообщение достижения критического значения параметром 37
- P30 'performance book' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 30
- P32 'r. with guitar' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 32
- P33 'r. with bass' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 33
- P34 'r. with keyboards' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 34
- P35 'r. with drums' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 35
- P36 'r. with vocals' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 36
- P39 'Performance' [0..500] тип=обычный
    старт: [0]
    [0..500] Audience appraisal: <>
    критическое: Сообщение достижения критического значения параметром 15
- P40 'Alumminica' [0..500] тип=обычный
    старт: [0]
    [0..500] Alumminica scores: <>
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Pink Asteroid' [0..500] тип=обычный
    старт: [0]
    [0..500] Pink Asteroid scores: <>
    критическое: Сообщение достижения критического значения параметром 41
- P42 'Drink 182' [0..500] тип=обычный
    старт: [0]
    [0..500] Drink 182 scores: <>
    критическое: Сообщение достижения критического значения параметром 42
- P45 'Music' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 45
- P46 'y' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Box' [0..10] тип=обычный
    старт: [5]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 47
- P48 'x' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: When you landed on the planet of <ToPlanet> it was late in the evening already. The security check did not take long, they asked you about the purpose of your v…
    эффект: P1(time) = 1
    эффект: P48(x) = 1
    скрыт: P2,P3,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P16,P17,P18,P19,P20,P21,P23,P24,P25,P26,P27,P29,P30,P31,P32,P33,P34,P35,P36,P39,P40,P41,P42
    показ: P22
  -> Path452 => Loc62  вер=1 порядок=5
       текст: Lazily wake up
       эффект: P1(time) = 1

### Loc62 [обычная]
    выбор описания: {[p48]}
    Loc62-1: You are in your room, furnished in the traditional Human <clr>"quick-and-dirty"<clrEnd> manner, very fashionable these days. The huge window overlooks the main …
    Loc62-2: Lazily you got out of bed, went to the shower, after which you had a stuffy breakfast sitting on the sofa and watching the stereovision.
    Loc62-3: You were so tired that you fell asleep right where you were standing. Most naturally this did not improve your mood much, but it least it was in a hotel, not ou…
    Loc62-4: You went back to the hotel. Passing through a long corridor, you found yourself in a small but rather cosy room.
    Loc62-5: Boy is it nice to have some rest when you know all business has been taken care of! So you spent the rest of the day and night lying in your room, watching the …
    Loc62-6: You lied in your room till it was dark. After all big city nights offer a completely different life!
    показ: P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P15,P16,P17,P18,P19,P20,P21,P25,P26,P28
    скрыт: P23,P30,P39
  -> Path109 => Loc64  вер=1 порядок=1
       текст: To the main square
       условия: P2(Fest) 1..3
  -> Path118 => Loc73  вер=1 порядок=5
       текст: Turn on the laptop
       условия: P2(Fest) 1..3
  -> Path167 => Loc99  вер=1 порядок=8
       текст: Sleep
       условия: P1(time) 31..59
       эффект: P48(x) = 2
  -> Path290 => Loc301  вер=1 проходов<=1
       текст: Today is the gig! Go to the stadium
       условия: P2(Fest) 0..0; P20(Participation request) 1..1
  -> Path701 => Loc302  вер=1 порядок=5
       текст: You did not check in on the festival bill! Now you will have to leave the planet
       условия: P2(Fest) 0..0; P20(Participation request) 0..0
  -> Path739 => Loc99  вер=1
       текст: Everything's ready! Now you can have some good rest before the gig
       условия: P1(time) 1..30; P2(Fest) 1..3; P20(Participation request) 1..1
       эффект: P4(Mood) +5
       эффект: P48(x) = 5
  -> Path743 => Loc301  вер=1 проходов<=1
       текст: Today is the gig day! Go to the stadium having a bottle of warm-up beer
       условия: P2(Fest) 0..0; P20(Participation request) 1..1
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) = {[p4]+[3..5]}
  -> Path763 => Loc312  вер=1 порядок=9
       текст: Send it all to hell and leave
       условия: P2(Fest) 1..3
  -> Path765 => Loc313  вер=1 порядок=8
       текст: Wait for the night
       условия: P1(time) 1..30; P2(Fest) 1..3
       эффект: P1(time) = 31

### Loc64 [пустая]
    Loc64-1: You are standing in the main square of planet <ToPlanet>. As usual it is rather crowded in the square, with the absolute majority of folks being Humans.  /  / B…
    показ: P6,P7,P16,P18,P19,P21,P22,P25,P26,P30
  -> Path111 => Loc66  вер=1 порядок=1
       текст: To the studio
       условия: P1(time) 1..30; P20(Participation request) 0..0
       эффект: P1(time) +5
  -> Path113 => Loc68  вер=1 порядок=5
       текст: To the rock-club
       условия: P1(time) 1..30; P13(Drummer) 0..0; P23(Барабанщик (если нанять)) 0..0; P26(Flags) 0..1
       эффект: P1(time) +5
  -> Path116 => Loc71  вер=1 порядок=2
       текст: To the long-street
       условия: P1(time) 1..30; P10(Guitarist) 0..0
       эффект: P1(time) +5
  -> Path169 => Loc62  вер=1
       текст: To the hotel
       эффект: P48(x) = 4
  -> Path337 => Loc168  вер=1 порядок=4
       текст: To the pub
       условия: P1(time) 31..59
       эффект: P1(time) +5
  -> Path393 => Loc196  вер=1 порядок=9
       текст: To the tattoo-parlour
       условия: P1(time) 1..30; P7(Piercing) 0..0
       эффект: P1(time) +5
  -> Path515 => Loc78  вер=1 порядок=5
       текст: To the pool-room
       условия: P1(time) 31..59
       эффект: P1(time) +5
  -> Path672 => Loc196  вер=1 порядок=5
       текст: To the tattoo-parlour
       условия: P1(time) 1..30; P6(Dragon tattoo) 0..2
       эффект: P1(time) +5
  -> Path673 => Loc196  вер=1 порядок=5
       текст: To the tattoo-parlour
       условия: P1(time) 1..30; P22(Keyboardist (you know about him)) 0..0
       эффект: P1(time) +5
  -> Path715 => Loc65  вер=1 порядок=5
       текст: To the pub
       условия: P1(time) 1..30
       эффект: P1(time) +5
  -> Path716 => Loc66  вер=1 порядок=5
       текст: To the studio
       условия: P1(time) 1..30; P19(A song order) 0..0
       эффект: P1(time) +5
  -> Path717 => Loc66  вер=1 порядок=5
       текст: To the studio
       условия: P1(time) 1..30; P15(rehearsal in the studio) 0..17
       эффект: P1(time) +5
  -> Path754 => Loc167  вер=1 порядок=5
       текст: To the rock-club
       условия: P1(time) 1..30; P13(Drummer) 0..0; P23(Барабанщик (если нанять)) 0..0; P26(Flags) 2..4
       эффект: P1(time) +5
       эффект: P48(x) = 5

### Loc65 [пустая]
    выбор описания: {(2*([p26] div 2)<>[p26])+1}
    Loc65-1: During the daytime the pub is quite crowded, some people would watch hatch-ball cheering and chanting loudly, others would just relax, kicking back on the sofas…
    Loc65-2: During the daytime the pub is quite crowded, some people would watch hatch-ball cheering and chanting loudly, others would just relax, kicking back on the sofas…
  -> Path179 => Loc64  вер=1 порядок=9
       текст: Back to the square
  -> Path230 => Loc123  вер=1 [всегда видна] порядок=5
       текст: Have a drink (40 rockarollars)
       условия: P3(Money) 40..5000
       эффект: P3(Money) -40
  -> Path381 => Loc195  вер=1 порядок=5
       текст: Walk over to the Gaalian
       условия: P26(Flags) кратно[2]

### Loc66 [пустая]
    Loc66-1: You are standing in the middle of a large studio. Here you can record a song or hold a rehearsal.  /  / - Can I help you? - asked a Peleng behind the counter.
  -> Path130 => Loc85  вер=1 порядок=2
       текст: Buy a song
       условия: P19(A song order) 0..0
  -> Path190 => Loc64  вер=1 порядок=9
       текст: Back to the square
  -> Path269 => Loc137  вер=1 проходов<=1 порядок=5
       текст: Check in to the fest
       условия: P9(Singer) 1..3; P10(Guitarist) 1..4; P11(Keyboardist) 1..4; P12(Bass-player) 1..4; P13(Drummer) 1..4; P19(A song order) 1..4; P20(Participation request) 0..0
       показ: P14
  -> Path434 => Loc214  вер=1 порядок=3
       текст: Rehearse
       условия: P20(Participation request) 1..1; логика {([p9]<3) or ([p10]<4) or ([p11]<4) or ([p12]<4) or ([p13]<4) or ([p14]<140)}
       эффект: P1(time) +1
       эффект: P48(x) = 1

### Loc68 [обычная]
    Loc68-1: You walked over to the rock-club, when a Maloq bouncer with piercing all over his face blocked your way. / - Hey dude, the place is closed, get lost, or you wan…
  -> Path336 => Loc167  вер=1 порядок=5
       текст: I wanted to hire me a musician
       эффект: P26(Flags) +2
       эффект: P48(x) = 1
  -> Path368 => Loc64  вер=1 порядок=9
       текст: No, nothing

### Loc71 [обычная]
    Loc71-1: You approached a travelling musician who was playing the guitar and singing. Looks like he is getting good money out of this (judging by his expensive custom-ma…
  -> Path176 => Loc64  вер=1 порядок=6
       текст: Back to the square
  -> Path186 => Loc107  вер=1 проходов<=10 порядок=5
       текст: Invite to join the band
       условия: P6(Dragon tattoo) 1..3; P17(Strings) 1..2
  -> Path720 => Loc305  вер=1 проходов<=1 порядок=5
       текст: Invite to join the band
       условия: P6(Dragon tattoo) 1..3; P17(Strings) 0..0
  -> Path721 => Loc77  вер=1 порядок=5
       текст: Invite to join the band
       условия: P6(Dragon tattoo) 0..0; P17(Strings) 1..2
  -> Path722 => Loc77  вер=1 порядок=5
       текст: Invite to join the band
       условия: P6(Dragon tattoo) 0..0; P17(Strings) 0..0

### Loc73 [пустая]
    Loc73-1: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees /  / Latest news:  / <clr>So…
    Loc73-2: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees /  / Latest news:  / <clr>Pi…
    Loc73-3: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees /  / Latest news:  / <clr>A …
    Loc73-4: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <clr>…
    Loc73-5: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <clr>…
    Loc73-6: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <clr>…
    Loc73-7: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <clr>…
    Loc73-8: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <ToPl…
    Loc73-9: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees /  / Latest news:  / <clr>Se…
    Loc73-10: Laptop <clr>Inter Dendium 5<clrEnd> /  / Today is <CurDate> /  / Days before gig: [p2] /  / Temperature outside: {[16..18]} degrees   /  / Latest news:  / <clr>…
  -> Path138 => Loc93  вер=1 порядок=3
       текст: Musician search (5 rockarollars)
       условия: P3(Money) 5..5000; P11(Keyboardist) 0..0
       эффект: P3(Money) -5
  -> Path148 => Loc62  вер=1 порядок=9
       текст: Turn off the laptop
  -> Path426 => Loc210  вер=1 порядок=5
       текст: Library
       условия: логика {([p21]=0) or ([p18]=0) or ([p30]<2) or ([p25]=0)}
       эффект: P48(x) = 1
  -> Path440 => Loc237  вер=1 порядок=6
       текст: Mailbox
       эффект: P48(x) = {1}
  -> Path517 => Loc248  вер=1 порядок=4
       текст: Search musical instruments (5 rockarollars)
       условия: P3(Money) 5..5000; P16(Sticks) 0..0
       эффект: P3(Money) -5
  -> Path545 => Loc248  вер=1 порядок=4
       текст: Search musical instruments (5 rockarollars)
       условия: P3(Money) 5..5000; P17(Strings) 0..0
       эффект: P3(Money) -5
  -> Path708 => Loc93  вер=1 порядок=3
       текст: Musician search (5 rockarollars)
       условия: P3(Money) 5..5000; P12(Bass-player) 0..0
       эффект: P3(Money) -5
  -> Path709 => Loc93  вер=1 порядок=3
       текст: Musician search (5 rockarollars)
       условия: P3(Money) 5..5000; P13(Drummer) 0..0
       эффект: P3(Money) -5
  -> Path710 => Loc93  вер=1 порядок=3
       текст: Musician search (5 rockarollars)
       условия: P3(Money) 5..5000; P10(Guitarist) 0..0
       эффект: P3(Money) -5

### Loc75 [обычная]
    Loc75-1: Search finished. /  / No musicians available at this time.
  -> Path142 => Loc93  вер=1 порядок=1
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path143 => Loc73  вер=1 порядок=2
       текст: Cancel

### Loc77 [обычная]
    Loc77-1: - You don't look cool, you don't even have any <clr>tattoos<clrEnd>, - the guitarist said and did not pay any more attention to you.
  -> Path554 => Loc64  вер=1 порядок=5
       текст: Back to the square

### Loc78 [пустая]
    выбор описания: {[p25]+1}
    Loc78-1: You found yourself in a large room. The music is playing accompanied by the sound of knocking billiard-balls. Too bad that you are <clr>a poor pool-player<clrEn…
    Loc78-2: You found yourself in a large room. The music is playing accompanied by the sound of knocking billiard-balls. Thanks to the <clr>book you read<clrEnd>, you now …
    эффект: P24(Посетил бильярд) = 1
  -> Path221 => Loc118  вер=2 [всегда видна] порядок=5
       текст: Put a stake (50 rockarollars)
       условия: P3(Money) 50..5000; P25(Pool skills) 1..1
       эффект: P3(Money) = {[p3]-50}
  -> Path409 => Loc203  вер=1 проходов<=1 порядок=8
       текст: Look for a keyboardist
       условия: P2(Fest) 2..2; P11(Keyboardist) 0..0; P22(Keyboardist (you know about him)) 1..1
  -> Path516 => Loc64  вер=1 порядок=9
       текст: Back to the square
  -> Path557 => Loc332  вер=2 порядок=5
       текст: Put a stake (50 rockarollars)
       условия: P3(Money) 50..5000; P25(Pool skills) 0..0
       эффект: P3(Money) = {[p3]-50}
  -> Path705 => Loc118  вер=1 порядок=5
       текст: Put a stake (50 rockarollars)
       условия: P3(Money) 50..5000; P25(Pool skills) 0..0
       эффект: P3(Money) = {[p3]-50}
  -> Path718 => Loc120  вер=1 порядок=5
       текст: Put a stake (50 rockarollars)
       условия: P3(Money) 50..5000; P25(Pool skills) 1..1
       эффект: P3(Money) = {[p3]-50}
  -> Path755 => Loc118  вер=1 порядок=5
       текст: Put a stake (50 rockarollars)
       условия: P3(Money) 50..5000; P5(Drunkenness) 3..4
       эффект: P3(Money) = {[p3]-50}
  -> Path758 => Loc203  вер=1 проходов<=1 порядок=8
       текст: Look for a keyboardist
       условия: P2(Fest) 1..1; P11(Keyboardist) 0..0; P22(Keyboardist (you know about him)) 1..1
  -> Path832 => Loc203  вер=1 проходов<=1 порядок=8
       текст: Look for a keyboardist
       условия: P2(Fest) 3..3; P11(Keyboardist) 0..0; P22(Keyboardist (you know about him)) 1..1

### Loc85 [обычная]
    Loc85-1: Of course you could sing some old song from your old repertoire. But then again you could ask a professional to right a better and a longer one for you. So what…
  -> Path252 => Loc66  вер=1 [всегда видна] порядок=2
       текст: 50 rockarollars (5 minutes)
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P19(A song order) = 2
  -> Path648 => Loc66  вер=1 [всегда видна] порядок=4
       текст: 150 rockarollars (7 minutes)
       условия: P3(Money) 150..5000
       эффект: P3(Money) -150
       эффект: P19(A song order) = 4
  -> Path695 => Loc66  вер=1 [всегда видна] порядок=3
       текст: 100 rockarollars (6 minutes)
       условия: P3(Money) 100..5000
       эффект: P3(Money) -100
       эффект: P19(A song order) = 3
  -> Path696 => Loc66  вер=1 порядок=1
       текст: Your own (3 minutes, but it's free)
       эффект: P19(A song order) = 1
  -> Path737 => Loc66  вер=1 порядок=9
       текст: Buy a song later

### Loc93 [пустая]
    Loc93-1: Suddenly you felt you were losing consciousness. You really shouldn't be spending so much time at the computer, you know? It's unhealthy!
    эффект: P1(time) +1
  -> Path120 => Loc75  вер=3 порядок=5
  -> Path144 => Loc94  вер=1 порядок=5
       условия: P13(Drummer) 0..0
       эффект: P48(x) = {[1..3]}
  -> Path502 => Loc242  вер=1 порядок=5
       условия: P10(Guitarist) 0..0
       эффект: P48(x) = {[1..3]}
  -> Path661 => Loc298  вер=1 порядок=5
       условия: P11(Keyboardist) 0..0
       эффект: P48(x) = {[1..3]}
  -> Path662 => Loc299  вер=1 порядок=5
       условия: P12(Bass-player) 0..0
       эффект: P48(x) = {[1..3]}
  -> Path730 => Loc307  вер=1 порядок=5
       текст: Next
       условия: P1(time) 60..60
       эффект: P1(time) = 1

### Loc94 [обычная]
    выбор описания: {[p48]}
    Loc94-1: Search complete. /  / Found <clr>1<clrEnd> musician: / Instrument: <clr>Drums<clrEnd> / Musicianship: <clr>poor<clrEnd> / Start-up fee: <clr>200<clrEnd> rockaro…
    Loc94-2: Search complete. /  / Found <clr>1<clrEnd> musician: / Instrument: <clr>Drums<clrEnd> / Musicianship: <clr>average<clrEnd> / Start-up fee: <clr>300<clrEnd> rock…
    Loc94-3: Search complete. /  / Found <clr>1<clrEnd> musician: / Instrument: <clr>Drums<clrEnd> / Musicianship: <clr>good<clrEnd> / Start-up fee: <clr>400<clrEnd> rockaro…
  -> Path145 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path147 => Loc93  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path735 => Loc73  вер=1 [всегда видна]
       текст: Hire
       условия: логика {[p3]>=([p48]*100+100)}
       эффект: P3(Money) = {[p3]-[p48]*100-100}
       эффект: P13(Drummer) = {[p48]}

### Loc99 [пустая]
    эффект: P1(time) = 1
    эффект: P2(Fest) -1
  -> Path168 => Loc62  вер=1 порядок=5
       эффект: P5(Drunkenness) = 0
       эффект: P4(Mood) = {[p4]-[p5]}

### Loc107 [обычная] визитов<=10
    Loc107-1: - Hey, cool strings, and I like your tat too, when did you make it? Well, if you are interested I could join your band, how's that?
    Loc107-2: - Did you give it a thought? Are you taking me in?
    Loc107-3: - Did you give it a thought? Are you taking me in?
    Loc107-4: - Did you give it a thought? Are you taking me in?
    Loc107-5: - Did you give it a thought? Are you taking me in?
    Loc107-6: - Did you give it a thought? Are you taking me in?
    Loc107-7: - Did you give it a thought? Are you taking me in?
    Loc107-8: - Did you give it a thought? Are you taking me in?
    Loc107-9: - Did you give it a thought? Are you taking me in?
    Loc107-10: - Did you give it a thought? Are you taking me in?
    скрыт: P17
  -> Path187 => Loc64  вер=1 порядок=3
       текст: You're in
       эффект: P10(Guitarist) = 2
       эффект: P17(Strings) +1
  -> Path724 => Loc64  вер=1 порядок=5
       текст: No I am not taking you

### Loc118 [пустая]
    эффект: P1(time) +2
  -> Path226 => Loc78  вер=1 порядок=5
       ответ: Congratulations - you've returned your stake and won {50} rockarollars!!!
       эффект: P3(Money) = {[p3]+100}
  -> Path756 => Loc78  вер=1 порядок=5
       ответ: Congratulations, you returned your stake and won {50} rockarollars!!! Looks like it's true what they say about <clr>drunks<clrEnd> being lucky!
       условия: P5(Drunkenness) 3..4
       эффект: P3(Money) = {[p3]+100}
  -> Path757 => Loc78  вер=1 порядок=5
       ответ: Congratulations, you returned your stake and won {50} rockarollars!!! That's what reading a <clr>book about pool<clrEnd> can do.
       условия: P25(Pool skills) 1..1
       эффект: P3(Money) = {[p3]+100}

### Loc120 [пустая]
    эффект: P1(time) +2
  -> Path225 => Loc78  вер=1 порядок=5
       ответ: Alas, your guess about that player was wrong and he <clr>lost<clrEnd>, and so did you.

### Loc123 [пустая]
  -> Path335 => Loc65  вер=1 порядок=5
       ответ: The bartender handed your drink to you and turned to the next customer. Right a living human being, and behaves like a robot...  /  / You drank a glass of stron…
       эффект: P1(time) +1
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) +2

### Loc137 [пустая] визитов<=1
    показ: P14
  -> Path270 => Loc66  вер=1 проходов<=1 порядок=5
       ответ: You checked in to participate in the concert and they put you on the bill. Now it's time to do some practising!
       эффект: P20(Participation request) +1

### Loc140 [обычная]
    Loc140-1: The stadium was crowded. Each spectator had a special voting device, which allowed them to give marks to each of the bands on stage. They than calculated a mean…
  -> Path694 => Loc150  вер=1 порядок=5
       текст: Go on stage
       эффект: P39(Performance) = {[p39]+[p14]/[5..7]}

### Loc150 [пустая]
    Loc150-1: You are on stage. There is a huge crowd around and everyone is shouting something incoherent. Got to do something about it.
    скрыт: P1,P2,P3,P7,P15,P16,P17,P18,P19,P21
    показ: P14,P28,P29,P39
  -> Path593 => Loc271  вер=1 проходов<=9 порядок=3
       текст: Music actions
       условия: P29(Time on stage) 25..420; P37(репетиция действ.) 1..1; P38(р.) 1..1
       эффект: P45(Music) = 0
  -> Path596 => Loc333  вер=4 проходов<=8 порядок=6
       текст: Show
       условия: P29(Time on stage) 25..420; P45(Music) 5..10
       эффект: P45(Music) +2
       эффект: P39(Performance) = {[p39]-[7..12]}
       эффект: P48(x) = 10
  -> Path657 => Loc291  вер=1 [всегда видна] порядок=9
       текст: Finish the gig
       условия: P29(Time on stage) 0..30
  -> Path769 => Loc334  вер=3 проходов<=7 порядок=5
       текст: Special effects
       условия: P29(Time on stage) 13..420; P45(Music) 3..7
       эффект: P45(Music) +1
       эффект: P48(x) = {9}
  -> Path810 => Loc333  вер=2 проходов<=8 порядок=6
       текст: Show
       условия: P29(Time on stage) 25..420; P45(Music) 0..4
       эффект: P45(Music) +2
       эффект: P48(x) = {[0..8]}
  -> Path811 => Loc333  вер=3 проходов<=8 порядок=6
       текст: Show
       условия: P29(Time on stage) 25..420; P45(Music) 3..7
       эффект: P45(Music) +2
       эффект: P39(Performance) = {[p39]-[3..7]}
       эффект: P48(x) = 9
  -> Path813 => Loc334  вер=2 проходов<=7 порядок=5
       текст: Special effects
       условия: P29(Time on stage) 13..420; P45(Music) 0..4
       эффект: P45(Music) +1
       эффект: P48(x) = {[0..8]}
  -> Path814 => Loc334  вер=4 проходов<=7 порядок=5
       текст: Special effects
       условия: P29(Time on stage) 13..420; P45(Music) 5..10
       эффект: P45(Music) +1
       эффект: P48(x) = 10

### Loc152 [пустая] визитов<=1
  -> Path312 => Loc150  вер=1 порядок=5
       ответ: You decided to follow the example of the dude from this popular band called "Rock Hard Chilly Peppers", who would undress completely at each gig. But while this…
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path313 => Loc150  вер=3 порядок=5
       ответ: You decided to follow the example of the dude from this popular band called "Rock Hard Chilly Peppers", who would undress completely at each gig. You threw off …
       условия: P6(Dragon tattoo) 1..3
       эффект: P4(Mood) +3
       эффект: P39(Performance) = {[p39]+[3..5]*[p6]}
  -> Path750 => Loc150  вер=1 порядок=5
       ответ: You decided to follow the example of the dude from this popular band called "Rock Hard Chilly Peppers", who would undress completely at each gig. However, appar…
       условия: P6(Dragon tattoo) 0..0
       эффект: P39(Performance) = {[p39]-[3..7]}

### Loc153 [пустая] визитов<=1
  -> Path314 => Loc150  вер=1 порядок=5
       ответ: You started running about the stage like crazy screaming your head off. At first the audience looked indifferent, but when somebody threw a rotten tomato at you…
       эффект: P4(Mood) -3
       эффект: P39(Performance) = {[p39]+[1..5]}
  -> Path315 => Loc150  вер=1 порядок=5
       ответ: You started running about the stage like crazy screaming your head off. At first the audience looked indifferent, but when you slipped and accidentally tripped …
       эффект: P14(Band skill) -10
       эффект: P39(Performance) = {[p39]+[5..10]}

### Loc154 [пустая] визитов<=1
  -> Path310 => Loc150  вер=1 порядок=5
       ответ: You started singing in a romantic manner, and got through to everyone in the hall, even the menacing Maloq security guard started crying.
       условия: P4(Mood) 6..20; P5(Drunkenness) 0..1; P9(Singer) 1..3
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path311 => Loc150  вер=1 порядок=5
       ответ: You decided to sing the next verse in a more romantic way, but the crowd continued slamming and moshing, and your attempts were in vain.
  -> Path746 => Loc150  вер=3 порядок=5
       ответ: Instantly you remembered these lines you read in the book about daffodils and poppies, and inserted them into the lyrics. It sounded great, and crowd cheered.
       условия: P18(Book as a present) 1..2
       эффект: P39(Performance) = {[p39]+[4..10]}
  -> Path767 => Loc150  вер=1 порядок=5
       ответ: Looks like your rehearsals did you a world of good, your poetic skills got through to the audience, half of the crowd started crying and went sad...
       условия: P9(Singer) 2..3
       эффект: P39(Performance) = {[p39]+[6..10]}
  -> Path768 => Loc150  вер=1 порядок=5
       ответ: You started singing something poetic into the maxiphone but you would constantly fall into obscenities. Nothing poetic at all. Maybe you should not have gotten …
       условия: P5(Drunkenness) 2..4
       эффект: P39(Performance) = {[p39]-[1..5]-[p5]+[p9]/2}

### Loc155 [пустая] визитов<=1
  -> Path316 => Loc150  вер=1 порядок=5
       ответ: You started coming up with new lyrics, and did a good job at that remembering some cool lines from a <clr>book<clrEnd>, that you read online the other day. The …
       условия: P30(performance book) 1..1
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path317 => Loc150  вер=1 порядок=5
       ответ: You started coming up with new words in order to very the performance at least a little bit, but unfortunately you did not do such a good job with that. The wor…
       условия: P30(performance book) 0..0
       эффект: P39(Performance) = {[p39]-[1..5]}
  -> Path747 => Loc150  вер=3 порядок=5
       ответ: You started to come up with new words, to somehow vary the performance, and did a great job doing it! After all <clr>reading books<clrEnd> helped develop your e…
       условия: P30(performance book) 2..10
       эффект: P39(Performance) = {[p39]+[5..15]}

### Loc156 [пустая] визитов<=1
  -> Path318 => Loc150  вер=1 порядок=5
       ответ: You directed the maxiphone into the audience but they did not want to sing along. As a result there was a dropout in the sound, and you even heard somebody crac…
       эффект: P39(Performance) = {[p39]+[1..5]}
  -> Path319 => Loc150  вер=1 порядок=5
       ответ: You directed the maxiphone into the audience, and they started shouting something, it was cool. Only that when the turn reached the Pelengs, they started scream…
       эффект: P39(Performance) = {[p39]-[1..3]}

### Loc157 [пустая] визитов<=1
  -> Path320 => Loc150  вер=1 порядок=5
       ответ: You grabbed a bottle of beer and were about to throw it to the audience, but suddenly you felt a strike of greediness. You corked open the bottle and killed it …
       условия: P5(Drunkenness) 0..2
       эффект: P5(Drunkenness) +2
       эффект: P39(Performance) = {[p39]-[1..5]}
  -> Path321 => Loc150  вер=1 порядок=5
       ответ: You snatched a couple of beer bottles and hurled them into the crowd, initiating a fight - free beers are a rarity in these parts. As a result the tow persons t…
       условия: P5(Drunkenness) 3..4
       эффект: P14(Band skill) -10
       эффект: P39(Performance) = {[p39]+[5..10]}

### Loc158 [пустая] визитов<=1
  -> Path322 => Loc150  вер=1 порядок=5
       ответ: You dived off the stage and into the crowd, and they started carrying you across the stadium, but when the turn reached the Faeyans, they failed it and dropped …
       эффект: P39(Performance) = {[p39]+[1..5]}
  -> Path323 => Loc150  вер=1 порядок=5
       ответ: You dived off the stage and into the crowd, but either they weren't expecting it or they simply decided to fool you, instead of catching you the audience parted…
       эффект: P4(Mood) -3
       эффект: P39(Performance) = {[p39]+[3..7]}

### Loc159 [пустая] визитов<=1
  -> Path324 => Loc150  вер=1 порядок=5
       ответ: You snatched the guitar from the guitar player and raised it over your head. The crowd was amazed, they cheered and demanded that you smashed the instrument. "S…
       эффект: P10(Guitarist) = 1
       эффект: P14(Band skill) -7
       эффект: P39(Performance) = {[p39]+[5..10]}
  -> Path325 => Loc150  вер=1 порядок=5
       ответ: You snatched the guitar from the guitar player and raised it over your head. The crowd was amazed, they cheered and demanded that you smashed the instrument. "S…
       эффект: P14(Band skill) -25
       эффект: P39(Performance) = {[p39]+[3..7]}

### Loc167 [обычная]
    выбор описания: {[p48]}
    Loc167-1: - Who exactly?
    Loc167-2: - Sometimes he'd drop by the <clr>pub<clrEnd> so you may want to go and check if he's there, but he sure is a freak, so I warned you.
    Loc167-3: - No, the guitarist is not here.
    Loc167-4: It's not that often that they are here, and this time is not the exception.
    Loc167-5: The familiar Maloq-bouncer met you with a grin: /  / - Oh, you again! Still looking for musicians, are you?
  -> Path369 => Loc186  вер=1 проходов<=1 порядок=5
       текст: I was looking for a guitar player
       условия: P10(Guitarist) 0..0
       эффект: P48(x) = 3
  -> Path370 => Loc186  вер=1 проходов<=1 порядок=5
       текст: I'm short of keyboardist
       условия: P11(Keyboardist) 0..0
       эффект: P48(x) = 4
  -> Path371 => Loc186  вер=1 проходов<=1 порядок=5
       текст: I thought maybe I could find a bass-player here
       условия: P12(Bass-player) 0..0
       эффект: P48(x) = 2
  -> Path372 => Loc188  вер=1 порядок=5
       текст: I need a drummer
       условия: P7(Piercing) 0..0; P13(Drummer) 0..0
  -> Path373 => Loc64  вер=1 порядок=9
       текст: I think I will take my leave now!
  -> Path550 => Loc258  вер=1 порядок=5
       текст: I need a drummer
       условия: P7(Piercing) 1..1; P13(Drummer) 0..0; P16(Sticks) 0..0
  -> Path726 => Loc306  вер=1 проходов<=10 порядок=5
       текст: I need a drummer
       условия: P7(Piercing) 1..1; P13(Drummer) 0..0; P16(Sticks) 1..2

### Loc168 [пустая]
    выбор описания: {([p12]=0)+1}
    Loc168-1: At night there's even more people at the pub, than during the daytime, and the booze is cheaper. A drunken Peleng is sitting at the bar-table.
    Loc168-2: At night there's even more people at the pub, than during the daytime, and the booze is cheaper. There's a guy on stage playing a bass-guitar. A drunken Peleng …
  -> Path338 => Loc64  вер=1 порядок=8
       текст: Back to the square
  -> Path339 => Loc169  вер=1
       текст: To the bar table
  -> Path344 => Loc173  вер=1 порядок=3
       текст: Approach the man
       условия: P5(Drunkenness) 0..0; P12(Bass-player) 0..0
  -> Path364 => Loc183  вер=1 порядок=3
       текст: Approach the man
       условия: P5(Drunkenness) 1..4; P12(Bass-player) 0..0
  -> Path702 => Loc303  вер=1 проходов<=1 порядок=5
       текст: Play on stage
       условия: P19(A song order) 1..4; P20(Participation request) 1..1
       эффект: P1(time) +5
       эффект: P14(Band skill) +10

### Loc169 [пустая]
    Loc169-1: At night they have a robot bartender, which, however, does not prevent the patrons from getting drunk, starting a brawl break something and stuff. By the way, a…
  -> Path340 => Loc170  вер=1 [всегда видна] порядок=3
       текст: Have a drink (30 rockarollars)
       условия: P3(Money) 30..5000
       эффект: P3(Money) -30
  -> Path443 => Loc168  вер=1 порядок=7
       текст: Walk away from the bar-table
  -> Path547 => Loc257  вер=1 проходов<=3 порядок=6
       текст: Drink with the Peleng who sits next to you (60 rockarollars)
       условия: P3(Money) 60..5000
       эффект: P3(Money) -60

### Loc170 [пустая]
  -> Path341 => Loc169  вер=1 порядок=5
       ответ: You drank an excellent cocktail - now you could start taking care of business.
       эффект: P1(time) +1
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) +2

### Loc172 [обычная]
    выбор описания: {[p48]}
    Loc172-1: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>805<clrEnd>, / gou-tuu hell means <clr>78<clrEnd>, / tuu-hell wizzat means <clr>6…
    Loc172-2: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>607<clrEnd>, / gou-tuu hell means <clr>56<clrEnd>, / tuu-hell wizzat means <clr>8…
    Loc172-3: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>708<clrEnd>, / gou-tuu hell means <clr>67<clrEnd>, / tuu-hell wizzat means <clr>2…
    Loc172-4: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>207<clrEnd>, / gou-tuu hell means <clr>52<clrEnd>, / tuu-hell wizzat means <clr>8…
    Loc172-5: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>208<clrEnd>, / gou-tuu hell means <clr>52<clrEnd>, / tuu-hell wizzat means <clr>7…
    Loc172-6: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>206<clrEnd>, / gou-tuu hell means <clr>82<clrEnd>, / tuu-hell wizzat means <clr>5…
    Loc172-7: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>206<clrEnd>, / gou-tuu hell means <clr>52<clrEnd>, / tuu-hell wizzat means <clr>7…
    Loc172-8: In the ancient language of Goshi civilisation:  / hoo di-hell izzat means <clr>607<clrEnd>, / gou-tuu hell means <clr>56<clrEnd>, / tuu-hell wizzat means <clr>2…
    эффект: P26(Flags) +1
  -> Path382 => Loc310  вер=1 порядок=4
       текст: 678
       эффект: P46(y) = 4
  -> Path384 => Loc310  вер=1 порядок=5
       текст: 687
       эффект: P46(y) = 5
  -> Path385 => Loc310  вер=1 порядок=8
       текст: 872
       эффект: P46(y) = 8
  -> Path386 => Loc310  вер=1 порядок=2
       текст: 278
       эффект: P46(y) = 2
  -> Path565 => Loc310  вер=1 порядок=3
       текст: 582
       эффект: P46(y) = 3
  -> Path566 => Loc310  вер=1 порядок=6
       текст: 765
       эффект: P46(y) = 6
  -> Path567 => Loc310  вер=1 порядок=1
       текст: 256
       эффект: P46(y) = 1
  -> Path568 => Loc310  вер=1 порядок=7
       текст: 867
       эффект: P46(y) = 7

### Loc173 [пустая]
    Loc173-1: The guy was a bass-guitar god, his fingers were flying across the fret-board so fast that your head started spinning.
  -> Path359 => Loc168  вер=1 порядок=9
       текст: Go away
  -> Path360 => Loc182  вер=1 порядок=5
       текст: Invite the bass-player to join the band
       условия: P12(Bass-player) 0..0; P21(A book on "Good Manners") 0..0
  -> Path366 => Loc184  вер=1 проходов<=1 порядок=8
       текст: Listen to the music
  -> Path432 => Loc213  вер=1 порядок=6
       текст: Politely ask the bass-guitarist to join you
       условия: P12(Bass-player) 0..0; P18(Book as a present) 0..0; P21(A book on "Good Manners") 1..1
  -> Path574 => Loc262  вер=1 порядок=6
       текст: Politely ask the bass-guitarist to join you
       условия: P12(Bass-player) 0..0; P18(Book as a present) 1..2; P21(A book on "Good Manners") 1..1

### Loc182 [пустая]
    эффект: P26(Flags) = 1
  -> Path425 => Loc168  вер=1 порядок=5
       ответ: - I am sorry I don't want to join your band, because you are too <clr> impolite <clrEnd>, and too stupid at that, - the bass-player cut off.

### Loc183 [пустая]
  -> Path365 => Loc168  вер=1 порядок=5
       ответ: You hardly even approached the guy, when he sent you to hell calling you an uncultured and an impolite <clr>drunkard<clrEnd>. "Right, look at the straight-guy h…

### Loc184 [пустая] визитов<=1
  -> Path367 => Loc173  вер=1 проходов<=1 порядок=5
       ответ: You relaxed listening to the beautiful music. Your mood has improved slightly.
       эффект: P1(time) +3
       эффект: P4(Mood) +3

### Loc186 [пустая]
  -> Path376 => Loc167  вер=1 порядок=5

### Loc188 [обычная]
    Loc188-1: - I am the drummer, one of the best in this club. But I got some bad news for you - I am not going to join your band. We have this rule in our rock-club that <c…
  -> Path378 => Loc64  вер=1 порядок=5
       текст: Back to the square

### Loc191 [обычная]
    Loc191-1: The Gaalian looked quite surprised and said something about a wild guess, but a promise is a promise, so he offered you to choose one of the following available…
  -> Path383 => Loc65  вер=1 порядок=5
       текст: Sticks
       ответ: - Here, take it. Real Maloq drumsticks. One of the best in the Galaxy.
       условия: P16(Sticks) 0..0
       эффект: P16(Sticks) +1
  -> Path540 => Loc65  вер=1 порядок=5
       текст: Strings
       ответ: - Here. Real Faeyan liquid-glass strings. Super quality.
       условия: P17(Strings) 0..0
       эффект: P17(Strings) +1
  -> Path714 => Loc65  вер=1 порядок=5
       текст: Advice
       ответ: - When you and the band practice, work on the skills of <clr>each<clrEnd> band-member in particular, so that they play their individual parts better, as well as…

### Loc195 [обычная]
    Loc195-1: The Gaalian said he had no time to waste on some tourist, but if you could guess his riddle he would give you a set of strings, drumsticks, or useful advice - w…
  -> Path674 => Loc172  вер=1 порядок=5
       текст: Go ahead
       эффект: P48(x) = {[1..8]}
  -> Path751 => Loc65  вер=1 порядок=7
       текст: To hell with you!

### Loc196 [пустая]
    Loc196-1: In the grim tattoo-parlour decorated in anti-gothic fashion you could get a cheap tat and pierce anything that dangles.
    показ: P6,P7,P22
  -> Path394 => Loc64  вер=1 порядок=9
       текст: Back to the square
  -> Path395 => Loc197  вер=1 проходов<=1 порядок=5
       текст: Ask if they have a musician here
       условия: P11(Keyboardist) 0..0
  -> Path398 => Loc199  вер=1 [всегда видна] порядок=5
       текст: Get a tattoo (starting from 20 rockarollars)
       условия: P3(Money) 20..5000; P6(Dragon tattoo) 0..2
  -> Path404 => Loc201  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: Pierce an ear (20 rockarollars)
       условия: P3(Money) 20..5000
       эффект: P3(Money) -20
       эффект: P4(Mood) +2
       эффект: P7(Piercing) +1

### Loc197 [пустая] визитов<=1
  -> Path396 => Loc196  вер=1 проходов<=1 порядок=5
       ответ: One of the tattoo-artists said that he knew a <clr>keyboardist<clrEnd>, who spent a lot of time in the poolroom. If you want to hire him you should mention you …
       эффект: P22(Keyboardist (you know about him)) +1 [показ]

### Loc199 [обычная]
    Loc199-1: You opened the catalogue and started browsing through the available tattoo-flashes. After some time you stopped on a beautiful tat depicting a three-neck guitar…
    показ: P6
  -> Path399 => Loc196  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Choose a dragon (20 rockarollars)
       ответ: An old grey-headed man made you a beautiful tattoo, depicting an ancient beast, which once used to live on Human planets. The Dragon was blowing a long blue fla…
       условия: P3(Money) 20..5000
       эффект: P3(Money) -20
       эффект: P4(Mood) +2
       эффект: P6(Dragon tattoo) +1
  -> Path401 => Loc196  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: Choose a guitar (35 rockarollars)
       ответ: An old grey-headed man made you a beautiful tattoo, depicting a three-neck 20-string guitar against the background of dark sky with two violet pieces of the moo…
       условия: P3(Money) 35..5000
       эффект: P3(Money) -35
       эффект: P4(Mood) +3
       эффект: P6(Dragon tattoo) +2
  -> Path831 => Loc196  вер=1 порядок=9
       текст: Reconsider

### Loc201 [пустая] визитов<=1
  -> Path671 => Loc196  вер=1 проходов<=1 порядок=5
       ответ: You sat down in the piercing chair, closed your eyes and prepared yourself... /  / - Hey, dude, are you going to spend the entire day sitting here? - said the F…

### Loc203 [обычная]
    Loc203-1: You found the keyboardist, said him hello from Maarlie, and invited him to join your band...  /  / - Band? Nah, I don't feel like it. Then again, if you win a g…
  -> Path415 => Loc78  вер=1 порядок=5
       текст: Play
       ответ: Unfortunately, <clr> you lost <clrEnd>, and the keyboardist left. Today he is not coming back here.
       условия: P28(Знание о споении соперника в бильярде) 0..0
  -> Path575 => Loc78  вер=4 порядок=5
       текст: Play
       ответ: Remembering the <clr>book<clrEnd>, you remembered a couple of tricks and easily won against your competitor. Now your band has a <clr>keyboardist<clrEnd>!
       условия: P25(Pool skills) 1..1; P28(Знание о споении соперника в бильярде) 0..0
       эффект: P11(Keyboardist) +2
       скрыт: P22
  -> Path723 => Loc78  вер=1 [всегда видна] порядок=5
       текст: Get him drunk (100 rockarollars)
       ответ: You offered to have a drink first, and then play. You guessed right, no musician would ever refuse a free pint. After drinking quite a lot you went to the pool …
       условия: P3(Money) 100..5000; P28(Знание о споении соперника в бильярде) 2..2
       эффект: P3(Money) = {[p3]-100}
       эффект: P5(Drunkenness) +1
       эффект: P11(Keyboardist) +2
       скрыт: P22
  -> Path759 => Loc78  вер=2 порядок=5
       текст: Play
       ответ: Today you were in <clr>excellent mood<clrEnd> and you hand was steady. After a long struggle you won against your opponent. Now you had a <clr>keyboardist<clrEn…
       условия: P4(Mood) 16..20; P5(Drunkenness) 0..1; P28(Знание о споении соперника в бильярде) 0..0
       эффект: P11(Keyboardist) +2
       скрыт: P22
  -> Path830 => Loc78  вер=10 порядок=5
       текст: Play
       ответ: No theoretic knowledge would ever help you win a pool game if you are <clr>drunk<clrEnd>! You did not manage to win that game. The happy keyboardist went home. …
       условия: P5(Drunkenness) 3..4; P25(Pool skills) 1..1; P28(Знание о споении соперника в бильярде) 0..0

### Loc210 [обычная]
    выбор описания: {[p48]}
    Loc210-1: The start page of the library takes aeons to load - seems like the net-users are really into reading. Finally it loaded. So what will it be? The cost per one bo…
    Loc210-2: Some of the rules of Human etiquette, mentioned in the book were a revelation to you. As it turned out you could never say to a stranger: "Yo, scumbag!" A well-…
    Loc210-3: In spite of your expectations, instead of the longed-for soft-core, the book turned out to be an ancient boring love story, with a godzillion of characters and …
    Loc210-4: The book by a famous Peleng pool-player contained a load of valuable advice on the game: "Hold the cue-stick with all your four hands", "Never close your eyes b…
    Loc210-5: You opened the book on a random page and read the following: /  / In the field the daffodils, / Ripen as a bunch of thrills, / But I still can't understand, / W…
    Loc210-6: You read a collection of classic Peleng obscene jokes, which certainly improved your mood!
    эффект: P1(time) +1
  -> Path428 => Loc254  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: O. Hippie, "Politeness in a Human Society - Rules of Etiquette"
       условия: P3(Money) 50..5000
       эффект: P3(Money) = {[p3]-50}
       эффект: P21(A book on "Good Manners") +1
       эффект: P48(x) = 2
  -> Path506 => Loc254  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Chvakha Cheet "Galactic Pool - The Winner's Manual"
       условия: P3(Money) 50..5000
       эффект: P3(Money) = {[p3]-50}
       эффект: P25(Pool skills) +1
       эффект: P48(x) = 4
  -> Path569 => Loc254  вер=1 [всегда видна] проходов<=1 порядок=6
       текст: E. Grim, "The Passionate Love of Marquise de Maniac "
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P30(performance book) +1
       эффект: P48(x) = 3
  -> Path571 => Loc254  вер=1 [всегда видна] проходов<=1 порядок=5
       текст: A collection of Peleng obscene jokes
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P4(Mood) +3
       эффект: P30(performance book) +1
       эффект: P48(x) = 6
  -> Path572 => Loc254  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: "Contemporary Poetry", the anthology
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P18(Book as a present) +1
       эффект: P48(x) = 5
  -> Path728 => Loc73  вер=1 порядок=9
       текст: Back
  -> Path732 => Loc307  вер=1 порядок=5
       текст: Next
       условия: P1(time) 60..60
       эффект: P1(time) = 1

### Loc213 [пустая]
  -> Path433 => Loc168  вер=1 порядок=5
       ответ: - This is actually the first time I see somebody cultured enough here, but I don't want to join your band. I respect only those, who love <clr>poetry<clrEnd>, -…
       эффект: P18(Book as a present) = 1

### Loc214 [обычная]
    выбор описания: {[p48]}
    Loc214-1: You had to wait before they cleaned up the rehearsal room after the previous band. Finally you were ready to go. One rehearsal costs <clr>50<clrEnd> rockarollar…
    Loc214-2: "Now let's try it altogether!" - you said and started singing a song. With each and every time you played your band sounded better and better - your musicians w…
    Loc214-3: "Work on the beat!" - you told the drummer. He responded by totally whaling out at his drums and cymbals. Soon you noticed that the drummer was now sounding muc…
    Loc214-4: "Hey that was good riff - practice it!" - you told the guitarist. He started shredding his guitar until he finally came up with the riff that you all liked. He …
    Loc214-5: "I want a more distinct bass-line here, - you told the bass-player. - Try something!" The guy spent some time torturing your ears with heavy booming sounds, but…
    Loc214-6: "Hey, come on, just jam, dude, - you told the keyboardist. - How about "Smoke On The Water"?" The keyboardist started playing and you noticed that you liked him…
    Loc214-7: "And now silence everyone! - you shouted to the musicians. - I'm going to sing!" /  / You started singing and quickly understood you totally forgot how you do i…
  -> Path451 => Loc66  вер=1 порядок=9
       текст: Enough of practising!
  -> Path578 => Loc290  вер=1 проходов<=6 порядок=8
       текст: Work on the professionalism of the entire band
       условия: P3(Money) 50..5000; P14(Band skill) 0..139
       эффект: P3(Money) = {[p3]-50}
       эффект: P14(Band skill) +25
       эффект: P15(rehearsal in the studio) +1
       эффект: P48(x) = 2
  -> Path638 => Loc290  вер=1 проходов<=3 порядок=3
       текст: Work on the guitarist's skills
       условия: P3(Money) 50..5000; P10(Guitarist) 1..3
       эффект: P3(Money) -50
       эффект: P10(Guitarist) +1
       эффект: P14(Band skill) +10
       эффект: P15(rehearsal in the studio) +1
       эффект: P32(r. with guitar) +1
       эффект: P48(x) = 4
  -> Path639 => Loc290  вер=1 проходов<=3 порядок=6
       текст: Work on the drummer's skills
       условия: P3(Money) 50..5000; P13(Drummer) 1..3
       эффект: P3(Money) -50
       эффект: P13(Drummer) +1
       эффект: P14(Band skill) +10
       эффект: P15(rehearsal in the studio) +1
       эффект: P35(r. with drums) +1
       эффект: P48(x) = 3
  -> Path640 => Loc290  вер=1 проходов<=3 порядок=2
       текст: Work on the bass-player's skills
       условия: P3(Money) 50..5000; P12(Bass-player) 1..3
       эффект: P3(Money) -50
       эффект: P12(Bass-player) +1
       эффект: P14(Band skill) +10
       эффект: P15(rehearsal in the studio) +1
       эффект: P33(r. with bass) +1
       эффект: P48(x) = 5
  -> Path641 => Loc290  вер=1 проходов<=3 порядок=5
       текст: Work on the keyboardist's skills
       условия: P3(Money) 50..5000; P11(Keyboardist) 1..3
       эффект: P3(Money) -50
       эффект: P11(Keyboardist) +1
       эффект: P14(Band skill) +10
       эффект: P15(rehearsal in the studio) +1
       эффект: P34(r. with keyboards) +1
       эффект: P48(x) = 6
  -> Path642 => Loc290  вер=1 проходов<=3
       текст: Work on your own skills
       условия: P3(Money) 50..5000; P9(Singer) 0..2
       эффект: P3(Money) -50
       эффект: P9(Singer) +1
       эффект: P14(Band skill) +10
       эффект: P15(rehearsal in the studio) +1
       эффект: P36(r. with vocals) +1
       эффект: P48(x) = 7

### Loc231 [пустая] визитов<=1
  -> Path482 => Loc150  вер=1 порядок=5
       ответ: The guitar-player sucked, and the entire crowd was booing at you.
       условия: P10(Guitarist) 1..2; P32(r. with guitar) 0..0
       эффект: P39(Performance) = {[p39]-[3..10]}
  -> Path688 => Loc150  вер=1 порядок=5
       ответ: The guitarist did a unique job, the audience was in awe.
       условия: P10(Guitarist) 4..4; P32(r. with guitar) 1..3
       эффект: P39(Performance) = {[p39]+[10..20]}
  -> Path689 => Loc150  вер=1 порядок=5
       ответ: The guitarist did an average job, some of the audience booed, but some liked him.
       условия: P10(Guitarist) 1..2; P32(r. with guitar) 1..3
       эффект: P39(Performance) = {[p39]+[1..7]}
  -> Path690 => Loc150  вер=1 порядок=5
       ответ: The guitarist played very well, the crowd liked him.
       условия: P10(Guitarist) 3..3
       эффект: P39(Performance) = {[p39]+[7..12]}

### Loc237 [обычная]
    выбор описания: {[p48]}
    Loc237-1: Hello, Ranger <Ranger>, you have [p47]  messages in your mailbox "<Ranger><clr>_the-magnificent_and_the_wonderful<clrEnd><clr>@hotmale.com<clrEnd>".
    Loc237-2: From: <FromPlanet> <clr>Govt<clrEnd> / Subject: <clr>Mission<clrEnd> /  / Hello, <Ranger>. Here're the details of your mission: / You have to form a band of <cl…
    Loc237-3: From: <clr>Faeyanette Scientific Base<clrEnd> / Subject: <clr>Article "Ascending and descending air streams"<clrEnd> /  / "While the current velocity remains at…
    Loc237-4: From: <clr>"God Sons" Sect<clrEnd> / Subject: <clr>Holy Message<clrEnd> /  / "Once you get this letter copy it 33 million times and send it to 33 million addres…
    Loc237-5: From: <clr>Ranger Feebling<clrEnd> / Subject: <clr>Want to purge a system from Dominators?<clrEnd> /  / "Anyone who is interested in teaming up with me and purg…
    Loc237-6: From: <clr>Ranger Laamer<clrEnd> / Subject: <clr>Tired of Lamers?<clrEnd> /  / "This is the last time I am explaining this: in order to format a hard disk drive…
    эффект: P1(time) +1
  -> Path454 => Loc241  вер=1
       текст: <FromPlanet> Govt
       эффект: P48(x) = 2
  -> Path456 => Loc241  вер=1 проходов<=1 порядок=6
       текст: Holy Message
       эффект: P47(Box) -1
       эффект: P48(x) = 4
  -> Path494 => Loc241  вер=1 проходов<=1 порядок=4
       текст: Ranger Laamer
       эффект: P47(Box) -1
       эффект: P48(x) = 6
  -> Path495 => Loc241  вер=1 проходов<=1 порядок=3
       текст: Ranger Feebling
       эффект: P47(Box) -1
       эффект: P48(x) = 5
  -> Path496 => Loc241  вер=1 проходов<=1 порядок=1
       текст: Weekly Scientific Newsletter
       эффект: P47(Box) -1
       эффект: P48(x) = 3
  -> Path729 => Loc73  вер=1 порядок=9
       текст: Back
  -> Path738 => Loc307  вер=1 порядок=5
       текст: Next
       условия: P1(time) 60..60
       эффект: P1(time) = 1

### Loc241 [пустая]
  -> Path498 => Loc237  вер=1 порядок=5

### Loc242 [обычная]
    выбор описания: {[p48]}
    Loc242-1: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Guitarist<clrEnd> / Musicianship: <clr>poor<clrEnd> / Start-up fee: <clr>200<clrEnd> roc…
    Loc242-2: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Guitarist<clrEnd> / Musicianship: <clr>average<clrEnd> / Start-up fee: <clr>300<clrEnd> …
    Loc242-3: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Guitarist<clrEnd> / Musicianship: <clr>good<clrEnd> / Start-up fee: <clr>400<clrEnd> roc…
  -> Path504 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path505 => Loc93  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path734 => Loc73  вер=1 [всегда видна]
       текст: Hire
       условия: логика {[p3]>=([p48]*100+100)}
       эффект: P3(Money) = {[p3]-[p48]*100-100}
       эффект: P10(Guitarist) = {[p48]}

### Loc248 [пустая]
  -> Path521 => Loc250  вер=3 порядок=5
       ответ: Search complete. /  / Found <clr>drumsticks<clrEnd> / Condition: <clr>average<clrEnd> / Price: <clr>50<clrEnd> cr
       условия: P16(Sticks) 0..0
  -> Path522 => Loc252  вер=1 порядок=5
       ответ: Search complete. /  / Found <clr>drumsticks<clrEnd> / Condition: <clr>Excellent<clrEnd> / Price: <clr>200<clrEnd> cr
       условия: P16(Sticks) 0..0
  -> Path523 => Loc251  вер=1 порядок=5
       ответ: Search complete. /  / Found <clr>Strings<clrEnd> / Condition: <clr>Good<clrEnd> / Price: <clr>200<clrEnd> cr
       условия: P17(Strings) 0..0
  -> Path524 => Loc253  вер=3 порядок=5
       ответ: Search complete. /  / Found <clr>Strings<clrEnd> / Condition: <clr>Satisfactory<clrEnd> / Price: <clr>50<clrEnd> cr
       условия: P17(Strings) 0..0

### Loc250 [пустая]
  -> Path528 => Loc248  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path533 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path534 => Loc73  вер=1 [всегда видна] порядок=1
       текст: Buy
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P16(Sticks) +1

### Loc251 [пустая]
  -> Path529 => Loc248  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path532 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path535 => Loc73  вер=1 [всегда видна] порядок=1
       текст: Buy
       условия: P3(Money) 200..5000
       эффект: P3(Money) -200
       эффект: P17(Strings) +1

### Loc252 [пустая]
  -> Path525 => Loc73  вер=1 [всегда видна] порядок=1
       текст: Buy
       условия: P3(Money) 200..5000
       эффект: P3(Money) -200
       эффект: P16(Sticks) +1
  -> Path526 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path527 => Loc248  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3

### Loc253 [пустая]
  -> Path530 => Loc248  вер=1 порядок=2
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path531 => Loc73  вер=1 порядок=3
       текст: Cancel
  -> Path536 => Loc73  вер=1 [всегда видна] порядок=1
       текст: Buy
       условия: P3(Money) 50..5000
       эффект: P3(Money) -50
       эффект: P17(Strings) +1

### Loc254 [пустая]
  -> Path733 => Loc210  вер=1 порядок=5

### Loc257 [пустая] визитов<=3
  -> Path546 => Loc169  вер=1 проходов<=1 порядок=5
       ответ: You had a couple of pints with the Peleng, and he told you that there was always a whole lot of musicians at the rock-club, but it had been a week now that it w…
       эффект: P1(time) +3
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) +2
  -> Path548 => Loc169  вер=1 проходов<=1 порядок=5
       ответ: You had a couple of pints with the Peleng and he told you that he once won a game of pool by getting his opponent drunk.
       эффект: P1(time) +3
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) +2
       эффект: P28(Знание о споении соперника в бильярде) +1
  -> Path549 => Loc169  вер=1 проходов<=1 порядок=5
       ответ: You had a chance over a pint, exchanging some interesting stories. The Peleng told you a couple of funny jokes that considerably improved your spirits.
       эффект: P1(time) +3
       эффект: P5(Drunkenness) +1
       эффект: P4(Mood) +4

### Loc258 [обычная]
    Loc258-1: Hey, I like your piercing, dude, I have total respect for such humanoids and I will gladly join your band, but I don't have <clr>drumsticks<clrEnd>.
  -> Path551 => Loc64  вер=1 порядок=5
       текст: See you

### Loc262 [обычная]
    Loc262-1: - This is the first time I see somebody who is actually cultured in these parts, - the bass-player said - I see you have a book of "Contemporary Poetry". I have…
  -> Path573 => Loc168  вер=1 порядок=5
       текст: Present the book to the bass-guitarist
       ответ: - Thanks for the excellent book, you got me totally hooked, - he rhymed. / - See you, - you said.
       эффект: P12(Bass-player) +3
       эффект: P18(Book as a present) +1
  -> Path766 => Loc168  вер=1 порядок=5
       текст: Refuse
       ответ: - Too bad, - said the bass-player. - But if you reconsider, come back.

### Loc271 [обычная] визитов<=9
    Loc271-1: Rather than to impress the audience with your hooliganism, you thought of playing a really beautiful song. Maybe you should use some of the stuff you practised …
    Loc271-2: What musical masterpiece you are going to deliver to the audience?
    Loc271-3: Good music played by professional musicians is something that the audience is going to like!
    Loc271-4: What should we do? Play a shredding solo or let the audience see what the band as whole can do?
    Loc271-5: You are standing on the scene in front of roaring crowd. Let's show them what real music is about!!!
    Loc271-6: Haven't the audience yet understood who is the best at this show tonight?! Well let them listen to your <clr>muzak<clrEnd>!
    Loc271-7: Looks like it's time you impressed the audience with your musical professionalism. How are you going to do it?
  -> Path295 => Loc154  вер=1 проходов<=1 порядок=6
       текст: Sing romantically
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path469 => Loc231  вер=1 проходов<=1 порядок=1
       текст: Play a shredding guitar solo
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path597 => Loc277  вер=1 проходов<=1
       текст: Perform a great vocal party
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path598 => Loc276  вер=1 проходов<=1 порядок=3
       текст: Play a wicked keyboard solo
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path599 => Loc275  вер=1 проходов<=1 порядок=5
       текст: Play the drums the punk-rock way
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path600 => Loc274  вер=1 проходов<=1 порядок=2
       текст: Play some cool bass-line
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path740 => Loc308  вер=1 проходов<=3 порядок=9
       текст: Just sing and play
       эффект: P29(Time on stage) = {[p29]-[27..33]}

### Loc273 [обычная] визитов<=8
    выбор описания: {[p48]}
    Loc273-1: You decided you should do something extraordinary but what exactly?
    Loc273-2: And now you are going to show the crowd something they had never seen before! Let's awe them!!!
    Loc273-3: Oh, damn, you forgot the next verse! Well, let's try and work this out somehow...
    Loc273-4: If the audience wanted to listen to the music, they would have simply switched on one of the dozen music channels on the stereovision and stayed home. When they…
    Loc273-5: The audience can feel bored at whoever else's gig, but not at yours! And no mistake!
    Loc273-6: Isn't it time you entertained the audience with something? Looks like about time you did!
    Loc273-7: Seems, like it's time your performance was mixed with something extraordinary. In other words - let's get naughty!
    Loc273-8: "If you mix a couple of good gimmicks with good music, it's not going to be worse", - you thought to yourself. What can you possibly do to entertain the audienc…
    Loc273-9: You wanted to make a "show"? But where are all the <clr>musical<clrEnd> gimmicks?! After all this is a live concert, not some stupid stereo-show "Dumb & Dumber"…
    Loc273-10: Seeing that instead of playing music, you were about to show them another trick the crowed booed.  /  / - Where's the cool <clr>music<clrEnd>?! Hyper-rock forev…
  -> Path276 => Loc156  вер=1 проходов<=1 порядок=5
       текст: Direct the maxiphone to the audience, so that they sing it for you
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path282 => Loc155  вер=1 проходов<=1 порядок=5
       текст: Come up with new words on the spot
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path298 => Loc157  вер=1 проходов<=1 порядок=5
       текст: Pur some beer on the audience
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path301 => Loc158  вер=1 проходов<=1 порядок=5
       текст: Dive off the stage
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path302 => Loc159  вер=1 проходов<=1 порядок=5
       текст: Smash the guitar against the stage
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path304 => Loc152  вер=1 проходов<=1 порядок=5
       текст: Undress
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path306 => Loc153  вер=1 проходов<=1 порядок=5
       текст: Run about the stage and scream hysterically
       эффект: P29(Time on stage) = {[p29]-[27..33]}
  -> Path742 => Loc309  вер=1 проходов<=1 порядок=5
       текст: Drink from two bottles at a time
       эффект: P29(Time on stage) = {[p29]-[27..33]}

### Loc274 [пустая] визитов<=1
  -> Path613 => Loc150  вер=1 порядок=5
       ответ: The bass-player did an excellent job and the crowded gave him a long applause.
       условия: P12(Bass-player) 3..3
       эффект: P39(Performance) = {[p39]+[7..12]}
  -> Path675 => Loc150  вер=1 порядок=5
       ответ: The bass-player did an average job and some of the audience booed.
       условия: P12(Bass-player) 1..2; P33(r. with bass) 1..1
       эффект: P39(Performance) = {[p39]+[1..7]}
  -> Path676 => Loc150  вер=1 порядок=5
       ответ: The bass-player did a unique job, the audience was in a slight shock.
       условия: P12(Bass-player) 4..4
       эффект: P39(Performance) = {[p39]+[10..20]}
  -> Path677 => Loc150  вер=1 порядок=5
       ответ: The bass-played sucked and the entire hall booed.
       условия: P12(Bass-player) 1..2; P33(r. with bass) 0..0
       эффект: P39(Performance) = {[p39]-[3..10]}

### Loc275 [пустая] визитов<=1
  -> Path611 => Loc150  вер=1 порядок=5
       ответ: You said to your drummer to remember how you played it at the rehearsal and he played a bit better, everybody liked it.
       условия: P13(Drummer) 1..2; P35(r. with drums) 1..3
       эффект: P39(Performance) = {[p39]+[1..7]}
  -> Path682 => Loc150  вер=1 порядок=5
       ответ: The drummer played very well, the audience gave him a long applause.
       условия: P13(Drummer) 3..3
       эффект: P39(Performance) = {[p39]+[7..12]}
  -> Path683 => Loc150  вер=1 порядок=5
       ответ: The drummer sucked big time and was out of rhythm, so the entire hall booed.
       условия: P13(Drummer) 1..2; P35(r. with drums) 0..0
       эффект: P39(Performance) = {[p39]-[4..10]}
  -> Path684 => Loc150  вер=1 порядок=5
       ответ: The drummer did a unique job playing, and the crowd was shocked by his skill.
       условия: P13(Drummer) 4..4
       эффект: P39(Performance) = {[p39]+[10..20]}

### Loc276 [пустая] визитов<=1
  -> Path609 => Loc150  вер=1 порядок=5
       ответ: The keyboardist sucked, and the entire crowd booed.
       условия: P11(Keyboardist) 0..2; P34(r. with keyboards) 0..0
       эффект: P39(Performance) = {[p39]-[3..10]}
  -> Path685 => Loc150  вер=1 порядок=5
       ответ: The keyboardist did an average job, some of the crowd booed, but the majority seemed to like you anyway.
       условия: P13(Drummer) 1..2; P34(r. with keyboards) 1..3
       эффект: P39(Performance) = {[p39]+[1..7]}
  -> Path686 => Loc150  вер=1 порядок=5
       ответ: The keyboardist played very well, and the audience seemed pleased.
       условия: P11(Keyboardist) 3..3
       эффект: P39(Performance) = {[p39]+[7..12]}
  -> Path687 => Loc150  вер=1 порядок=5
       ответ: The keyboardist did a unique job playing, the audience was in awe of him.
       условия: P11(Keyboardist) 4..4
       эффект: P39(Performance) = {[p39]+[10..20]}

### Loc277 [пустая] визитов<=1
  -> Path615 => Loc150  вер=1 порядок=5
       ответ: You did an average job singing, some of the audience booed, some liked it.
       условия: P9(Singer) 1..1; P36(r. with vocals) 1..3
       эффект: P39(Performance) = {[p39]+[1..5]+[p4]/5-[p5]/2}
  -> Path678 => Loc150  вер=1 порядок=5
       ответ: You sang very well, and the audience was pleased.
       условия: P9(Singer) 2..2
       эффект: P39(Performance) = {[p39]+[5..10]+[p4]/5-[p5]/2}
  -> Path679 => Loc150  вер=1 порядок=5
       ответ: You did a unique job singing, the fans were deeply impressed!
       условия: P9(Singer) 3..3
       эффект: P39(Performance) = {[p39]+[10..15]+[p4]/5-[p5]/2}
  -> Path680 => Loc150  вер=1 порядок=5
       ответ: Your singing sucked and the entire hall booed.
       условия: P9(Singer) 0..0
       эффект: P4(Mood) -3
       эффект: P39(Performance) = {[p39]-[3..10]+[p4]/5-[p5]/2}
  -> Path745 => Loc150  вер=1 порядок=5
       ответ: You did a lousy job singing and you missed half of the notes, and the crowd booed. You should have practised more!
       условия: P9(Singer) 0..1; P36(r. with vocals) 0..0
       эффект: P4(Mood) -1
       эффект: P39(Performance) = {[p39]-[3..10]+[p4]/5-[p5]/2}

### Loc290 [пустая]
    эффект: P1(time) = {[p1]+[3..5]}
  -> Path643 => Loc214  вер=1 порядок=5

### Loc291 [обычная]
    Loc291-1: You finished your act. Now you have to wait for the other bands to perform. What are you going to do?
  -> Path652 => Loc293  вер=1 порядок=5
       текст: Go and talk to the audience
  -> Path653 => Loc294  вер=1 порядок=4
       текст: Do something wicked to the competitors
  -> Path744 => Loc295  вер=1
       текст: Wait for the results
  -> Path804 => Loc331  вер=1 порядок=5
       текст: Do an interview

### Loc293 [обычная]
  -> Path655 => Loc295  вер=1 порядок=5
       ответ: You went down into the crowd, talked to your fans, signed a couple of autographs, drank some beer with them. You rating ahs slightly improved.
       условия: P4(Mood) 11..20; P5(Drunkenness) 0..3
       эффект: P5(Drunkenness) +1
       эффект: P39(Performance) = {[p39]+[1..5]}
  -> Path761 => Loc295  вер=1 порядок=5
       ответ: You went down to the crowd to talk to your fans and give them a couple of autographs. However your  <clr>mood<clrEnd> was so bad, that the audience felt it. You…
       условия: P4(Mood) 0..10; P5(Drunkenness) 0..3
       эффект: P39(Performance) = {[p39]-[1..5]}
  -> Path762 => Loc295  вер=2 порядок=5
       ответ: You went down to the crowd to talk to your fans and give them a couple of autographs. However you were so <clr>drunk<clrEnd>, that you couldn't even put a prope…
       условия: P5(Drunkenness) 3..4
       эффект: P39(Performance) = {[p39]-[1..5]}

### Loc294 [обычная]
  -> Path656 => Loc295  вер=1 порядок=5
       ответ: You sneaked on the stage behind the curtains and cut one of the tweeters with a knife. Now it is going to rattle during the performance of other bands, and you …
       условия: P5(Drunkenness) 0..2
       эффект: P46(y) = 1
  -> Path658 => Loc295  вер=3 порядок=5
       ответ: You sneaked into your opponents' dressing room in order to put their instruments out of tune, but you were too drunk to keep it quiet. Accidentally you tumbled …
       условия: P5(Drunkenness) 2..4
       эффект: P39(Performance) = {[p39]-[20..30]}
  -> Path827 => Loc295  вер=3 порядок=5
       ответ: You sneaked on stage behind the curtains with plans to cut a whole in one of the tweeters, so that it would rattle during the performance of remaining acts, whi…

### Loc295 [пустая]
    эффект: P40(Alumminica) = {[110..140]-[10..20]*[p46]}
    эффект: P41(Pink Asteroid) = {[105..135]-[10..20]*[p46]}
    эффект: P42(Drink 182) = {[100..130]-[10..20]*[p46]}
  -> Path760 => Loc311  вер=1 порядок=5
       эффект: P40(Alumminica) = {[p40]+([p40]=[p39])}
       эффект: P41(Pink Asteroid) = {[p41]+([p41]=[p39])}
       эффект: P42(Drink 182) = {[p42]+([p42]=[p39])}

### Loc296 [УСПЕХ]
    Loc296-1: Finally the scores appeared on the table: / <clr>Your band<clrEnd>: [p39] / Alumminica: [p40] / Pink Asteroid: [p41] / Drink 182: [p42] / ... /  / The scores of…

### Loc297 [ПРОВАЛ]
    выбор описания: {1+2*(([p42]>[p40]) and ([p42]>[p41]))+(([p41]>=[p42]) and ([p41]>[p40]))}
    Loc297-1: Finally the scores appeared on the table: / <clr>Your band<clrEnd>: [p39] / Alumminica: [p40] / Pink Asteroid: [p41] / Drink 182: [p42] / ... /  / The scores of…
    Loc297-2: Finally the scores appeared on the table: / <clr>Your band<clrEnd>: [p39] / Alumminica: [p40] / Pink Asteroid: [p41] / Drink 182: [p42] / ... /  / The scores of…
    Loc297-3: Finally the scores appeared on the table: / <clr>Your band<clrEnd>: [p39] / Alumminica: [p40] / Pink Asteroid: [p41] / Drink 182: [p42] / ... /  / The scores of…
    показ: P40,P41,P42

### Loc298 [обычная]
    выбор описания: {[p48]}
    Loc298-1: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Keyboardist<clrEnd> / Musicianship: <clr>poor<clrEnd> / Start-up fee: <clr>200<clrEnd> r…
    Loc298-2: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Keyboardist<clrEnd> / Musicianship: <clr>average<clrEnd> / Start-up fee: <clr>300<clrEnd…
    Loc298-3: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Keyboardist<clrEnd> / Musicianship: <clr>good<clrEnd> / Start-up fee: <clr>400<clrEnd> r…
  -> Path664 => Loc73  вер=1 порядок=5
       текст: Cancel
  -> Path665 => Loc93  вер=1 порядок=4
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path736 => Loc73  вер=1 [всегда видна]
       текст: Hire
       условия: логика {[p3]>=([p48]*100+100)}
       эффект: P3(Money) = {[p3]-[p48]*100-100}
       эффект: P11(Keyboardist) = {[p48]}

### Loc299 [обычная]
    выбор описания: {[p48]}
    Loc299-1: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Bass-player<clrEnd> / Musicianship: <clr>poor<clrEnd> / Start-up fee: <clr>200<clrEnd> r…
    Loc299-2: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Bass-player<clrEnd> / Musicianship: <clr>average<clrEnd> / Start-up fee: <clr>300<clrEnd…
    Loc299-3: Search complete. /  / Found <clr>1<clrEnd> musician: / Occupation: <clr>Bass-player<clrEnd> / Musicianship: <clr>good<clrEnd> / Start-up fee: <clr>400<clrEnd> r…
  -> Path663 => Loc73  вер=1 порядок=5
       текст: Cancel
  -> Path666 => Loc93  вер=1 порядок=4
       текст: Search more (3 rockarollars)
       условия: P3(Money) 3..5000
       эффект: P3(Money) -3
  -> Path668 => Loc73  вер=1 [всегда видна]
       текст: Hire
       условия: логика {[p3]>=([p48]*100+100)}
       эффект: P3(Money) = {[p3]-[p48]*100-100}
       эффект: P12(Bass-player) = {[p48]}

### Loc301 [пустая]
    эффект: P39(Performance) = {[0..5]+[p4]-3*[p5]}
    эффект: P46(y) = 0
    скрыт: P7,P15,P16,P17,P18,P21,P22,P25,P30
  -> Path697 => Loc140  вер=1 порядок=5
       условия: P19(A song order) 4..4
       эффект: P29(Time on stage) = 420
  -> Path698 => Loc140  вер=1 порядок=5
       условия: P19(A song order) 1..1
       эффект: P29(Time on stage) = 180
  -> Path699 => Loc140  вер=1 порядок=5
       условия: P19(A song order) 2..2
       эффект: P29(Time on stage) = 300
  -> Path700 => Loc140  вер=1 порядок=5
       условия: P19(A song order) 3..3
       эффект: P29(Time on stage) = 360

### Loc302 [ПРОВАЛ]
    Loc302-1: You forgot to check in at the fest. Which means you are not wanted at this celebration of music! You had no other choice but to go back to the spaceport. /  / Y…

### Loc303 [пустая] визитов<=1
  -> Path703 => Loc168  вер=1 проходов<=1 порядок=5
       ответ: You met the bar-owner and asked him if your band could play that night. At first he would not agree, and only after said you were going to play for free, did he…

### Loc305 [обычная] визитов<=1
    Loc305-1: - Hey, cool tattoo, dude, only that the <clr>strings<clrEnd> on my guitar got all worn out. If you bring me a set of new strings I will join your band.
  -> Path670 => Loc64  вер=1 проходов<=1 порядок=5
       текст: Back to the square
       условия: P10(Guitarist) 0..0

### Loc306 [обычная] визитов<=10
    Loc306-1: - Hey you have <clr>piercing in your ear <clrEnd>, then I can join you as a drummer, only that I don't have drumsticks. What, you have <clr>drumsticks<clrEnd> t…
    Loc306-2: Did you give it a thought? Will you take me?
    Loc306-3: Did you give it a thought? Will you take me?
    Loc306-4: Did you give it a thought? Will you take me?
    Loc306-5: Did you give it a thought? Will you take me?
    Loc306-6: Did you give it a thought? Will you take me?
    Loc306-7: Did you give it a thought? Will you take me?
    Loc306-8: Did you give it a thought? Will you take me?
    Loc306-9: Did you give it a thought? Will you take me?
    Loc306-10: Did you give it a thought? Will you take me?
  -> Path725 => Loc64  вер=1 порядок=5
       текст: Sure
       эффект: P13(Drummer) +2
       эффект: P16(Sticks) +1
       эффект: P23(Барабанщик (если нанять)) +1
  -> Path727 => Loc64  вер=1 порядок=5
       текст: No way

### Loc307 [пустая]
    эффект: P2(Fest) -1
    эффект: P4(Mood) -3
  -> Path731 => Loc62  вер=1 порядок=5
       эффект: P5(Drunkenness) = 0
       эффект: P4(Mood) = {[p4]-[p5]}
       эффект: P48(x) = 3

### Loc308 [пустая] визитов<=3
  -> Path741 => Loc150  вер=1 проходов<=3 порядок=5
       ответ: "Let's give the crowd a break, - you thought to yourself. - Let them see how well we play and sound as a band!"
       эффект: P39(Performance) = {[p39]+([p14]-40)/[4..6]+[-3..3]+[p4]/5-[p5]}

### Loc309 [пустая] визитов<=1
  -> Path748 => Loc150  вер=1 порядок=5
       ответ: You remembered this trick, that a ranger you knew showed you once: took a couple of beer bottles, stuck them in your mouth and bent backwards so that the beer w…
       условия: P5(Drunkenness) 3..4
       эффект: P4(Mood) -5
       эффект: P9(Singer) -2
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path749 => Loc150  вер=1 порядок=5
       ответ: You remembered this trick, that a ranger you knew showed you once: took a couple of beer bottles, stuck them in your mouth and bent backwards so that the beer w…
       условия: P5(Drunkenness) 0..2
       эффект: P5(Drunkenness) +2
       эффект: P9(Singer) -1
       эффект: P39(Performance) = {[p39]+[5..15]}

### Loc310 [пустая]
  -> Path752 => Loc65  вер=1 порядок=5
       ответ: Calmly the Gaalian told you that you were mistaken, just like everyone else had been. Then he sank back into thought.
       условия: логика {[p46]<>[p48]}
  -> Path753 => Loc191  вер=1 порядок=5
       условия: логика {[p46]=[p48]}

### Loc311 [пустая]
  -> Path659 => Loc297  вер=1 порядок=5
  -> Path660 => Loc296  вер=1000 порядок=5
       условия: логика {([p39]>[p40]) and ([p39]>[p41]) and ([p39]>[p42])}

### Loc312 [ПРОВАЛ]
    Loc312-1: You were sick to death of all these wannabe rock stars with all their whims and exaggerated financial expectations. Better go and fight some Dominators, and let…

### Loc313 [пустая]
  -> Path764 => Loc62  вер=1 порядок=5
       эффект: P5(Drunkenness) = 0
       эффект: P4(Mood) = {[p4]-[p5]}
       эффект: P48(x) = 6

### Loc314 [обычная] визитов<=7
    выбор описания: {[p48]}
    Loc314-1: What hyper-rock gig would it be without special effects? No way!!!
    Loc314-2: The audience wants a show? Let's give it to them! Bring the FX on!!!
    Loc314-3: What if we add some special FX?
    Loc314-4: A little explosions never hurt anybody!!!
    Loc314-5: It's kind of dark and dull in here - let's bring the fire!!!
    Loc314-6: Who would possibly come to a gig to listen to the music?! Well, some people might, but music is nothing without special FX - it's like a book without pictures! …
    Loc314-7: The famous Peleng fireworks - each fifth of them actually works properly! Hope you get lucky and none of the fans get killed.
    Loc314-8: Let's add some special FX!!! Fire'em up!!!
    Loc314-9: Haven't you a bit overdone it with the show and special effects? The audience want to hear cool <clr>music<clrEnd>! After all this is a live concert not the pro…
    Loc314-10: Seeing that instead of music you were going to deliver yet another special effect the crowd went mad: /  / - Take your show and shove it! Give us the <clr>music…
  -> Path770 => Loc315  вер=1 проходов<=1 порядок=5
       текст: Fireworks along the scene
  -> Path771 => Loc316  вер=1 проходов<=1 порядок=5
       текст: Alternating background
  -> Path772 => Loc317  вер=1 проходов<=1 порядок=5
       текст: Artificial rain
  -> Path773 => Loc318  вер=1 проходов<=1 порядок=5
       текст: Laser show
  -> Path774 => Loc319  вер=1 проходов<=1 порядок=5
       текст: Sky Fireworks
  -> Path775 => Loc320  вер=1 проходов<=1 порядок=5
       текст: Holograms
  -> Path776 => Loc321  вер=1 проходов<=1 порядок=5
       текст: Light FX

### Loc315 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path795 => Loc150  вер=1 порядок=5
       ответ: You ordered <clr>fireworks<clrEnd> around the scene. It looked as if the band was playing in a ring of fire. The effect looked real cool and the crowd stood in …
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path822 => Loc150  вер=1 порядок=5
       ответ: You ordered <clr>fireworks<clrEnd> around the scene. It looked as if the band was playing in a ring of fire. The effect looked real cool and the crowd was entra…
       эффект: P12(Bass-player) = 1
       эффект: P14(Band skill) -7
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path823 => Loc150  вер=2 порядок=5
       ответ: You ordered <clr>fireworks<clrEnd> around the scene. It looked as if the band was playing in a ring of fire. The effect looked real cool and the crowd was shock…
       условия: P5(Drunkenness) 3..4
       эффект: P14(Band skill) = {[p14]-[15..25]}
       эффект: P39(Performance) = {[p39]+[2..5]}
  -> Path824 => Loc150  вер=1 порядок=5
       ответ: You ordered <clr>fireworks<clrEnd> around the scene. It looked as if the band was playing in a ring of fire. The effect looked real cool and the crowd was impre…
       эффект: P13(Drummer) = 1
       эффект: P14(Band skill) -7
       эффект: P39(Performance) = {[p39]+[5..10]}

### Loc316 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path796 => Loc150  вер=1 порядок=5
       ответ: You ordered an <clr> alternating background<clrEnd>, in order to brighten things up on stage a little. All kinds of cool picture started appearing on the backdr…
       эффект: P39(Performance) = {[p39]+[2..5]}
  -> Path825 => Loc150  вер=1 порядок=5
       ответ: You ordered an <clr> alternating background<clrEnd>, in order to brighten things up on stage a little. All kinds of cool picture started appearing on the backdr…

### Loc317 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path797 => Loc150  вер=1 порядок=5
       ответ: You ordered <clr>artificial rain<clrEnd>, one of the most complex and expensive effects. Maybe this was the reason why it failed. A multitude of charges rockete…
       эффект: P39(Performance) = {[p39]-[1..4]}
  -> Path826 => Loc150  вер=1 порядок=5
       ответ: You ordered <clr>artificial rain<clrEnd>, one of the most complex and expensive effects. A multitude of charges shot into the air and blasted accompanied by you…
       эффект: P39(Performance) = {[p39]+[3..7]}

### Loc318 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path798 => Loc150  вер=1 порядок=5
       ответ: You thought that it was about time to start the <clr>laser show<clrEnd> to cheer up the audience! But alas, it almost had no effect on the audience. Looks like …
       эффект: P39(Performance) = {[p39]+[0..1]}
  -> Path821 => Loc150  вер=1 порядок=5
       ответ: You thought that it was about time to start the <clr>laser show<clrEnd> to cheer up the audience! The old time-tested effect has totally lived up to your expect…
       эффект: P39(Performance) = {[p39]+[2..5]}

### Loc319 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path799 => Loc150  вер=1 порядок=5
       ответ: The <clr>Sky Fireworks<clrEnd> took years to prepare and was over all too soon. The rave of colours that turned the sky into an amazing play of lights lasted on…
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path818 => Loc150  вер=1 порядок=5
       ответ: The <clr>Sky Fireworks<clrEnd> were supposed to become the climax of your performance! However the promoters decided to save up on this effect, and instead of b…
       эффект: P39(Performance) = {[p39]+[1..3]}

### Loc320 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path800 => Loc150  вер=1 порядок=5
       ответ: Alright, time for some <clr> holographic effects<clrEnd>! You ordered a huge monster that appeared over the stadium is several seconds! Unfortunately the dumb M…
       эффект: P29(Time on stage) = {[p29]-[25..30]}
       эффект: P39(Performance) = {[p39]+[2..5]}
  -> Path816 => Loc150  вер=1 порядок=5
       ответ: Alright, time for some <clr> holographic effects<clrEnd>! You ordered a huge monster that appeared over the stadium is several seconds! The monster flew all ove…
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path817 => Loc150  вер=1 порядок=5
       ответ: Alright, time for some <clr> holographic effects<clrEnd>! You ordered a huge monster that was to appear over the stadium. But unfortunately you were too <clr>dr…
       условия: P5(Drunkenness) 2..4
       эффект: P39(Performance) = {[p39]+[0..1]}

### Loc321 [пустая] визитов<=1
    эффект: P29(Time on stage) = {[p29]-[13..17]}
  -> Path801 => Loc150  вер=1 порядок=5
       ответ: The moment you ordered the <clr>light effects<clrEnd>, the light went out. The audience booed, but in mere second the stadium lit up with hyper-searchlights! Th…
       эффект: P39(Performance) = {[p39]+[5..10]}
  -> Path819 => Loc150  вер=1 порядок=5
       ответ: The moment you ordered the <clr>light effects<clrEnd>, the light went out. The audience grasped for air, but... Nothing happened! The hyper-searchlights that we…
       эффект: P39(Performance) = {[p39]-[2..5]}
  -> Path820 => Loc150  вер=1 порядок=5
       ответ: The moment you ordered the <clr>light effects<clrEnd>, the whole stadium lit up with hyper-searchlights! Colourful and beautiful they would have left the audien…
       эффект: P39(Performance) = {[p39]+[2..5]}

### Loc331 [пустая]
  -> Path805 => Loc295  вер=1 порядок=5
       ответ: Your mood was bad, so the interview turned out to be a bit on the rude side, and you did not even thank the audience for their support. However, much thanks to …
       условия: P4(Mood) 0..10; P5(Drunkenness) 2..3
       эффект: P39(Performance) = {[p39]-[1..3]}
  -> Path806 => Loc295  вер=1 порядок=5
       ответ: Your spirits were high, and besides you already were a little tipsy. These two factors combined ensured that your interview - that was aired live on stereovisio…
       условия: P4(Mood) 16..20; P5(Drunkenness) 2..3
       эффект: P39(Performance) = {[p39]+[2..5]}
  -> Path807 => Loc295  вер=2 порядок=5
       ответ: You went over to the reporter and said: "Alright, creep, I want an interview!" Not expecting this, he got scared, dropped the mike and ran off. You picked up th…
       условия: P5(Drunkenness) 3..4
       эффект: P39(Performance) = {[p39]-[3..7]}
  -> Path808 => Loc295  вер=3 порядок=5
       ответ: You made a good interview, sent your regards to all the rangers you knew and Ma, thanked the audience and sang a verse from your song as a token of gratitude. A…
       условия: P4(Mood) 11..20; P5(Drunkenness) 0..2; P9(Singer) 3..3
       эффект: P39(Performance) = {[p39]+[3..7]}
  -> Path828 => Loc295  вер=1 порядок=5
       ответ: You were not in your best <clr>mood<clrEnd>, and not <clr>drunk<clrEnd> enough either. Which is why the interview was rather boring and the audience did not lik…
       условия: P4(Mood) 0..10; P5(Drunkenness) 0..1
       эффект: P39(Performance) = {[p39]-[2..5]}
  -> Path829 => Loc295  вер=1 порядок=5
       ответ: You did a good interview, said hello to everyone you were supposed to, thanked the audience and promised to come back again next year with a new album. The usua…
       условия: P4(Mood) 11..20; P5(Drunkenness) 0..2
       эффект: P39(Performance) = {[p39]+[1..3]}

### Loc332 [пустая]
  -> Path809 => Loc78  вер=1 порядок=5
       ответ: Unfortunately your forecast about this player was wrong and he lost the game, and so did you. Had you been <clr>reading<clrEnd> a bit more, maybe you would have…

### Loc333 [пустая] визитов<=8
  -> Path812 => Loc273  вер=1 проходов<=8 порядок=5

### Loc334 [пустая] визитов<=7
  -> Path815 => Loc314  вер=1 проходов<=7 порядок=5

## Анализ
- стартовых: [1]
- концовки: {296: 'УСПЕХ', 297: 'ПРОВАЛ', 302: 'ПРОВАЛ', 312: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
