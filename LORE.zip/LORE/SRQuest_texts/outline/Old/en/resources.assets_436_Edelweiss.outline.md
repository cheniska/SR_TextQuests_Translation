# Квест (формат 1111111126)
Сложность 35; стартовая локация: [42]; путей по умолчанию: 1

## Параметры
- P1 'Your health' [0..100] тип=смерть
    старт: [100]
    [0..100] Your health: <>%
    критическое: You dropped down dead and didn't live to see the bright day of payment of <Money> cr. for the instal…
- P2 '=You are wearing a spacesuit.=' [0..1] тип=обычный
    старт: [0]
    [0..1] You are wearing a spacesuit.
    критическое: Сообщение достижения критического значения параметром 9
- P3 'Spacesuit.' [0..100] тип=обычный
    старт: [0]
    [0..0] No oxygen in the spacesuit!
    [1..20] Oxygen supply: {<>}% <clr>A refill is recommended!<clrEnd>
    [21..100] Oxygen supply in the spacesuit's : {<>}%
    критическое: Сообщение достижения критического значения параметром 1
- P4 "----- You've got: -----" [0..1] тип=обычный
    старт: [0]
    [0..1] YOU'VE GOT:
    критическое: Сообщение достижения критического значения параметром 3
- P5 "=You've got the Edelweiss=" [0..1] тип=обычный
    старт: [0]
    [0..1] Edelweiss
    критическое: Сообщение достижения критического значения параметром 6
- P6 "=You've got the device=" [0..1] тип=обычный
    старт: [0]
    [0..1] The device is on your wrist.
    критическое: Сообщение достижения критического значения параметром 2
- P7 "=You've got the analyzer=" [0..1] тип=обычный
    старт: [0]
    [0..1] Terrain analyzer
    критическое: Сообщение достижения критического значения параметром 7
- P8 '=you have a multi-tool screwdriver=' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] multi-tool screwdriver
    [2..2] =The door to the geologist’s bunkroom is open=
    критическое: Сообщение достижения критического значения параметром 4
- P9 "=you've got a saw=" [0..1] тип=обычный
    старт: [0]
    [0..1] Circular saw
    критическое: Сообщение достижения критического значения параметром 8
- P10 'Events' [0..99] тип=обычный
    старт: [1]
    [0..99] Event: <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Pedometer' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Pedometer: <>
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Search' [0..10] тип=обычный
    старт: [0]
    [0..10] Search: <>
    критическое: Сообщение достижения критического значения параметром 12
- P20 'Parameter 20' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 20: <>
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Parameter 21' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 21: <>
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Parameter 22' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 22: <>
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Parameter 23' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Parameter 24' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Parameter 25' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 25: <>
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Parameter 26' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 26: <>
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Parameter 27' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Parameter 27: <>
    критическое: Сообщение достижения критического значения параметром 27
- P28 'X' [0..100] тип=обычный
    старт: [0]
    [0..100] X: <>
    критическое: Сообщение достижения критического значения параметром 28
- P29 'Horizontal mask' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Horizontal mask: <>
    критическое: Сообщение достижения критического значения параметром 29
- P30 "Player's position" [0..99] тип=обычный
    старт: [33]
    [0..99] Player's position: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Next position' [0..99] тип=обычный
    старт: [0]
    [0..99] Next position: <>
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Inverse mask' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] Inverse mask: <>
    критическое: Сообщение достижения критического значения параметром 32
- P33 'Installation site' [0..99] тип=обычный
    старт: [99]
    [0..99] Installation site: <>
    критическое: Сообщение достижения критического значения параметром 33
- P34 'Current cell type' [0..9] тип=обычный
    старт: [0]
    [0..9] Current cell type: <>
    критическое: Сообщение достижения критического значения параметром 34
- P48 'N' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] N: <>
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc2 [обычная]
    выбор описания: {(([p10]<2)+2*([p10] in [2..6])+3*([p10] in [7;8])+4*([p10]>8))*([p48]=0)+[p48]}
    Loc2-1: The bunkroom is quite cozy, with every kind of convenience and a medical device on the wall. It also has a modern radio station. There is a computer on the tabl…
    Loc2-2: The computer, as usual, is on the table. The medical device on the wall heartily welcomes you with the green light of its stand-by mode.
    Loc2-3: It's quiet in your bunkroom.
    Loc2-4: Someone ransacked the bunkroom and <clr> broke the medical device<clrEnd>.
    Loc2-5: This multi-tool can do more than just drive in screws, breaking locks with it isn't a big problem.
    Loc2-6: You enter the gaalian ranger's badge number, and the file opens. / The video showed a bunkroom, nearly the same as yours, except for a large, concave table with…
    Loc2-7: 1. The installation site must meet a number of requirements (a long list of requirements follows) / ... / Use of a standard geological multipurpose analyzer is …
    Loc2-8: A couple of manipulators slid quickly along your body, making staccato injections in specific locations. The effect is immediate - your health is completely res…
    эффект: P10(Events) = {[p10]+([p10]=7)}
  -> Path36 => Loc3  вер=1
       текст: To the corridor
       эффект: P48(N) = {0}
  -> Path77 => Loc48  вер=1 порядок=3
       текст: Read the instructions for the Edelweiss installation
       эффект: P48(N) = {7}
  -> Path78 => Loc49  вер=1 [всегда видна] порядок=4
       текст: Enter the password for the video file
       условия: логика {[p10]>5}
       эффект: P48(N) = {6}
  -> Path79 => Loc50  вер=1 [всегда видна] порядок=2
       текст: Use the medical device
       условия: логика {[p1]<100 and [p10]<9}
       эффект: P1(Your health) = {100}
       эффект: P48(N) = {8}
  -> Path133 => Loc76  вер=1 порядок=7
       текст: Communicate with the government of planet <FromPlanet>
       условия: логика {[p10]<12}
  -> Path135 => Loc77  вер=1 проходов<=1 порядок=7
       текст: Communicate with the government of planet <FromPlanet>
       условия: логика {[p10]=12}
  -> Path148 => Loc80  вер=1 проходов<=1 порядок=6
       текст: Take the multi-tool screwdriver
       эффект: P4(----- You've got: -----) = {1}
       эффект: P8(=you have a multi-tool screwdriver=) = {1}
       эффект: P48(N) = {5}

### Loc3 [обычная]
    выбор описания: {([p10]=0)+2*([p10]=1)+[3..5]*([p10] in [2..14])}
    Loc3-1: The well-lit corridor is empty. Only the shallow drumming of rubble and the hissing of sand on the station cover break the silence. The storm is still raging ou…
    Loc3-2: You enter the corridor. Suddenly the lock chamber doors swish open and something huge tumbles inside. It's a hydraulic spacesuit for walking on the surface of p…
    Loc3-3: As usual, the corridor is empty. Your footsteps echo loudly in the silence.
    Loc3-4: There's nobody in the corridor. The noise of the storm outside interrupts the silence.
    Loc3-5: The light of a lamp streams down the empty corridor, not foreshadowing anything fearful.
  -> Path32 => Loc27  вер=1 порядок=7
       текст: To the hangar
       эффект: P10(Events) = {[p10]+([p10]=1)}
  -> Path33 => Loc26  вер=1
       текст: To the lock chamber
       эффект: P10(Events) = {[p10]+([p10]=1)}
       эффект: P48(N) = {1}
  -> Path35 => Loc2  вер=1 порядок=6
       текст: To your bunkroom
       эффект: P10(Events) = {[p10]+([p10]=1)+([p10]=0)+([p10]=7)}
  -> Path39 => Loc28  вер=1 порядок=5
       текст: To the equipment
       эффект: P10(Events) = {[p10]+([p10]=1)}
       эффект: P48(N) = {7*([p10]=7)+8*([p10]>7 and [p10]<12)}
  -> Path67 => Loc29  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {[p10]=0 or [p10]=7}
       эффект: P10(Events) = {[p10]+([p10]=1)}
       эффект: P48(N) = {0}
  -> Path123 => Loc72  вер=1000 порядок=6
       текст: To your bunkroom
       условия: логика {[p2]>0}
  -> Path125 => Loc72  вер=1000 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {[p2]>0}
  -> Path126 => Loc72  вер=1000 порядок=7
       текст: To the hangar
       условия: логика {[p2]>0}
  -> Path156 => Loc82  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {[p10]=1 or [p10]=2 or [p10]=3}
       эффект: P10(Events) = {[p10]+([p10]=1)}
  -> Path177 => Loc29  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {([p10]=8 or [p10]=9) and [p8]=1}
       эффект: P48(N) = {0}
  -> Path178 => Loc29  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {([p10]=8 or [p10]=9) and [p8]=2}
       эффект: P48(N) = {4}
  -> Path179 => Loc29  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {([p10]=8 or [p10]=9) and [p8]=0}
       эффект: P48(N) = {0}
  -> Path186 => Loc29  вер=1 порядок=6
       текст: To the geologist's bunkroom
       условия: логика {[p10]>3 and [p10]<7}
       эффект: P10(Events) = {[p10]+([p10]=1)}
       эффект: P48(N) = {2}

### Loc4 [обычная]
    выбор описания: {[1..3]+3*[p2]+3*([p3]>0)}
    Loc4-1: You grope along a wasteland flooded with the red light. The pungent smell of ammonia makes you sick, and the wind throws sand into your face. It's difficult to …
    Loc4-2: You grope along a wasteland flooded with red light. The pungent smell of ammonia makes you ill, and the wind beats sand into your face. It's difficult to find y…
    Loc4-3: You grope along a wasteland flooded with red light. The pungent smell of ammonia makes you ill, and the wind beats sand into your face. It's difficult to find y…
    Loc4-4: You grope through the storm, choking on the ammonia-saturated air. You have to rely on your memory, because the spacesuit doesn't have radar.
    Loc4-5: You grope through the storm, choking on the ammonia-saturated air. You have to rely on your memory, because the spacesuit doesn't have radar.
    Loc4-6: You grope through the storm, choking on the ammonia-saturated air. You have to rely on your memory, because the spacesuit doesn't have radar.
    Loc4-7: You can't figure out which way to go because of the poor visibility caused by the sand and dust blowing all around. The spacesuit's oxygen supply is limited, so…
    Loc4-8: You can't figure out which way to go because of the poor visibility caused by the sand and dust blowing all around. The spacesuit's oxygen supply is limited, so…
    Loc4-9: You can't figure out which way to go because of the poor visibility caused by the sand and dust blowing all around. The spacesuit's oxygen supply is limited, so…
  -> Path3 => Loc6  вер=1 порядок=6
       текст: Go north
       условия: логика {[p30] mod 10>0}
       эффект: P31(Next position) = {[p30]-1}
  -> Path4 => Loc7  вер=1 порядок=8
       текст: Go south
       условия: логика {[p30] mod 10<7}
       эффект: P31(Next position) = {[p30]+1}
  -> Path5 => Loc9  вер=1 порядок=7
       текст: Go east
       условия: логика {[p30] div 10 mod 10<7}
       эффект: P31(Next position) = {[p30]+10}
  -> Path6 => Loc8  вер=1 порядок=9
       текст: Go west
       условия: логика {[p30] div 10 mod 10>0}
       эффект: P31(Next position) = {[p30]-10}
  -> Path88 => Loc26  вер=1 порядок=1
       текст: Go back to the base
       условия: логика {[p30]=33}
       эффект: P48(N) = {2}

### Loc5 [обычная]
    выбор описания: {[p48]+1+2*([p10]>11)}
    Loc5-1: You ascend the ladder, put your hand to the scanner, and open the door. All systems are functioning. You're ready for takeoff right away.
    Loc5-2: You land the ship in the station hangar. The doors above the ship close, and the dust and harmful impurities are pumped out of the air.
    Loc5-3: You ascend the ladder and are about to put your hand to the scanner when you suddenly notice that the <clr>door is already opened<clrEnd>. But you don't see any…
    Loc5-4: You land the ship in the station hangar.
    скрыт: P3,P20,P21,P22,P23,P24,P25,P26,P27,P48
  -> Path2 => Loc27  вер=1
       текст: Go down the ramp
       эффект: P48(N) = {0}
  -> Path61 => Loc40  вер=1 порядок=9
       текст: Decline to fulfill the mission
  -> Path62 => Loc41  вер=1
       текст: Fly the ship above the sandstorm in order to talk with the government
       условия: логика {[p10]<13}
       эффект: P48(N) = {0}

### Loc6 [пустая]
  -> Path8 => Loc54  вер=1 порядок=5

### Loc7 [пустая]
  -> Path9 => Loc54  вер=1 порядок=5

### Loc8 [пустая]
  -> Path7 => Loc54  вер=1 порядок=5

### Loc9 [пустая]
  -> Path10 => Loc54  вер=1 порядок=5

### Loc10 [пустая]
    эффект: P1(Your health) = {[p1]-12*([p3]=0)}
    эффект: P3(Spacesuit.) = {[p3]-7}
    эффект: P29(Horizontal mask) = {1111111*([p30] div 10=0)+10111111*([p30] div 10=1)+11011111*([p30] div 10=2)+11101111*([p30] div 10=3)+11110111*([p30] div 10=4)+11111011*([p30] div 10=5)+11111101*([p30] div 10=6)+11111110*([p30] div 10=7)}
    эффект: P32(Inverse mask) = {10000000*([p30] div 10=0)+1000000*([p30] div 10=1)+100000*([p30] div 10=2)+10000*([p30] div 10=3)+1000*([p30] div 10=4)+100*([p30] div 10=5)+10*([p30] div 10=6)+([p30] div 10=7)}
  -> Path11 => Loc11  вер=1 порядок=5
       условия: логика {[p30] mod 10=0}
  -> Path12 => Loc12  вер=1 порядок=5
       условия: логика {[p30] mod 10=1}
  -> Path13 => Loc13  вер=1 порядок=5
       условия: логика {[p30] mod 10=2}
  -> Path14 => Loc14  вер=1 порядок=5
       условия: логика {[p30] mod 10=3}
  -> Path45 => Loc32  вер=1 порядок=5
       условия: логика {[p30] mod 10=4}
  -> Path46 => Loc33  вер=1 порядок=5
       условия: логика {[p30] mod 10=5}
  -> Path47 => Loc34  вер=1 порядок=5
       условия: логика {[p30] mod 10=6}
  -> Path48 => Loc35  вер=1 порядок=5
       условия: логика {[p30] mod 10=7}

### Loc11 [пустая]
    эффект: P20(Parameter 20) = {10000000*[p20] div 10000000*[p29] div 10000000+1000000*[p20] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p20] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p20] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p20] div 1000 mod 10*[p29] div 1000 mod 10+100*[p20] div 100 mod 10*[p29] div 100 mod 10+10*[p20] div 10 mod 10*[p29] div 10 mod 10+[p20] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path20 => Loc16  вер=1 порядок=5

### Loc12 [пустая]
    эффект: P21(Parameter 21) = {10000000*[p21] div 10000000*[p29] div 10000000+1000000*[p21] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p21] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p21] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p21] div 1000 mod 10*[p29] div 1000 mod 10+100*[p21] div 100 mod 10*[p29] div 100 mod 10+10*[p21] div 10 mod 10*[p29] div 10 mod 10+[p21] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path19 => Loc16  вер=1 порядок=5

### Loc13 [пустая]
    эффект: P22(Parameter 22) = {10000000*[p22] div 10000000*[p29] div 10000000+1000000*[p22] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p22] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p22] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p22] div 1000 mod 10*[p29] div 1000 mod 10+100*[p22] div 100 mod 10*[p29] div 100 mod 10+10*[p22] div 10 mod 10*[p29] div 10 mod 10+[p22] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path18 => Loc16  вер=1 порядок=5

### Loc14 [пустая]
    эффект: P23(Parameter 23) = {10000000*[p23] div 10000000*[p29] div 10000000+1000000*[p23] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p23] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p23] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p23] div 1000 mod 10*[p29] div 1000 mod 10+100*[p23] div 100 mod 10*[p29] div 100 mod 10+10*[p23] div 10 mod 10*[p29] div 10 mod 10+[p23] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path17 => Loc16  вер=1 порядок=5

### Loc15 [пустая]
  -> Path16 => Loc53  вер=1 порядок=5
       условия: логика {[p30]=33}
  -> Path189 => Loc53  вер=1 порядок=5
       условия: логика {[p30]<>33}

### Loc16 [пустая]
    эффект: P30(Player's position) = {[p31]}
  -> Path21 => Loc20  вер=1 порядок=5

### Loc20 [пустая]
    эффект: P29(Horizontal mask) = {1111111*([p30] div 10=0)+10111111*([p30] div 10=1)+11011111*([p30] div 10=2)+11101111*([p30] div 10=3)+11110111*([p30] div 10=4)+11111011*([p30] div 10=5)+11111101*([p30] div 10=6)+11111110*([p30] div 10=7)}
    эффект: P32(Inverse mask) = {10000000*([p30] div 10=0)+1000000*([p30] div 10=1)+100000*([p30] div 10=2)+10000*([p30] div 10=3)+1000*([p30] div 10=4)+100*([p30] div 10=5)+10*([p30] div 10=6)+([p30] div 10=7)}
  -> Path22 => Loc21  вер=1 порядок=5
       условия: логика {[p30] mod 10=3}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p23] div 10000000+[p32] div 1000000 mod 10*[p23] div 1000000 mod 10+[p32] div 100000 mod 10*[p23] div 100000 mod 10+[p32] div 10000 mod 10*[p23] div 10000 mod 10+[p32] div 1000 mod 10*[p23] div 1000 mod 10+[p32] div 100 mod 10*[p23] div 100 mod 10+[p32] div 10 mod 10*[p23] div 10 mod 10+[p32] mod 10*[p23] mod 10}
  -> Path23 => Loc22  вер=1 порядок=5
       условия: логика {[p30] mod 10=2}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p22] div 10000000+[p32] div 1000000 mod 10*[p22] div 1000000 mod 10+[p32] div 100000 mod 10*[p22] div 100000 mod 10+[p32] div 10000 mod 10*[p22] div 10000 mod 10+[p32] div 1000 mod 10*[p22] div 1000 mod 10+[p32] div 100 mod 10*[p22] div 100 mod 10+[p32] div 10 mod 10*[p22] div 10 mod 10+[p32] mod 10*[p22] mod 10}
  -> Path24 => Loc23  вер=1 порядок=5
       условия: логика {[p30] mod 10=1}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p21] div 10000000+[p32] div 1000000 mod 10*[p21] div 1000000 mod 10+[p32] div 100000 mod 10*[p21] div 100000 mod 10+[p32] div 10000 mod 10*[p21] div 10000 mod 10+[p32] div 1000 mod 10*[p21] div 1000 mod 10+[p32] div 100 mod 10*[p21] div 100 mod 10+[p32] div 10 mod 10*[p21] div 10 mod 10+[p32] mod 10*[p21] mod 10}
  -> Path25 => Loc24  вер=1 порядок=5
       условия: логика {[p30] mod 10=0}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p20] div 10000000+[p32] div 1000000 mod 10*[p20] div 1000000 mod 10+[p32] div 100000 mod 10*[p20] div 100000 mod 10+[p32] div 10000 mod 10*[p20] div 10000 mod 10+[p32] div 1000 mod 10*[p20] div 1000 mod 10+[p32] div 100 mod 10*[p20] div 100 mod 10+[p32] div 10 mod 10*[p20] div 10 mod 10+[p32] mod 10*[p20] mod 10}
  -> Path53 => Loc36  вер=1 порядок=5
       условия: логика {[p30] mod 10=4}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p24] div 10000000+[p32] div 1000000 mod 10*[p24] div 1000000 mod 10+[p32] div 100000 mod 10*[p24] div 100000 mod 10+[p32] div 10000 mod 10*[p24] div 10000 mod 10+[p32] div 1000 mod 10*[p24] div 1000 mod 10+[p32] div 100 mod 10*[p24] div 100 mod 10+[p32] div 10 mod 10*[p24] div 10 mod 10+[p32] mod 10*[p24] mod 10}
  -> Path54 => Loc37  вер=1 порядок=5
       условия: логика {[p30] mod 10=5}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p25] div 10000000+[p32] div 1000000 mod 10*[p25] div 1000000 mod 10+[p32] div 100000 mod 10*[p25] div 100000 mod 10+[p32] div 10000 mod 10*[p25] div 10000 mod 10+[p32] div 1000 mod 10*[p25] div 1000 mod 10+[p32] div 100 mod 10*[p25] div 100 mod 10+[p32] div 10 mod 10*[p25] div 10 mod 10+[p32] mod 10*[p25] mod 10}
  -> Path55 => Loc38  вер=1 порядок=5
       условия: логика {[p30] mod 10=6}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p26] div 10000000+[p32] div 1000000 mod 10*[p26] div 1000000 mod 10+[p32] div 100000 mod 10*[p26] div 100000 mod 10+[p32] div 10000 mod 10*[p26] div 10000 mod 10+[p32] div 1000 mod 10*[p26] div 1000 mod 10+[p32] div 100 mod 10*[p26] div 100 mod 10+[p32] div 10 mod 10*[p26] div 10 mod 10+[p32] mod 10*[p26] mod 10}
  -> Path56 => Loc39  вер=1 порядок=5
       условия: логика {[p30] mod 10=7}
       эффект: P34(Current cell type) = {[p32] div 10000000*[p27] div 10000000+[p32] div 1000000 mod 10*[p27] div 1000000 mod 10+[p32] div 100000 mod 10*[p27] div 100000 mod 10+[p32] div 10000 mod 10*[p27] div 10000 mod 10+[p32] div 1000 mod 10*[p27] div 1000 mod 10+[p32] div 100 mod 10*[p27] div 100 mod 10+[p32] div 10 mod 10*[p27] div 10 mod 10+[p32] mod 10*[p27] mod 10}

### Loc21 [пустая]
    эффект: P23(Parameter 23) = {10000000*[p23] div 10000000*[p29] div 10000000+1000000*[p23] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p23] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p23] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p23] div 1000 mod 10*[p29] div 1000 mod 10+100*[p23] div 100 mod 10*[p29] div 100 mod 10+10*[p23] div 10 mod 10*[p29] div 10 mod 10+[p23] mod 10*[p29] mod 10+[p32]}
  -> Path26 => Loc25  вер=1 порядок=5

### Loc22 [пустая]
    эффект: P22(Parameter 22) = {10000000*[p22] div 10000000*[p29] div 10000000+1000000*[p22] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p22] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p22] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p22] div 1000 mod 10*[p29] div 1000 mod 10+100*[p22] div 100 mod 10*[p29] div 100 mod 10+10*[p22] div 10 mod 10*[p29] div 10 mod 10+[p22] mod 10*[p29] mod 10+[p32]}
  -> Path27 => Loc25  вер=1 порядок=5

### Loc23 [пустая]
    эффект: P21(Parameter 21) = {10000000*[p21] div 10000000*[p29] div 10000000+1000000*[p21] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p21] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p21] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p21] div 1000 mod 10*[p29] div 1000 mod 10+100*[p21] div 100 mod 10*[p29] div 100 mod 10+10*[p21] div 10 mod 10*[p29] div 10 mod 10+[p21] mod 10*[p29] mod 10+[p32]}
  -> Path28 => Loc25  вер=1 порядок=5

### Loc24 [пустая]
    эффект: P20(Parameter 20) = {10000000*[p20] div 10000000*[p29] div 10000000+1000000*[p20] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p20] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p20] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p20] div 1000 mod 10*[p29] div 1000 mod 10+100*[p20] div 100 mod 10*[p29] div 100 mod 10+10*[p20] div 10 mod 10*[p29] div 10 mod 10+[p20] mod 10*[p29] mod 10+[p32]}
  -> Path29 => Loc25  вер=1 порядок=5

### Loc25 [пустая]
  -> Path113 => Loc15  вер=1 порядок=5
  -> Path115 => Loc68  вер=1000 проходов<=1 порядок=5
       условия: логика {[p11]=0 and [p7]=1 and [p10]=4}
       эффект: P28(X) = {3}
       эффект: P48(N) = {1}
  -> Path117 => Loc69  вер=1000 проходов<=1 порядок=5
       условия: P31(Next position) ∉[22, 23, 24, 32, 33, 34, 42, 43, 44]; логика {[p11]=0 and [p7]=1 and [p10]=5}
  -> Path118 => Loc70  вер=1000 проходов<=1 порядок=5
       условия: P31(Next position) ∉[13, 22, 23, 24, 31, 32, 33, 34, 35, 42, 43, 44, 53]; логика {[p11]=0 and [p7]=1 and [p10]=6 and [p34]<>8}
  -> Path128 => Loc73  вер=1000 проходов<=1 порядок=5
       условия: логика {[p33]=[p30] and [p10]=9}
  -> Path129 => Loc74  вер=1000 проходов<=1 порядок=5
       условия: логика {[p10]=10}
       эффект: P1(Your health) -15%
       эффект: P10(Events) = {11}
       эффект: P28(X) = {3}
       эффект: P48(N) = {1}

### Loc26 [обычная]
    выбор описания: {[p48]}
    Loc26-1: The doors close, and the lock chamber falls silent.
    Loc26-2: As soon as the external gate closes, the pumps start up. The air is cleared of impurities and dust, and you can inhale the pure air freely.
    Loc26-3: You connect the charging device to a special jack on the spacesuit's chest panel. The hoses strain from the pressure, but soon the charging system shuts down wi…
  -> Path34 => Loc3  вер=1 порядок=8
       текст: To the corridor
  -> Path41 => Loc53  вер=1 порядок=5
       текст: To the surface
       эффект: P30(Player's position) = {33}
       эффект: P34(Current cell type) = {9}
  -> Path194 => Loc28  вер=1 порядок=9
       текст: To the equipment
       условия: логика {[p10]>1}
       эффект: P48(N) = {7*([p10]=7)+8*([p10]>7 and [p10]<12)}

### Loc27 [обычная]
    выбор описания: {([p10]=0)+2*([p10]>0)}
    Loc27-1: Heat from your ship's engines is spreading throughout the small hangar. The door from here leads into a corridor that connects all the rooms of the station.
    Loc27-2: Your ship is in the small hanger, ready for a takeoff.
    эффект: P10(Events) = {[p10]+([p10]=7)}
  -> Path31 => Loc3  вер=1
       текст: To the corridor
  -> Path64 => Loc5  вер=1 порядок=5
       текст: Climb up into the ship
       эффект: P48(N) = {0}

### Loc28 [обычная]
    выбор описания: {[p48]+1}
    Loc28-1: You are at a stand with various geological equipment.
    Loc28-2: After checking that its reserves are okay, you squash into a heavy spacesuit and turn it on.
    Loc28-3: You deftly get out of the spacesuit and plug it into the charging device. It starts whistling, replenishes the spacesuit's reserves, and then switches off.
    Loc28-4: You pick up the analyzer. This rather heavy device can show where the Edelweiss unit can be installed in order to provide permanent communication, the soil shou…
    Loc28-5: You put down the Edelweiss and pick up the analyzer. / The device consists of a heavy case equipped with the Violet Fang system, which transmits the data direct…
    Loc28-6: You pick up the box with the Edelweiss unit.
    Loc28-7: They are too heavy to carry at the same time. You put down the analyzer case, and pick up the box with the Edelweiss unit.
    Loc28-8: The <clr>Edelweiss unit is missing<clrEnd> from the equipment rack!
    Loc28-9: All the equipment is there <clr>but the spacesuit!<clrEnd>
    Loc28-10: You connect the charging device to a special jack on the spacesuit's chest panel. The hoses strain from the pressure, but soon the charging system shut down wit…
  -> Path40 => Loc3  вер=1 порядок=1
       текст: To the corridor
       эффект: P48(N) = {0}
  -> Path42 => Loc30  вер=1 порядок=9
       текст: Put the spacesuit on
       условия: логика {[p2]=0 and ([p10] in [2..7])}
       эффект: P2(=You are wearing a spacesuit.=) = {1}
       эффект: P3(Spacesuit.) = {100} [показ]
       эффект: P48(N) = {1}
  -> Path43 => Loc30  вер=1 порядок=9
       текст: Remove the spacesuit
       условия: логика {[p2]}
       эффект: P2(=You are wearing a spacesuit.=) = {0}
       эффект: P3(Spacesuit.) = {0} [скрыт]
       эффект: P48(N) = {2}
  -> Path81 => Loc51  вер=1 порядок=5
       текст: Take the Edelweiss unit
       условия: логика {[p5]=0 and [p10]<7 and [p7]=0}
       эффект: P4(----- You've got: -----) = {1}
       эффект: P5(=You've got the Edelweiss=) = {1}
       эффект: P48(N) = {5}
  -> Path152 => Loc81  вер=1 порядок=2
       текст: Take the analyzer
       условия: логика {[p7]=0 and [p5]=0 and [p10]<7}
       эффект: P4(----- You've got: -----) = {1}
       эффект: P7(=You've got the analyzer=) = {1}
       эффект: P48(N) = {3}
  -> Path153 => Loc81  вер=1 порядок=1
       текст: Take the analyzer
       условия: логика {[p7]=0 and [p5]=1 and [p10]<7}
       эффект: P4(----- You've got: -----) = {1}
       эффект: P5(=You've got the Edelweiss=) = {0}
       эффект: P7(=You've got the analyzer=) = {1}
       эффект: P48(N) = {4}
  -> Path154 => Loc51  вер=1 порядок=4
       текст: Take the Edelweiss unit
       условия: логика {[p5]=0 and [p10]<7 and [p7]=1}
       эффект: P4(----- You've got: -----) = {1}
       эффект: P5(=You've got the Edelweiss=) = {1}
       эффект: P7(=You've got the analyzer=) = {0}
       эффект: P48(N) = {6}
  -> Path193 => Loc26  вер=1
       текст: To the air lock
       условия: логика {[p10]>1}
       эффект: P48(N) = {1}
  -> Path195 => Loc30  вер=1 порядок=8
       текст: Replenish the spacesuit's reserves
       условия: логика {[p2] and [p3]<100}
       эффект: P2(=You are wearing a spacesuit.=) = {1}
       эффект: P3(Spacesuit.) = {100}
       эффект: P48(N) = {9}

### Loc29 [обычная]
    выбор описания: {1+[p48]}
    Loc29-1: The door to the geologist's bunkroom is locked, and nobody answers.
    Loc29-2: The screwdriver rustling in the lock made the geologist open the door and nearly choke at your boldness:  / "What the ...! What do you think you are doing?!" He…
    Loc29-3: You hear a circular saw can heard from time to time behind the door. But the geologist obviously isn't going to open the door.
    Loc29-4: The door with number {[p28]} opens, but you find nothing useful in this compartment.
    Loc29-5: You are in the middle of the geologist's bunkroom. The nauseating sight of the remains of a worm on a dissection table suppresses any desire to stay here.
    Loc29-6: The box with the Edelweiss unit is covered with a cloth on the bottom shelf of the rack.
    Loc29-7: Based on the information on the panel, you realize that most of the samples taken from the annulus creeper's stomach are gold nuggets! But you don’t find the pr…
    Loc29-8: A secret compartment in the cabinet opens. It is holding a circular saw inside, which soon made its way into your hands.
    Loc29-9: You find only slime and fine slices of the worm under the table.
    Loc29-10: With the kind of screwdriver you have, this wasn't difficult. The door swings open and you are greeted with a disgusting sight: the worm's remains are lying on …
    эффект: P10(Events) = {[p10]+([p10]=7)}
  -> Path38 => Loc3  вер=1 порядок=5
       текст: To the corridor
       эффект: P48(N) = {0}
  -> Path121 => Loc86  вер=1 проходов<=1 порядок=9
       текст: Look under the table
       условия: логика {[p8]=2}
       эффект: P48(N) = {8}
  -> Path151 => Loc86  вер=1 проходов<=1 порядок=6
       текст: Force open the door
       условия: логика {[p10]=8 and [p8]=1}
       эффект: P8(=you have a multi-tool screwdriver=) = {2} [скрыт]
       эффект: P48(N) = {9}
  -> Path173 => Loc86  вер=1 проходов<=1 порядок=6
       текст: Force open the door
       условия: логика {[p10]<8 and [p8]=1}
       эффект: P48(N) = {1}
  -> Path174 => Loc87  вер=1 порядок=7
       текст: Open the second door on the case
       условия: логика {[p8]=2 and [p12]<>3 and [p9]=0}
       эффект: P12(Search) = {1}
       эффект: P28(X) = {2}
       эффект: P48(N) = {3}
  -> Path175 => Loc86  вер=1 проходов<=1 порядок=9
       текст: Examine the rack
       условия: логика {[p8]=2}
       эффект: P5(=You've got the Edelweiss=) = {1}
       эффект: P7(=You've got the analyzer=) = {0}
       эффект: P10(Events) = {9}
       эффект: P48(N) = {5}
  -> Path176 => Loc86  вер=1 проходов<=1 порядок=9
       текст: Examine the rock analyzer
       условия: логика {[p8]=2}
       эффект: P48(N) = {6}
  -> Path181 => Loc87  вер=1 порядок=6
       текст: Open the first door on the case
       условия: логика {[p8]=2 and [p9]=0}
       эффект: P12(Search) = {3*([p12]=2)}
       эффект: P28(X) = {1}
       эффект: P48(N) = {3}
  -> Path182 => Loc87  вер=1 порядок=8
       текст: Open the third door on the case
       условия: логика {[p8]=2 and [p9]=0}
       эффект: P12(Search) = {2*([p12]=1)}
       эффект: P28(X) = {3}
       эффект: P48(N) = {3}
  -> Path183 => Loc86  вер=1 проходов<=1 порядок=7
       текст: Open the second door on the case
       условия: логика {[p8]=2 and [p12]=3 and [p9]=0}
       эффект: P9(=you've got a saw=) = {1}
       эффект: P28(X) = {2}
       эффект: P48(N) = {7}

### Loc30 [пустая]
    эффект: P10(Events) = {[p10]+([p10]=0)}
  -> Path44 => Loc28  вер=1 порядок=5

### Loc32 [пустая]
    эффект: P24(Parameter 24) = {10000000*[p24] div 10000000*[p29] div 10000000+1000000*[p24] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p24] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p24] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p24] div 1000 mod 10*[p29] div 1000 mod 10+100*[p24] div 100 mod 10*[p29] div 100 mod 10+10*[p24] div 10 mod 10*[p29] div 10 mod 10+[p24] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path49 => Loc16  вер=1 порядок=5

### Loc33 [пустая]
    эффект: P25(Parameter 25) = {10000000*[p25] div 10000000*[p29] div 10000000+1000000*[p25] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p25] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p25] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p25] div 1000 mod 10*[p29] div 1000 mod 10+100*[p25] div 100 mod 10*[p29] div 100 mod 10+10*[p25] div 10 mod 10*[p29] div 10 mod 10+[p25] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path50 => Loc16  вер=1 порядок=5

### Loc34 [пустая]
    эффект: P26(Parameter 26) = {10000000*[p26] div 10000000*[p29] div 10000000+1000000*[p26] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p26] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p26] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p26] div 1000 mod 10*[p29] div 1000 mod 10+100*[p26] div 100 mod 10*[p29] div 100 mod 10+10*[p26] div 10 mod 10*[p29] div 10 mod 10+[p26] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path51 => Loc16  вер=1 порядок=5

### Loc35 [пустая]
    эффект: P27(Parameter 27) = {10000000*[p27] div 10000000*[p29] div 10000000+1000000*[p27] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p27] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p27] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p27] div 1000 mod 10*[p29] div 1000 mod 10+100*[p27] div 100 mod 10*[p29] div 100 mod 10+10*[p27] div 10 mod 10*[p29] div 10 mod 10+[p27] mod 10*[p29] mod 10+[p32]*[p34]}
  -> Path52 => Loc16  вер=1 порядок=5

### Loc36 [пустая]
    эффект: P24(Parameter 24) = {10000000*[p24] div 10000000*[p29] div 10000000+1000000*[p24] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p24] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p24] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p24] div 1000 mod 10*[p29] div 1000 mod 10+100*[p24] div 100 mod 10*[p29] div 100 mod 10+10*[p24] div 10 mod 10*[p29] div 10 mod 10+[p24] mod 10*[p29] mod 10+[p32]}
  -> Path57 => Loc25  вер=1 порядок=5

### Loc37 [пустая]
    эффект: P25(Parameter 25) = {10000000*[p25] div 10000000*[p29] div 10000000+1000000*[p25] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p25] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p25] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p25] div 1000 mod 10*[p29] div 1000 mod 10+100*[p25] div 100 mod 10*[p29] div 100 mod 10+10*[p25] div 10 mod 10*[p29] div 10 mod 10+[p25] mod 10*[p29] mod 10+[p32]}
  -> Path58 => Loc25  вер=1 порядок=5

### Loc38 [пустая]
    эффект: P26(Parameter 26) = {10000000*[p26] div 10000000*[p29] div 10000000+1000000*[p26] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p26] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p26] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p26] div 1000 mod 10*[p29] div 1000 mod 10+100*[p26] div 100 mod 10*[p29] div 100 mod 10+10*[p26] div 10 mod 10*[p29] div 10 mod 10+[p26] mod 10*[p29] mod 10+[p32]}
  -> Path59 => Loc25  вер=1 порядок=5

### Loc39 [пустая]
    эффект: P27(Parameter 27) = {10000000*[p27] div 10000000*[p29] div 10000000+1000000*[p27] div 1000000 mod 10*[p29] div 1000000 mod 10+100000*[p27] div 100000 mod 10*[p29] div 100000 mod 10+10000*[p27] div 10000 mod 10*[p29] div 10000 mod 10+1000*[p27] div 1000 mod 10*[p29] div 1000 mod 10+100*[p27] div 100 mod 10*[p29] div 100 mod 10+10*[p27] div 10 mod 10*[p29] div 10 mod 10+[p27] mod 10*[p29] mod 10+[p32]}
  -> Path60 => Loc25  вер=1 порядок=5

### Loc40 [ПРОВАЛ]
    Loc40-1: The force of sand and dust hisses against the roof of the ship, but you soon leave the storm area and land and a quiet region of planet <ToPlanet>. / You're saf…

### Loc41 [обычная]
    выбор описания: {1+[p48]}
    Loc41-1: After leaving the dense clouds of sand and dust below, you are able to contact the head of the research department. He looks at you attentively.  / "Is there so…
    Loc41-2: "You need to install the Edelweiss radio unit so we can communicate with the station despite the furious sandstorms. It's vital that you wear the spacesuit to a…
    Loc41-3: "Hmmm. It's very strange, but Guyolak insists that he won't come out until <ToStar>'s hyperactivity ends. And these storms seem to be related to it. Maybe he's …
    Loc41-4: "So it seems this engineer left the station without radar?" asks the chief in amazement. / "Yes. That's what Guyolak told me. What's more, he had his device!" y…
    Loc41-5: "I huge worm attacked me! You didn't warn me that this mission would be dangerous! How are you going to cover these risks?"  / "Just a minute..." the chief said…
    Loc41-6: You describe your careful discovery. The chief looks at you sympathetically.  / "I'm very sorry you had to go through that. Nevertheless, you must fulfill your …
    Loc41-7: "Perfect. Just a mere formality remains. I need you to connect with me from your bunkroom, <Ranger>. Then we can consider this job done!"
    Loc41-8: "That won't do. How did you lose your spacesuit?" asks the chief reproachfully. / "Guyolak took it. So how am I to install the Edelweiss unit now?" / "Hmmm... Y…
    Loc41-9: "Of course, to go under the surface of a severe planet like <ToPlanet> you should have a spacesuit, but it is possible without one. The important thing is to on…
  -> Path63 => Loc5  вер=1
       текст: Land in the station hangar
       эффект: P48(N) = {1}
  -> Path80 => Loc88  вер=1 порядок=9
       текст: Decline to fulfill the mission
  -> Path138 => Loc79  вер=1 проходов<=1 порядок=2
       текст: Describe the geologist's activities on the surface
       условия: логика {[p10]>1 and [p10]<6}
       эффект: P48(N) = {2}
  -> Path139 => Loc79  вер=1 порядок=1
       текст: Clarify your mission
       условия: логика {[p10]<10}
       эффект: P48(N) = {1}
  -> Path140 => Loc79  вер=1 проходов<=1 порядок=4
       текст: Mention the worm
       условия: логика {[p10]>4 and [p10]<10}
       эффект: P48(N) = {4}
  -> Path141 => Loc79  вер=1 проходов<=1 порядок=3
       текст: Mention the geologist's radar
       условия: логика {[p10]>3 and [p10]<10}
       эффект: P48(N) = {3}
  -> Path142 => Loc79  вер=1 проходов<=1 порядок=5
       текст: Say something about the Gaal's discovery
       условия: логика {[p10]>5 and [p10]<10}
       эффект: P48(N) = {5}
  -> Path143 => Loc79  вер=1 проходов<=1 порядок=6
       текст: Ask how to proceed further
       условия: логика {[p10]=12}
       эффект: P48(N) = {6}
  -> Path144 => Loc79  вер=1 проходов<=1 порядок=7
       текст: Ask about arriving on the surface
       условия: логика {[p10]=9}
       эффект: P48(N) = {8}

### Loc42 [СТАРТ]
    выбор описания: {1}
    Loc42-1: The chief geological researcher from planet <FromPlanet> came on the line, gave you the coordinates of the station, and began to bring you up to speed on the si…
    Loc42-2: Edelweiss © 2006 Ruslan Tchernyi
    эффект: P10(Events) = {0} [скрыт]
    эффект: P11(Pedometer) = {[5..8]} [скрыт]
    скрыт: P3,P12,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P48
  -> Path65 => Loc27  вер=1
       текст: Go down the ramp
  -> Path66 => Loc40  вер=1 порядок=9
       текст: Decline to fulfill the mission

### Loc48 [пустая]
  -> Path85 => Loc50  вер=1 порядок=5

### Loc49 [пустая]
  -> Path86 => Loc48  вер=1 порядок=5

### Loc50 [пустая]
  -> Path84 => Loc2  вер=1 порядок=5

### Loc51 [пустая]
  -> Path155 => Loc81  вер=1 порядок=5

### Loc53 [пустая]
  -> Path110 => Loc4  вер=1 порядок=5
       условия: логика {[p6]=0}
  -> Path111 => Loc55  вер=1 порядок=5
       условия: логика {[p7]=0 and [p6]=1}
  -> Path112 => Loc56  вер=1 порядок=5
       условия: логика {[p7]=1 and [p6]=1}

### Loc54 [пустая]
  -> Path89 => Loc10  вер=1 порядок=5
       эффект: P34(Current cell type) = {0}

### Loc55 [обычная]
    выбор описания: {[1..3]+3*[p2]+3*([p3]>0)}
    Loc55-1: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc55-2: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc55-3: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc55-4: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc55-5: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc55-6: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc55-7: The heavy boots of your spacesuit sink down into quicksand. / Your location is shown on the radar: / <fix> / ----------------- / |{[p20] div10000000} {[p20] div…
    Loc55-8: The heavy boots of your spacesuit sink down into quicksand. / Your location is shown on the radar: / <fix> / ----------------- / |{[p20] div10000000} {[p20] div…
    Loc55-9: The heavy boots of your spacesuit sink down into quicksand. / Your location is shown on the radar: / <fix> / ----------------- / |{[p20] div10000000} {[p20] div…
  -> Path92 => Loc58  вер=1 порядок=7
       текст: Go east
       условия: логика {[p30] div 10 mod 10<7}
       эффект: P31(Next position) = {[p30]+10}
  -> Path94 => Loc59  вер=1 порядок=9
       текст: Go west
       условия: логика {[p30] div 10 mod 10>0}
       эффект: P31(Next position) = {[p30]-10}
  -> Path97 => Loc60  вер=1 порядок=6
       текст: Go north
       условия: логика {[p30] mod 10>0}
       эффект: P31(Next position) = {[p30]-1}
  -> Path99 => Loc57  вер=1 порядок=8
       текст: Go south
       условия: логика {[p30] mod 10<7}
       эффект: P31(Next position) = {[p30]+1}
  -> Path108 => Loc26  вер=1 порядок=1
       текст: Go back to the base
       условия: логика {[p30]=33}
       эффект: P48(N) = {2}

### Loc56 [обычная]
    выбор описания: {([1..3]+3*[p2]+3*([p3]>0))*([p10]<6)+([1..3]+3*[p2]+3*([p3]>0))*([p10]>5 and [p11]<>2)+10*([p10]>5 and [p11]=2)}
    Loc56-1: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc56-2: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc56-3: The local atmosphere is suffocating you, but you carry on through the clouds of sand and dust. / The radar is tracking your exact location: / <fix> / ----------…
    Loc56-4: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc56-5: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc56-6: While wearing the spacesuit, every step you take on the planet's stony surface rings in your ears. Your lungs begin cramping as you struggle to breathe the pois…
    Loc56-7: All of the spacesuit's systems are operational as you grope slowly along the surface of the planet. / The analyzer is doing its work, marking the explored areas…
    Loc56-8: All of the spacesuit's systems are operational as you grope slowly along the surface of the planet. / The analyzer is doing its work, marking the explored areas…
    Loc56-9: All of the spacesuit's systems are operational as you grope slowly along the surface of the planet. / The analyzer is doing its work, marking the explored areas…
    Loc56-10: You go 100 meters and notice that your radar unit is dead. Slapping its case a few times seems to revive it, but its indicator lights are flickering: / <fix> / …
  -> Path93 => Loc62  вер=1 порядок=7
       текст: Go east
       условия: логика {[p30] div 10 mod 10<7}
       эффект: P31(Next position) = {[p30]+10}
  -> Path95 => Loc63  вер=1 порядок=9
       текст: Go west
       условия: логика {[p30] div 10 mod 10>0}
       эффект: P31(Next position) = {[p30]-10}
  -> Path96 => Loc64  вер=1 порядок=6
       текст: Go north
       условия: логика {[p30] mod 10>0}
       эффект: P31(Next position) = {[p30]-1}
  -> Path98 => Loc61  вер=1 порядок=8
       текст: Go south
       условия: логика {[p30] mod 10<7}
       эффект: P31(Next position) = {[p30]+1}
  -> Path109 => Loc26  вер=1 порядок=1
       текст: Go back to the base
       условия: логика {[p30]=33}
       эффект: P48(N) = {2}

### Loc57 [пустая]
  -> Path107 => Loc65  вер=1 порядок=5

### Loc58 [пустая]
  -> Path100 => Loc65  вер=1 порядок=5

### Loc59 [пустая]
  -> Path106 => Loc65  вер=1 порядок=5

### Loc60 [пустая]
  -> Path105 => Loc65  вер=1 порядок=5

### Loc61 [пустая]
  -> Path104 => Loc66  вер=1 порядок=5

### Loc62 [пустая]
  -> Path101 => Loc66  вер=1 порядок=5

### Loc63 [пустая]
  -> Path103 => Loc66  вер=1 порядок=5

### Loc64 [пустая]
  -> Path102 => Loc66  вер=1 порядок=5

### Loc65 [пустая]
  -> Path90 => Loc10  вер=1 порядок=5

### Loc66 [пустая]
    эффект: P11(Pedometer) = {[p11]-([p34]=0)}
  -> Path91 => Loc10  вер=1 порядок=5
       эффект: P34(Current cell type) = {8*([p30]<>[p33])+2*([p30]=[p33])}

### Loc67 [обычная]
    выбор описания: {[p48]}
    Loc67-1: The blow is powerful and exact. The worm arches, begins trembles, and then becomes still. You cautiously get out of the quicksand and cast an apprehensive glanc…
    Loc67-2: You nearly trip over something. It's the body of a Gaal in a spacesuit. He's frozen as if attempting to shout, clutching his throat with his hands. You examine …
    Loc67-3: The analyzer emits a pleasant sound, indicating that your current location satisfies the installation requirements for the radio unit.
    Loc67-4: Relieved, you put down the box and press the "Install" button. The panels on the packaging open and the mechanism releases several supports, which immediately g…
    Loc67-5: You evade the geologist's blows and kick at him powerfully in return. The Fae takes a blow in the stomach and falls, dripping froth from his mouth onto the sand…
    Loc67-6: Guyolak tries to grab your throat, but you thrust the saw forward and turn it on... The offensive sound of the bones being cut asunder muffles the howls of the …
  -> Path15 => Loc15  вер=1 порядок=5
       текст: Keep moving
  -> Path168 => Loc15  вер=1 порядок=9
       текст: Put the geologist's spacesuit on
       условия: логика {[p10]=12}
       эффект: P2(=You are wearing a spacesuit.=) = {1}
       эффект: P3(Spacesuit.) = {[45..55]} [показ]

### Loc68 [обычная]
    выбор описания: {[p48]}
    Loc68-1: Suddenly, your legs disappear into the sand. You struggle with all your might, but you are helplessly stuck. A huge worm emerges from the soil. You can't escape…
    Loc68-2: Waiting for the right moment, you strike the worm on its head. It's as hard as concrete. In response, the creeper gives you a strong bite.
    Loc68-3: The creeper manages to open its jaws and bite your arm, causing you great pain.
    Loc68-4: The worm's back is unprotected. You strike, leaving it with just {[p28]*30}% of its health.
    Loc68-5: The screwdriver cuts badly into the worm's neck, leaving it with {[p28]*30}% of its health.
    Loc68-6: In your struggle to escape, you find yourself sinking deeper into the sand. The worm manages to creep around behind you. It bites you severely in the back.
    эффект: P10(Events) = {5}
    эффект: P11(Pedometer) = {[3..5]}
  -> Path162 => Loc84  вер=1 порядок=2
       текст: Hit the worm on the head
       эффект: P1(Your health) -20%
       эффект: P48(N) = {2}
  -> Path163 => Loc84  вер=1 порядок=3
       текст: Hit the worm in the teeth
       эффект: P1(Your health) -50%
       эффект: P48(N) = {3}
  -> Path164 => Loc84  вер=1 порядок=4
       текст: Hit the worm on the back
       эффект: P28(X) = {[p28]-1}
       эффект: P48(N) = {4}
  -> Path165 => Loc84  вер=1 порядок=1
       текст: Hit the worm on the side
       эффект: P28(X) = {[p28]-3}
       эффект: P48(N) = {5}
  -> Path166 => Loc84  вер=1 порядок=9
       текст: Try to run away
       эффект: P1(Your health) -50%
       эффект: P48(N) = {6}
  -> Path188 => Loc84  вер=1 порядок=5
       текст: Stab him with the screwdriver
       условия: логика {[p8]}
       эффект: P28(X) = {[p28]-2}
       эффект: P48(N) = {5}

### Loc69 [пустая] визитов<=1
    эффект: P10(Events) = {6}
    эффект: P11(Pedometer) = {[2..4]}
    эффект: P48(N) = {2}
  -> Path119 => Loc67  вер=1 проходов<=1 порядок=5

### Loc70 [пустая] визитов<=1
    эффект: P10(Events) = {7}
    эффект: P11(Pedometer) = {0}
    эффект: P33(Installation site) = {[p31]}
    эффект: P48(N) = {3}
  -> Path120 => Loc67  вер=1 проходов<=1 порядок=5

### Loc72 [обычная]
    Loc72-1: The door opening is too small for your spacesuit to pass through!
    Loc72-2: The spacesuit is too big - it's preventing you from going through the door.
    Loc72-3: You must remove the spacesuit to pass through the door.
    Loc72-4: You must remove the spacesuit to pass through the door. You can do that at the equipment rack.
  -> Path124 => Loc3  вер=1 порядок=5
       текст: Step away from the door

### Loc73 [пустая] визитов<=1
    эффект: P5(=You've got the Edelweiss=) = {0}
    эффект: P10(Events) = {10}
    эффект: P48(N) = {4}
  -> Path127 => Loc67  вер=1 проходов<=1 порядок=5

### Loc74 [обычная]
    выбор описания: {[p48]}
    Loc74-1: Something hits you in the back! Turning around, you see Guyolak wearing a spacesuit. He's brandishing a stick at you.  / "Heh, heh. You weren't expecting that w…
    Loc74-2: In response to your peaceful gesture, the geologist laughed haughtily and walloped you with the stick.  / "Are all rangers so stupid that they can't understand …
    Loc74-3: You deliver a series of blows, but most of them hit the hard parts of his spacesuit. Guyolak bursts out laughing and again brings the stick down on your head.
    Loc74-5: You manage to kick Guyolak in the unprotected area of the stomach. It hurt the Fae - a lot.
  -> Path130 => Loc75  вер=1 порядок=2
       текст: Try to find a peaceful resolution
       эффект: P1(Your health) -50%
       эффект: P48(N) = {2}
  -> Path170 => Loc75  вер=1 порядок=3
       текст: Beat the geologist with your hands
       эффект: P1(Your health) -40%
       эффект: P48(N) = {3}
  -> Path171 => Loc75  вер=1 порядок=4
       текст: Kick the geologist
       эффект: P1(Your health) -20%
       эффект: P28(X) = {[p28]-1}
       эффект: P48(N) = {5}
  -> Path172 => Loc75  вер=1 порядок=6
       текст: Use the saw
       условия: логика {[p9]}
       эффект: P28(X) = {0}
       эффект: P48(N) = {6}

### Loc75 [пустая]
    эффект: P10(Events) = {12}
  -> Path131 => Loc67  вер=1000 порядок=5
       условия: логика {[p28]=0}
       эффект: P10(Events) = {12}
  -> Path169 => Loc74  вер=1 порядок=5

### Loc76 [обычная]
    Loc76-1: The speakers emit only an annoying "Psh-psh-psh-psh" sound. You can't make out anything because of all the interference.
  -> Path134 => Loc80  вер=1 порядок=5
       текст: Turn off the transmitter

### Loc77 [УСПЕХ] визитов<=1
    Loc77-1: It isn't the most crisp picture, but the signal is stable enough to communicate with planet <FromPlanet>. "Oh, I see you've connected from your bunkroom!" said …
    эффект: P10(Events) = {13}

### Loc79 [пустая]
  -> Path146 => Loc41  вер=1 порядок=5

### Loc80 [пустая]
  -> Path149 => Loc49  вер=1 порядок=5

### Loc81 [пустая]
  -> Path83 => Loc30  вер=1 порядок=5

### Loc82 [обычная]
    выбор описания: {[p48]+1}
    Loc82-1: After hearing your knock, the geologist opens the door slightly and looks at you questioningly.
    Loc82-2: Guyolak only scowls.  / "Blah, blah, blah-blity, blah...get to the point, <clr>Little<clrEnd> <Ranger>! / "<Ranger>," you correct him. / "It doesn't matter. Say…
    Loc82-3: Guyolak's eyes narrow, then he suddenly puts on an affected grin.  / "Heh, heh. It's quite simple. The blockhead went out <clr>onto the surface with no radar an…
    Loc82-4: "The annulus creeper is a local predator. The creepers cover large distances underground. For me, they're like a natural probe that extends the area of my resea…
    Loc82-5: "That doesn't concern me. You're an engineer; <clr>you've got equipment, a computer<clrEnd> - so, go right ahead! You're not expecting me to do your job, are yo…
    Loc82-6: "Man, you are really obnoxious. Do your job, and I'll do mine. And you don't need to go breaking into my bunkroom: after all, I've got a right to privacy, too. …
    Loc82-7: "Uh," said the fae, faltering for a moment. That creeper wouldn't let me sleep with its constant scratching at the bottom of my bunkroom, so I neutralized it.
    Loc82-8: "Ah. So that's what you're after. Just a second..." The geologist retreats deep into the bunkroom, and through the open door you can see slime stains on the flo…
  -> Path70 => Loc83  вер=1 проходов<=1 порядок=2
       текст: Ask about the engineer who died
       эффект: P10(Events) = {3}
       эффект: P48(N) = {2}
  -> Path71 => Loc83  вер=1 проходов<=1 порядок=3
       текст: Ask about the worm
       эффект: P48(N) = {3}
  -> Path72 => Loc83  вер=1 проходов<=1 порядок=4
       текст: Ask about the Edelweiss installation
       эффект: P48(N) = {4}
  -> Path73 => Loc83  вер=1 проходов<=1 порядок=5
       текст: Hint that his cooperation is required
       эффект: P48(N) = {5}
  -> Path82 => Loc83  вер=1 проходов<=1 порядок=6
       текст: Suggest that the geologist should come outside
       эффект: P48(N) = {6}
  -> Path157 => Loc3  вер=1 порядок=9
       текст: Walk away from the door
       эффект: P48(N) = {0}
  -> Path159 => Loc83  вер=1 проходов<=1 порядок=1
       текст: Apologize for your intrusion
       эффект: P48(N) = {1}
  -> Path160 => Loc83  вер=1 проходов<=1 порядок=7
       текст: Ask about a radar unit
       условия: логика {[p10]=3}
       эффект: P6(=You've got the device=) = {1}
       эффект: P10(Events) = {4}
       эффект: P48(N) = {7}

### Loc83 [пустая]
  -> Path158 => Loc82  вер=1 порядок=5

### Loc84 [пустая]
  -> Path116 => Loc67  вер=1000 порядок=5
       условия: логика {[p28]=0}
       эффект: P48(N) = {1}
  -> Path167 => Loc68  вер=1 порядок=5

### Loc86 [пустая]
  -> Path180 => Loc29  вер=1 порядок=5

### Loc87 [пустая]
  -> Path187 => Loc29  вер=1 порядок=5

### Loc88 [обычная]
    Loc88-1: "Hold on, <Ranger>! You encounter more difficult tasks in your everyday service. Please help us install the radio unit," begs the official.
  -> Path191 => Loc40  вер=1 порядок=9
       текст: Decline to fulfill the mission
  -> Path192 => Loc5  вер=1
       текст: Land in the station hangar
       эффект: P48(N) = {1}

## Анализ
- стартовых: [42]
- концовки: {40: 'ПРОВАЛ', 77: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
