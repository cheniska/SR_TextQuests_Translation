# Квест (формат 1111111126)
Сложность 45; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Money' [0..10000] тип=обычный
    старт: [0]
    [0..0] You haven’t enough money.
    [1..10000] You have <> marks.
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Fishing rod' [0..5] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] <clr>"Filter"<clrEnd> fishing rod
    [2..2] <clr>"Cotton"<clrEnd> fishing rod
    [3..3] <clr>"Aqua"<clrEnd> fishing rod
    [4..4] <clr>"Reflex"<clrEnd> fishing rod
    [5..5] Ordinary fishing rod
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Tackle' [0..5] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Thick line and a rusty hook
    [2..2] Ordinary line and an ordinary hook
    [3..3] Thin line and a sharp hook
    [4..4] Transparent line and a titanium hook
    [5..5] Ordinary tackle
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Green worms' [0..1000] тип=обычный
    старт: [0]
    [0..1000] <> green worms
    критическое: Сообщение достижения критического значения параметром 4
- P5 'White worms' [0..1000] тип=обычный
    старт: [0]
    [0..1000] <> white worms
    критическое: Сообщение достижения критического значения параметром 5
- P6 'Ordinary worms' [0..1000] тип=обычный
    старт: [0]
    [0..1000] <> ordinary worms
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Sobriety' [0..5] тип=провал
    старт: [0]
    [0..0] 
    [1..1] You feel relaxed
    [2..2] You are a little drunk
    [3..3] You are drunk
    [4..4] You are drunk as a sailor
    [5..5] You're really ill
    критическое: You drank too much and feel sick. Somebody called an ambulance and you were taken to the hospital. I…
- P8 'Time' [0..30] тип=обычный
    старт: [0]
    [0..0] Your time has run out!
    [1..30] <> minutes left
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Fish weight' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Fish weight: <> g
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Carrion weight' [0..100000] тип=обычный
    старт: [0]
    [0..100000] Vulture's fish weight: / : <>
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Your current fish' [0..20000] тип=обычный
    старт: [0]
    [0..20000] 
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Balance' [0..6] тип=обычный
    старт: [0]
    [0..0] <Ranger> [<clr>+<clrEnd>. . . . . . ] <clr>Vulture<clrEnd>
    [1..1] <Ranger> [ .<clr>+<clrEnd>. . . . . ] <clr>Vulture<clrEnd>
    [2..2] <Ranger> [ . .<clr>+<clrEnd>. . . . ] <clr>Vulture<clrEnd>
    [3..3] <Ranger> [ . . .<clr>+<clrEnd>. . . ] <clr>Vulture<clrEnd>
    [4..4] <Ranger> [ . . . .<clr>+<clrEnd>. . ] <clr>Vulture<clrEnd>
    [5..5] <Ranger> [ . . . . .<clr>+<clrEnd>. ] <clr>Vulture<clrEnd>
    [6..6] <Ranger> [ . . . . . .<clr>+<clrEnd>] <clr>Vulture<clrEnd>
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Worms' [0..4] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Hooked ordinary worm
    [2..2] Hooked white worm
    [3..3] Hooked green worm
    [4..4] No worm hooked
    критическое: Сообщение достижения критического значения параметром 13
- P21 '' [0..10] тип=обычный
    старт: [1]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 21
- P22 '' [0..10] тип=обычный
    старт: [1]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Reeds' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter 23: <>
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Bar!!!!!!!!!!!!!!!' [0..9999] тип=обычный
    старт: [0]
    [0..9999] Parameter 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'ber1-10.' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Number of competitions' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 26
- P35 'Bonus' [0..10000] тип=обычный
    старт: [0]
    [0..10000] Parameter 35: <>
    критическое: Сообщение достижения критического значения параметром 35
- P36 "Player's money" [0..999999999] тип=обычный деньги
    старт: [0]
    [0..999999999] Parameter 36: <>
    критическое: Сообщение достижения критического значения параметром 36
- P37 'Bar' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 37
- P38 'Wardrobe' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 38
- P39 'Fishing rod 100.' [0..100] тип=обычный
    старт: [0]
    [0..100] Fishing rod <>
    критическое: Сообщение достижения критического значения параметром 39
- P40 'Tackle 100' [0..100] тип=обычный
    старт: [0]
    [0..100] Tackle <>
    критическое: Сообщение достижения критического значения параметром 40
- P41 'Road upwards' [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 41
- P42 'Your dice' [0..12] тип=обычный
    старт: [0]
    [0..12] 
    критическое: Сообщение достижения критического значения параметром 42
- P43 "Person1's dice" [0..12] тип=обычный
    старт: [0]
    [0..12] 
    критическое: Сообщение достижения критического значения параметром 43
- P44 "Person2's dice" [0..12] тип=обычный
    старт: [0]
    [0..12] 
    критическое: Сообщение достижения критического значения параметром 44
- P45 'Vulture' [0..3] тип=обычный
    старт: [0]
    [0..3] 
    критическое: Сообщение достижения критического значения параметром 45
- P46 "Vulture's win" [0..1] тип=обычный
    старт: [0]
    [0..1] 
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Money dice' [0..10000] тип=обычный
    старт: [0]
    [0..10000] 
    критическое: Сообщение достижения критического значения параметром 47

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You arrive on planet <ToPlanet>. It's identical to other planets of this class except for its rich flora. Upon reaching the championship venue, you look around …
    скрыт: P8,P10,P11,P12,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47
  -> Path2 => Loc2  вер=1 порядок=5
       текст: Follow the man
       эффект: P1(Money) = {800}
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {1}
       эффект: P47(Money dice) +330
  -> Path58 => Loc28  вер=1 порядок=9
       текст: Spit in the man's eye and fly away from this planet

### Loc2 [обычная]
    выбор описания: {[p24]}
    Loc2-1: You walk for a short time. Your guide leads you to your night's lodgings. It wasn't what you had dreamed of, but it'll do for one night. You enter the hut. The …
    Loc2-2: "There is a bar not far from here. All the fishermen in the region go there to drink."
    Loc2-3: "The competition's host planet is determined each year by lot. The competition rules were made up a long time ago. They're very simple.  / At dawn, participants…
    Loc2-4: "This peleng is an absolute champion. He's won the competition five times in a row. He's a real master at what he does. When Vulture fishes, it's almost as if t…
  -> Path5 => Loc5  вер=1 порядок=1
       текст: What are the rules of the game?
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {3}
  -> Path6 => Loc5  вер=1 порядок=2
       текст: Tell me about Vulture
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {4}
  -> Path9 => Loc5  вер=1 порядок=3
       текст: Where can I hang out with the other fishermen?
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path60 => Loc4  вер=1
       текст: I don't have any questions right now

### Loc4 [обычная]
    Loc4-1: You're standing in the middle of your hut. You are in familiar territory: an old sofa, a wardrobe, and a one-legged table. A fishing rod hangs above the table. …
  -> Path11 => Loc8  вер=1 проходов<=1 порядок=1
       текст: Look in the wardrobe
  -> Path13 => Loc9  вер=1 порядок=1
       текст: Read the manual
       условия: P38(Wardrobe) 1..1
  -> Path17 => Loc11  вер=1
       текст: Go outside
  -> Path63 => Loc30  вер=1 порядок=9
       текст: Go to sleep
       эффект: P7(Sobriety) = 0

### Loc5 [пустая]
  -> Path7 => Loc2  вер=1 порядок=5

### Loc8 [пустая] визитов<=1
    эффект: P38(Wardrobe) +1
  -> Path53 => Loc4  вер=4 порядок=5
       ответ: You open the wardrobe but find only old clothes. While searching the pockets, you find nothing but a fishing manual, which you put on the table
       эффект: P42(Your dice) +1
  -> Path581 => Loc148  вер=3 порядок=5
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {((1 to 6)*10)}

### Loc9 [обычная]
    Loc9-1: <clr>FISHING MANUAL<clrEnd>. / Do you want to learn how to fish, where to fish, and how to choose your bait? Then you may be interested in the following: / <clr…
  -> Path14 => Loc4  вер=1 порядок=5
       текст: Put the manual on the table

### Loc11 [обычная]
    Loc11-1: The vegetation in this small town is stunning. High trees, overgrown alleyways... These plants are everywhere! / You're standing in the middle of the road. In f…
  -> Path18 => Loc4  вер=1 порядок=1
       текст: Go into the hut
  -> Path19 => Loc12  вер=1 порядок=9
       текст: Take the road downhill
  -> Path21 => Loc13  вер=1 проходов<=1 порядок=3
       текст: Take the road uphill
       условия: P41(Road upwards) 0..0
       эффект: P41(Road upwards) +1
  -> Path23 => Loc14  вер=1 порядок=2
       текст: Enter the stand
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {1}
  -> Path64 => Loc31  вер=1 порядок=3
       текст: Take the road uphill
       условия: P41(Road upwards) 1..1

### Loc12 [обычная]
    Loc12-1: You go down to the lake. You are met by an awful sight: There's just mud here – hardly any greenery at all. But the silence here calms your soul, which suffered…
  -> Path20 => Loc11  вер=1 порядок=5
       текст: Take the road uphill

### Loc13 [обычная] визитов<=1
    Loc13-1: You walk down the road and see a bar with broken windows and battered door. Two pelengs are standing on the stoop, smoking weed.  / "Ha! Poor Vulture...I'm goin…
  -> Path22 => Loc11  вер=1 порядок=9
       текст: Take the road downhill
  -> Path68 => Loc32  вер=1
       текст: Go to the bar
       ответ: You’ve never seen a bar like this before People are crowding near the tables, it's very noisy and everybody is shouting. The smoke is so thick, it's impossible …
       условия: P37(Bar) 0..0
       эффект: P37(Bar) +1
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {7}

### Loc14 [обычная]
    выбор описания: {[p24]}
    Loc14-1: You go into the stand. An old gaal is at the counter. His black cap has a hole in the forehead for his third eye, and he's wearing a yellow t-shirt with Greenpe…
    Loc14-2: You are in the stand. An old gaal is at the counter. His black cap has a hole in the forehead for his third eye, and he's wearing a yellow t-shirt with Greenpea…
  -> Path34 => Loc24  вер=1 порядок=1
       текст: Have a look at the fishing rods
  -> Path36 => Loc25  вер=1 [всегда видна] порядок=4
       текст: Have a look at the white worms
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path38 => Loc26  вер=1 [всегда видна] порядок=5
       текст: Have a look at the ordinary worms
  -> Path40 => Loc23  вер=1 [всегда видна] порядок=3
       текст: Have a look at the green worms
  -> Path43 => Loc27  вер=1 порядок=2
       текст: Have a look at the fishing tackle
  -> Path44 => Loc11  вер=1 порядок=6
       текст: Leave the stand

### Loc16 [пустая]
  -> Path27 => Loc24  вер=1 порядок=5

### Loc19 [пустая]
  -> Path46 => Loc27  вер=1 порядок=5

### Loc23 [обычная]
    Loc23-1: You come to a small aquarium filled with clean, clear water. There are some strange, dark-green creatures covered with bubbles swimming inside. They mill about …
  -> Path32 => Loc14  вер=1 порядок=5
       текст: Look at something else
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path557 => Loc145  вер=1 [всегда видна]
       текст: Buy a bag of green worms - 10 for 30 marks.
       условия: P1(Money) 30..10000
       эффект: P1(Money) = {[p1]-30}
       эффект: P4(Green worms) = {[p4]+10}
  -> Path559 => Loc145  вер=1 [всегда видна] порядок=1
       текст: Buy a small bag of green worms - 5 for 15 marks.
       условия: P1(Money) 15..10000
       эффект: P1(Money) = {[p1]-15}
       эффект: P4(Green worms) = {[p4]+5}
  -> Path560 => Loc145  вер=1 [всегда видна] порядок=2
       текст: Buy one green worm for 3 marks.
       условия: P1(Money) 3..10000
       эффект: P1(Money) = {[p1]-3}
       эффект: P4(Green worms) = {[p4]+1}

### Loc24 [обычная]
    Loc24-1: There is a selection of various fishing rods in front of you. The gaal stands near the rods and makes a sales pitch. / The <clr>Reflex<clrEnd> fishing rod is a …
  -> Path24 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Buy a medium-quality <clr>Filter<clrEnd> fishing rod for 330 marks
       условия: P1(Money) 220..10000; P2(Fishing rod) 0..0
       эффект: P1(Money) -220
       эффект: P2(Fishing rod) +1
       эффект: P39(Fishing rod 100.) +40
  -> Path26 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Buy an inferior-quality <clr>Cotton<clrEnd> fishing rod for 220 marks
       условия: P1(Money) 330..10000; P2(Fishing rod) 0..0
       эффект: P1(Money) -330
       эффект: P2(Fishing rod) +2
       эффект: P39(Fishing rod 100.) +60
  -> Path28 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Buy a good-quality <clr>Aqua<clrEnd> fishing rod for 440 marks
       условия: P1(Money) 440..10000; P2(Fishing rod) 0..0
       эффект: P1(Money) -440
       эффект: P2(Fishing rod) +3
       эффект: P39(Fishing rod 100.) +80
  -> Path30 => Loc16  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Buy a top-quality <clr>Reflex<clrEnd> fishing rod for 550 marks
       условия: P1(Money) 550..10000; P2(Fishing rod) 0..0
       эффект: P1(Money) -550
       эффект: P2(Fishing rod) +4
       эффект: P39(Fishing rod 100.) +100
  -> Path35 => Loc14  вер=1 порядок=5
       текст: Look at something else
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}

### Loc25 [обычная]
    Loc25-1: You come up to a container directly in front of you. You can see countless translucent white worms – all actively creeping about. They're nearly jumping out of …
  -> Path37 => Loc14  вер=1 порядок=5
       текст: Look at something else
  -> Path561 => Loc144  вер=1 [всегда видна]
       текст: Buy a bag of white worms - 10 for 20 marks.
       условия: P1(Money) 20..10000
       эффект: P1(Money) = {[p1]-20}
       эффект: P5(White worms) = {[p5]+10}
  -> Path563 => Loc144  вер=1 [всегда видна] порядок=1
       текст: Buy a bag of white worms - 5 for 10 marks.
       условия: P1(Money) 10..10000
       эффект: P1(Money) = {[p1]-10}
       эффект: P5(White worms) = {[p5]+5}
  -> Path564 => Loc144  вер=1 [всегда видна] порядок=2
       текст: Buy one white worm for 2 marks.
       условия: P1(Money) 2..10000
       эффект: P1(Money) = {[p1]-2}
       эффект: P5(White worms) = {[p5]+1}

### Loc26 [обычная]
    Loc26-1: In a dark corner, you find an old aluminum basin filled with something. You come closer and see a heap of old, stinky worms. Nothing special here - these are th…
  -> Path39 => Loc14  вер=1 порядок=5
       текст: Look at something else
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path565 => Loc146  вер=1 [всегда видна]
       текст: Take 10 disgusting worms for 10 marks.
       условия: P1(Money) 10..10000
       эффект: P1(Money) = {[p1]-10}
       эффект: P6(Ordinary worms) = {[p6]+10}
  -> Path566 => Loc146  вер=1 [всегда видна] порядок=1
       текст: Take 5 disgusting worms for 5 marks.
       условия: P1(Money) 5..10000
       эффект: P1(Money) = {[p1]-5}
       эффект: P6(Ordinary worms) = {[p6]+5}
  -> Path567 => Loc146  вер=1 [всегда видна] порядок=2
       текст: Buy one disgusting worm for 1 mark.
       условия: P1(Money) 1..10000
       эффект: P1(Money) = {[p1]-1}
       эффект: P6(Ordinary worms) = {[p6]+1}

### Loc27 [обычная]
    Loc27-1: Select the right fishing tackle:  / - <clr>Transparent line and a titanium hook<clrEnd> - A transparent line is absolutely invisible in the water for fish and e…
  -> Path42 => Loc14  вер=1 порядок=5
       текст: Look at something else
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path45 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=4
       текст: Buy the fishing tackle with thick line and a blunt, rusty hook for 220 marks
       условия: P1(Money) 220..10000; P3(Tackle) 0..0
       эффект: P1(Money) -220
       эффект: P3(Tackle) +1
       эффект: P40(Tackle 100) +40
  -> Path47 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=3
       текст: Buy the fishing tackle with ordinary line and an ordinary hook for 330 marks
       условия: P1(Money) 330..10000; P3(Tackle) 0..0
       эффект: P1(Money) -330
       эффект: P3(Tackle) +2
       эффект: P40(Tackle 100) +60
  -> Path49 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=2
       текст: Buy the fishing tackle with a thin line / and a sharp hook for 440 marks
       условия: P1(Money) 440..10000; P3(Tackle) 0..0
       эффект: P1(Money) -440
       эффект: P3(Tackle) +3
       эффект: P40(Tackle 100) +80
  -> Path51 => Loc19  вер=1 [всегда видна] проходов<=1 порядок=1
       текст: Buy the fishing tackle with a transparent line / and a titanium hook for 550 marks
       условия: P1(Money) 550..10000; P3(Tackle) 0..0
       эффект: P1(Money) -550
       эффект: P3(Tackle) +4
       эффект: P40(Tackle 100) +100

### Loc28 [ПРОВАЛ]
    Loc28-1: The man looks at you scornfully with one eye. He turns red with anger and curses you loudly, stamping and kicking the hull of your ship. After a couple of minut…

### Loc30 [обычная]
    Loc30-1: You lie on the sofa, contemplating the competition tomorrow. The main question in your mind is whether or not the great ranger <Ranger> can beat this invincible…
  -> Path154 => Loc53  вер=1 порядок=5
       текст: Go to the competition.
       условия: P2(Fishing rod) 1..5; P3(Tackle) 1..5
  -> Path155 => Loc53  вер=1 порядок=5
       текст: Take the fishing rod and tackle off the wall and go to the competition.
       условия: P2(Fishing rod) 0..0; P3(Tackle) 0..0
       эффект: P2(Fishing rod) +5
       эффект: P3(Tackle) +5
       эффект: P39(Fishing rod 100.) +40
       эффект: P40(Tackle 100) +40
  -> Path156 => Loc53  вер=1 порядок=5
       текст: Take the fishing rod off the wall and go to the competition.
       условия: P2(Fishing rod) 0..0; P3(Tackle) 1..5
       эффект: P2(Fishing rod) +5
       эффект: P39(Fishing rod 100.) +40
  -> Path157 => Loc53  вер=1 порядок=5
       текст: Take the fishing tackle off the wall and go to the competition.
       условия: P2(Fishing rod) 1..5; P3(Tackle) 0..0
       эффект: P3(Tackle) +5
       эффект: P40(Tackle 100) +40

### Loc31 [обычная]
    Loc31-1: You are near the bar with the broken windows. The door is beaten in. Pelengs are standing on the stoop, smoking weed.
  -> Path65 => Loc32  вер=1
       текст: Go to the bar
       ответ: You’ve never seen a bar like this before People are crowding near the tables, it's very noisy and everybody is shouting. The smoke is so thick, it's impossible …
       условия: P37(Bar) 0..0
       эффект: P37(Bar) +1
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {7}
  -> Path66 => Loc32  вер=1
       текст: Go to the bar
       условия: P37(Bar) 1..1
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {7}
  -> Path69 => Loc11  вер=1 порядок=1
       текст: Take the road downhill

### Loc32 [обычная]
    выбор описания: {[p24]}
    Loc32-1: You're standing in a smoky bar. There are a lot of drunk fishermen discussing tomorrow’s competition. You can hear the name <clr>Vulture<clrEnd> in their conver…
    Loc32-2: You get up from the bar. What will you do now?
    Loc32-3: You leave the gamblers. What next?
    Loc32-4: No! Why try if you don't know if you can win? A space pilot's work is exhausting and affects muscle mass.
    Loc32-5: You drop your head and walk away from Vulture, who is smiling proudly. What are you going to do next?
    Loc32-6: You walk away from Vulture proudly, feeling like a victor. The others in the bar watch you go out with a smile.  You feel like doing something like this again, …
    Loc32-7: You're standing in a smoky bar. There are a lot of drunk fishermen discussing tomorrow’s competition. You can hear the name <clr>Vulture<clrEnd> in their conver…
  -> Path67 => Loc31  вер=1 порядок=4
       текст: Leave the bar
  -> Path75 => Loc36  вер=1 порядок=2
       текст: Approach the gamblers
       условия: P47(Money dice) 51..10000
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {1}
  -> Path135 => Loc44  вер=1 проходов<=1 порядок=3
       текст: Approach Vulture
       эффект: P45(Vulture) = {1}
  -> Path147 => Loc49  вер=1 порядок=3
       текст: Approach Vulture
       условия: логика {[p45]<>0 and [p45]<>3}

### Loc36 [обычная]
    выбор описания: {[p24]}
    Loc36-1: You push your way through to the people playing dice. The crowd around the table is huge.
    Loc36-2: You leave the gambling table, but the others continue playing.
  -> Path77 => Loc32  вер=1 порядок=2
       текст: Leave the people playing dice
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {3}
  -> Path78 => Loc37  вер=1 [всегда видна] порядок=1
       текст: Play dice
       условия: P1(Money) 20..10000; P47(Money dice) 51..10000

### Loc37 [обычная]
    Loc37-1: You take a seat at the table. There are swarthy people sitting around, watching you. / "The table stakes are <clr>20 marks<clrEnd>," says one. / "These are the …
  -> Path79 => Loc36  вер=1 порядок=2
       текст: Refuse to play and get up from the table
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path80 => Loc38  вер=1 [всегда видна] порядок=1
       текст: Roll the dice
       эффект: P42(Your dice) = {[p42]+(2 to 12)}
       эффект: P43(Person1's dice) = {((1 to 6)+(1 to 6))}
       эффект: P44(Person2's dice) = {((1 to 6)+(1 to 6))}

### Loc38 [пустая]
  -> Path81 => Loc42  вер=1 порядок=5
       ответ: Your roll is only [p42] - that's very bad. / Your first opponent's highest roll is [p43]. / Your second opponent's highest roll is [p44].
       условия: логика {[p42]<[p43] and [p42]<[p44]}
  -> Path553 => Loc42  вер=1 порядок=5
       ответ: Your highest roll is only [p42] - that's very bad. / Your first opponent's highest roll is [p43]. / Your second opponent's highest roll is [p44].
       условия: логика {([p42]>=[p43] and [p42]<[p44]) or ([p42]>=[p44] and [p42]<[p43])}
  -> Path554 => Loc42  вер=1 порядок=5
       ответ: Your highest score is [p42]. That's good. / Your first opponent's highest roll is [p43]. / Your second opponent's highest roll is [p44].
       условия: логика {([p42]=[p43] and [p42]>[p44]) or ([p42]=[p44] and [p42]>[p43]) or ([p42]=[p43] and [p42]=[p44])}
  -> Path556 => Loc42  вер=1 порядок=5
       ответ: Your highest score is [p42]. That's excellent. / Your first opponent's highest roll is [p43]. / Your second opponent's highest roll is [p44].
       условия: логика {[p42]>[p43] and [p42]>[p44]}

### Loc41 [обычная]
    Loc41-1: You're sitting at the table, gambling.
    эффект: P42(Your dice) = 0
    эффект: P43(Person1's dice) = 0
    эффект: P44(Person2's dice) = 0
  -> Path107 => Loc36  вер=1 порядок=2
       текст: Refuse to play and get up from the table
       условия: P47(Money dice) 51..10000
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}
  -> Path111 => Loc38  вер=1 порядок=1
       текст: Roll the dice
       условия: P1(Money) 20..10000; P47(Money dice) 51..10000
       эффект: P42(Your dice) = {[p42]+((1 to 6)+(1 to 6))}
       эффект: P43(Person1's dice) = {((1 to 6)+(1 to 6))}
       эффект: P44(Person2's dice) = {((1 to 6)+(1 to 6))}
  -> Path149 => Loc50  вер=1 порядок=5
       текст: Go on.
       ответ: "Sorry, but we're all out of money. You've taken it all."
       условия: P47(Money dice) 0..50

### Loc42 [пустая]
  -> Path108 => Loc41  вер=1 порядок=5
       текст: Collect 40 marks
       условия: логика {[p42]>[p43] and [p43]>[p44]}
       эффект: P1(Money) +40
       эффект: P47(Money dice) -40
  -> Path109 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p43]>[p42] and [p44]>=[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path110 => Loc41  вер=1 порядок=5
       текст: Draw - the second player loses. Take 10 marks from him.
       условия: логика {[p42]=[p43] and [p43]>[p44]}
       эффект: P1(Money) +10
       эффект: P47(Money dice) -10
  -> Path125 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p44]>[p42] and [p43]>=[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path126 => Loc41  вер=1 порядок=5
       текст: Draw - the first player loses. Take 10 marks from him
       условия: логика {[p42]=[p44] and [p44]>[p43]}
       эффект: P1(Money) +10
       эффект: P47(Money dice) -10
  -> Path127 => Loc41  вер=1 порядок=5
       текст: Collect 40 marks
       условия: логика {[p42]>[p44] and [p44]>[p43]}
       эффект: P1(Money) +40
       эффект: P47(Money dice) -40
  -> Path128 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p43]=[p44] and [p43]>[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path129 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p44]=[p43] and [p44]>[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path130 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p43]>[p44] and [p43]>[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path131 => Loc41  вер=1 порядок=5
       текст: Give 20 marks
       условия: логика {[p44]>[p43] and [p44]>[p42]}
       эффект: P1(Money) -20
       эффект: P47(Money dice) +20
  -> Path132 => Loc41  вер=1 порядок=5
       текст: Collect 40 marks
       условия: логика {[p42]>[p43] and [p43]=[p44]}
       эффект: P1(Money) +40
       эффект: P47(Money dice) -40
  -> Path133 => Loc41  вер=1 порядок=5
       текст: Collect 40 marks
       условия: логика {[p42]>[p44] and [p44]=[p43]}
       эффект: P1(Money) +40
       эффект: P47(Money dice) -40
  -> Path134 => Loc41  вер=1 порядок=5
       текст: Draw.
       условия: логика {[p42]=[p43] and [p43]=[p44]}

### Loc44 [обычная] визитов<=1
    Loc44-1: Vulture looks at you, his right eye twitching. / "Ah! I think I know you!" he cries. "You're ranger <Ranger> – I've heard about you.  / Do you really think you …
  -> Path138 => Loc32  вер=1 порядок=2
       текст: I don't have that kind of money.
       ответ: You turn around and walk away from the table.
  -> Path139 => Loc45  вер=1 [всегда видна] порядок=1
       текст: Agree and take a seat at the table.
       условия: P1(Money) 100..10000

### Loc45 [обычная]
    Loc45-1: You sit at a table and grip Vulture's hand. Your eyes meet. He looks at you confidently, smiles, and spits on the ground enthusiastically. At present, you're th…
    эффект: P12(Balance) = {3} [показ]
  -> Path140 => Loc150  вер=1 порядок=5
       текст: Tighten up.

### Loc49 [обычная]
    выбор описания: {[p45]}
    Loc49-1: You again come up to Vulture. / "Well? Are you going to wrestle with me?" Vulture asks.
    Loc49-2: You come up to the peleng once again. He gave a vicious look with his eyes. / "Is there something else you need?" Vulture asks.
  -> Path146 => Loc45  вер=1 порядок=5
       текст: I'm dying for revenge! Wanna arm wrestle?
       условия: P1(Money) 100..10000; P45(Vulture) 2..2
  -> Path148 => Loc32  вер=1 порядок=5
       текст: No, I'd better go.
       ответ: You turn around and walk away from the table.
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {4}
  -> Path604 => Loc45  вер=1
       текст: I'm ready!
       условия: P1(Money) 100..10000; P45(Vulture) 1..1

### Loc50 [пустая]
  -> Path150 => Loc51  вер=1 порядок=5

### Loc51 [обычная]
    Loc51-1: People get up from the table and the crowd disperses. / You win!!!
  -> Path151 => Loc32  вер=1 порядок=5
       текст: Get up from the table.
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {3}

### Loc53 [обычная]
    Loc53-1: When you leave your hut, you find a man who met you at the spaceport is already waiting for you. He's wearing coveralls and has a net on his head. Behind him, y…
  -> Path158 => Loc69  вер=1 порядок=5
       эффект: P8(Time) = 30 [показ]
       эффект: P13(Worms) = 4
       эффект: P25(ber1-10.) = {1 to 10}

### Loc54 [обычная]
    Loc54-1: The lake looks rather beautiful from here. There’s a small cliff, average depth, no reeds. That makes this a good place for wolts.
    эффект: P23(Reeds) = 0
    эффект: P25(ber1-10.) = {1}
  -> Path159 => Loc55  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path190 => Loc67  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path191 => Loc67  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
       эффект: P14(черви белые) +1
  -> Path192 => Loc67  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
       эффект: P15(черви обычные) +1
  -> Path193 => Loc64  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path461 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path479 => Loc63  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path530 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path619 => Loc67  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc55 [обычная]
    Loc55-1: You descend to the water's edge. The lake is calm here. The water level is low and the bank is a bit reedy. It’s ideal for murlocks.
    эффект: P23(Reeds) = 1
    эффект: P25(ber1-10.) = {2}
  -> Path171 => Loc56  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path251 => Loc71  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path333 => Loc106  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path342 => Loc106  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path351 => Loc106  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path460 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path506 => Loc54  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path529 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path610 => Loc106  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc56 [обычная]
    Loc56-1: You carefully approach the water along the gently sloping shore. The bright sunlight blinds you. Taking a closer look, you determine the lake has an average dep…
    эффект: P23(Reeds) = 2
    эффект: P25(ber1-10.) = {3}
  -> Path161 => Loc57  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path250 => Loc72  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path332 => Loc105  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path341 => Loc105  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path350 => Loc105  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path462 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path503 => Loc55  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path538 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path611 => Loc105  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc57 [обычная]
    Loc57-1: You move quickly to the water's edge. The water is surprisingly dark, indicating it is quite deep. The bank is a little reedy, but it's still good for catching …
    эффект: P23(Reeds) = 1
    эффект: P25(ber1-10.) = {4}
  -> Path162 => Loc58  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path249 => Loc73  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path331 => Loc104  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path340 => Loc104  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path349 => Loc104  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path463 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path500 => Loc56  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path537 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path612 => Loc104  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc58 [обычная]
    Loc58-1: You move across the cliff very slowly and carefully. You see a small murlock in the clear water. It's shallow here and there are no reeds on the shore. That mea…
    эффект: P23(Reeds) = 0
    эффект: P25(ber1-10.) = {5}
  -> Path163 => Loc59  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path248 => Loc74  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path330 => Loc103  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path339 => Loc103  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path348 => Loc103  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path464 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path497 => Loc57  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path536 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path613 => Loc103  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc59 [обычная]
    Loc59-1: You are standing before an abrupt dropoff. The current is strong here and the waters dark. It must be very deep here – you can't see a single reed. This shore i…
    эффект: P23(Reeds) = 0
    эффект: P25(ber1-10.) = {6}
  -> Path164 => Loc60  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path247 => Loc75  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path329 => Loc102  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path338 => Loc102  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path347 => Loc102  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path465 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path494 => Loc58  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path535 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path614 => Loc102  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc60 [обычная]
    Loc60-1: You approach the precipice. There's not much current and the water is dark, which means it's deep here. The shore is perfectly clean, not a reed in sight. There…
    эффект: P23(Reeds) = 0
    эффект: P25(ber1-10.) = {7}
  -> Path165 => Loc61  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path246 => Loc76  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path328 => Loc101  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path337 => Loc101  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path346 => Loc101  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path466 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path491 => Loc59  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path533 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path615 => Loc101  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc61 [обычная]
    Loc61-1: You're at the cliff, attracted by the water's calm appearance. Upon closer inspection, you determine that the lake has an average depth here. There are a few re…
    эффект: P23(Reeds) = 1
    эффект: P25(ber1-10.) = {8}
  -> Path166 => Loc62  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path245 => Loc77  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path327 => Loc100  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path336 => Loc100  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path345 => Loc100  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path467 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path488 => Loc60  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path534 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path616 => Loc100  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc62 [обычная]
    Loc62-1: You carefully approach the water along the gently sloping shore. The water near the shore is as clear as glass, but it becomes dark rather abruptly a bit farthe…
    эффект: P23(Reeds) = 2
    эффект: P25(ber1-10.) = {9}
  -> Path167 => Loc63  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path244 => Loc78  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path326 => Loc99  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path335 => Loc99  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path344 => Loc99  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path468 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path485 => Loc61  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path532 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path617 => Loc99  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc63 [обычная]
    Loc63-1: You move across a sharp decent to get a bit closer to the water. The water is calm and the view of the lake is excellent. Upon closer inspection, you determine …
    эффект: P23(Reeds) = 1
    эффект: P25(ber1-10.) = {10}
  -> Path168 => Loc54  вер=1 порядок=5
       текст: Go left.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path243 => Loc79  вер=1 порядок=1
       текст: Cast your rod
       условия: логика {[p8]>0}
  -> Path325 => Loc98  вер=1 порядок=2
       текст: Use a green worm as bait.
       условия: P4(Green worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P4(Green worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 3
  -> Path334 => Loc98  вер=1 порядок=3
       текст: Use a white worm as bait.
       условия: P5(White worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P5(White worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 2
  -> Path343 => Loc98  вер=1 порядок=4
       текст: Use an ordinary worm as bait.
       условия: P6(Ordinary worms) 1..1000; логика {[p8]>0 and [p13]=4}
       эффект: P6(Ordinary worms) -1
       эффект: P8(Time) -1
       эффект: P13(Worms) = 1
  -> Path469 => Loc127  вер=1 порядок=5
       текст: Go weigh your catch.
       условия: логика {[p8]<1}
       эффект: P10(Carrion weight) = 0
  -> Path482 => Loc62  вер=1 порядок=6
       текст: Go right.
       условия: логика {[p8]>0}
       эффект: P8(Time) = {[p8]-1}
  -> Path531 => Loc141  вер=1 порядок=9
       текст: Dig up worms.
       условия: логика {([p4]=0 and [p5]=0 and [p6]=0) and [p8]>0}
  -> Path618 => Loc98  вер=1 порядок=2
       текст: Remove the worm from the hook.
       условия: P13(Worms) 1..3; логика {[p8]>0}
       эффект: P13(Worms) = 4

### Loc64 [обычная]
    Loc64-1: The fishing rod is in the water.
  -> Path194 => Loc54  вер=1 порядок=5
       текст: Reel in your line.
  -> Path195 => Loc66  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}

### Loc66 [пустая]
  -> Path196 => Loc64  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path199 => Loc70  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: логика {[p13]<4}
  -> Path200 => Loc70  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: логика {[p13]<4}
       эффект: P8(Time) -1
  -> Path201 => Loc70  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: логика {[p13]<4}
       эффект: P8(Time) -1

### Loc67 [пустая]
  -> Path197 => Loc54  вер=1 порядок=5

### Loc68 [пустая]
  -> Path203 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 7..100; P40(Tackle 100) 7..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(1 to 3)*10}
  -> Path204 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path205 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing and lost your worm.
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
  -> Path206 => Loc69  вер=1 [всегда видна] порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 22..100; P40(Tackle 100) 22..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(10 to 20)*10}
  -> Path207 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 9..100; P40(Tackle 100) 9..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 8)*10}
  -> Path208 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 15..100; P40(Tackle 100) 15..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(25 to 30)*10}
  -> Path209 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 15..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(31 to 38)*10}
  -> Path210 => Loc69  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(35 to 45)*10}
  -> Path211 => Loc69  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 28..100; P40(Tackle 100) 28..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(37 to 47)*10}
  -> Path212 => Loc69  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(38 to 48)*10}
  -> Path213 => Loc69  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 70..100; P40(Tackle 100) 70..100; логика {[p23]=0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -5
       эффект: P40(Tackle 100) -4
       эффект: P11(Your current fish) = {(50 to 70)*10}
  -> Path214 => Loc69  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(25 to 39)*10}
  -> Path215 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path216 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path217 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path220 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 11..100; P40(Tackle 100) 11..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 12)*10}
  -> Path221 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 1..100; P40(Tackle 100) 1..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 8)*10}
  -> Path222 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 2..100; P40(Tackle 100) 2..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 10)*10}
  -> Path232 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing and lost your worm.
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
  -> Path233 => Loc69  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing and lost your worm.
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
  -> Path285 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 2..100; P40(Tackle 100) 2..100; логика {[p23]}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(4 to 12)*10}
  -> Path286 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 4..100; P40(Tackle 100) 4..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(10 to 16)*10}
  -> Path569 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 2..100; P40(Tackle 100) 2..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 10)*10}
  -> Path570 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 1..100; P40(Tackle 100) 1..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(1 to 6)*10}
  -> Path571 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 1..100; P40(Tackle 100) 1..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(3 to 8)*10}
  -> Path572 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 2..100; P40(Tackle 100) 2..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 14)*10}
  -> Path573 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 1..100; P40(Tackle 100) 1..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(2 to 9)*10}
  -> Path574 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 14..100; P40(Tackle 100) 14..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(1 to 20)*10}
  -> Path575 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100; логика {[p23]>0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(5 to 15)*10}
  -> Path576 => Loc69  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 14..100; P40(Tackle 100) 14..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(8 to 22)*10}
  -> Path577 => Loc69  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 11..100; P40(Tackle 100) 11..100; логика {[p23]>1}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(8 to 24)*10}
  -> Path578 => Loc69  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 70..100; P40(Tackle 100) 70..100; логика {[p23]=0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -7
       эффект: P40(Tackle 100) -4
       эффект: P11(Your current fish) = {(30 to 90)*10}
  -> Path579 => Loc69  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 60..100; P40(Tackle 100) 60..100; логика {[p23]=0}
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -5
       эффект: P40(Tackle 100) -4
       эффект: P11(Your current fish) = {(50 to 100)*10}

### Loc69 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
  -> Path219 => Loc54  вер=1 порядок=5
       условия: P25(ber1-10.) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path223 => Loc55  вер=1 порядок=5
       условия: P25(ber1-10.) 2..2
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path224 => Loc56  вер=1 порядок=5
       условия: P25(ber1-10.) 3..3; P27(бер3) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path225 => Loc57  вер=1 порядок=5
       условия: P25(ber1-10.) 4..4; P28(бер4) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path226 => Loc58  вер=1 порядок=5
       условия: P25(ber1-10.) 5..5; P29(бер5) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path227 => Loc59  вер=1 порядок=5
       условия: P25(ber1-10.) 6..6; P30(бер6) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path228 => Loc60  вер=1 порядок=5
       условия: P25(ber1-10.) 7..7; P31(бер7) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path229 => Loc61  вер=1 порядок=5
       условия: P25(ber1-10.) 8..8; P32(бер8) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path230 => Loc62  вер=1 порядок=5
       условия: P25(ber1-10.) 9..9; P33(бер9) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}
  -> Path231 => Loc63  вер=1 порядок=5
       условия: P25(ber1-10.) 10..10; P34(бер10) 1..1
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc70 [пустая]
  -> Path218 => Loc68  вер=8 порядок=5
  -> Path373 => Loc110  вер=5 порядок=5

### Loc71 [обычная]
    Loc71-1: The fishing rod is in the water.
  -> Path242 => Loc80  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path307 => Loc55  вер=1 порядок=5
       текст: Reel in your line.

### Loc72 [обычная]
    Loc72-1: The fishing rod is in the water.
  -> Path241 => Loc82  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path308 => Loc56  вер=1 порядок=5
       текст: Reel in your line.

### Loc73 [обычная]
    Loc73-1: The fishing rod is in the water.
  -> Path240 => Loc84  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path309 => Loc57  вер=1 порядок=5
       текст: Reel in your line.

### Loc74 [обычная]
    Loc74-1: The fishing rod is in the water.
  -> Path239 => Loc86  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path310 => Loc58  вер=1 порядок=5
       текст: Reel in your line.

### Loc75 [обычная]
    Loc75-1: The fishing rod is in the water.
  -> Path238 => Loc88  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path311 => Loc59  вер=1 порядок=5
       текст: Reel in your line.

### Loc76 [обычная]
    Loc76-1: The fishing rod is in the water.
  -> Path237 => Loc90  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path312 => Loc60  вер=1 порядок=5
       текст: Reel in your line.

### Loc77 [обычная]
    Loc77-1: The fishing rod is in the water.
  -> Path236 => Loc92  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path313 => Loc61  вер=1 порядок=5
       текст: Reel in your line.

### Loc78 [обычная]
    Loc78-1: The fishing rod is in the water.
  -> Path235 => Loc94  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path314 => Loc62  вер=1 порядок=5
       текст: Reel in your line.

### Loc79 [обычная]
    Loc79-1: The fishing rod is in the water.
  -> Path234 => Loc96  вер=1 [всегда видна] порядок=1
       текст: Wait for one minute.
       условия: логика {[p8]>0}
  -> Path315 => Loc63  вер=1 порядок=5
       текст: Reel in your line.

### Loc80 [пустая]
  -> Path252 => Loc71  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path304 => Loc81  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path305 => Loc81  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path306 => Loc81  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3

### Loc81 [пустая]
  -> Path316 => Loc68  вер=8 порядок=5
  -> Path457 => Loc125  вер=5 порядок=5

### Loc82 [пустая]
  -> Path256 => Loc72  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path301 => Loc83  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3
  -> Path302 => Loc83  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3
  -> Path303 => Loc83  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1

### Loc83 [пустая]
  -> Path317 => Loc68  вер=8 порядок=5
  -> Path446 => Loc123  вер=5 порядок=5

### Loc84 [пустая]
  -> Path260 => Loc73  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path299 => Loc85  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path300 => Loc85  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3

### Loc85 [пустая]
  -> Path318 => Loc68  вер=8 порядок=5
  -> Path361 => Loc107  вер=5 порядок=5

### Loc86 [пустая]
  -> Path266 => Loc74  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path296 => Loc87  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3
  -> Path297 => Loc87  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path298 => Loc87  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1

### Loc87 [пустая]
  -> Path437 => Loc121  вер=5 порядок=5
  -> Path438 => Loc68  вер=8 порядок=5

### Loc88 [пустая]
  -> Path267 => Loc75  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path294 => Loc89  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path295 => Loc89  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3

### Loc89 [пустая]
  -> Path320 => Loc68  вер=8 порядок=5
  -> Path428 => Loc119  вер=5 порядок=5

### Loc90 [пустая]
  -> Path272 => Loc76  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path292 => Loc91  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path293 => Loc91  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1

### Loc91 [пустая]
  -> Path420 => Loc117  вер=5 порядок=5
  -> Path421 => Loc68  вер=8 порядок=5

### Loc92 [пустая]
  -> Path276 => Loc77  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path290 => Loc93  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3
  -> Path291 => Loc93  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1

### Loc93 [пустая]
  -> Path410 => Loc115  вер=5 порядок=5
  -> Path413 => Loc68  вер=8 порядок=5

### Loc94 [пустая]
  -> Path279 => Loc78  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path283 => Loc95  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: логика {[p13]<4}
       эффект: P8(Time) -1
  -> Path284 => Loc95  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: логика {[p13]<4}
       эффект: P8(Time) -1

### Loc95 [пустая]
  -> Path400 => Loc113  вер=5 порядок=5
  -> Path401 => Loc68  вер=8 порядок=5

### Loc96 [пустая]
  -> Path281 => Loc79  вер=1 порядок=5
       ответ: You wait for a minute, but the fish aren't biting.
       эффект: P8(Time) -1
  -> Path287 => Loc97  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path288 => Loc97  вер=1 порядок=5
       ответ: You wait for one minute and your float begins to move.
       условия: P13(Worms) 1..3
       эффект: P8(Time) -1
  -> Path289 => Loc97  вер=1 порядок=5
       ответ: Today you don't even have to wait - the fish bite immediately.
       условия: P13(Worms) 1..3

### Loc97 [пустая]
  -> Path324 => Loc68  вер=8 порядок=5
  -> Path383 => Loc111  вер=5 порядок=5

### Loc98 [пустая]
  -> Path360 => Loc63  вер=1 порядок=5

### Loc99 [пустая]
  -> Path359 => Loc62  вер=1 порядок=5

### Loc100 [пустая]
  -> Path358 => Loc61  вер=1 порядок=5

### Loc101 [пустая]
  -> Path357 => Loc60  вер=1 порядок=5

### Loc102 [пустая]
  -> Path356 => Loc59  вер=1 порядок=5

### Loc103 [пустая]
  -> Path355 => Loc58  вер=1 порядок=5

### Loc104 [пустая]
  -> Path354 => Loc57  вер=1 порядок=5

### Loc105 [пустая]
  -> Path353 => Loc56  вер=1 порядок=5

### Loc106 [пустая]
  -> Path352 => Loc55  вер=1 порядок=5

### Loc107 [пустая]
  -> Path362 => Loc108  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(20 to 75)*10}
  -> Path363 => Loc108  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 60..100; P40(Tackle 100) 60..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(50 to 105)*10}
  -> Path364 => Loc108  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(40 to 65)*10}
  -> Path365 => Loc108  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(30 to 85)*10}
  -> Path367 => Loc108  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(50 to 60)*10}
  -> Path368 => Loc108  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path369 => Loc108  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path370 => Loc108  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 44..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -3
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(55 to 80)*10}
  -> Path371 => Loc108  вер=1 проходов<=1 порядок=5
       ответ: What bad luck! You dredged up a <clr>tin can<clrEnd>.
       эффект: P8(Time) -1
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -6
       эффект: P40(Tackle 100) -8

### Loc108 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path366 => Loc57  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc109 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path382 => Loc54  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc110 [пустая]
  -> Path375 => Loc109  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -3
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(50 to 75)*10}
  -> Path376 => Loc109  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(45 to 55)*10}
  -> Path377 => Loc109  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(60 to 85)*10}
  -> Path378 => Loc109  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -5
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(70 to 95)*10}
  -> Path379 => Loc109  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(57 to 67)*10}
  -> Path380 => Loc109  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path381 => Loc109  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.

### Loc111 [пустая]
  -> Path385 => Loc112  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path386 => Loc112  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path387 => Loc112  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(55 to 120)*10}
  -> Path388 => Loc112  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(30 to 65)*10}
  -> Path389 => Loc112  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(67 to 77)*10}
  -> Path390 => Loc112  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(36 to 61)*10}
  -> Path391 => Loc112  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 44..100; P40(Tackle 100) 44..100
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(35 to 55)*10}

### Loc112 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path392 => Loc63  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc113 [пустая]
  -> Path393 => Loc114  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 2..100; P40(Tackle 100) 2..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(10 to 35)*10}
  -> Path394 => Loc114  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 25..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(40 to 65)*10}
  -> Path395 => Loc114  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(30 to 60)*10}
  -> Path396 => Loc114  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path397 => Loc114  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path398 => Loc114  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(28 to 33)*10}
  -> Path399 => Loc114  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 25..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(35 to 60)*10}

### Loc114 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path412 => Loc62  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc115 [пустая]
  -> Path402 => Loc116  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(30 to 55)*10}
  -> Path403 => Loc116  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(50 to 75)*10}
  -> Path404 => Loc116  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(41 to 66)*10}
  -> Path405 => Loc116  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 35..100
       эффект: P13(Worms) = 4
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(43 to 68)*10}
  -> Path406 => Loc116  вер=1 проходов<=1 порядок=5
       ответ: What bad luck! You dredged up a <clr>shoe<clrEnd>.
       эффект: P8(Time) -1
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -6
       эффект: P40(Tackle 100) -6
  -> Path407 => Loc116  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path408 => Loc116  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path409 => Loc116  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = {4}
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(25 to 35)*10}

### Loc116 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path411 => Loc61  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc117 [пустая]
  -> Path414 => Loc118  вер=1 проходов<=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 80..100; P40(Tackle 100) 80..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -5
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(50 to 150)*10}
  -> Path415 => Loc118  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(68 to 88)*10}
  -> Path416 => Loc118  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(47 to 57)*10}
  -> Path417 => Loc118  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path418 => Loc118  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path419 => Loc118  вер=1 порядок=5
       ответ: You've caught a cheric ([p11] g).
       условия: P13(Worms) 1..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(1 to 3)*10}

### Loc118 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
  -> Path512 => Loc60  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}

### Loc119 [пустая]
  -> Path422 => Loc120  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(41 to 51)*10}
  -> Path423 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(70 to 95)*10}
  -> Path424 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 60..100; P40(Tackle 100) 60..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -6
       эффект: P40(Tackle 100) -4
       эффект: P11(Your current fish) = {(80 to 105)*10}
  -> Path425 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 80..100; P40(Tackle 100) 80..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(80 to 125)*10}
  -> Path426 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 35..100; P40(Tackle 100) 32..100
       эффект: P13(Worms) = {4}
       эффект: P39(Fishing rod 100.) -3
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(55 to 100)*10}
  -> Path427 => Loc120  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path510 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -1
       эффект: P11(Your current fish) = {(45 to 70)*10}
  -> Path551 => Loc120  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path552 => Loc120  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path620 => Loc120  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 35..100
       эффект: P13(Worms) = {4}
       эффект: P39(Fishing rod 100.) -3
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(65 to 120)*10}

### Loc120 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path429 => Loc59  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc121 [пустая]
  -> Path431 => Loc122  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path432 => Loc122  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path433 => Loc122  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(44 to 61)*10}
  -> Path434 => Loc122  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(29 to 39)*10}
  -> Path435 => Loc122  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(50 to 70)*10}
  -> Path436 => Loc122  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 10..30; P40(Tackle 100) 10..30
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(2 to 4)*10}
  -> Path509 => Loc122  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -5
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(76 to 101)*10}

### Loc122 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path511 => Loc58  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc123 [пустая]
  -> Path439 => Loc124  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(47 to 57)*10}
  -> Path440 => Loc124  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(51 to 61)*10}
  -> Path441 => Loc124  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(21 to 36)*10}
  -> Path442 => Loc124  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -2
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(20 to 35)*10}
  -> Path443 => Loc124  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path444 => Loc124  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path445 => Loc124  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(44 to 59)*10}

### Loc124 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path447 => Loc56  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc125 [пустая]
  -> Path449 => Loc126  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 10..100; P40(Tackle 100) 10..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -3
       эффект: P11(Your current fish) = {(40 to 50)*10}
  -> Path450 => Loc126  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(17 to 27)*10}
  -> Path451 => Loc126  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 30..100; P40(Tackle 100) 30..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -3
       эффект: P40(Tackle 100) -4
       эффект: P11(Your current fish) = {(30 to 55)*10}
  -> Path452 => Loc126  вер=1 порядок=5
       ответ: You caught a wolt ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 50..100; P40(Tackle 100) 50..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -4
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(62 to 87)*10}
  -> Path453 => Loc126  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 3..3; P39(Fishing rod 100.) 40..100; P40(Tackle 100) 40..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(48 to 73)*10}
  -> Path454 => Loc126  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path455 => Loc126  вер=1 порядок=5
       ответ: You reel in your line, but you caught nothing.
  -> Path456 => Loc126  вер=1 порядок=5
       ответ: You've caught a murlock ([p11] g).
       условия: P13(Worms) 2..3; P39(Fishing rod 100.) 20..100; P40(Tackle 100) 20..100
       эффект: P13(Worms) = 4
       эффект: P39(Fishing rod 100.) -1
       эффект: P40(Tackle 100) -2
       эффект: P11(Your current fish) = {(31 to 41)*10}

### Loc126 [пустая]
    эффект: P9(Fish weight) = {[p9]+[p11]}
    эффект: P10(Carrion weight) = {[p10]+[p12]}
  -> Path458 => Loc55  вер=1 порядок=5
       эффект: P11(Your current fish) = {0}
       эффект: P12(Balance) = {0}

### Loc127 [пустая]
    эффект: P26(Number of competitions) +1
    скрыт: P8
  -> Path580 => Loc147  вер=1 порядок=5
       условия: логика {[p26]=1}
       эффект: P10(Carrion weight) = {(310 to 410)*10}
       эффект: P35(Bonus) = {[p9]}

### Loc128 [УСПЕХ]
    выбор описания: {[p26]}
    Loc128-1: Your catch is weighed. It is [p9] g more than the rest! / Vulture only took in [p10] g. / There can be no doubt about it - you win. You are given a great-lookin…
    Loc128-2: Your catch is weighed a second time. It is [p9] g more than everybody else's! / Vulture only took in [p10] g. / You win. You win a great-looking cup with your n…
    эффект: P36(Player's money) = {[p36]+[p35]}

### Loc130 [ПРОВАЛ]
    выбор описания: {[p26]}
    Loc130-1: Your catch is weighed. It is [p9] g. That's less than Vulture's take, which is [p10] g. / You lose. You didn't feel like yourself. Deciding not to linger here a…
    Loc130-2: Your catch is weighed a second time. It is [p9] g. That's less than Vulture's take, which is [p10] g. / You lose. You didn't feel like yourself. Deciding not to…

### Loc134 [обычная]
    Loc134-1: You've dug up: / [p4] green worms. / [p5] white worms. / [p6] ordinary worms.
  -> Path545 => Loc142  вер=1 порядок=5

### Loc135 [обычная]
    Loc135-1: You've dug up: / [p4] green worms. / [p5] white worms.
  -> Path544 => Loc142  вер=1 порядок=5

### Loc136 [обычная]
    Loc136-1: You've dug up: / [p4] green worms. / [p6] ordinary worms.
  -> Path543 => Loc142  вер=1 порядок=5

### Loc137 [обычная]
    Loc137-1: You've dug up: / [p5] white worms. / [p6] ordinary worms.
  -> Path542 => Loc142  вер=1 порядок=5

### Loc138 [обычная]
    Loc138-1: You've dug up: / [p4] green worms.
  -> Path541 => Loc142  вер=1 порядок=5

### Loc139 [обычная]
    Loc139-1: You've dug up: / [p5] white worms.
  -> Path540 => Loc142  вер=1 порядок=5

### Loc140 [обычная]
    Loc140-1: You've dug up: / [p6] ordinary worms.
  -> Path539 => Loc142  вер=1 порядок=5

### Loc141 [пустая]
  -> Path522 => Loc134  вер=1 порядок=5
       эффект: P4(Green worms) = {1 to 5}
       эффект: P5(White worms) = {1 to 5}
       эффект: P6(Ordinary worms) = {1 to 5}
  -> Path523 => Loc135  вер=1 порядок=5
       эффект: P4(Green worms) = {1 to 5}
       эффект: P5(White worms) = {1 to 5}
  -> Path524 => Loc136  вер=1 порядок=5
       эффект: P4(Green worms) = {1 to 5}
       эффект: P6(Ordinary worms) = {1 to 5}
  -> Path525 => Loc137  вер=1 порядок=5
       эффект: P5(White worms) = {1 to 5}
       эффект: P6(Ordinary worms) = {1 to 5}
  -> Path526 => Loc138  вер=1 порядок=5
       эффект: P4(Green worms) = {1 to 5}
  -> Path527 => Loc139  вер=1 порядок=5
       эффект: P5(White worms) = {1 to 5}
  -> Path528 => Loc140  вер=1 порядок=5
       эффект: P6(Ordinary worms) = {1 to 5}

### Loc142 [пустая]
  -> Path550 => Loc69  вер=1 порядок=5
       эффект: P8(Time) = {[p8]-(1 to 2)}

### Loc144 [пустая]
  -> Path562 => Loc25  вер=1 порядок=5

### Loc145 [пустая]
  -> Path558 => Loc23  вер=1 порядок=5

### Loc146 [пустая]
  -> Path568 => Loc26  вер=1 порядок=5

### Loc147 [пустая]
  -> Path470 => Loc128  вер=1 порядок=5
       условия: логика {[p9]>[p10]}
  -> Path473 => Loc130  вер=1 порядок=5
       условия: логика {[p10]>[p9]}
  -> Path603 => Loc152  вер=1 порядок=5
       условия: логика {[p9]=[p10]}

### Loc148 [пустая]
  -> Path582 => Loc4  вер=1 порядок=5
       ответ: You open the wardrobe but only find some old clothes. In searching the pockets, you find nothing but a fishing manual, which you put on the table
       эффект: P1(Money) = {[p1]+[p24]}

### Loc149 [пустая]
  -> Path587 => Loc151  вер=1 порядок=5
       ответ: Both you and Vulture use the same technique, so nobody gains the advantage.
       условия: логика {([p21]=1 and [p22]=1) or ([p21]=2 and [p22]=2) or ([p21]=3 and [p22]=3)}
  -> Path592 => Loc151  вер=1 порядок=5
       ответ: You use a top-roll, which is good, because he's is trying to do a press on you.
       условия: логика {[p21]=1 and [p22]=2}
       эффект: P12(Balance) -1
  -> Path593 => Loc151  вер=1 порядок=5
       ответ: You tighten up and Vulture's poor attempt to win using a hook fails.
       условия: логика {[p21]=2 and [p22]=3}
       эффект: P12(Balance) -1
  -> Path594 => Loc151  вер=1 порядок=5
       ответ: You decide to use a top-roll, which is lucky for you, because Vulture is trying a press.
       условия: логика {[p21]=3 and [p22]=1}
       эффект: P12(Balance) -1
  -> Path595 => Loc151  вер=1 порядок=5
       ответ: You tighten up and begin to press, but your move fails. You pressed with all your might, but it didn't work. Vulture had decided to use a press and was thus get…
       условия: логика {[p21]=2 and [p22]=1}
       эффект: P12(Balance) +1
  -> Path596 => Loc151  вер=1 порядок=5
       ответ: You decide to show your strength with a top-roll, but it fails as Vulture moves your hand forcefully to the opposite side of the table.
       условия: логика {[p21]=3 and [p22]=2}
       эффект: P12(Balance) +1
  -> Path597 => Loc151  вер=1 порядок=5
       ответ: You decide to use a press, but that fails - he wins with a quick, clean jerk.
       условия: логика {[p21]=1 and [p22]=3}
       эффект: P12(Balance) +1

### Loc150 [обычная]
    Loc150-1: Feeling bitter, Vulture sits before you and glares. Clearly, he has no intention of losing to you. Right now all your thoughts are concentrated on Vulture's han…
  -> Path588 => Loc149  вер=1
       текст: Tighten up and pull his hand down with all your might.
       эффект: P21 = {2}
       эффект: P22 = {1 to 3}
  -> Path589 => Loc149  вер=1 порядок=1
       текст: Use a top-roll.
       эффект: P21 = {3}
       эффект: P22 = {1 to 3}
  -> Path590 => Loc149  вер=1 порядок=2
       текст: Perform a press.
       эффект: P21 = {1}
       эффект: P22 = {1 to 3}

### Loc151 [пустая]
  -> Path605 => Loc149  вер=1 порядок=5
       текст: Perform a press.
       условия: P12(Balance) 1..5
       эффект: P21 = {1}
       эффект: P22 = {1 to 3}
  -> Path606 => Loc149  вер=1 порядок=5
       текст: Tighten up and pull his hand down with all your might.
       условия: P12(Balance) 1..5
       эффект: P21 = {2}
       эффект: P22 = {1 to 3}
  -> Path607 => Loc149  вер=1 порядок=5
       текст: Use a top-roll.
       условия: P12(Balance) 1..5
       эффект: P21 = {3}
       эффект: P22 = {1 to 3}
  -> Path608 => Loc153  вер=1 порядок=5
       условия: логика {[p12]=0}
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {1}
  -> Path609 => Loc153  вер=1 порядок=5
       условия: логика {[p12]=6}
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {2}

### Loc152 [УСПЕХ]
    Loc152-1: Your catch is weighed. It is [p9] g. Vulture's catch is weighed and it is...  also [p10] g! / The judges are confused. The two leading fishermen have never befo…
    эффект: P36(Player's money) = {[p36]+[p35]}

### Loc153 [обычная]
    выбор описания: {[p24]}
    Loc153-1: You struggle tooth and nail and tighten your muscles. Sensing your advantage over Vulture, you prevailed against him - even though he's a formidable opponent. L…
    Loc153-2: You struggle tooth and nail, but... The peleng still takes the cake! / With a telling look, he reminds you about the money.
  -> Path145 => Loc32  вер=1 порядок=5
       текст: Pay your money and leave the table.
       условия: P12(Balance) 6..6
       эффект: P1(Money) -100
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {5}
       эффект: P45(Vulture) +1
       скрыт: P12
  -> Path602 => Loc32  вер=1 порядок=5
       текст: Collect your money and leave the table.
       условия: P12(Balance) 0..0
       эффект: P1(Money) = {[p1]+100}
       эффект: P24(Bar!!!!!!!!!!!!!!!) = {6}
       эффект: P45(Vulture) +2
       скрыт: P12

## Анализ
- стартовых: [1]
- концовки: {28: 'ПРОВАЛ', 128: 'УСПЕХ', 130: 'ПРОВАЛ', 152: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
