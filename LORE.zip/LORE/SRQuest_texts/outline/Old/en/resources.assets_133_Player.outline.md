# Квест (формат 1111111126)
Сложность 20; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Parameter 1' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 1 - white
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Parameter 2' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 2 - white
    [2..2] Box № 2 - black
    критическое: Сообщение достижения критического значения параметром 2
- P3 'Parameter 3' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 3 - white
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Parameter 4' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 4 - white
    [2..2] Box № 4 - black
    критическое: Сообщение достижения критического значения параметром 4
- P5 'Parameter 5' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 5 - black
    критическое: Сообщение достижения критического значения параметром 5
- P6 'Parameter 6' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 6 - white
    [2..2] Box № 6 - black
    критическое: Сообщение достижения критического значения параметром 6
- P7 'Parameter 7' [0..1] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 7 - white
    критическое: Сообщение достижения критического значения параметром 7
- P8 'Parameter 8' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Box № 8 - white
    [2..2] Box № 8 - black
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Line' [0..7] тип=обычный
    старт: [7]
    [0..7] 
    критическое: Сообщение достижения критического значения параметром 9
- P10 'Square' [0..15] тип=обычный
    старт: [15]
    [0..15] 
    критическое: Сообщение достижения критического значения параметром 10
- P11 'Colour' [1..3] тип=обычный
    старт: [1]
    [1..3] 
    критическое: Сообщение достижения критического значения параметром 11
- P13 'Attempt' [1..2] тип=обычный
    старт: [1]
    [1..2] 
    критическое: Сообщение достижения критического значения параметром 13

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: A decently dressed Faeyan met you near the spaceport. He introduced himself as the director of the Museum of Faeyan Technology (as usual, you let his name go by…
    эффект: P1(Parameter 1) = 0
    эффект: P2(Parameter 2) = 0
    эффект: P3(Parameter 3) = 0
    эффект: P4(Parameter 4) = 0
    эффект: P5(Parameter 5) = 0
    эффект: P6(Parameter 6) = 0
    эффект: P7(Parameter 7) = 0
    эффект: P8(Parameter 8) = 0
    эффект: P9(Line) = 7
    эффект: P10(Square) = 15
    эффект: P11(Colour) = 1
    эффект: P13(Attempt) = 1
  -> Path2 => Loc2  вер=1 проходов<=1 порядок=5
       текст: Tell me about the device

### Loc2 [обычная] визитов<=1
    Loc2-1: - The device has <clr>a square indicator 3*3 boxes in size<clrEnd>. After we hook the tuner up to the player and push the button, we set <clr>the overtone<clrEn…
  -> Path12 => Loc3  вер=1 проходов<=1 порядок=3
       текст: It's clear now, let's not waste time and start
  -> Path26 => Loc11  вер=1 порядок=5
       текст: Is this all or are there any more details?

### Loc3 [обычная] визитов<=14
    выбор описания: {[p11]}
    Loc3-1: Awkward silence settled in the car for some time. /  / - Also I must warn you, that the tuner is rather old itself, and its <clr> checking function for box №9 d…
    Loc3-2: Quiet buzzing was heard, and the box that you chose became <clr>white<clrEnd>. /  / There is the indicator of the DND player's tuner in front of your eyes: /  /…
    Loc3-3: Quiet buzzing was heard, and the box that you chose became <clr> black <clrEnd>. /  / There is the indicator of the DND player's tuner in front of your eyes: / …
  -> Path3 => Loc4  вер=1 проходов<=1 порядок=4
       текст: 4
       условия: P6(Parameter 6) 0..0
       эффект: P4(Parameter 4) +1
       эффект: P9(Line) = {2*([p9] div 2)}
       эффект: P10(Square) = {4*([p10] div 4)}
       эффект: P11(Colour) = 2
  -> Path4 => Loc4  вер=1 проходов<=1 порядок=5
       текст: 5
       эффект: P5(Parameter 5) +1
       эффект: P9(Line) = 2
       эффект: P11(Colour) = 3
  -> Path5 => Loc4  вер=1 проходов<=1 порядок=6
       текст: 6
       условия: P4(Parameter 4) 1..2
       эффект: P6(Parameter 6) +2
       эффект: P9(Line) = {4}
       эффект: P11(Colour) = 3
  -> Path6 => Loc4  вер=1 проходов<=1 порядок=7
       текст: 7
       эффект: P7(Parameter 7) +1
       эффект: P9(Line) = {2*([p9] div 2)}
       эффект: P10(Square) = {([p10] mod 2)+4*([p10] div 4)}
       эффект: P11(Colour) = 2
  -> Path7 => Loc4  вер=1 проходов<=1 порядок=8
       текст: 8
       условия: P2(Parameter 2) 1..2
       эффект: P8(Parameter 8) = 2
       эффект: P10(Square) = 0
       эффект: P11(Colour) = 3
  -> Path9 => Loc4  вер=1 проходов<=1 порядок=1
       текст: 1
       эффект: P1(Parameter 1) +1
       эффект: P9(Line) = {2*([p9] div 2)}
       эффект: P10(Square) = {2*([p10] div 2)}
       эффект: P11(Colour) = 2
  -> Path10 => Loc4  вер=1 проходов<=1 порядок=2
       текст: 2
       условия: P8(Parameter 8) 0..0
       эффект: P2(Parameter 2) +2
       эффект: P9(Line) = {2}
       эффект: P10(Square) = {([p10] mod 2)+8*([p10] div 8)}
       эффект: P11(Colour) = 3
  -> Path11 => Loc4  вер=1 проходов<=1 порядок=3
       текст: 3
       эффект: P3(Parameter 3) +1
       эффект: P9(Line) = {[p9] mod 4}
       эффект: P10(Square) = {[p10] mod 8}
       эффект: P11(Colour) = 2
  -> Path16 => Loc4  вер=1 проходов<=1 порядок=2
       текст: 2
       условия: P8(Parameter 8) 1..2
       эффект: P2(Parameter 2) = 1
       эффект: P9(Line) = 0
       эффект: P11(Colour) = 2
  -> Path17 => Loc4  вер=1 проходов<=1 порядок=6
       текст: 6
       условия: P4(Parameter 4) 0..0
       эффект: P6(Parameter 6) +1
       эффект: P9(Line) = {([p9] mod 4)}
       эффект: P10(Square) = {([p10] mod 4)}
       эффект: P11(Colour) = 2
  -> Path18 => Loc4  вер=1 проходов<=1 порядок=8
       текст: 8
       условия: P2(Parameter 2) 0..0
       эффект: P8(Parameter 8) = 2
       эффект: P9(Line) = 2
       эффект: P10(Square) = {2*(([p10] mod 8) div 2)}
       эффект: P11(Colour) = 3
  -> Path19 => Loc4  вер=1 проходов<=1 порядок=4
       текст: 4
       условия: P6(Parameter 6) 1..2
       эффект: P4(Parameter 4) +2
       эффект: P9(Line) = 1
       эффект: P11(Colour) = 3
  -> Path20 => Loc4  вер=1 проходов<=1 порядок=8
       текст: 8
       условия: P2(Parameter 2) 1..2
       эффект: P8(Parameter 8) = 1
       эффект: P9(Line) = 0
       эффект: P11(Colour) = 2
  -> Path21 => Loc4  вер=1 проходов<=1 порядок=2
       текст: 2
       условия: P8(Parameter 8) 1..2
       эффект: P2(Parameter 2) = 2
       эффект: P10(Square) = 0
       эффект: P11(Colour) = 3

### Loc4 [пустая]
    выбор описания: {[p11]-1}
    Loc4-1: Quiet buzzing was heard, and the box that you chose became <clr>white<clrEnd>. /  / The testing is over. You are staring obtusely at the indicator of the DND pl…
    Loc4-2: Quiet buzzing was heard, and the box that you chose became <clr>black<clrEnd>. /  / The testing is over. You are staring obtusely at the indicator of the DND pl…
  -> Path13 => Loc3  вер=1 порядок=5
       условия: P13(Attempt) 1..1
       эффект: P13(Attempt) +1
  -> Path14 => Loc6  вер=1 порядок=5
       текст: Call the Faeyan
       условия: P9(Line) 0..0; P13(Attempt) 2..2
  -> Path15 => Loc5  вер=1 порядок=5
       текст: Call the Faeyan
       условия: P9(Line) 1..7; P13(Attempt) 2..2

### Loc5 [пустая]
  -> Path22 => Loc7  вер=1 порядок=5
       условия: P10(Square) 0..0
  -> Path23 => Loc8  вер=1 порядок=5
       условия: P10(Square) 1..15; логика {([p9] mod 2)=1}
  -> Path24 => Loc9  вер=1 порядок=5
       условия: P10(Square) 1..15; логика {(([p9] mod 4) div 2)=1}
  -> Path25 => Loc10  вер=1 порядок=5
       условия: P10(Square) 1..15; логика {[p9]>3}

### Loc6 [УСПЕХ]
    выбор описания: {[p8]}
    Loc6-1: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc6-2: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…

### Loc7 [УСПЕХ]
    Loc7-1: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…

### Loc8 [ПРОВАЛ]
    выбор описания: {1+2*([p10]>3)+([p10]>7)+(([p10]=2) or ([p10]=3))}
    Loc8-1: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc8-2: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc8-3: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc8-4: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…

### Loc9 [ПРОВАЛ]
    выбор описания: {1+2*([p10]>3)+([p10]>7)+(([p10]=2) or ([p10]=3))}
    Loc9-1: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc9-2: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc9-3: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc9-4: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…

### Loc10 [ПРОВАЛ]
    выбор описания: {1+2*([p10]>3)+([p10]>7)+(([p10]=2) or ([p10]=3))}
    Loc10-1: The museum director came closer and examined the display for some time  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |<…
    Loc10-2: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc10-3: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…
    Loc10-4: The museum director came closer and examined the display for some time.  /  / <fix> / <format=center,33>-------------</format> / <format=center,33>| 1 | 2 | 3 |…

### Loc11 [обычная]
    Loc11-1: - I was reluctant to tell you about it but as long as you asked... See, we didn't have any tuners for DND-players by that time already so we had to buy one from…
  -> Path27 => Loc3  вер=1 порядок=5
       текст: So, am I supposed to fix a broken player with the help of a defective tuner?!

## Анализ
- стартовых: [1]
- концовки: {6: 'УСПЕХ', 7: 'УСПЕХ', 8: 'ПРОВАЛ', 9: 'ПРОВАЛ', 10: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
