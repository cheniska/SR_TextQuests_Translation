# Квест (формат 1111111126)
Сложность 50; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Health' [0..100] тип=смерть
    старт: [100]
    [0..15] Health: <>% (<clr>!!!<clrEnd>)
    [16..100] Health: <>%
    критическое: Your strength gave out. You are not worthy of an authorisation to change sex. What is the reason to …
- P2 'Respect' [0..100] тип=смерть
    старт: [40..50]
    [0..15] Respect: <>% (<clr>!!!<clrEnd>)
    [16..100] Respect: <>%
    критическое: Your behaviour at the village was extremely antisocial and respect for you fell flat. You felt it wh…
- P3 'Burrow' [0..20000] тип=смерть
    старт: [5..10]
    [0..10] Burrow depth: <> ar (<clr>!!!<clrEnd>)
    [11..20000] Burrow depth: <> ar
    критическое: You burrow has almost crumbled! "Not a big deal, I can bum it over somewhere" you thought, but other…
- P4 'Weight' [0..20000] тип=смерть
    старт: [25..35]
    [0..10] Weight: <> hg (<clr>!!!<clrEnd>)
    [11..20000] Weight: <> hg
    критическое: Just look at yourself with your own six eyes!!! There's almost nothing to see! You're so skinny you …
- P5 'Scalps' [0..2000] тип=обычный
    старт: [0]
    [0..2000] Scalps: <>
    критическое: Пачварашей стало гораздо больше, чем нор, где им можно было жить. Несколько тварей рванили в вашу но…
- P6 'D(Health)' [-100..100] тип=обычный
    старт: [0]
    [-100..100] Value 6: <>
    критическое: Сообщение достижения критического значения параметром 6
- P7 'D(Resp,3B)' [-100..100] тип=обычный
    старт: [0]
    [-100..100] Units: <>
    критическое: Сообщение достижения критического значения параметром 7
- P8 'D(Burrow,BB)' [-100..100] тип=обычный
    старт: [0]
    [-100..100] Units small: <>
    критическое: Сообщение достижения критического значения параметром 8
- P9 'D(Weight)' [-100..100] тип=обычный
    старт: [0]
    [-100..100] Ssmall: <>
    критическое: Сообщение достижения критического значения параметром 9
- P10 'x' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 24
- P11 'Previous health' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 10
- P12 'Previous respect' [0..100] тип=обычный
    старт: [0]
    [0..100] 
    критическое: Сообщение достижения критического значения параметром 11
- P13 'Previous burrow' [0..20000] тип=обычный
    старт: [0]
    [0..20000] 
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Previous weight' [0..20000] тип=обычный
    старт: [0]
    [0..20000] 
    критическое: Сообщение достижения критического значения параметром 14
- P15 "Chief's health" [0..100] тип=обычный
    старт: [100]
    [0..100] Chief's health: [p15]%
    критическое: Сообщение достижения критического значения параметром 12
- P16 "Chief's weight" [0..75] тип=обычный
    старт: [75]
    [0..75] Chief's weight: [p16] hg
    критическое: Сообщение достижения критического значения параметром 16
- P24 'Back' [0..1000] тип=обычный
    старт: [0]
    [0..1000] 
    критическое: Сообщение достижения критического значения параметром 15

## Локации и переходы

### Loc1 [СТАРТ]
    выбор описания: {[p10]+1}
    Loc1-1: You landed in a common Peleng spaceport. But once you had prepared yourself for several traditionally tiresome hours of Peleng customs procedures (what do they …
    Loc1-2: - Should I also send you on a secret mission? - laughed Buor O'Cratt in return. He definitely has an extensive experience of accepting rangers in his office!
    Loc1-3: - Thanks to modern technologies you will be turned into a <clr>pachvarash<clrEnd>. It is a little sacred creature with three legs and six eyes. Then you will be…
    Loc1-4: - There is no time in the pachvarash village, - said the lyakusha. - Just do everything right!
    эффект: P1(Health) +0% [скрыт]
    эффект: P6(D(Health)) = {} [скрыт]
    скрыт: P2,P3,P4,P5,P7,P8,P9,P11,P12,P13,P14,P15,P16
  -> Path205 => Loc62  вер=1 порядок=6
       текст: Tell me about the ritual
       условия: P10(x) ∉[2]
       эффект: P10(x) = 2
  -> Path206 => Loc62  вер=1 проходов<=1 порядок=8
       текст: Do you have some coffee?
       эффект: P10(x) = 1
  -> Path207 => Loc64  вер=1 порядок=9
       текст: Turn me into a pachvarash??? No way, that was not in the deal, I go back to the spaceport!!!
       условия: P10(x) ∈[2, 3]
  -> Path208 => Loc62  вер=1000 проходов<=1 порядок=7
       текст: How much time there is?
       условия: P10(x) ∈[2]
       эффект: P10(x) = 3
  -> Path210 => Loc63  вер=1
       текст: Let's start the ritual!
       ответ: - Good! We begin your transformation into a pachvarash! - Peleng said, pushing a button on the wall.  /  / A small droid rolled to you from the far end of the r…
       эффект: P5(Scalps) = 0 [показ]
       эффект: P6(D(Health)) = 0
       эффект: P7(D(Resp,3B)) = 0
       эффект: P8(D(Burrow,BB)) = 0
       эффект: P9(D(Weight)) = 0
       эффект: P10(x) = {9}
       показ: P1,P2,P3,P4

### Loc29 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path105 => Loc63  вер=1 порядок=5
       эффект: P10(x) = 10

### Loc57 [обычная]
    выбор описания: {[p10]}
    Loc57-1: You made it! Weight of [p4] hg, a burrow [p3] ar deep and [p2]% of respect - it is more than enough to win! The lights died and the pachvarash village has vanis…
    Loc57-2: You have beaten the Chief himself! Now you are the main pachvarash in the village. You will become a new Chief and other pachvarashes will bring you best food a…
    скрыт: P1,P2,P3,P4,P5,P15,P16
  -> Path331 => Loc91  вер=1 порядок=5
       текст: Uoooblokkghkabrghhhhblblekhhhhh!
  -> Path332 => Loc91  вер=1 порядок=5
       текст: Aggrrhhhakhoglogkhorrrrvakhhhh!
  -> Path333 => Loc91  вер=1 порядок=5
       текст: Dablkhbylbulbikhhhirgrriggrizlbnikhh!
  -> Path334 => Loc91  вер=1 порядок=5
       текст: Whydidntyouwarnmethatiwontbeabletospeaaagbldisgustiiinnnnnn...
  -> Path335 => Loc91  вер=1 порядок=5
       текст: Whatthehellblnelkotttdamyuuuuu!

### Loc58 [обычная] визитов<=1
    Loc58-1: - As far as I know, on planet <FromPlanet> they said that thousands of Pelengs <clr>wish<clrEnd> to pass the ritual every year. I'd rather say that millions wan…
  -> Path202 => Loc59  вер=1 проходов<=1 порядок=5
       текст: 300 years only?! But they say it is the oldest Peleng tradition!
  -> Path203 => Loc61  вер=1 проходов<=1 порядок=6
       текст: Then I am cooler than the Pelengs! Now excuse me, have to go to the spaceport...

### Loc59 [обычная] визитов<=1
    Loc59-1: - Given that a Peleng law or tradition is hardly to survive for more than 100 years, the change of sex authorisation ritual is indeed our most ancient tradition…
  -> Path204 => Loc60  вер=1 проходов<=1 порядок=5
       текст: But if the exercise can not be completed, how could I win?

### Loc60 [УСПЕХ] визитов<=1
    Loc60-1: - Because you are not Peleng! Your psychology is different and enabled you to avoid our nice traps. For instance, it never occurred to you to swim in a beautifu…

### Loc61 [УСПЕХ]
    Loc61-1: After saying goodbye to the Peleng, you returned to the spaceport. Despite the success of the mission, your mood is rather bad. Only the anticipation of the pri…

### Loc62 [пустая]
  -> Path209 => Loc1  вер=1 порядок=5

### Loc63 [обычная]
    выбор описания: {[p10]}
    Loc63-1: "I'd live to spend my whole life in this burrow! - you thought. - Wait, I already begin to think like an animal, I am a highly intelligent creature!!!"  /  / It…
    Loc63-2: The pachvarashes stayed in their burrows and did nothing. It seems as if they are afraid to do anything themselves. /  / Determination is your second name! It i…
    Loc63-3: This night on planet <ToPlanet> - is the best of all nights. The sky is full of stars and it's pleasant to remember that some time ago you run around pirate sys…
    Loc63-4: It would be nice to have a deal with another pachvarash; together we can complete the ritual faster. An ability to speak - that's what makes a humanoid differen…
    Loc63-5: Don't stop at what has been accomplished! You will not pass the ritual by sitting in your burrow. It's time to act!
    Loc63-6: It is safe to stay in the burrow. But you should not just stay there, you have to act. A wind started and small particles of soil are blown around like snow. Yo…
    Loc63-7: You have carefully spelled your name with a toe in the dust by your door: "<Ranger>". You can not speak, but nobody can take the right to write! "Long live free…
    Loc63-8: Everything has changed in your burrow - it's damp and dirty, and no one to talk to. And nothing to speak with... What boredom! Maybe you should have something t…
    Loc63-9: You looked around your burrow. What an ugly place! Will you really have to live here and dig it further?! You tried to curse, but all you managed were some shri…
    Loc63-10: A stone plate, installed nearby your burrow, contained the following inscription: /  / ------------------- / TWO WAYS TO WIN: /  / 1. PEACEFUL: / - Gain more we…
  -> Path104 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path211 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path212 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path213 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path214 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path215 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path329 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1

### Loc64 [ПРОВАЛ]
    Loc64-1: For some reason it seemed to you that Buor O'Cratt was not upset with your rejection. He just smiled with contempt, called for a familiar Peleng in a cassock an…

### Loc65 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path217 => Loc78  вер=1 порядок=5
       условия: P2(Respect) 1..30
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P10(x) = 6
  -> Path233 => Loc78  вер=2 порядок=5
       условия: P2(Respect) 1..15; P3(Burrow) 1..15
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P10(x) = 1
  -> Path237 => Loc78  вер=2 порядок=5
       условия: P2(Respect) 55..100
       эффект: P6(D(Health)) = {[10..15]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path238 => Loc78  вер=1 порядок=5
       условия: P3(Burrow) 30..20000
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P10(x) = 4
  -> Path239 => Loc78  вер=2 порядок=5
       условия: P4(Weight) 75..20000
       эффект: P6(D(Health)) = {[20..25]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 5
  -> Path240 => Loc78  вер=3 порядок=5
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 2
  -> Path241 => Loc78  вер=2 порядок=5
       условия: P2(Respect) 10..100; P3(Burrow) 10..20000
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 7
  -> Path242 => Loc78  вер=2 порядок=5
       условия: P2(Respect) 35..100
       эффект: P6(D(Health)) = {[15..20]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 8
  -> Path243 => Loc78  вер=1 порядок=5
       условия: P2(Respect) 1..65; P5(Scalps) 2..2000
       эффект: P5(Scalps) -1
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path244 => Loc78  вер=1 порядок=5
       условия: P2(Respect) 1..50; P3(Burrow) 11..20000; P4(Weight) 25..20000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {-[4..9]}
       эффект: P7(D(Resp,3B)) = {-[7..12]}
       эффект: P8(D(Burrow,BB)) = {[4..9]}
       эффект: P9(D(Weight)) = {-[1..3]}
       эффект: P10(x) = 10

### Loc66 [обычная]
    Loc66-1: You can eat some tarnished grass around your burrow - it's not extremely nutritious, but rather safe. On the other hand you can go to a nice meadow in the centr…
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path280 => Loc70  вер=1 порядок=9
       текст: Going nowhere, staying in the burrow
       эффект: P24(Back) = {63}
  -> Path281 => Loc77  вер=1 порядок=4
       текст: Eat grass next to the burrow
  -> Path282 => Loc81  вер=1 порядок=5
       текст: Go to the wonderful meadow

### Loc67 [обычная]
    выбор описания: {1+([p2]=100)}
    Loc67-1: It's time to gain respect from others, and the best way to do it is to fight other pachvarashes! Respect is increased most after beating a strong opponent. But …
    Loc67-2: Why do you have to fight in the first place? Your rating is already {100}%! It's just a waste of strength. However, if you are lucky enough, you may get a scalp…
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path323 => Loc89  вер=1 порядок=9
       текст: Won't fight, better return to the burrow
  -> Path347 => Loc95  вер=1 порядок=4
       текст: Fight with a weak opponent
  -> Path348 => Loc92  вер=1 порядок=5
       текст: Fight with a strong opponent

### Loc68 [обычная]
    Loc68-1: How actively you are going to dig?
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path245 => Loc75  вер=1 порядок=5
       текст: Dig full out
  -> Path246 => Loc76  вер=1 порядок=4
       текст: Dig slowly and carefully to save the strength
  -> Path279 => Loc70  вер=1 порядок=9
       текст: Do something else
       эффект: P24(Back) = {63}

### Loc69 [обычная]
    Loc69-1: You have got <clr>5<clrEnd> scalps, which entitles you to call the Chief himself for a fight! You decided to exercise your right. You approached the Chief's bur…
    эффект: P5(Scalps) -5
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
    показ: P15,P16
  -> Path371 => Loc96  вер=1 порядок=5
       текст: Bite the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path372 => Loc97  вер=1 порядок=4
       текст: Hit the Chief with a paw
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path373 => Loc98  вер=1 порядок=6
       текст: Throw something at the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75

### Loc70 [пустая]
    эффект: P11(Previous health) = {[p1]}
    эффект: P12(Previous respect) = {[p2]}
    эффект: P13(Previous burrow) = {[p3]}
    эффект: P14(Previous weight) = {[p4]}
    эффект: P15(Chief's health) +1
    эффект: P16(Chief's weight) +1
  -> Path216 => Loc63  вер=1 порядок=5
       условия: P24(Back) ∈[63]
       эффект: P10(x) = {[1..8]}
  -> Path276 => Loc72  вер=1 порядок=5
       условия: P24(Back) ∈[72]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {-[p3]*(([p3]+[p8])<0)+[p8]*(([p3]+[p8])>=0)}
       эффект: P9(D(Weight)) = {[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9])>=0)}
  -> Path277 => Loc74  вер=1 порядок=5
       условия: P24(Back) ∈[74]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {-[p3]*(([p3]+[p8])<0)+[p8]*(([p3]+[p8])>=0)}
       эффект: P9(D(Weight)) = {[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9])>=0)}
  -> Path278 => Loc71  вер=1 порядок=5
       условия: P24(Back) ∈[71]
       эффект: P6(D(Health)) = {(100-[p1])*(([p1]+[p6])>100)-[p1]*(([p1]+[p6])<0)+[p6]*(([p1]+[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {[p3]*(([p3]-[p8])<0)+[p8]*(([p3]-[p8])>=0)}
       эффект: P9(D(Weight)) = {-[p4]*(([p4]+[p9])<0)+[p9]*(([p4]+[p9])>=0)}
  -> Path285 => Loc85  вер=1 порядок=5
       условия: P24(Back) ∈[85]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {(100-[p2])*(([p2]+[p7])>100)-[p2]*(([p2]+[p7])<0)+[p7]*(([p2]+[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {[p3]*(([p3]-[p8])<0)+[p8]*(([p3]-[p8])>=0)}
       эффект: P9(D(Weight)) = {[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9])>=0)}
  -> Path286 => Loc86  вер=1 порядок=5
       условия: P24(Back) ∈[86]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {(100-[p2])*(([p2]+[p7])>100)-[p2]*(([p2]+[p7])<0)+[p7]*(([p2]+[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {[p3]*(([p3]-[p8])<0)+[p8]*(([p3]-[p8])>=0)}
       эффект: P9(D(Weight)) = {[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9])>=0)}
  -> Path287 => Loc87  вер=1 порядок=5
       условия: P24(Back) ∈[87]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {[p3]*(([p3]-[p8])<0)+[p8]*(([p3]-[p8])>=0)}
       эффект: P9(D(Weight)) = {-[p4]*(([p4]+[p9])<0)+[p9]*(([p4]+[p9])>=0)}
  -> Path289 => Loc88  вер=1 порядок=5
       условия: P24(Back) ∈[88]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {[p3]*(([p3]-[p8])<0)+[p8]*(([p3]-[p8])>=0)}
       эффект: P9(D(Weight)) = {-[p4]*(([p4]+[p9])<0)+[p9]*(([p4]+[p9])>=0)}
  -> Path309 => Loc73  вер=1 порядок=5
       условия: P24(Back) ∈[73]
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p2]-100)*(([p2]-[p7])>100)+[p2]*(([p2]-[p7])<0)+[p7]*(([p2]-[p7]) in [0..100])}
       эффект: P8(D(Burrow,BB)) = {-[p3]*(([p3]+[p8])<0)+[p8]*(([p3]+[p8])>=0)}
       эффект: P9(D(Weight)) = {[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9])>=0)}

### Loc71 [обычная]
    выбор описания: {[p10]}
    Loc71-1: You just could not fall asleep - you were having a nightmare, as if other pachvarashes tear you in pieces. This must be due to your low respect - only [p12]%. T…
    Loc71-2: While relaxing after the pachvarash business you can heal your wounds. "Health goes first!" - you thought and relaxed to renew your strength. /  / Your health r…
    Loc71-3: Some free time al last! You have an opportunity to relax and have a good rest. Nobody dared to disturb you thanks to respect of [p12]%! /  / Your health recover…
    Loc71-4: It's nice to relax, think of space travel and hot stars. That soon it's all going to end and you will get behind the wheel of your spaceship... But your tranqui…
    Loc71-5: What can be better for gaining weight than a good siesta, especially when your weight is already [p14] hg? You cuddled and snored, not worrying about the conseq…
    Loc71-6: You decided to have a sleep, but they did not let you rest for long: some arrogant pachvarash approached your burrow and threw a stone in it. It's time to incre…
    Loc71-7: A rest is essential not only for intelligent creatures but also for pachvarashes.  / Looking up you studied irregularities on the cave surface. With six eyes yo…
    Loc71-8: It's so pleasant to have a rest! There is nothing to do, just enjoy yourself. You can stretch your 3 paws and have a nap. A respect of [p12]% ensures relaxation…
    Loc71-9: You had a little nap, and after you woke up you discovered that <clr>someone had stolen a scalp<clrEnd>! What a shame, you relaxed for just a moment!!! /  / You…
    Loc71-10: Once you closed your eyes, some arrogant pachvarash broke into your burrow. You did not tolerate that of course and attacked the trespasser with the whole weigh…
    эффект: P1(Health) = {[p1]+[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]-[p8]}
    эффект: P4(Weight) = {[p4]+[p9]}
  -> Path247 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path249 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path250 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path251 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path321 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1
  -> Path324 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path325 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}

### Loc72 [обычная]
    выбор описания: {[p10]}
    Loc72-1: Digging on planet <ToPlanet> is a mere torture. You used three legs at once - they are pachvarash's primary weapon in its fight against the soil. Two legs were …
    Loc72-2: You began to dig as if it was natural for you. You vigorously extracted familiar yellow-blue soil when a <clr>stone crushed<clrEnd> on you, that you had not not…
    Loc72-3: Digging a small burrow like yours is not difficult. Nevertheless you worked hard and suddenly felt you had lost weight of [p9] hg. On the other hand the burrow …
    Loc72-4: You worked hard digging the burrow but did not take into account that other pachvarashes have no respect for you. A crowd of those pranksters jumped over a newl…
    Loc72-5: Isn't it nice when [p12]% of pachvarashes respect you! You were completely focused on your work and nobody dared to disturb you. You dug the burrow until you ru…
    Loc72-6: You went to the far end of your large burrow and began to think over a plan of activities for today. At once another pachvarash infiltrated your burrow! He must…
    Loc72-7: While you were focused on digging the burrow, a respectful pachvarash noticed that your burrow is rather shallow and attacked you. He crabbed and hit you with h…
    Loc72-8: It is hard to work hard when you weight is just [p14] hg! While digging the burrow you sweated heavily and clumsily hit the walls with your body. Once you run o…
    Loc72-9: With such a small weight (only [p14] hg!) you can't dig much, no matter how hard you try. You'd better save your strength.  /  / You managed to deepen the burro…
    Loc72-10: Fools rush in! Is it appropriate for a respectable pachvarash with a weight of [p14] hg and respect of [p12]% to work hard? Especially when his burrow is alread…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]+[p8]}
    эффект: P4(Weight) = {[p4]-[p9]}
  -> Path219 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path222 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path225 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path228 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path231 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path235 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path327 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1

### Loc73 [обычная]
    выбор описания: {[p10]}
    Loc73-1: On the way back to your burrow you suddenly slipped and fell. The weight of [p14] hg makes a pachvarash rather clumsy. It took [p6]% of your health. /  / What d…
    Loc73-2: A considerable level of respect ([p12]%) is good for an experienced pachvarash - you realised it when you noticed that the others are afraid to approach you. Th…
    Loc73-3: You easily finished the helpless pachvarash and took his scalp. It is the [p5]- scalp in your inventory! However your low act produced only disgust among other …
    Loc73-4: You bent over the helpless pachvarash and it suddenly jolted and bit you by the leg! At once other pachvarashes jumped out of the nearby bush and attacked you. …
    Loc73-5: You decided against finishing the helpless pachvarash to show that you have enough scalps and prefer to extract them in a straight fight. Such coolness impresse…
    Loc73-6: Once you returned to the burrow you discovered that a <clr>scalp was stolen <clrEnd>!!! It looks like the respect of [p12]% did not keep away the thief, while i…
    Loc73-7: Upon you return to the burrow you discovered everything was upside down! While you were away, someone broke into your burrow to steal one of your scalps. It loo…
    Loc73-8: A frightened pachvarash run by your burrow. He saw you in his way and attacked you with a stick. You caught the stick with your paws, but the pachvarash bit you…
    Loc73-9: The level of the others' respect for you is [p12]%! It is an excellent result. They are afraid of you. While you returned to your burrow everybody tried to hide…
    Loc73-10: While approaching the burrow you head a terrible rumble. It turned out that the far end of the burrow collapsed under the weight of the soil. The burrow was too…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]+[p8]}
    эффект: P4(Weight) = {[p4]-[p9]}
  -> Path218 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path221 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path224 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path227 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path230 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path234 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path328 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1

### Loc74 [обычная]
    выбор описания: {[p10]}
    Loc74-1: You began digging and at once some philosophical thoughts emerged in your head, sort of. Why a pachvarash digs a burrow that is already <clr>50 ar<clrEnd> deep?…
    Loc74-2: The role of the weight is not always positive in a pachvarach's life. Once you began to dig, under your heavy body sticky liquid flushed from beneath, your burr…
    Loc74-3: You dug slowly, with no hurry. Sure you will not dig much that way, but on the other hand you are not tired.  /  / You deepened the burrow by [p8] ar. / The oth…
    Loc74-4: You began to dig the burrow slowly. You can hardly run if your weight is [p14] hg! You sweat more and more with every move. /  / You deepened the burrow by [p8]…
    Loc74-5: There's no need to work hard while digging such a small burrow. You did not, but soon deepened your burrow by [p8] ar. However, other pachvarashes saw how shall…
    Loc74-6: You began digging you burrow carefully, bringing spare soil outside, but other naughty pachvarashes threw it back! Several lumps of earth hit your head painfull…
    Loc74-7: You dug the burrow carefully and were so focused on it that did not notice a big boulder that fell on your head. Enraged you decided to stop digging immediately…
    Loc74-8: It is nice to be respected by [p12]% of pachvarashes! You dug the burrow for the whole day and nobody dared to disturb you. However in the end you felt very tir…
    Loc74-9: Your burrow was so deep ([p13] ar!), that you had to carry heavy lumps of soil a long way to the exit. This impacted you physical condition.  /  / You deepened …
    Loc74-10: A careful work and good health ensure a quick eye! You suddenly noticed that soil to the left has a lighter tint. That was a layer of sandstone! It is easier to…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]+[p8]}
    эффект: P4(Weight) = {[p4]-[p9]}
  -> Path220 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path223 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path226 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path229 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path232 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path236 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path322 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1

### Loc75 [пустая]
  -> Path265 => Loc79  вер=2 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[7..12]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 1
  -> Path266 => Loc79  вер=1 порядок=5
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P10(x) = 2
  -> Path267 => Loc79  вер=2 порядок=5
       условия: P3(Burrow) 1..15
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[10..15]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 3
  -> Path268 => Loc79  вер=2 порядок=5
       условия: P2(Respect) 1..25
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 4
  -> Path269 => Loc79  вер=2 порядок=5
       условия: P2(Respect) 55..100
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[15..20]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 5
  -> Path270 => Loc79  вер=1 порядок=5
       условия: P3(Burrow) 30..20000; P4(Weight) 25..20000; P5(Scalps) 1..2000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {-[5..10]}
       эффект: P8(D(Burrow,BB)) = {-[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 6
  -> Path271 => Loc79  вер=3 порядок=5
       условия: P2(Respect) 1..15; P3(Burrow) 1..12
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 7
  -> Path272 => Loc79  вер=2 порядок=5
       условия: P4(Weight) 60..20000
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[10..15]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 8
  -> Path273 => Loc79  вер=3 порядок=5
       условия: P4(Weight) 1..15
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 9
  -> Path274 => Loc79  вер=2 порядок=5
       условия: P2(Respect) 35..100; P3(Burrow) 30..20000; P4(Weight) 30..20000
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 10

### Loc76 [пустая]
  -> Path253 => Loc80  вер=1 порядок=5
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[4..9]}
       эффект: P10(x) = 1
  -> Path255 => Loc80  вер=1 порядок=5
       условия: P4(Weight) 70..20000
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {-[1..3]}
       эффект: P10(x) = 2
  -> Path256 => Loc80  вер=1 порядок=5
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path257 => Loc80  вер=1 порядок=5
       условия: P4(Weight) 50..20000
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 4
  -> Path258 => Loc80  вер=2 порядок=5
       условия: P3(Burrow) 1..10
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[5..10]}
       эффект: P10(x) = 5
  -> Path259 => Loc80  вер=1 порядок=5
       условия: P2(Respect) 1..30; P4(Weight) 1..30
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 6
  -> Path260 => Loc80  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P10(x) = 7
  -> Path261 => Loc80  вер=1 порядок=5
       условия: P2(Respect) 40..100
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[7..12]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 8
  -> Path262 => Loc80  вер=1 порядок=5
       условия: P3(Burrow) 40..100
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 9
  -> Path263 => Loc80  вер=1 порядок=5
       условия: P1(Health) 95..100; P3(Burrow) 20..20000
       эффект: P8(D(Burrow,BB)) = {[7..12]}
       эффект: P10(x) = 10

### Loc77 [пустая]
  -> Path283 => Loc83  вер=2 порядок=5
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 1
  -> Path295 => Loc83  вер=2 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 2
  -> Path296 => Loc83  вер=1 порядок=5
       условия: P2(Respect) 1..30
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {-[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path297 => Loc83  вер=2 порядок=5
       условия: P4(Weight) 60..20000
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[5..10]}
       эффект: P10(x) = 4
  -> Path298 => Loc83  вер=3 порядок=5
       условия: P2(Respect) 1..20; P4(Weight) 1..20
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 5
  -> Path299 => Loc83  вер=1 порядок=5
       условия: P8(D(Burrow,BB)) 30..100
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 6
  -> Path300 => Loc83  вер=1 порядок=5
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[4..9]}
       эффект: P10(x) = 7
  -> Path301 => Loc83  вер=1 порядок=5
       условия: P1(Health) 90..100
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {-[2..5]}
       эффект: P10(x) = 8
  -> Path302 => Loc83  вер=1 порядок=5
       условия: P2(Respect) 1..40; P4(Weight) 20..40; P5(Scalps) 1..2000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {-[3..7]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P9(D(Weight)) = {-[3..7]}
       эффект: P10(x) = 9
  -> Path317 => Loc83  вер=2 порядок=5
       условия: P3(Burrow) 1..15
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 10

### Loc78 [пустая]
    эффект: P24(Back) = {71}
  -> Path252 => Loc70  вер=1 порядок=5

### Loc79 [пустая]
    эффект: P24(Back) = {72}
  -> Path264 => Loc70  вер=1 порядок=5

### Loc80 [пустая]
    эффект: P24(Back) = {74}
  -> Path254 => Loc70  вер=1 порядок=5

### Loc81 [пустая]
  -> Path310 => Loc82  вер=1 порядок=5
       условия: P2(Respect) 1..70
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[5..10]}
       эффект: P10(x) = 1
  -> Path312 => Loc82  вер=2 порядок=5
       условия: P2(Respect) 30..60; P4(Weight) 25..60
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[5..10]}
       эффект: P10(x) = 2
  -> Path336 => Loc82  вер=2 порядок=5
       условия: P2(Respect) 60..100; P4(Weight) 50..20000
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[10..15]}
       эффект: P10(x) = 3
  -> Path337 => Loc82  вер=4 порядок=5
       условия: P2(Respect) 1..25
       эффект: P6(D(Health)) = {[10..15]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {-[3..7]}
       эффект: P10(x) = 4
  -> Path338 => Loc82  вер=2 порядок=5
       условия: P2(Respect) 10..50
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 5
  -> Path339 => Loc82  вер=1 порядок=5
       условия: P2(Respect) 20..40; P4(Weight) 60..20000
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P7(D(Resp,3B)) = {-[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[4..9]}
       эффект: P10(x) = 6
  -> Path340 => Loc82  вер=1 порядок=5
       условия: P2(Respect) 60..100; P4(Weight) 1..50
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[7..12]}
       эффект: P10(x) = 7
  -> Path343 => Loc82  вер=1 порядок=5
       условия: P2(Respect) 25..55; P4(Weight) 40..20000
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P7(D(Resp,3B)) = {-[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[4..9]}
       эффект: P10(x) = 8
  -> Path345 => Loc82  вер=1 порядок=5
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P10(x) = 9
  -> Path346 => Loc82  вер=2 порядок=5
       условия: P2(Respect) 70..100
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[12..17]}
       эффект: P10(x) = 10

### Loc82 [пустая]
    эффект: P24(Back) = {88}
  -> Path311 => Loc70  вер=1 порядок=5

### Loc83 [пустая]
    эффект: P24(Back) = 87
  -> Path288 => Loc70  вер=1 порядок=5

### Loc85 [обычная]
    выбор описания: {[p10]}
    Loc85-1: It is a mere suicide to challenge cool pachvarashes when your weight is only [p14] hg! With the first blow your mighty opponent brought you down and began to be…
    Loc85-2: Today you attacked an opponent who was stronger than you: your weight was just [p14] hg, while your opponent's weight was at least 70 hg. Nevertheless you got i…
    Loc85-3: With a weight of [p14] hg you can afford to attack a cool pachvarash. That's what you did by attacking one of the strongest inhabitants of the village. The figh…
    Loc85-4: You attacked one of the village's strongest pachvarashes. You had nothing to be afraid of with a weight of [p14] hg. It is you they should be afraid of! And thi…
    Loc85-5: You weight of [p14] hg, secured you the position among the village's strongest pachvarashes. That is why you attacked a local authority without much considerati…
    Loc85-6: You overestimated you strength when you attacked a stronger opponent. It became clear after a few minutes of the fight, when you opponent brought you down and b…
    Loc85-7: You attacked one of the coolest and respectable pachvarashes of the village. Sure it was hard - you desperately tried to avoid his terrible blows and did not ev…
    Loc85-8: Obviously, with a weight of [p14] hg and rating of [p12]% you could not even think of a fight with cool pachvarashes, and it was clear for you. But it did not p…
    Loc85-9: You selected a more or less equal opponent and engaged in a furious fight. You hit each other with your fists and bit with your teeth. After you fell to the gro…
    Loc85-10: You decided to get a scalp at whatever cost. To do this you found a large club and quietly approached the first cool pachvarash you saw. You zonked his head wit…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]+[p7]}
    эффект: P3(Burrow) = {[p3]-[p8]}
    эффект: P4(Weight) = {[p4]-[p9]}
  -> Path305 => Loc89  вер=1 порядок=5
       текст: Return to the burrow

### Loc86 [обычная]
    выбор описания: {[p10]}
    Loc86-1: You selected a weak pachvarash and moved to him. That was not an easy one and after he noticed a huge pachvarash of [p14] hg moving in his direction, he run awa…
    Loc86-2: You selected an equal opponent - with a weight of [p14] hg, you'd better stay away from the coolest pachvarashes! You smashed and bit each other, but no one cou…
    Loc86-3: You selected one of the weakest pachvarashes as your opponent, and even he turned out to be stronger than you are. He grabbed you in his paws and began beating …
    Loc86-4: You noticed the weakest pachvarash among your opponents and caught him before he could escape. After bringing him down to the ground you began kicking, beating …
    Loc86-5: Since your level of respect was [p12]%, no one was really afraid of you. On the other hand, the weight of [p14] hg made you really a dangerous opponent. Your we…
    Loc86-6: You are not very strong, while the respect level of [p12]% terrifies weak pachvarashes. The same happened this time - as soon as you approached the opponent, he…
    Loc86-7: You attacked one of the pachvarashes and began beating him. He desperately fought back, but you seemed to be stronger. Suddenly you head a distant rumble. You u…
    Loc86-8: It is not very nice to have a weight of just [p14] hg, and respect level of [p12]%! It was quiet and suddenly a huge pachvarash attacked you! HE held you in his…
    Loc86-9: You selected a more or less equal opponent and engaged him in a deadly fight. You exchanged furious blows and bit each other tearing large lumps of flesh. Final…
    Loc86-10: Today you've decided to obtain a scalp at whatever cost. You quietly approached a weak pachvarash and grabbed him before he could escape. After you brought him …
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]+[p7]}
    эффект: P3(Burrow) = {[p3]-[p8]}
    эффект: P4(Weight) = {[p4]-[p9]}
  -> Path304 => Loc89  вер=1 порядок=5
       текст: Return to the burrow

### Loc87 [обычная]
    выбор описания: {[p10]}
    Loc87-1: You had a snack of the first grass you found. It was not very tasty, but on the other hand nobody disturbed you. /  / You gained [p9] hg of weight and lost [p7]…
    Loc87-2: The grass next to your home was of an odd yellowish colour. It did not look fresh. Nevertheless you began munching it until you felt bad. Soon you vomited right…
    Loc87-3: It is no good when only [p12]% of pachvarashes have respect for you! As soon as you started your modest meal at your burrow without bothering anybody, an aggres…
    Loc87-4: Why going far away when you weight is already [p14] hg? You lie down right next to your burrow and began munching grass. Other pachvarashes saw how fat and lazy…
    Loc87-5: When you weight is only [p14] hg, and the respect for you is [p12]%, you can't afford any luxury foods. You run out of the burrow, picked some grass and run bac…
    Loc87-6: You had a peaceful meal next to your burrow and nobody disturbed you. Suddenly you heard a loud rumbling from the burrow - it looked like there had been a lands…
    Loc87-7: You got out of the burrow and saw a nice place for a dinner of watery and creepy grass to the right. It definitely looked creepy, but tasted alright. You were l…
    Loc87-8: This time you had a cheerful mood thanks to the health of [p11]%. Juicy and nutritious grass grew right next to your burrow. You decided against going far and a…
    Loc87-9: You got out of the burrow to have a snack of some stale grass, you noticed, that another pachvarash quickly leaped into your burrow! It looked like your weight …
    Loc87-10: You climbed out of your small burrow and ate some stale grass near the entrance. You gained [p9] hg of weight and you borrow did not crumble. As other pachvaras…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]-[p8]}
    эффект: P4(Weight) = {[p4]+[p9]}
  -> Path290 => Loc68  вер=1 порядок=4
       текст: Dig the burrow
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path291 => Loc66  вер=1 порядок=5
       текст: Have a snack
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path292 => Loc67  вер=1 порядок=3
       текст: Go fight other pachvarashes
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path293 => Loc29  вер=1 порядок=9
       текст: Get out and look at the stone plate
       условия: логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path294 => Loc65  вер=1 порядок=8
       текст: Relax
       условия: P1(Health) 1..99; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path326 => Loc69  вер=1
       текст: Fight the Chief
       условия: P5(Scalps) 5..2000; логика {[p4]<100 or [p3]<50 or [p2]<50}
  -> Path330 => Loc57  вер=10000 порядок=5
       текст: You won!
       условия: логика {[p4]>=100 and [p3]>=50 and [p2]>=50}
       эффект: P10(x) = 1

### Loc88 [обычная]
    выбор описания: {[p10]}
    Loc88-1: You arrived at a wonderful meadow in the middle of the village and were amazed to see there was nobody there! You are definitely lucky! You had more than enough…
    Loc88-2: With a weight of [p14] hog and respect of [p12]% you are neither the elite nor the low of the pachvarash society. Fortunately, when you arrived at the best mead…
    Loc88-3: When you weight only [p14] hg and are respected by [p12]% of pachvarashes, you have nothing to fear! You came to the meadow and occupied the best place. Other p…
    Loc88-4: It is silly to go to the best meadow of the village when you are respected only by [p12]% of pachvarashes! Cool pachvarashes, that were at the meadow, did not t…
    Loc88-5: The [p12]% level of respect for you is not enough to grass at the best meadow of the village. Anyway, when you arrived at the meadow, there was no cool pachvara…
    Loc88-6: You are not a very respectable pachvarash - only [p12]% have respect for you. Many pachvarashes did not like that such an unvalued pachvarash came to the best m…
    Loc88-7: It is nice to have respect of [p12]%! Even stronger pachvarashes did not dare to prevent you from eating enough of good grass. Only after the Chief himself arri…
    Loc88-8: With your level of respect of [p12]% you still had to fight for a place on the meadow. Fortunately your weight of [p14] hg is good for fighting. You could keep …
    Loc88-9: Once you arrived at the burrow you noticed that all grass had been eaten and new grass had not time to grow. What a nuisance! Due to the stress your blood press…
    Loc88-10: You are one of the most respectable pachvarashes in the village, your rating is [p12]%. Once you arrived at the meadow, other pachvarashes vacated a place for y…
    эффект: P1(Health) = {[p1]-[p6]}
    эффект: P2(Respect) = {[p2]-[p7]}
    эффект: P3(Burrow) = {[p3]-[p8]}
    эффект: P4(Weight) = {[p4]+[p9]}
  -> Path303 => Loc89  вер=1 порядок=5
       текст: Return to the burrow

### Loc89 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
    эффект: P11(Previous health) = {[p1]}
    эффект: P12(Previous respect) = {[p2]}
    эффект: P13(Previous burrow) = {[p3]}
    эффект: P14(Previous weight) = {[p4]}
  -> Path307 => Loc70  вер=8 порядок=5
       эффект: P24(Back) = {63}
  -> Path308 => Loc70  вер=1 порядок=5
       условия: P2(Respect) 55..100
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {-[1..3]}
       эффект: P10(x) = 2
       эффект: P24(Back) = {73}
  -> Path313 => Loc70  вер=1 порядок=5
       условия: P4(Weight) 40..20000
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P10(x) = 1
       эффект: P24(Back) = {73}
  -> Path314 => Loc90  вер=1 порядок=5
       эффект: P24(Back) = {73}
  -> Path319 => Loc70  вер=1 порядок=5
       условия: P2(Respect) 1..60; P3(Burrow) 1..25; P5(Scalps) 2..2000; логика {[p2]<[p5]*10+10}
       эффект: P5(Scalps) -1
       эффект: P10(x) = 6
       эффект: P24(Back) = {73}
  -> Path320 => Loc70  вер=1 порядок=5
       условия: P2(Respect) 1..70; P3(Burrow) 30..20000; P5(Scalps) 2..2000; логика {[p2]<[p5]*10+20}
       эффект: P8(D(Burrow,BB)) = {-[2..5]}
       эффект: P10(x) = 7
       эффект: P24(Back) = {73}
  -> Path341 => Loc70  вер=1 порядок=5
       условия: P2(Respect) 1..50
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {-[2..5]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 8
       эффект: P24(Back) = {73}
  -> Path342 => Loc70  вер=1 порядок=5
       условия: P2(Respect) 60..100
       эффект: P6(D(Health)) = {-[1..3]}
       эффект: P10(x) = 9
       эффект: P24(Back) = {73}
  -> Path344 => Loc70  вер=1 порядок=5
       условия: P3(Burrow) 35..20000
       эффект: P8(D(Burrow,BB)) = {-[2..5]}
       эффект: P10(x) = 10
       эффект: P24(Back) = {73}

### Loc90 [обычная]
    Loc90-1: On the way back to the burrow you noticed a pachvarash lying in a drain, displaying almost no vital signs. He is either too old or got poisoned with bad grass, …
  -> Path315 => Loc70  вер=3 порядок=5
       текст: Finish the pachvarash and scalp him
       эффект: P5(Scalps) +1
       эффект: P7(D(Resp,3B)) = {[5..10]}
       эффект: P10(x) = 3
  -> Path316 => Loc70  вер=1 порядок=5
       текст: Finish the pachvarash and scalp him
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 4
  -> Path318 => Loc70  вер=1 порядок=5
       текст: Pass by
       эффект: P7(D(Resp,3B)) = {-[2..5]}
       эффект: P10(x) = 5

### Loc91 [обычная] визитов<=2
    Loc91-1: - It is amazing, <Ranger>! - lyakusha Buor O'Cratt repeated, paying no attention to your desperate efforts to speak. - You are the first to pass this ritual dur…
  -> Path200 => Loc61  вер=1 проходов<=1 порядок=6
       текст: Well, I'm really glad! Now excuse me - I have to go to the spaceport...
  -> Path201 => Loc58  вер=1 проходов<=1 порядок=5
       текст: How come?! They told me thousands of Pelengs pass this ritual every year!!!

### Loc92 [пустая]
  -> Path361 => Loc93  вер=2 порядок=5
       условия: P4(Weight) 1..35
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 1
  -> Path362 => Loc93  вер=2 порядок=5
       условия: P4(Weight) 25..55
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 2
  -> Path363 => Loc93  вер=2 порядок=5
       условия: P4(Weight) 50..80
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[5..10]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path364 => Loc93  вер=2 порядок=5
       условия: P4(Weight) 75..20000
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {[10..15]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 4
  -> Path365 => Loc93  вер=1 порядок=5
       условия: P2(Respect) 1..25; P4(Weight) 70..20000
       эффект: P6(D(Health)) = {[4..9]}
       эффект: P7(D(Resp,3B)) = {[12..17]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 5
  -> Path366 => Loc93  вер=1 порядок=5
       условия: P2(Respect) 65..100; P4(Weight) 30..60
       эффект: P6(D(Health)) = {[7..12]}
       эффект: P7(D(Resp,3B)) = {[5..10]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 6
  -> Path367 => Loc93  вер=1 порядок=5
       условия: P3(Burrow) 35..20000; P4(Weight) 25..75
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[10..15]}
       эффект: P8(D(Burrow,BB)) = {[4..9]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 7
  -> Path368 => Loc93  вер=1 порядок=5
       условия: P2(Respect) 1..15; P4(Weight) 1..15
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 8
  -> Path369 => Loc93  вер=1 порядок=5
       условия: P2(Respect) 55..100; P4(Weight) 60..20000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[4..9]}
       эффект: P7(D(Resp,3B)) = {[7..12]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path370 => Loc93  вер=3 порядок=5
       условия: P1(Health) 75..100; P4(Weight) 90..20000
       эффект: P5(Scalps) +2
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {-[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 10

### Loc93 [пустая]
    эффект: P24(Back) = {85}
  -> Path350 => Loc70  вер=1 порядок=5

### Loc94 [пустая]
    эффект: P24(Back) = {86}
  -> Path349 => Loc70  вер=1 порядок=5

### Loc95 [пустая]
  -> Path351 => Loc94  вер=2 порядок=5
       условия: P4(Weight) 60..20000
       эффект: P7(D(Resp,3B)) = {[1..3]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 1
  -> Path352 => Loc94  вер=2 порядок=5
       условия: P4(Weight) 20..50
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 2
  -> Path353 => Loc94  вер=2 порядок=5
       условия: P4(Weight) 1..30
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path354 => Loc94  вер=2 порядок=5
       условия: P4(Weight) 45..65
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 4
  -> Path355 => Loc94  вер=1 порядок=5
       условия: P2(Respect) 1..30; P4(Weight) 50..20000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 5
  -> Path356 => Loc94  вер=1 порядок=5
       условия: P2(Respect) 55..100; P4(Weight) 15..55
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 6
  -> Path357 => Loc94  вер=1 порядок=5
       условия: P3(Burrow) 40..20000; P4(Weight) 35..55
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 7
  -> Path358 => Loc94  вер=1 порядок=5
       условия: P2(Respect) 1..35; P4(Weight) 1..40
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 8
  -> Path359 => Loc94  вер=1 порядок=5
       условия: P2(Respect) 20..80; P4(Weight) 25..55
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[5..10]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path360 => Loc94  вер=3 порядок=5
       условия: P2(Respect) 40..100; P4(Weight) 55..20000
       эффект: P5(Scalps) +1
       эффект: P6(D(Health)) = {[1..3]}
       эффект: P7(D(Resp,3B)) = {-[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 10

### Loc96 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path390 => Loc99  вер=2 порядок=5
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[3..7]}
       эффект: P10(x) = 1
  -> Path397 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 2
  -> Path398 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 3
  -> Path399 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P10(x) = 4
  -> Path404 => Loc99  вер=2 порядок=5
       условия: логика {[p4]>[p16]+20}
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P10(x) = 5
  -> Path405 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P10(x) = 6
  -> Path407 => Loc99  вер=1 порядок=5
       условия: логика {[p4]<[p16]-20}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P10(x) = 7
  -> Path423 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P10(x) = 8
  -> Path426 => Loc99  вер=2 порядок=5
       условия: логика {[p4]<[p16]-20}
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path427 => Loc99  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P8(D(Burrow,BB)) = {[2..5]}
       эффект: P10(x) = 10

### Loc97 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path400 => Loc100  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P10(x) = 1
  -> Path403 => Loc100  вер=1 порядок=5
       условия: логика {[p4]>[p16]+10}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P9(D(Weight)) = {[1..3]}
       эффект: P10(x) = 2
  -> Path406 => Loc100  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]+[p16]/[10..15]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P10(x) = 3
  -> Path408 => Loc100  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P9(D(Weight)) = {[3..7]}
       эффект: P10(x) = 4
  -> Path413 => Loc100  вер=2 порядок=5
       условия: логика {[p4]<[p16]-20}
       эффект: P6(D(Health)) = {[3..7]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P10(x) = 5
  -> Path414 => Loc100  вер=2 порядок=5
       условия: логика {[p4]>[p16]+20}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[10..15]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[8..12]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 6
  -> Path415 => Loc100  вер=1 порядок=5
       условия: логика {[p4]>[p16]+10}
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]+[p4]/[8..12]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 7
  -> Path418 => Loc100  вер=1 порядок=5
       условия: логика {[p4]>[p16]+20}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[10..15]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 8
  -> Path421 => Loc100  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path422 => Loc100  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]}
       эффект: P10(x) = 10

### Loc98 [пустая]
    эффект: P6(D(Health)) = 0
    эффект: P7(D(Resp,3B)) = 0
    эффект: P8(D(Burrow,BB)) = 0
    эффект: P9(D(Weight)) = 0
  -> Path401 => Loc101  вер=1 порядок=5
       условия: логика {([p4]-[p16]) in [-10..10]}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[10..15]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[10..15]}
       эффект: P10(x) = 1
  -> Path402 => Loc101  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[3..7]+[p4]/[10..13]}
       эффект: P10(x) = 2
  -> Path409 => Loc101  вер=2 порядок=5
       условия: логика {[p16]-[p4]>10}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[3..7]+[p4]/[10..15]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 3
  -> Path410 => Loc101  вер=1 порядок=5
       эффект: P6(D(Health)) = {[2..5]}
       эффект: P7(D(Resp,3B)) = {[3..7]+[p4]/[10..15]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 4
  -> Path411 => Loc101  вер=2 порядок=5
       условия: логика {[p4]>10+[p16]}
       эффект: P6(D(Health)) = {[3..7]+[p16]/[10..15]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[10..15]}
       эффект: P10(x) = 5
  -> Path412 => Loc101  вер=2 порядок=5
       условия: логика {[p16]>10+[p4]}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[10..15]}
       эффект: P7(D(Resp,3B)) = {[3..7]+[p4]/[10..15]}
       эффект: P10(x) = 6
  -> Path416 => Loc101  вер=2 порядок=5
       условия: логика {[p16]>20+[p4]}
       эффект: P6(D(Health)) = {[2..5]+[p16]/[8..12]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[10..15]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 7
  -> Path417 => Loc101  вер=1 порядок=5
       условия: логика {[p16]>20+[p4]}
       эффект: P7(D(Resp,3B)) = {[2..5]+[p4]/[10..15]}
       эффект: P8(D(Burrow,BB)) = {[1..3]}
       эффект: P10(x) = 8
  -> Path424 => Loc101  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[1..3]+[p4]/[10..15]}
       эффект: P9(D(Weight)) = {[2..5]}
       эффект: P10(x) = 9
  -> Path425 => Loc101  вер=1 порядок=5
       эффект: P6(D(Health)) = {[3..7]}
       эффект: P7(D(Resp,3B)) = {[2..5]}
       эффект: P10(x) = 10

### Loc99 [пустая]
  -> Path420 => Loc104  вер=1 порядок=5
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p15]-100)*(([p15]-[p7])>100)+[p15]*(([p15]-[p7])<0)+[p7]*(([p15]-[p7]) in [0..100])-([p1]<=[p6])}
       эффект: P8(D(Burrow,BB)) = {([p16]-100)*(([p16]-[p8])>100)+[p16]*(([p16]-[p8])<0)+[p8]*(([p16]-[p8]) in [0..100])}
       эффект: P9(D(Weight)) = {([p4]-100)*(([p4]-[p9])>100)+[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9]) in [0..100])}

### Loc100 [пустая]
  -> Path393 => Loc102  вер=1 порядок=5
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p15]-100)*(([p15]-[p7])>100)+[p15]*(([p15]-[p7])<0)+[p7]*(([p15]-[p7]) in [0..100])-([p1]<=[p6])}
       эффект: P8(D(Burrow,BB)) = {([p16]-100)*(([p16]-[p8])>100)+[p16]*(([p16]-[p8])<0)+[p8]*(([p16]-[p8]) in [0..100])}
       эффект: P9(D(Weight)) = {([p4]-100)*(([p4]-[p9])>100)+[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9]) in [0..100])}

### Loc101 [пустая]
  -> Path419 => Loc103  вер=1 порядок=5
       эффект: P6(D(Health)) = {([p1]-100)*(([p1]-[p6])>100)+[p1]*(([p1]-[p6])<0)+[p6]*(([p1]-[p6]) in [0..100])}
       эффект: P7(D(Resp,3B)) = {([p15]-100)*(([p15]-[p7])>100)+[p15]*(([p15]-[p7])<0)+[p7]*(([p15]-[p7]) in [0..100])-([p1]<=[p6])}
       эффект: P8(D(Burrow,BB)) = {([p16]-100)*(([p16]-[p8])>100)+[p16]*(([p16]-[p8])<0)+[p8]*(([p16]-[p8]) in [0..100])}
       эффект: P9(D(Weight)) = {([p4]-100)*(([p4]-[p9])>100)+[p4]*(([p4]-[p9])<0)+[p9]*(([p4]-[p9]) in [0..100])}

### Loc102 [обычная]
    выбор описания: {[p10]}
    Loc102-1: You began smashing the Chief with your paws and he responded likewise. After a small clash you jumped away from each other. Such exchanges of blows are usually …
    Loc102-2: You are heavier than the Chief and therefore clumsier. The Chief took advantage of that, avoiding your blows and applying his. It took you a lot of effort to ca…
    Loc102-3: While you were preparing for the next blow, the Chief hit you with a stick. You felt something cracked in one of your paws. This enraged you a great deal and ma…
    Loc102-4: You placed a powerful blow into the Chief's jaw. The pachvarash chirped offensively and attacked you. He could bit you three times. A narrow thread of blood app…
    Loc102-5: It is silly to engage in a close combat with an opponent, that has a large weight advantage. With a miserable patience, the Chief let you make several blows, an…
    Loc102-6: You are much heavier than the Chief. Obviously he decided against engaging you in a close combat and preferred to avoid your blows and throw stones at you. For …
    Loc102-7: You decided to try a close combat. In this case you have an advantage, since you are heavier than the Chief. Suddenly you noticed him aiming at your side. In th…
    Loc102-8: You tried to switch to a close combat, since you're much heavier than the Chief. But he was no fool and easily dodged your blows and threw stones at you. After …
    Loc102-9: You attacked the Chief, but he was prepared and easily ducked. Your glancing blow caused only [p7]% damage to the opponent. While the Chief placed a perfect hit…
    Loc102-10: You stood on two paws and extended the third one in front of you like a ram. You ran to the opponent. He tried to defend - bend over and tripped you. You starte…
    эффект: P1(Health) = {[p1]-[p6]} «Your strength gave out. You could not continue the fight, or…»
    эффект: P4(Weight) = {[p4]-[p9]} «Look at yourself with all six eyes!!! There is nothing to se…»
    эффект: P15(Chief's health) = {[p15]-[p7]}
    эффект: P16(Chief's weight) = {[p16]-[p8]}
  -> Path377 => Loc98  вер=1 порядок=6
       текст: Throw something at the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path379 => Loc96  вер=1 порядок=5
       текст: Bite the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path381 => Loc97  вер=1 порядок=4
       текст: Hit the Chief with a paw
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path384 => Loc105  вер=1 порядок=9
       текст: Run to the burrow, until it's too late!!!
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path395 => Loc57  вер=10000
       текст: You won!
       условия: логика {[p16]=0 or [p15]=0}
       эффект: P10(x) = 2

### Loc103 [обычная]
    выбор описания: {[p10]}
    Loc103-1: You threw a stone to the Chief and he responded likewise. Since your weights are almost equal, the efficiency of this measure should be equal too.  /  / The dam…
    Loc103-2: While the Chief hesitated to attack you, you slowly buried your claw in the sand. Once you felt like you inserted it deep enough, you quickly pulled it out. Sma…
    Loc103-3: You decided to avoid a close combat as the Chief is much heavier than you are. Instead, you began throwing stones at the Chief and dodge his paws. That turned o…
    Loc103-4: You began throwing sticks and stones at the Chief. You opponent did not react at first. Suddenly he attacked you and bit you by the belly! Fortunately you had o…
    Loc103-5: You threw a stone at the Chief and he responded likewise. A real skirmish broke out! As you are heavier than the Chief, your throws cause greater damage. Howeve…
    Loc103-6: The idea to throw a stone at your opponent occurred to your and the Chief simultaneously. At once a serious skirmish began, in which both opponents tried to thr…
    Loc103-7: You successfully ducked the Chief thanks to your mobility advantage and threw stones at him. The Chief chased and finally caught you. This was bad for you - the…
    Loc103-8: You are much lighter and thus - more mobile than the Chief is. That is why you could easily duck the Chief's blows, which tried to engage in a close combat, and…
    Loc103-9: You started throwing stones at the nervous opponent, and ominously waived you paws. The Chief got scared of your pressure, slowly moved back and fell. You attac…
    Loc103-10: You took a heavy boulder from the ground. The pachvarash noticed your move and took a stone as well. For some time you hesitated to throw the stone at the Chief…
    эффект: P1(Health) = {[p1]-[p6]} «Your strength gave out. You could not continue the fight, or…»
    эффект: P4(Weight) = {[p4]-[p9]} «Look at yourself with all six eyes!!! There is nothing to se…»
    эффект: P15(Chief's health) = {[p15]-[p7]}
    эффект: P16(Chief's weight) = {[p16]-[p8]}
  -> Path374 => Loc96  вер=1 порядок=5
       текст: Bite the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path375 => Loc97  вер=1 порядок=4
       текст: Hit the Chief with a paw
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path376 => Loc98  вер=1 порядок=6
       текст: Throw something at the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path385 => Loc105  вер=1 порядок=9
       текст: Run to the burrow, until it's too late!!!
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path394 => Loc57  вер=10000
       текст: You won!
       условия: логика {[p16]=0 or [p15]=0}
       эффект: P10(x) = 2

### Loc104 [обычная]
    выбор описания: {[p10]}
    Loc104-1: The Chief was intently waiting for your blow. You bent down to the ground and crawled to your opponent. He did not expect such a move and watched you with his m…
    Loc104-2: You attacked the opponent and bit him next to his neck, what a bold move! Blood spurred from the Chief's neck. He doubled and you stood above him, ready for the…
    Loc104-3: You nit the Chief and he bit you! You tore large lumps of flesh from each other, causing strong pain.  /  / You lost [p6]% of health and [p9] hg of weight. / Th…
    Loc104-4: You attacked the Chief and bit him. He roared and began scratching you with his large dirty claws. Skin tore apart on your back and the pain was unbearable afte…
    Loc104-5: You forgot that the Chief is much lighter and more mobile than you are are. He easily ducked your stone and threw another one at you, so you lost [p6]% of healt…
    Loc104-6: You attacked the Chief and bit him. HE roared and began scratching you with his large dirty claws. Skin tore apart on your back and the pain was unbearable afte…
    Loc104-7: You attacked the Chief in order to bite him, but the Chief was prepared and hit you with his paw. You responded likewise, but that was hardly an equal response …
    Loc104-8: You managed to get close to the opponent. You jumped and bit his neck. Something cracked inside the Chief. He gasped and backed off. You decided to repeat the m…
    Loc104-9: Thanks to your smaller weight, you are much more mobile than the Chief is. You should use that! After several feints, you disoriented your opponent and put your…
    Loc104-10: You bend down and bit the Chief by the leg. He was not prepared for that move. He took a stone and began hitting you in the head. It was very painful, but you d…
    эффект: P1(Health) = {[p1]-[p6]} «Your strength gave out. You could not continue the fight, or…»
    эффект: P4(Weight) = {[p4]-[p9]} «Look at yourself with all six eyes!!! There is nothing to se…»
    эффект: P15(Chief's health) = {[p15]-[p7]}
    эффект: P16(Chief's weight) = {[p16]-[p8]}
  -> Path378 => Loc98  вер=1 порядок=6
       текст: Throw something at the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path380 => Loc96  вер=1 порядок=5
       текст: Bite the Chief
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path382 => Loc97  вер=1 порядок=4
       текст: Hit the Chief with a paw
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
  -> Path383 => Loc105  вер=1 порядок=9
       текст: Run to the burrow, until it's too late!!!
       условия: P15(Chief's health) 1..100; P16(Chief's weight) 1..75
       эффект: P7(D(Resp,3B)) = {[5..10]*([p2]<90)}
  -> Path396 => Loc57  вер=10000
       текст: You won!
       условия: логика {[p16]=0 or [p15]=0}
       эффект: P10(x) = 2

### Loc105 [обычная]
    выбор описания: {1+([p2]>=90)}
    Loc105-1: You turned away and run, accepting your defeat. A victorious roar of the pachvarashes' Chief could be heard behind. You were too weak to fight him. All <clr>you…
    Loc105-2: You turned away and run, accepting your defeat. A victorious roar of the pachvarashes' Chief could be heard behind. You were too weak to fight him. All <clr>you…
    эффект: P2(Respect) = {[p2]+[p7]}
    эффект: P24(Back) = {63}
    скрыт: P15,P16
  -> Path386 => Loc70  вер=1 порядок=5
       текст: More
       эффект: P6(D(Health)) = 0
       эффект: P7(D(Resp,3B)) = 0
       эффект: P8(D(Burrow,BB)) = 0
       эффект: P9(D(Weight)) = 0

## Анализ
- стартовых: [1]
- концовки: {60: 'УСПЕХ', 61: 'УСПЕХ', 64: 'ПРОВАЛ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
