# Квест (формат 1111111126)
Сложность 50; стартовая локация: [51]; путей по умолчанию: 1

## Параметры
- P1 'time' [0..9999] тип=обычный
    старт: [60]
    [0..9999] Enemy reinforcements will arrive in <> min.
    критическое: Сообщение достижения критического значения параметром 1
- P2 'Camouflage' [0..100] тип=обычный
    старт: [0]
    [0..100] Camouflage: <>%
    критическое: Сообщение достижения критического значения параметром 10
- P3 'Health' [0..100] тип=обычный
    старт: [100]
    [0..100] Your health: <>%
    критическое: Сообщение достижения критического значения параметром 3
- P4 'Speed' [0..4] тип=обычный
    старт: [2]
    [0..0] You've stopped in your tracks.
    [1..1] You are crawling. You have:
    [2..2] You are sneaking.
    [3..3] You are walking.
    [4..4] You are running.
    критическое: Сообщение достижения критического значения параметром 4
- P6 'Weapon' [0..99999999] тип=обычный
    старт: [0]
    [0..9999999] 
    [10000000..19999999] Metal bar
    [20000000..29999999] Maloq machete
    [30000000..39999999] Laser sword. Charge: {(<>div10000mod1000)}
    [40000000..49999999] Submachine gun. Ammo: {(<>div10000mod1000)}
    [50000000..59999999] Blaster. Charge: {(<>div10000mod1000)}
    [60000000..69999999] Shotgun. Ammo: {(<>div10000mod1000)}
    [70000000..79999999] Plasma musket. Charge: {(<>div10000mod1000)}
    [80000000..89999999] Machine gun. Ammo: {(<>div10000mod1000)}
    [90000000..99999999] Optical laser rifle. Charge: {(<>div10000mod1000)}
    критическое: Сообщение достижения критического значения параметром 6
- P8 'Item' [0..99999999] тип=обычный
    старт: [0]
    [0..9999999] 
    [10000000..19999999] х:<> pc.
    [20000000..29999999] xх:<> pc.
    [30000000..39999999] xxх:<> pc.
    [40000000..49999999] xxxх:<> pc.
    [50000000..59999999] xxxxх:<> pc.
    [60000000..69999999] Grenades: {(<>div100000mod100)} pc.
    [70000000..79999999] Remote-controlled mine
    [80000000..89999999] Mine remote control unit
    [90000000..99999999] Medical kit: {(<>div100000mod100)} doses.
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Gadgets' [0..11] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Key to the stealth ship found
    [2..10] Megavision glasses found
    [11..11] Key to the ship and Megavision glasses found
    критическое: Сообщение достижения критического значения параметром 9
- P10 '----------------' [0..3] тип=обычный
    старт: [0]
    [0..0] ---------------------
    [1..1] ENEMY TURN
    [2..2] 2
    [3..3] 3
    критическое: Сообщение достижения критического значения параметром 2
- P11 'Mercenary nametags collected' [0..100] тип=обычный
    старт: [0]
    [0..100] Mercenary nametags collected: <> pc.
    критическое: Сообщение достижения критического значения параметром 11
- P12 'Near' [0..11] тип=обычный
    старт: [0]
    [0..0] 
    [1..9] ----- Enemies in your vicinity: -----
    [10..11] ----- You're taking fire!!! -----
    критическое: Сообщение достижения критического значения параметром 12
- P13 'Fat mercenary' [0..99999999] тип=обычный
    старт: [99024000;99034000;99044000]
    [0..999999] Fat mercenary's corpse
    [1000000..39999999] The fat mercenary is heavily injured
    [40000000..59999999] The fat mercenary is wounded
    [60000000..79999999] The fat mercenary has minor wounds
    [80000000..99999999] Fat mercenary
    критическое: Сообщение достижения критического значения параметром 13
- P14 'Chunky mercenary' [0..99999999] тип=обычный
    старт: [99024000;99034000]
    [0..999999] Chunky mercenary's corpse
    [1000000..39999999] The chunky mercenary is heavily injured
    [40000000..59999999] The chunky mercenary is wounded
    [60000000..79999999] The chunky mercenary has minor wounds
    [80000000..99999999] Chunky mercenary
    критическое: Сообщение достижения критического значения параметром 14
- P15 'Mercenary in a spacesuit' [0..99999999] тип=обычный
    старт: [99074000;99084000]
    [0..999999] Dead body in a spacesuit
    [1000000..39999999] The mercenary in a spacesuit is heavily wounded
    [40000000..59999999] The mercenary in a spacesuit is wounded
    [60000000..79999999] The mercenary in a spacesuit has minor wounds
    [80000000..99999999] Mercenary in a spacesuit
    критическое: Сообщение достижения критического значения параметром 15
- P16 'Mercenary in a mask' [0..99999999] тип=обычный
    старт: [99054000;99064000;99074000]
    [0..999999] Corpse wearing a mask
    [1000000..39999999] The mercenary in a mask is heavily injured
    [40000000..59999999] The mercenary in a mask is wounded
    [60000000..79999999] The mercenary in a mask has minor wounds
    [80000000..99999999] Mercenary in a mask
    критическое: Сообщение достижения критического значения параметром 16
- P17 'Mercenary in a hat' [0..99999999] тип=обычный
    старт: [99054000;99064000;99044000]
    [0..999999] Corpse wearing a hat
    [1000000..39999999] The mercenary in a hat is heavily injured
    [40000000..59999999] The mercenary in a hat is wounded
    [60000000..79999999] The mercenary in a hat has minor wounds
    [80000000..99999999] Mercenary in a hat
    критическое: Сообщение достижения критического значения параметром 17
- P18 'Mercenary in a helmet' [0..99999999] тип=обычный
    старт: [99054000;99064000;99044000;99034000]
    [0..999999] Corpse in a helmet
    [1000000..39999999] The mercenary in a helmet is heavily injured
    [40000000..59999999] The mercenary in a helmet is wounded
    [60000000..79999999] The mercenary in a helmet has minor wounds
    [80000000..99999999] Mercenary in a helmet
    критическое: Сообщение достижения критического значения параметром 18
- P19 'One-eyed mercenary' [0..99999999] тип=обычный
    старт: [99054000;99064000;99044000;99034000]
    [0..999999] One-eyed corpse
    [1000000..39999999] The one-eyed mercenary is heavily injured
    [40000000..59999999] The one-eyed mercenary is wounded
    [60000000..79999999] The one-eyed mercenary has minor wounds
    [80000000..99999999] One-eyed mercenary
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Tall mercenary' [0..99999999] тип=обычный
    старт: [0]
    [0..999999] Tall mercenary’s body
    [1000000..39999999] The tall mercenary is heavily injured
    [40000000..59999999] The tall mercenary is wounded
    [60000000..79999999] The tall mercenary has minor wounds
    [80000000..99999999] Tall mercenary
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Wiry mercenary' [0..99999999] тип=обычный
    старт: [0]
    [0..999999] Wiry mercenary’s body
    [1000000..39999999] The wiry mercenary is heavily injured
    [40000000..59999999] The wiry mercenary is wounded
    [60000000..79999999] The wiry mercenary has minor wounds
    [80000000..99999999] Wiry mercenary
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Mercenary in glasses' [0..99999999] тип=обычный
    старт: [99074000;99084000]
    [0..999999] Body of the mercenary in glasses
    [1000000..39999999] The mercenary in glasses is heavily injured
    [40000000..59999999] The mercenary in glasses is wounded
    [60000000..79999999] The mercenary in glasses has minor wounds
    [80000000..99999999] Mercenary in cool glasses
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Mercenary with a cigar' [0..99999999] тип=обычный
    старт: [0]
    [0..999999] Body of the mercenary with a cigar
    [1000000..39999999] The mercenary with a cigar is heavily injured
    [40000000..59999999] The mercenary with a cigar is wounded
    [60000000..79999999] The mercenary with a cigar has minor wounds
    [80000000..99999999] Mercenary with a cigar
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Mercenary in coveralls' [0..99999999] тип=обычный
    старт: [0]
    [0..999999] Corpse in coveralls
    [1000000..39999999] The mercenary in coveralls is heavily injured
    [40000000..59999999] The mercenary in coveralls is wounded
    [60000000..79999999] The mercenary in coveralls has minor wounds
    [80000000..99999999] Mercenary in coveralls
    критическое: Сообщение достижения критического значения параметром 24
- P34 'Money' [0..999999999] тип=обычный деньги
    старт: [0]
    [0..999999999] Money: <>
    критическое: Сообщение достижения критического значения параметром 34
- P35 'Gate support' [0..100] тип=обычный
    старт: [0]
    [0..100] gate support: <>%
    критическое: Сообщение достижения критического значения параметром 35
- P36 'future exits' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] future exits: <>
    критическое: Сообщение достижения критического значения параметром 36
- P38 "Who's there?\r\nwho's there?" [0..11] тип=обычный
    старт: [0]
    [0..0] 
    [1..9] Someone is far off to the west
    [10..10] Someone is far off to the east
    [11..11] Someone is far off to the west and the east
    критическое: Сообщение достижения критического значения параметром 38
- P39 'No' [0..100] тип=обычный
    старт: [0]
    [0..49] N: <> 0%
    [50..100] N: = <>0%
    критическое: Сообщение достижения критического значения параметром 39
- P40 'time delta' [0..99] тип=обычный
    старт: [0]
    [0..99] time delta: <>
    критическое: Сообщение достижения критического значения параметром 40
- P41 'noisy location' [0..99] тип=обычный
    старт: [0]
    [0..99] noisy location <>
    критическое: Сообщение достижения критического значения параметром 41
- P42 '' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] <>
    критическое: Сообщение достижения критического значения параметром 42
- P43 'total damage' [0..99999] тип=обычный
    старт: [0]
    [0..99999] total damage: {(<>div1000)} of {(<>mod100)} mercenaries
    критическое: Сообщение достижения критического значения параметром 43
- P44 'adjacent to mine' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] adjacent to mine <>
    критическое: Сообщение достижения критического значения параметром 44
- P45 'current retreats' [0..99999999] тип=обычный
    старт: [0]
    [0..99999999] current retreats: <>
    критическое: Сообщение достижения критического значения параметром 45
- P46 'alternating mercenary' [0..999999999] тип=обычный
    старт: [0]
    [0..999999999] alternating mercenary: <>
    критическое: Сообщение достижения критического значения параметром 46
- P47 'your current location' [0..999] тип=обычный
    старт: [0]
    [0..999] your current location: <>
    критическое: Сообщение достижения критического значения параметром 47
- P48 'destination location of the character' [0..999] тип=обычный
    старт: [0]
    [0..999] destination location of the character: <>
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc1-1: You are at <clr>the beginning of a path<clrEnd>. The trees are peacefully rustling, and the local birds' singing tells you that none of the mercenaries are arou…
    Loc1-2: You are at <clr>the beginning of a path<clrEnd>. <clr>You can hear footsteps through the rustling trees. A forest lies further to the east.
    Loc1-3: You are at <clr>the beginning of a path. The foliage cannot conceal you from the eagle eye of the enemy any longer - his <clr>fire is aimed right at you<clrEnd>…
    эффект: P45(current retreats) = {9902}
  -> Path12 => Loc10  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {103}
       эффект: P48(destination location of the character) = {2}
  -> Path127 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path208 => Loc14  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path407 => Loc71  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path410 => Loc71  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path413 => Loc71  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path416 => Loc71  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path424 => Loc11  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}
  -> Path425 => Loc11  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path426 => Loc11  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path427 => Loc11  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path428 => Loc11  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path429 => Loc11  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}

### Loc2 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc2-1: A typical <clr>forest on planet<clrEnd> <ToPlanet> is capable of concealing many secret bases under its dense foliage. However, you are certain that if you keep…
    Loc2-2: <clr>The forest<clrEnd> is home to a multitude of animals, but right now <clr>you can hear the footsteps<clrEnd> of a two-legged creature. It's a mercenary. He …
    Loc2-3: You can’t manage to hide, even <clr>in the forest<clrEnd>. <clr>You're taking fire!<clrEnd>
    эффект: P45(current retreats) = {103}
  -> Path2 => Loc10  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {204}
       эффект: P48(destination location of the character) = {3}
  -> Path3 => Loc10  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {2}
       эффект: P48(destination location of the character) = {1}
  -> Path7 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path8 => Loc14  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path406 => Loc71  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path408 => Loc71  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path411 => Loc71  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path415 => Loc71  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path430 => Loc11  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path431 => Loc11  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path432 => Loc11  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path433 => Loc11  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path434 => Loc11  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path435 => Loc11  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc3 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc3-1: You move through some <clr>fallen trees<clrEnd>. The light forest remains behind in the west. The edge of the forest lies to the east. It’s hard to keep moving.…
    Loc3-2: Even <clr>among the fallen trees you are not alone<clrEnd> - someone else is picking his way through with a weapon at the ready. You have to be careful in order…
    Loc3-3: It’s not easy to stand and fight <clr>among the deadfall<clrEnd>, but the enemy isn’t going to give up<clrEnd>: his shots are getting closer and more dangerous.
    эффект: P45(current retreats) = {204}
  -> Path10 => Loc10  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {103}
       эффект: P48(destination location of the character) = {2}
  -> Path15 => Loc10  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {305}
       эффект: P48(destination location of the character) = {4}
  -> Path128 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path209 => Loc14  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path405 => Loc71  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path409 => Loc71  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path412 => Loc71  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path414 => Loc71  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path436 => Loc11  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path437 => Loc11  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path438 => Loc11  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path439 => Loc11  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path440 => Loc11  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path441 => Loc11  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc4 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc4-1: The birds of the alien planet twitter cheerfully, as if nothing was threatening the peaceful surroundings. You could have a rest <clr>at the edge of the forest<…
    Loc4-2: <clr>The enemy got through to the edge of the forest<clrEnd>. You've got to do something about it.
    Loc4-3: <clr>The edge of the forest<clrEnd> is quite exposed, and the mercenary won’t let you get away. <clr>You're taking fire<clrEnd> - you have to do something!
    эффект: P45(current retreats) = {305}
  -> Path14 => Loc16  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {204}
       эффект: P48(destination location of the character) = {3}
  -> Path17 => Loc16  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {406}
       эффект: P48(destination location of the character) = {5}
  -> Path132 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path181 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path216 => Loc14  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path382 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path383 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path384 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path442 => Loc11  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path443 => Loc11  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path444 => Loc11  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path445 => Loc11  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path446 => Loc11  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path447 => Loc11  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc5 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc5-1: Sprawling <clr>bushes<clrEnd> with colorful berries grow all around the place. You know that, in moderation, <clr>this kind of halluberry is useful<clrEnd> for …
    Loc5-2: <clr>A mercenary is wandering among the halluberry bushes<clrEnd>. He may not be alone. He hasn’t spotted you yet, but how long will that last?
    Loc5-3: <clr>You dodge the mercenary's fire and try to take cover <clr>behind the halluberry bushes<clrEnd>, but the enemy isn't going to lose sight of you.
    эффект: P45(current retreats) = {406}
  -> Path13 => Loc16  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {305}
       эффект: P48(destination location of the character) = {4}
  -> Path133 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path135 => Loc16  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {507}
       эффект: P48(destination location of the character) = {6}
  -> Path217 => Loc113  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path385 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path386 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path387 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path388 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path448 => Loc81  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path449 => Loc81  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path450 => Loc81  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path451 => Loc81  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path452 => Loc81  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path453 => Loc81  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc6 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc6-1: The overgrown <clr>hill<clrEnd> is good cover for you. It lets you make your way farther without being detected. You ascend the hill. From the top, you can see …
    Loc6-2: <clr>Someone else is wandering among the bushes on the hill<clrEnd>. You have to be careful to avoid exposing yourself to enemy fire.
    Loc6-3: It’s too late to hide <clr>behind the vegetation on the hill<clrEnd>. <clr>The enemy has spotted you<clrEnd>. He won’t stop firing until he's killed you!
    эффект: P45(current retreats) = {507}
  -> Path136 => Loc16  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {608}
       эффект: P48(destination location of the character) = {7}
  -> Path137 => Loc16  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {406}
       эффект: P48(destination location of the character) = {5}
  -> Path144 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path219 => Loc113  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path389 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path393 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path397 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path401 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path454 => Loc81  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path455 => Loc81  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path456 => Loc81  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path457 => Loc81  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path458 => Loc81  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path459 => Loc81  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc7 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc7-1: The trees are slanted slightly on the overgrown <clr>slopes of the ravine<clrEnd>. You are making your way through the bushes. You try to avoid exposed location…
    Loc7-2: <clr>An enemy is moving along the edge of the ravine.<clrEnd> Crouching in the rich vegetation, you've managed to remain unseen so far.
    Loc7-3: <clr>You find yourself under fire<clrEnd>, despite all your efforts to take cover behind the trees <clr>on the edge of the ravine<clrEnd>.
    эффект: P45(current retreats) = {608}
  -> Path138 => Loc17  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {709}
       эффект: P48(destination location of the character) = {8}
  -> Path139 => Loc17  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {507}
       эффект: P48(destination location of the character) = {6}
  -> Path145 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path220 => Loc113  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path390 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path394 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path398 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path402 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path460 => Loc81  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path461 => Loc81  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path462 => Loc81  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path463 => Loc81  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path464 => Loc81  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path465 => Loc81  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc8 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc8-1: The perimeter of the base is enclosed by a mossy <clr>fence<clrEnd>. You could climb over in some places on the branches of the leaning trees. This strange negl…
    Loc8-2: <clr>An armed mercenary is walking along the fence<clrEnd>. You are concealed by the nearby bushes, but you'll have to watch out for other mercenaries.
    Loc8-3: <clr>The guards' shots are hitting both you and the base's old metal <clr>fence<clrEnd>. You can’t hide any longer - you have to stand and fight!
    эффект: P45(current retreats) = {709}
  -> Path140 => Loc17  вер=1
       текст: Head to the east
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {800}
       эффект: P48(destination location of the character) = {9}
  -> Path141 => Loc17  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {608}
       эффект: P48(destination location of the character) = {7}
  -> Path146 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path221 => Loc113  вер=1 порядок=7
       текст: Search for weapons and other items
  -> Path391 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path395 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path399 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path403 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path466 => Loc81  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path467 => Loc81  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path468 => Loc81  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path469 => Loc81  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path470 => Loc81  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path471 => Loc81  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc9 [обычная]
    выбор описания: {1+([p12]=1)+2*([p12]>1)}
    Loc9-1: You are <clr>in a small secret peleng base<clrEnd>. The watchtowers are unmanned. You can easily make your way to the <clr>hangar<clrEnd>.
    Loc9-2: You found somewhere to take cover even <clr>within the base<clrEnd>, and now you are observing <clr>someone loitering around at the entrance to the hangar<clrEn…
    Loc9-3: Hiding behind the crates <clr> in the secret base<clrEnd> didn't work, and now <clr>the guards are shooting at you<clrEnd>! As long as even one mercenary remain…
    эффект: P45(current retreats) = {899}
  -> Path142 => Loc17  вер=1 порядок=1
       текст: Head to the west
       условия: логика {[p4]>0}
       эффект: P36(future exits) = {709}
       эффект: P48(destination location of the character) = {8}
  -> Path143 => Loc50  вер=1 [всегда видна] порядок=6
       текст: Into the hangar
       условия: логика {[p4]>0 and [p12]=0}
  -> Path147 => Loc13  вер=1 порядок=6
       текст: Change your speed
  -> Path222 => Loc113  вер=1 порядок=7
       текст: Search for weapons and other items
       условия: логика {[p4]>0}
  -> Path392 => Loc93  вер=1 порядок=5
       текст: Use the medical kit
       условия: логика {[p8] div 10000000=9}
  -> Path396 => Loc93  вер=1 порядок=5
       текст: Use the mine's remote control unit
       условия: логика {[p8] div 10000000=8}
  -> Path400 => Loc93  вер=1 порядок=5
       текст: Plant the mine
       условия: логика {[p8] div 10000000=7}
  -> Path404 => Loc93  вер=1 порядок=5
       текст: Throw a grenade
       условия: логика {[p8] div 10000000=6}
  -> Path421 => Loc81  вер=1 порядок=4
       текст: Strike with the sword
       условия: логика {[p6] in [20000000..39999999]}
  -> Path473 => Loc81  вер=1 порядок=4
       текст: Shoot (low accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=4)}
  -> Path474 => Loc81  вер=1 порядок=4
       текст: Punch
       условия: логика {[p6]<10000000}
  -> Path475 => Loc81  вер=1 порядок=4
       текст: Hit with the bar
       условия: логика {[p6] in [10000000..19999999]}
  -> Path476 => Loc81  вер=1 порядок=4
       текст: Shoot (medium accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=3)}
  -> Path477 => Loc81  вер=1 порядок=4
       текст: Shoot (high accuracy)
       условия: логика {([p6] in [40000000..99999999]) and ([p4]=2)}

### Loc10 [пустая]
    эффект: P40(time delta) = {11-[p4]*2}
  -> Path19 => Loc15  вер=1 порядок=5

### Loc11 [пустая]
    эффект: P40(time delta) = {2}
    эффект: P48(destination location of the character) = {[p47]}
  -> Path110 => Loc91  вер=1 порядок=5

### Loc13 [пустая]
  -> Path375 => Loc154  вер=1 порядок=5
       условия: P6(Weapon) 40000000..99999999
  -> Path376 => Loc155  вер=1 порядок=5
       условия: P6(Weapon) 0..39999999

### Loc14 [пустая]
    эффект: P40(time delta) = {5}
    эффект: P48(destination location of the character) = {[p47]}
  -> Path210 => Loc102  вер=1 порядок=5

### Loc15 [пустая]
    эффект: P12(Near) = {0}
    эффект: P37(кто-здесь? сю) = {0}
    эффект: P38(Who's there?
who's there?) = {0}
    эффект: P39(No) = {12}
    эффект: P43(total damage) = 0
  -> Path22 => Loc82  вер=1 порядок=5
  -> Path331 => Loc146  вер=1000 проходов<=1 порядок=5
       условия: логика {[p1]=0}

### Loc16 [пустая]
  -> Path18 => Loc10  вер=1 порядок=5

### Loc17 [пустая]
  -> Path134 => Loc16  вер=1 порядок=5

### Loc18 [пустая]
  -> Path357 => Loc68  вер=111 порядок=5
       условия: логика {[p24] div 10000 mod 100=[p47]}
       показ: P24
  -> Path358 => Loc68  вер=1 порядок=5
       скрыт: P24

### Loc19 [пустая]
  -> Path23 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=1}
       эффект: P46(alternating mercenary) = {[p13]}
  -> Path24 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=2}
       эффект: P46(alternating mercenary) = {[p14]}
  -> Path25 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=3}
       эффект: P46(alternating mercenary) = {[p15]}
  -> Path26 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=4}
       эффект: P46(alternating mercenary) = {[p16]}
  -> Path27 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=5}
       эффект: P46(alternating mercenary) = {[p17]}
  -> Path153 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=6}
       эффект: P46(alternating mercenary) = {[p18]}
  -> Path155 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=7}
       эффект: P46(alternating mercenary) = {[p19]}
  -> Path157 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=8}
       эффект: P46(alternating mercenary) = {[p20]}
  -> Path231 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=9}
       эффект: P46(alternating mercenary) = {[p21]}
  -> Path232 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=10}
       эффект: P46(alternating mercenary) = {[p22]}
  -> Path233 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=11}
       эффект: P46(alternating mercenary) = {[p23]}
  -> Path234 => Loc21  вер=1 порядок=5
       условия: логика {[p39]=12}
       эффект: P46(alternating mercenary) = {[p24]}

### Loc20 [пустая]
    эффект: P3(Health) = {[p3]-[p43]}
  -> Path93 => Loc66  вер=1 порядок=5
       условия: логика {[p3]<1}
  -> Path94 => Loc67  вер=1 порядок=5
       условия: P39(No) 1..10; логика {[p3]>0 and [p43]>0}
  -> Path95 => Loc156  вер=1 порядок=5
       условия: логика {[p43]<1}
  -> Path378 => Loc158  вер=1 порядок=5
       условия: P39(No) 11..20; логика {[p3]>0 and [p43]>0}

### Loc21 [пустая]
  -> Path28 => Loc77  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)>2}
  -> Path29 => Loc39  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)<=2}

### Loc22 [пустая]
  -> Path41 => Loc153  вер=1000 порядок=5
       условия: логика {([p46] div 1000000)<10 and ([p46] div 1000000)>0 and ([p46] div 10000 mod 100<>9)}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+([p46] mod 1000)*1000+3000}
  -> Path42 => Loc31  вер=1 порядок=5
       условия: логика {([p46] div 1000000)>0}
  -> Path173 => Loc90  вер=1 порядок=5
       условия: P39(No) 1..10; логика {([p46] div 1000000)<=0}
  -> Path363 => Loc149  вер=1 порядок=5
       условия: P39(No) 11..20; логика {([p46] div 1000000)<=0}

### Loc23 [пустая]
  -> Path55 => Loc87  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=4}
  -> Path56 => Loc34  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=3}
  -> Path57 => Loc87  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=5}
       эффект: P46(alternating mercenary) = {([p46] div 1000000*1000000)+[p41]*10000+4000}
  -> Path58 => Loc74  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=6}
  -> Path175 => Loc87  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=2}

### Loc26 [пустая]
  -> Path30 => Loc23  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=6}
  -> Path31 => Loc27  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)<>6}

### Loc27 [пустая]
  -> Path48 => Loc32  вер=1000 порядок=5
       условия: логика {[p41]>0}
  -> Path81 => Loc23  вер=1 порядок=5
       условия: логика {[p41]=0}

### Loc28 [пустая]
    эффект: P46(alternating mercenary) = {([p46] div 10000*10000)+6000}
  -> Path45 => Loc23  вер=1 порядок=5

### Loc31 [пустая]
  -> Path43 => Loc28  вер=1000 порядок=5
       условия: логика {[p47]=([p46] div 10000 mod 100) and [p2]<(41+20*([p41]=[p47]))}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+([p46] mod 1000)*1000+6000}
  -> Path44 => Loc26  вер=1 порядок=5

### Loc32 [пустая]
  -> Path49 => Loc78  вер=1000 порядок=5
       условия: логика {([p46] div 10000 mod 100)=([p42] div 1000000)}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+5000+[p41]*10+3}
  -> Path50 => Loc78  вер=1000 порядок=5
       условия: логика {([p46] div 10000 mod 100)=([p42] div 10000 mod 100)}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+5000+[p41]*10+3}
  -> Path51 => Loc78  вер=1000 порядок=5
       условия: логика {([p46] div 10000 mod 100)=([p42] div 100 mod 100)}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+5000+[p41]*10+3}
  -> Path52 => Loc78  вер=1000 порядок=5
       условия: логика {([p46] div 10000 mod 100)=([p42] mod 100)}
       эффект: P46(alternating mercenary) = {([p46] div 10000)*10000+5000+[p41]*10+3}
  -> Path53 => Loc23  вер=1 порядок=5

### Loc34 [пустая]
  -> Path123 => Loc87  вер=1 порядок=5
       условия: логика {([p46] div 10000 mod 100)<>9}
       эффект: P46(alternating mercenary) = {([p46] div 1000000*1000000)+(([p46] div 10000 mod 100)+1)*10000+3000}
  -> Path124 => Loc87  вер=1 порядок=5
       условия: логика {([p46] div 10000 mod 100)=9}
       эффект: P46(alternating mercenary) = {[60..80]*1000000+94000}

### Loc39 [пустая]
    эффект: P39(No) = {[p39]-1}
  -> Path91 => Loc82  вер=1 порядок=5

### Loc41 [пустая]
  -> Path337 => Loc42  вер=111 порядок=5
       условия: логика {[p14] div 10000 mod 100=[p47]}
       показ: P14
  -> Path338 => Loc42  вер=1 порядок=5
       скрыт: P14

### Loc42 [пустая]
  -> Path339 => Loc43  вер=111 порядок=5
       условия: логика {[p15] div 10000 mod 100=[p47]}
       показ: P15
  -> Path340 => Loc43  вер=1 порядок=5
       скрыт: P15

### Loc43 [пустая]
  -> Path341 => Loc44  вер=111 порядок=5
       условия: логика {[p16] div 10000 mod 100=[p47]}
       показ: P16
  -> Path342 => Loc44  вер=1 порядок=5
       скрыт: P16

### Loc44 [пустая]
  -> Path343 => Loc45  вер=111 порядок=5
       условия: логика {[p17] div 10000 mod 100=[p47]}
       показ: P17
  -> Path344 => Loc45  вер=1 порядок=5
       скрыт: P17

### Loc45 [пустая]
  -> Path345 => Loc46  вер=111 порядок=5
       условия: логика {[p18] div 10000 mod 100=[p47]}
       показ: P18
  -> Path346 => Loc46  вер=1 порядок=5
       скрыт: P18

### Loc46 [пустая]
  -> Path347 => Loc47  вер=111 порядок=5
       условия: логика {[p19] div 10000 mod 100=[p47]}
       показ: P19
  -> Path348 => Loc47  вер=1 порядок=5
       скрыт: P19

### Loc47 [пустая]
  -> Path349 => Loc48  вер=111 порядок=5
       условия: логика {[p20] div 10000 mod 100=[p47]}
       показ: P20
  -> Path350 => Loc48  вер=1 порядок=5
       скрыт: P20

### Loc48 [пустая]
  -> Path351 => Loc49  вер=111 порядок=5
       условия: логика {[p21] div 10000 mod 100=[p47]}
       показ: P21
  -> Path352 => Loc49  вер=1 порядок=5
       скрыт: P21

### Loc49 [пустая]
  -> Path353 => Loc69  вер=111 порядок=5
       условия: логика {[p22] div 10000 mod 100=[p47]}
       показ: P22
  -> Path354 => Loc69  вер=1 порядок=5
       скрыт: P22

### Loc50 [пустая]
  -> Path277 => Loc124  вер=1111 проходов<=1 порядок=5
  -> Path298 => Loc129  вер=1 порядок=5

### Loc51 [СТАРТ]
    Loc51-1: A couple of hours later you found yourself bouncing in the backseat of an armored vehicle. You were somewhat alarmed by the fact that there were only two comman…
    Loc51-2: The commandos started to squabble again. / "You say 'accuracy'. But you're only accurate when you're sneaking. How about when you're walking or running? When yo…
    Loc51-3: 2006 © Ruslan Cherniy / "Stealth" Quest
    скрыт: P1,P2,P4,P5,P6,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P39
  -> Path59 => Loc52  вер=1 порядок=9
       текст: Sleep
       ответ: You stretched yourself out onto the backseat and quickly slipped into slumber; the stress of recent days was apparent. You had a dream. In your dream, you lay o…
  -> Path60 => Loc52  вер=1 порядок=2
       текст: Ask the maloq to give you a weapon
       ответ: "Come on, relax! We'll deliver you straight to the hangar gate. And we'll shoot all the six-paws that turn up along the way. We're almost there. / "But you're a…
       эффект: P6(Weapon) = {21110000} [показ]
       показ: P5
  -> Path61 => Loc100  вер=1 проходов<=1
       текст: Ask about the base
  -> Path62 => Loc55  вер=1 порядок=5
       текст: Support the maloq in the argument
  -> Path64 => Loc57  вер=1 порядок=6
       текст: Support the faeyan in the argument
  -> Path65 => Loc52  вер=1 порядок=3
       текст: Ask the faeyan to give you a weapon
       ответ: "Hey, sir. Would you let me borrow your sniper rifle during the operation?" / "No." / "Why not?" / "What a caveman!" said the driver, turning to the maloq. "How…
       эффект: P6(Weapon) = {30420000} [показ]
       показ: P5

### Loc52 [обычная]
    Loc52-1: A few loud pops stopped the car on the path - bullets had ripped through the front tires. The armored offroad vehicle started to pitch to the side as you heard …
    эффект: P3(Health) = {[p3]-4}
    эффект: P39(No) = {0}
    показ: P5,P6
  -> Path69 => Loc61  вер=1
       текст: Get the maloq out
       ответ: The enormous, crimson-faced maloq went limp. But he still had a death grip on the machine gun with his big hands. That made it much more difficult to drag the b…
       эффект: P6(Weapon) = {86000000}
  -> Path70 => Loc61  вер=1 порядок=1
       текст: Get the faeyan out
       ответ: The lifeless faeyan wasn't too heavy, but the <clr>sniper rifle<clrEnd> on his back made it quite difficult to carry him. You took it off him, and put it on you…
       эффект: P6(Weapon) = {90060000}
  -> Path71 => Loc53  вер=1 порядок=3
       текст: Take the box with the military marking on the lid
  -> Path72 => Loc61  вер=1 порядок=5
       текст: Get out all by yourself as quickly as possible
       ответ: That was pretty easy. You kicked the door out, ran from the armored car, which was in flames, and dove to the ground. An instant later a huge blast ripped the v…

### Loc53 [обычная]
    Loc53-1: You push the box out of the trunk and jumped out behind it. You crouched down, so your enemies wouldn't spot you... Then there was an explosion! Fragments of me…
  -> Path73 => Loc61  вер=1 порядок=5
       текст: Pick up 3 antipersonnel grenades
       эффект: P8(Item) = {60300000}
  -> Path74 => Loc61  вер=1 порядок=6
       текст: Pick up the remote-controlled mine
       эффект: P8(Item) = {70100000}
  -> Path75 => Loc61  вер=1 порядок=7
       текст: Pick up the medical kit
       эффект: P8(Item) = {90500000}

### Loc55 [обычная]
    Loc55-1: You clear your throat and blurted out, / "Only energy firecrackers are just for sissies! They're only good for burning cockroaches! An old-fashioned firearm, th…
  -> Path63 => Loc52  вер=1 порядок=5
       текст: Ask the maloq to give you a weapon
       ответ: "Hey, pal. Would you lend me a gun? I just want to make a few holes in these froggers." / "A comedian like you deserves a proper shotgun," said the maloq. He th…
       эффект: P3(Health) = {98}
       эффект: P6(Weapon) = {60120000} [показ]
       показ: P5
  -> Path67 => Loc52  вер=1 порядок=3
       текст: Ask the faeyan to give you a weapon
       ответ: In reply to your question, the driver only sniffed in contempt. Then he leaned slightly forward to the lookout window: / "What the...?!"

### Loc57 [обычная]
    Loc57-1: "The art of being a true warrior is staying invisible for the enemy and methodically cutting down its forces with an elegant energy weapon..." Two bickering com…
  -> Path66 => Loc52  вер=1 порядок=3
       текст: Ask the faeyan to give you a weapon
       ответ: "My hermaphrodite friend, can I demonstrate my great skill with weapons to you?" / "I don't see why not. This ought to do..." said the faeyan, extracting a plas…
       эффект: P6(Weapon) = {72800000} [показ]
       показ: P5
  -> Path68 => Loc52  вер=1 порядок=5
       текст: Ask the maloq to give you a weapon
       ответ: "Keep quiet, so I don't smash your head in!" snarled the maloq. He turned back to the lookout window. His eyes caught sight of an object as it flew by. He sudde…

### Loc59 [ПРОВАЛ]
    Loc59-1: It took nearly a day to get back. You were bleeding from the scratches you received from the thorns in the bushes on planet <ToPlanet>. Starving and infuriated …

### Loc61 [обычная]
    выбор описания: {[p39]+1}
    Loc61-1: You crouched down in the bushes not far from the remains of your armored car.
    Loc61-2: Your mission remains the same: you must steal the stealth ship from the hangar east of here. Your military escorts are dead, so you'll have to make your way the…
    эффект: P1(time) = {} [показ]
  -> Path76 => Loc59  вер=1 порядок=5
       текст: Abandon the mission
  -> Path77 => Loc79  вер=1
       текст: Come out of the bushes and onto the path
       эффект: P1(time) = {[p1]-1}
       эффект: P47(your current location) = {1}
       эффект: P48(destination location of the character) = {1}
  -> Path78 => Loc63  вер=1 порядок=3
       текст: Think things over
       эффект: P39(No) = {1}
  -> Path160 => Loc84  вер=1 проходов<=1 порядок=5
       текст: Search the remains of the armored car

### Loc63 [пустая]
    эффект: P1(time) = {[p1]-1}
  -> Path79 => Loc61  вер=1 порядок=5

### Loc66 [СМЕРТЬ]
    выбор описания: {[p4]+1}
    Loc66-1: Sitting it out didn't work - a few shots from a mercenary terminated your life. Planet <ToPlanet> became your final resting place.
    Loc66-2: The mercenary's shots were fatal. Gathering all your strength, you tried to get up, but fell back down... Never to rise again.
    Loc66-3: You dropped down dead under enemy fire.
    Loc66-4: A mercenary put an end to your career with an unerring shot.
    Loc66-5: A fatal burst from a mercenary's gun sent you running. Stabs of pain ripped through your innards; your legs fail, and you fall to the ground. The shooting cease…
    скрыт: P1,P2,P3,P4,P5,P6,P8,P11

### Loc67 [обычная]
    выбор описания: {[p39]}
    Loc67-1: A fat peleng shoots you, and you lose {[p43]}% of your health.
    Loc67-2: Your body has sustained new wounds! A chunky peleng decreases your health by {[p43]}%.
    Loc67-3: A mercenary in a spacesuit takes aim and inflicts {[p43]}% damage on you!
    Loc67-4: A masked mercenary took advantage of your hesitation and deprived you of {[p43]}% of your health.
    Loc67-5: A mercenary in a hat hit your leg ({[p43]}% damage) and tried to hide in the nearby bushes.
    Loc67-6: Your body has been burned: the new damage is {[p43]}% of your health. A ranger in a helmet has reloaded his weapon and is ready to carry on the combat.
    Loc67-7: The unerring shot of the one-eyed mercenary decreased your health by {[p43]}%.
    Loc67-8: The tall mercenary can handle weapons pretty well. He took {[p43]}% of your health away from you!
    Loc67-9: The wiry bastard has gotten too close to you. His shots have cut your life short by {[p43]}%.
    Loc67-10: The ranger in glasses is trying to maintain his distance. However, he's still managed to do {[p43]}% damage to you.
  -> Path96 => Loc156  вер=1 порядок=5

### Loc68 [пустая]
    эффект: P2(Camouflage) = {(2-[p4])*10+50}
    эффект: P40(time delta) = {0}
    эффект: P47(your current location) = {[p48]}
    эффект: P48(destination location of the character) = {0}
  -> Path97 => Loc83  вер=1 порядок=5

### Loc69 [пустая]
  -> Path355 => Loc18  вер=111 порядок=5
       условия: логика {[p23] div 10000 mod 100=[p47]}
       показ: P23
  -> Path356 => Loc18  вер=1 порядок=5
       скрыт: P23

### Loc70 [пустая]
    эффект: P2(Camouflage) = {(2-[p4])*10+50}
  -> Path109 => Loc83  вер=1 порядок=5

### Loc71 [пустая]
    эффект: P40(time delta) = {2}
    эффект: P48(destination location of the character) = {[p47]}
  -> Path189 => Loc95  вер=1 порядок=5

### Loc72 [обычная]
    выбор описания: {[p6] div 10000000+1}
    Loc72-1: Choose someone to punch.
    Loc72-2: Choose someone to hit with a metal bar.
    Loc72-3: Choose someone to stab with the machete.
    Loc72-4: Choose someone to hit with the sword.
    Loc72-5: Choose where to shoot.
    Loc72-6: Choose where to shoot.
    Loc72-7: Choose where to shoot.
    Loc72-8: Choose where to shoot.
    Loc72-9: Choose where to shoot.
    Loc72-10: Choose where to shoot.
  -> Path111 => Loc73  вер=1 порядок=1
       текст: At the fat mercenary
       ответ: The fat peleng takes {[p43]}% damage.
       условия: логика {[p47]=([p13] div 10000 mod 100) and [p13] div 1000 mod 10>2}
       эффект: P13(Fat mercenary) = {((([p13] div 1000000)-[p43]) in [0..99])*(([p13] div 1000000)-[p43])*1000000+([p13] mod 1000000)}
  -> Path113 => Loc73  вер=1 порядок=8
       текст: At the chunky mercenary
       ответ: The chunky bastard received {[p43]}% damage from you.
       условия: логика {[p47]=([p14] div 10000 mod 100) and [p14] div 1000 mod 10>2}
       эффект: P14(Chunky mercenary) = {((([p14] div 1000000)-[p43]) in [0..99])*(([p14] div 1000000)-[p43])*1000000+([p14] mod 1000000)}
  -> Path114 => Loc73  вер=1 порядок=1
       текст: At the mercenary in a spacesuit
       ответ: Great shot! The six-paw in a spacesuit lost {[p43]}% of his health.
       условия: логика {[p47]=([p15] div 10000 mod 100) and [p15] div 1000 mod 10>2}
       эффект: P15(Mercenary in a spacesuit) = {((([p15] div 1000000)-[p43]) in [0..99])*(([p15] div 1000000)-[p43])*1000000+([p15] mod 1000000)}
  -> Path115 => Loc73  вер=1 порядок=3
       текст: At the mercenary in a mask
       ответ: You hit the peleng’s chest and inflicted {[p43]}% damage.
       условия: логика {[p47]=([p16] div 10000 mod 100) and [p16] div 1000 mod 10>2}
       эффект: P16(Mercenary in a mask) = {((([p16] div 1000000)-[p43]) in [0..99])*(([p16] div 1000000)-[p43])*1000000+([p16] mod 1000000)}
  -> Path116 => Loc73  вер=1 порядок=6
       текст: At the mercenary in a hat
       ответ: You boldly inflicted {[p43]}% damage to the mercenary in a hat. You showed him what you are made of!
       условия: логика {[p47]=([p17] div 10000 mod 100) and [p17] div 1000 mod 10>2}
       эффект: P17(Mercenary in a hat) = {((([p17] div 1000000)-[p43]) in [0..99])*(([p17] div 1000000)-[p43])*1000000+([p17] mod 1000000)}
  -> Path170 => Loc73  вер=1 порядок=7
       текст: At the mercenary in a helmet
       ответ: Your accuracy helped you to blow away {[p43]}% of the health of the peleng in a helmet.
       условия: логика {[p47]=([p18] div 10000 mod 100) and [p18] div 1000 mod 10>2}
       эффект: P18(Mercenary in a helmet) = {((([p18] div 1000000)-[p43]) in [0..99])*(([p18] div 1000000)-[p43])*1000000+([p18] mod 1000000)}
  -> Path171 => Loc73  вер=1 порядок=2
       текст: At the one-eyed mercenary
       ответ: The one-eyed peleng wasn't able to hide behind the tree. He received {[p43]}% damage from you.
       условия: логика {[p47]=([p19] div 10000 mod 100) and [p19] div 1000 mod 10>2}
       эффект: P19(One-eyed mercenary) = {((([p19] div 1000000)-[p43]) in [0..99])*(([p19] div 1000000)-[p43])*1000000+([p19] mod 1000000)}
  -> Path172 => Loc73  вер=1 порядок=5
       текст: At the tall mercenary
       ответ: Your shots made the tall peleng {[p43]}% shorter.
       условия: логика {[p47]=([p20] div 10000 mod 100) and [p20] div 1000 mod 10>2}
       эффект: P20(Tall mercenary) = {((([p20] div 1000000)-[p43]) in [0..99])*(([p20] div 1000000)-[p43])*1000000+([p20] mod 1000000)}
  -> Path257 => Loc73  вер=1 порядок=9
       текст: At the wiry mercenary
       ответ: The {[p43]}% damage you inflicted calmed the wiry bastard down a bit.
       условия: логика {[p47]=([p21] div 10000 mod 100) and [p21] div 1000 mod 10>2}
       эффект: P21(Wiry mercenary) = {((([p21] div 1000000)-[p43]) in [0..99])*(([p21] div 1000000)-[p43])*1000000+([p21] mod 1000000)}
  -> Path258 => Loc73  вер=1 порядок=1
       текст: At the mercenary in glasses
       ответ: Despite the best efforts of the peleng wearing glasses to dodge your shots, you gave {[p43]}% damage.
       условия: логика {[p47]=([p22] div 10000 mod 100) and [p22] div 1000 mod 10>2}
       эффект: P22(Mercenary in glasses) = {((([p22] div 1000000)-[p43]) in [0..99])*(([p22] div 1000000)-[p43])*1000000+([p22] mod 1000000)}
  -> Path259 => Loc73  вер=1 порядок=2
       текст: At the mercenary with a cigar
       ответ: You got lucky. Your chose the right time to decrease the cigar-smoking peleng's life by {[p43]}%.
       условия: логика {[p47]=([p23] div 10000 mod 100) and [p23] div 1000 mod 10>2}
       эффект: P23(Mercenary with a cigar) = {((([p23] div 1000000)-[p43]) in [0..99])*(([p23] div 1000000)-[p43])*1000000+([p23] mod 1000000)}
  -> Path260 => Loc73  вер=1 порядок=4
       текст: At the mercenary in coveralls
       ответ: The mercenary in coveralls shrieked in pain ({[p43]}% damage).
       условия: логика {[p47]=([p24] div 10000 mod 100) and [p24] div 1000 mod 10>2}
       эффект: P24(Mercenary in coveralls) = {((([p24] div 1000000)-[p43]) in [0..99])*(([p24] div 1000000)-[p43])*1000000+([p24] mod 1000000)}
  -> Path380 => Loc159  вер=1
       текст: Into the air

### Loc73 [пустая]
    эффект: P6(Weapon) = {(([p6] div 10000 mod 1000)-[p39])*10000+([p6] div 10000000)*10000000}
  -> Path211 => Loc111  вер=1 порядок=5
       ответ: Your ammo clip is empty. You have to look for a new weapon.
       условия: логика {([p6] div 10000 mod 1000)=0 and [p6]<>0}
       эффект: P6(Weapon) = {0}
  -> Path248 => Loc111  вер=1 порядок=5
       условия: логика {([p6] div 10000 mod 1000)>0 or [p6]=0}

### Loc74 [пустая]
    эффект: P43(total damage) = {[5..7]*[p40]-2*[p4]+[5..15]*([p6]<40000000)}
    эффект: P46(alternating mercenary) = {([p46] div 1000000*1000000)+[p48]*10000+6000}
  -> Path379 => Loc20  вер=1 порядок=5

### Loc77 [пустая]
  -> Path39 => Loc23  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)=3}
  -> Path40 => Loc22  вер=1 порядок=5
       условия: логика {([p46] div 1000 mod 10)<>3}

### Loc78 [пустая]
  -> Path54 => Loc23  вер=1 порядок=5

### Loc79 [пустая]
    скрыт: P1,P2,P3,P4,P5,P6,P8,P10,P11,P12,P34,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48
  -> Path80 => Loc15  вер=1 порядок=5
       эффект: P36(future exits) = {2}
       эффект: P45(current retreats) = {2}
       эффект: P48(destination location of the character) = {1}

### Loc81 [пустая]
  -> Path152 => Loc11  вер=1 порядок=5

### Loc82 [пустая]
    эффект: P10(----------------) = {} [скрыт]
    скрыт: P1,P2,P3,P4,P5,P6,P8,P9,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48
  -> Path20 => Loc19  вер=1 порядок=5
       условия: логика {[p39]>0}
  -> Path21 => Loc157  вер=1 порядок=5
       условия: логика {[p39]=0}

### Loc83 [пустая]
    показ: P1,P3,P4,P6,P8,P9,P11,P12,P38
  -> Path98 => Loc9  вер=1 порядок=5
       условия: логика {[p47]=9}
  -> Path99 => Loc5  вер=1 порядок=5
       условия: логика {[p47]=5}
  -> Path100 => Loc4  вер=1 порядок=5
       условия: логика {[p47]=4}
  -> Path101 => Loc3  вер=1 порядок=5
       условия: логика {[p47]=3}
  -> Path102 => Loc1  вер=1 порядок=5
       условия: логика {[p47]=1}
  -> Path103 => Loc2  вер=1 порядок=5
       условия: логика {[p47]=2}
  -> Path166 => Loc6  вер=1 порядок=5
       условия: логика {[p47]=6}
  -> Path167 => Loc7  вер=1 порядок=5
       условия: логика {[p47]=7}
  -> Path168 => Loc8  вер=1 порядок=5
       условия: логика {[p47]=8}

### Loc84 [обычная] визитов<=1
    Loc84-1: Everything inside is charred black; torn metal protrudes sharply from both sides. You examine the remains of the car once again, but all you could find was a <c…
    эффект: P1(time) = {[p1]-2}
    эффект: P39(No) = {0}
  -> Path161 => Loc61  вер=1 порядок=5
       текст: Pick up the bar
       условия: логика {[p6]<2}
       эффект: P6(Weapon) = {10010000}
  -> Path162 => Loc85  вер=1 порядок=5
       текст: Pick up the bar
       условия: логика {[p6]>1}

### Loc85 [обычная]
    выбор описания: {([p6] div 10000000)+1}
    Loc85-1: The bar is quite heavy - it's better than nothing!
    Loc85-2: You already have a bar.
    Loc85-3: Although the bar is heavy and better than nothing, it clearly loses to the maloq's machete. You'll have to leave one or the other; you'll need to travel light t…
    Loc85-4: Although the bar is heavy and better than nothing, it clearly loses to the laser sword. You'll have to leave one or the other; you'll need to travel light to ma…
    Loc85-5: Bar
    Loc85-6: Bar
    Loc85-7: Although the bar is heavy and better than nothing, it clearly loses to the shotgun. You'll have to leave one or the other; you'll need to travel light to make i…
    Loc85-8: Although the bar is heavy and better than nothing, it clearly loses to the plasma musket. You'll have to leave one or the other; you'll need to travel light to …
    Loc85-9: Although the bar is heavy and better than nothing, it clearly loses to the machine gun. You'll have to leave one or the other; you'll need to travel light to ma…
    Loc85-10: Although the bar is heavy and better than nothing, it clearly loses to the sniper rifle. You'll have to leave one or the other; you'll need to travel light to m…
    эффект: P39(No) = {0}
  -> Path163 => Loc61  вер=1 порядок=5
       текст: Pick up the bar and put down the weapon you have
       эффект: P6(Weapon) = {19990000}
  -> Path164 => Loc61  вер=1 порядок=6
       текст: Stick with the weapon you already have

### Loc87 [пустая]
    эффект: P12(Near) = {([p12] mod 10 or (([p48]=[p46] div 10000 mod 100) and ([p46] div 1000 mod 10>2)))+10*([p12] div 10 mod 10 or (([p48]=[p46] div 10000 mod 100) and ([p46] div 1000 mod 10>4)))}
    эффект: P38(Who's there?
who's there?) = {((([p46] div 10000 mod 100)=([p36] div 100 mod 100)) or ([p38] mod 10))+((([p46] div 10000 mod 100)=([p36] mod 100)) or ([p38] div 10 mod 10))*10}
  -> Path86 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=4}
       эффект: P16(Mercenary in a mask) = {[p46]}
  -> Path87 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=2}
       эффект: P14(Chunky mercenary) = {[p46]}
  -> Path88 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=1}
       эффект: P13(Fat mercenary) = {[p46]}
  -> Path89 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=3}
       эффект: P15(Mercenary in a spacesuit) = {[p46]}
  -> Path90 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=5}
       эффект: P17(Mercenary in a hat) = {[p46]}
  -> Path154 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=6}
       эффект: P18(Mercenary in a helmet) = {[p46]}
  -> Path156 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=7}
       эффект: P19(One-eyed mercenary) = {[p46]}
  -> Path158 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=8}
       эффект: P20(Tall mercenary) = {[p46]}
  -> Path235 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=9}
       эффект: P21(Wiry mercenary) = {[p46]}
  -> Path236 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=10}
       эффект: P22(Mercenary in glasses) = {[p46]}
  -> Path237 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=11}
       эффект: P23(Mercenary with a cigar) = {[p46]}
  -> Path238 => Loc39  вер=1 порядок=5
       условия: логика {[p39]=12}
       эффект: P24(Mercenary in coveralls) = {[p46]}

### Loc90 [обычная]
    выбор описания: {[p39]}
    Loc90-1: The fat peleng's body plopped to the ground - he's dead!
    Loc90-2: The chunky mercenary is dead.
    Loc90-3: The peleng's spacesuit was cracked in several places. Thick blood streamed from the cracks, and the six-pawed dropped dead.
    Loc90-4: The mask fell from the peleng's face. His eyes have rolled to the back of his head - he's clearly dead.
    Loc90-5: Even in death, the mercenary kept his hat on. But that didn't bother you - one less bastard to worry about!
    Loc90-6: This time the helmet didn't help the peleng. A headshot took away his life.
    Loc90-7: The mercenary blinked his one eye in surprise, lost his balance, and fell down dead.
    Loc90-8: You fatally wounded the tall mercenary. To keep things simple, he died.
    Loc90-9: The wiry peleng tried to hide behind a tree, but you got him. One less bastard!
    Loc90-10: The peleng wearing the cool glasses fell down in a fit of agony. Then he fell silent... forever.
    эффект: P46(alternating mercenary) = {(([p46] div 10000)*10000)+2000}
  -> Path362 => Loc23  вер=1 порядок=5

### Loc91 [пустая]
  -> Path176 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [60000000..69999999]}
       эффект: P2(Camouflage) = {[p2]-[15..30]}
       эффект: P39(No) = {2}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[60..90]-10*([p4]=4)-3*([p4]=3)}
  -> Path249 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [80000000..89999999]}
       эффект: P2(Camouflage) = {[10..30]}
       эффект: P39(No) = {50}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[90..130]-20*([p4]=4)-5*([p4]=3)}
  -> Path250 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [40000000..49999999]}
       эффект: P2(Camouflage) = {[p2]-[15..30]}
       эффект: P39(No) = {20}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[35..45]-10*([p4]=4)-3*([p4]=3)}
  -> Path251 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [50000000..59999999]}
       эффект: P2(Camouflage) = {[p2]-[0;10;30;40]}
       эффект: P39(No) = {15}
       эффект: P43(total damage) = {40-2*[p4]}
  -> Path252 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [70000000..79999999]}
       эффект: P2(Camouflage) = {[p2]-[0;10;30;30]}
       эффект: P39(No) = {40}
       эффект: P43(total damage) = {[65..85]-3*[p4]}
  -> Path253 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [20000000..29999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[10..45]}
  -> Path254 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [30000000..39999999]}
       эффект: P2(Camouflage) = {[0..20]}
       эффект: P39(No) = {7}
       эффект: P43(total damage) = {[10..55]}
  -> Path255 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [10000000..19999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[10..45]}
  -> Path256 => Loc119  вер=1 порядок=5
       условия: логика {[p6] in [90000000..99999999]}
       эффект: P2(Camouflage) = {[p2]-[0;10;20;30;30;40]}
       эффект: P39(No) = {1}
       эффект: P43(total damage) = {[90..125]-10*[p4]}
  -> Path276 => Loc72  вер=1 порядок=5
       условия: логика {[p6] in [0..9999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[10..30]}

### Loc92 [обычная]
    Loc92-1: You put the medical kit to your temple. The kit's scanning probe buzzed around your head and, based on the results of the analysis, it injected you with the nan…
    Loc92-2: After the nanorobot injection, you gradually began to feel better.
    Loc92-3: The medical kit automatically gave you an injection. You felt much better.
    Loc92-4: You felt better after the injection.
  -> Path178 => Loc96  вер=1 порядок=5

### Loc93 [пустая]
  -> Path187 => Loc71  вер=1 порядок=5

### Loc94 [обычная]
    Loc94-1: You pull out the pin and skillfully lobbed the grenade before hitting the floor. In an instant, there was a huge explosion. Shrapnel hissed through the air, and…
    Loc94-2: You pull out the pin and skillfully lobbed the grenade before hitting the floor. In an instant, there was a huge explosion. If anyone is nearby, he must be rush…
    Loc94-3: You pull out the pin and skillfully along the grenade - tremendous explosion follows!
    Loc94-4: The grenade detonated, cutting down everything around with its shrapnel.
    эффект: P13(Fat mercenary) = {([p13] div 1000000-((([p13] div 1000000)/[1..3])*([p13] div 10000 mod 100=[p47]))) mod 100*1000000+[p13] mod 1000000}
    эффект: P14(Chunky mercenary) = {([p14] div 1000000-((([p14] div 1000000)/[1..3])*([p14] div 10000 mod 100=[p47]))) mod 100*1000000+[p14] mod 1000000}
    эффект: P15(Mercenary in a spacesuit) = {([p15] div 1000000-((([p15] div 1000000)/[1..3])*([p15] div 10000 mod 100=[p47]))) mod 100*1000000+[p15] mod 1000000}
    эффект: P16(Mercenary in a mask) = {([p16] div 1000000-((([p16] div 1000000)/[1..3])*([p16] div 10000 mod 100=[p47]))) mod 100*1000000+[p16] mod 1000000}
    эффект: P17(Mercenary in a hat) = {([p17] div 1000000-((([p17] div 1000000)/[1..3])*([p17] div 10000 mod 100=[p47]))) mod 100*1000000+[p17] mod 1000000}
    эффект: P18(Mercenary in a helmet) = {([p18] div 1000000-((([p18] div 1000000)/[1..3])*([p18] div 10000 mod 100=[p47]))) mod 100*1000000+[p18] mod 1000000}
    эффект: P19(One-eyed mercenary) = {([p19] div 1000000-((([p19] div 1000000)/[1..3])*([p19] div 10000 mod 100=[p47]))) mod 100*1000000+[p19] mod 1000000}
    эффект: P20(Tall mercenary) = {([p20] div 1000000-((([p20] div 1000000)/[1..3])*([p20] div 10000 mod 100=[p47]))) mod 100*1000000+[p20] mod 1000000}
    эффект: P21(Wiry mercenary) = {([p21] div 1000000-((([p21] div 1000000)/[1..3])*([p21] div 10000 mod 100=[p47]))) mod 100*1000000+[p21] mod 1000000}
    эффект: P22(Mercenary in glasses) = {([p22] div 1000000-((([p22] div 1000000)/[1..3])*([p22] div 10000 mod 100=[p47]))) mod 100*1000000+[p22] mod 1000000}
    эффект: P23(Mercenary with a cigar) = {([p23] div 1000000-((([p23] div 1000000)/[1..3])*([p23] div 10000 mod 100=[p47]))) mod 100*1000000+[p23] mod 1000000}
    эффект: P24(Mercenary in coveralls) = {([p24] div 1000000-((([p24] div 1000000)/[1..3])*([p24] div 10000 mod 100=[p47]))) mod 100*1000000+[p24] mod 1000000}
    эффект: P41(noisy location) = {[p47]}
    эффект: P42 = {[p45]}
  -> Path190 => Loc96  вер=1 порядок=5

### Loc95 [пустая]
  -> Path177 => Loc92  вер=1 порядок=5
       условия: логика {[p8] div 10000000=9}
       эффект: P3(Health) = {(([p3]+50)>100)*100+(([p3]+50)<=100)*([p3]+50)}
       эффект: P8(Item) = {(([p8] div 100000 mod 100-1)>0)*([p8] div 10000000*10000000+([p8] div 100000 mod 100-1)*100000+[p8] mod 100000)}
  -> Path188 => Loc94  вер=1 порядок=5
       условия: логика {[p8] div 10000000=6}
       эффект: P8(Item) = {(([p8] div 100000 mod 100-1)>0)*([p8] div 10000000*10000000+([p8] div 100000 mod 100-1)*100000+[p8] mod 100000)}
  -> Path192 => Loc96  вер=1 порядок=5
       ответ: You planted the mine where the mercenaries wouldn't find it. Then you got a safe distance away from it. The only thing left to do is to detonate it using the re…
       условия: логика {[p8] div 10000000=7}
       эффект: P8(Item) = {80000000+[p47]*1000}
       эффект: P44(adjacent to mine) = {[p45]}
  -> Path193 => Loc99  вер=1 порядок=5
       условия: логика {[p8] div 10000000=8}
       эффект: P41(noisy location) = {[p8] div 1000 mod 100}

### Loc96 [пустая]
  -> Path191 => Loc15  вер=1 порядок=5

### Loc99 [обычная]
    выбор описания: {1+([p47]=[p41])}
    Loc99-1: You pushed the mine activation button. A bright light blazed behind the trees. Then the rattle of the explosion reached your ears.
    Loc99-2: You pushed the mine activation button, and everything around lit up from the explosion.
    эффект: P8(Item) = {0}
    эффект: P13(Fat mercenary) = {([p13] div 1000000-((([p13] div 1000000)/(1+[0..5]/10))*([p13] div 10000 mod 100=[p41]))) mod 100*1000000+[p13] mod 1000000}
    эффект: P14(Chunky mercenary) = {([p14] div 1000000-((([p14] div 1000000)/(1+[0;0;0;2;5]/10))*([p14] div 10000 mod 100=[p41]))) mod 100*1000000+[p14] mod 1000000}
    эффект: P15(Mercenary in a spacesuit) = {([p15] div 1000000-((([p15] div 1000000)/(1+[0;0;0;2;5]/10))*([p15] div 10000 mod 100=[p41]))) mod 100*1000000+[p15] mod 1000000}
    эффект: P16(Mercenary in a mask) = {([p16] div 1000000-((([p16] div 1000000)/(1+[0;0;0;2;5]/10))*([p16] div 10000 mod 100=[p41]))) mod 100*1000000+[p16] mod 1000000}
    эффект: P17(Mercenary in a hat) = {([p17] div 1000000-((([p17] div 1000000)/(1+[0;0;0;2;5]/10))*([p17] div 10000 mod 100=[p41]))) mod 100*1000000+[p17] mod 1000000}
    эффект: P18(Mercenary in a helmet) = {([p18] div 1000000-((([p18] div 1000000)/(1+[0;0;0;2;5]/10))*([p18] div 10000 mod 100=[p41]))) mod 100*1000000+[p18] mod 1000000}
    эффект: P19(One-eyed mercenary) = {([p19] div 1000000-((([p19] div 1000000)/(1+[0;0;0;2;5]/10))*([p19] div 10000 mod 100=[p41]))) mod 100*1000000+[p19] mod 1000000}
    эффект: P20(Tall mercenary) = {([p20] div 1000000-((([p20] div 1000000)/(1+[0;0;0;2;5]/10))*([p20] div 10000 mod 100=[p41]))) mod 100*1000000+[p20] mod 1000000}
    эффект: P21(Wiry mercenary) = {([p21] div 1000000-((([p21] div 1000000)/(1+[0;0;0;2;5]/10))*([p21] div 10000 mod 100=[p41]))) mod 100*1000000+[p21] mod 1000000}
    эффект: P22(Mercenary in glasses) = {([p22] div 1000000-((([p22] div 1000000)/(1+[0;0;0;2;5]/10))*([p22] div 10000 mod 100=[p41]))) mod 100*1000000+[p22] mod 1000000}
    эффект: P23(Mercenary with a cigar) = {([p23] div 1000000-((([p23] div 1000000)/(1+[0;0;0;2;5]/10))*([p23] div 10000 mod 100=[p41]))) mod 100*1000000+[p23] mod 1000000}
    эффект: P24(Mercenary in coveralls) = {([p24] div 1000000-((([p24] div 1000000)/(1+[0;0;0;2;5]/10))*([p24] div 10000 mod 100=[p41]))) mod 100*1000000+[p24] mod 1000000}
    эффект: P41(noisy location) = {} [показ]
    эффект: P42 = {[p44]}
  -> Path194 => Loc96  вер=1 порядок=5

### Loc100 [обычная] визитов<=1
    Loc100-1: "We're getting close now," said the faeyan after checking the radar on the instrument panel. The rest of the path is guarded, so we will park the car in these b…
  -> Path195 => Loc51  вер=1 проходов<=1 порядок=5
       текст: Next

### Loc101 [пустая]
  -> Path246 => Loc116  вер=1 порядок=5
  -> Path247 => Loc117  вер=1 порядок=5

### Loc102 [обычная]
    Loc102-1: Search what?
  -> Path197 => Loc103  вер=1
       текст: Surrounding vegetation
  -> Path198 => Loc101  вер=1 порядок=4
       текст: Fat mercenary's corpse
       условия: логика {[p47]=([p13] div 10000 mod 100) and ([p13] div 1000 mod 10)=2}
       эффект: P13(Fat mercenary) = {0}
  -> Path223 => Loc101  вер=1 порядок=4
       текст: Chunky mercenary's corpse
       условия: логика {[p47]=([p14] div 10000 mod 100) and ([p14] div 1000 mod 10)=2}
       эффект: P14(Chunky mercenary) = {0}
  -> Path224 => Loc115  вер=1 порядок=4
       текст: Dead body in a spacesuit
       условия: логика {[p47]=([p15] div 10000 mod 100) and ([p15] div 1000 mod 10)=2}
       эффект: P15(Mercenary in a spacesuit) = {0}
  -> Path225 => Loc101  вер=1 порядок=4
       текст: Corpse of the mercenary in a mask
       условия: логика {[p47]=([p16] div 10000 mod 100) and ([p16] div 1000 mod 10)=2}
       эффект: P16(Mercenary in a mask) = {0}
  -> Path226 => Loc101  вер=1 порядок=4
       текст: Corpse of the mercenary in a hat
       условия: логика {[p47]=([p17] div 10000 mod 100) and ([p17] div 1000 mod 10)=2}
       эффект: P17(Mercenary in a hat) = {0}
  -> Path227 => Loc101  вер=1 порядок=4
       текст: Corpse of the mercenary in a helmet
       условия: логика {[p47]=([p18] div 10000 mod 100) and ([p18] div 1000 mod 10)=2}
       эффект: P18(Mercenary in a helmet) = {0}
  -> Path228 => Loc101  вер=1 порядок=4
       текст: Corpse of the one-eyed mercenary
       условия: логика {[p47]=([p19] div 10000 mod 100) and ([p19] div 1000 mod 10)=2}
       эффект: P19(One-eyed mercenary) = {0}
  -> Path229 => Loc101  вер=1 порядок=4
       текст: Tall mercenary’s body
       условия: логика {[p47]=([p20] div 10000 mod 100) and ([p20] div 1000 mod 10)=2}
       эффект: P20(Tall mercenary) = {0}
  -> Path230 => Loc101  вер=1 порядок=4
       текст: Wiry mercenary’s body
       условия: логика {[p47]=([p21] div 10000 mod 100) and ([p21] div 1000 mod 10)=2}
       эффект: P21(Wiry mercenary) = {0}
  -> Path239 => Loc101  вер=1 порядок=4
       текст: Corpse in coveralls
       условия: логика {[p47]=([p24] div 10000 mod 100) and ([p24] div 1000 mod 10)=2}
       эффект: P24(Mercenary in coveralls) = {0}
  -> Path240 => Loc114  вер=1 порядок=4
       текст: Body of the mercenary in glasses
       условия: логика {[p47]=([p22] div 10000 mod 100) and ([p22] div 1000 mod 10)=2}
       эффект: P22(Mercenary in glasses) = {0}
  -> Path241 => Loc101  вер=1 порядок=4
       текст: Body of the mercenary with a cigar
       условия: логика {[p47]=([p23] div 10000 mod 100) and ([p23] div 1000 mod 10)=2}
       эффект: P23(Mercenary with a cigar) = {0}

### Loc103 [пустая]
  -> Path206 => Loc109  вер=1 порядок=5
       условия: логика {[p47]=5}
       эффект: P39(No) = {0}
  -> Path207 => Loc110  вер=1 порядок=5
       условия: логика {[p47]<>5}

### Loc104 [обычная]
    Loc104-1: It's a good thing you checked the belt bag. You found an <clr>antipersonnel grenade<clrEnd>.
  -> Path201 => Loc105  вер=1 порядок=1
       текст: Pick up the grenade
       эффект: P8(Item) = {([p8] in [60000000..69999999])*(([p8] div 100000 mod 100+1)*100000+60000000)+([p8] div 10000000<>6)*60100000}
  -> Path203 => Loc105  вер=1 порядок=2
       текст: Decline to pick up the grenade

### Loc105 [пустая]
  -> Path215 => Loc112  вер=1 порядок=5

### Loc106 [пустая]
  -> Path204 => Loc104  вер=40 порядок=5
  -> Path205 => Loc107  вер=40 порядок=5
  -> Path417 => Loc160  вер=20 порядок=5
       условия: логика {[p3]<100}
       эффект: P39(No) = {100-[p3]}

### Loc107 [обычная]
    выбор описания: {[1..6]}
    Loc107-1: There were only useless peleng gillneck cigarettes in the belt bag.
    Loc107-2: You also checked the belt bag. It was empty.
    Loc107-3: You turned the belt bag upside down, but didn’t find anything in it except a useless brochure entitled “Combined Movements for the Lower Arm Muscles”.
    Loc107-4: A useless briquette of sublimated acid plankton was in the peleng’s belt bag.
    Loc107-5: The six-pawed bastard's belt bag contained a nearly-empty can of Machpella Dark.
    Loc107-6: You searched the peleng’s bag thoroughly, but all you found was an explicit photo of a peleng woman - a disgusting sight.
  -> Path202 => Loc105  вер=1 порядок=1
       текст: Drop the bag

### Loc109 [пустая]
    эффект: P39(No) = {20*([p3]<50)+(70-[p3])*([p3] in [50..70])}
  -> Path214 => Loc150  вер=1 порядок=5
       условия: логика {[p39]=0}
  -> Path364 => Loc151  вер=1 порядок=5
       условия: логика {[p39]>0}

### Loc110 [обычная]
    Loc110-1: You didn’t find anything useful.
  -> Path213 => Loc112  вер=1 порядок=5
       текст: End your search

### Loc111 [пустая]
  -> Path112 => Loc15  вер=1 порядок=5

### Loc112 [пустая]
  -> Path212 => Loc96  вер=1 порядок=5

### Loc113 [пустая]
  -> Path218 => Loc14  вер=1 порядок=5

### Loc114 [обычная]
    Loc114-1: You removed the <clr>glasses. They were labeled "Megavision"<clrEnd>. They support vision modes that you didn't know existed. Obviously not a mass-produced item…
    эффект: P9(Gadgets) = {[p9]+10}
  -> Path243 => Loc101  вер=1 порядок=5
       текст: Continue your search

### Loc115 [обычная]
    Loc115-1: In the spacesuit's breast pocket, you found the key with a few buttons on it. Furthermore, the key had a picture of a spaceship on it - the very stealth ship yo…
    эффект: P9(Gadgets) = {[p9]+1}
  -> Path242 => Loc101  вер=1 порядок=5
       текст: Continue your search

### Loc116 [обычная]
    Loc116-1: You took the dead mercenary's <clr>dogtags and chain - they might come in handy<clrEnd>! Then you checked his weapon: he had an ordinary blaster - not much powe…
    Loc116-2: You put the peleng's dogtags into your pocket. Some <clr>mercenaries will buy<clrEnd> these tags and show them off as if they were their own trophies. Then you …
    эффект: P11(Mercenary nametags collected) = {[p11]+1}
  -> Path199 => Loc106  вер=1 порядок=2
       текст: Pick up the blaster and put down your current weapon
       эффект: P6(Weapon) = {50000000+[6..8]*15*10000}
  -> Path200 => Loc106  вер=1 порядок=1
       текст: Drop the blaster

### Loc117 [обычная]
    Loc117-1: You took the dead mercenary's <clr>dogtags and chain<clrEnd> - they are worth quite a bit in certain circles! Then you checked his weapon: he had a submachine g…
    Loc117-2: The mercenary's <clr>dogtag<clrEnd> went into your pocket - all sorts of <clr>cutthroats will buy them<clrEnd> and them show them off, as if they were their own…
    эффект: P11(Mercenary nametags collected) = {[p11]+1}
  -> Path244 => Loc106  вер=1 порядок=2
       текст: Pick up the submachine gun and put down your current weapon
       эффект: P6(Weapon) = {40000000+[6..8]*20*10000}
  -> Path245 => Loc106  вер=1 порядок=1
       текст: Drop the submachine gun

### Loc119 [обычная]
    Loc119-1: Choose where to shoot.
  -> Path261 => Loc120  вер=1 порядок=1
       текст: At the fat mercenary
       ответ: The fat one croaked from his wound, which decreased his health by {[p43]}%.
       условия: логика {(([p45] div 100 mod 100)=[p13] div 10000 mod 100 or [p45] mod 100=[p13] div 10000 mod 100 or [p47]=[p13] div 10000 mod 100) and [p13] div 1000 mod 10>2}
       эффект: P13(Fat mercenary) = {((([p13] div 1000000)-[p43]) in [0..99])*(([p13] div 1000000)-[p43])*1000000+([p13] mod 1000000)}
  -> Path264 => Loc120  вер=1 порядок=1
       текст: At the mercenary in a spacesuit
       ответ: The peleng in a spacesuit tried to get down, but instead he got {[p43]}% of his body burned by the laser.
       условия: логика {(([p45] div 100 mod 100)=([p15] div 10000 mod 100) or [p45] mod 100=([p15] div 10000 mod 100) or [p47]=([p15] div 10000 mod 100)) and [p15] div 1000 mod 10>2}
       эффект: P15(Mercenary in a spacesuit) = {((([p15] div 1000000)-[p43]) in [0..99])*(([p15] div 1000000)-[p43])*1000000+([p15] mod 1000000)}
  -> Path265 => Loc120  вер=1 порядок=6
       текст: At the mercenary in a hat
       ответ: Hit by a laser blast, the peleng in a hat lost {[p43]}% of his blood.
       условия: логика {(([p45] div 100 mod 100)=([p17] div 10000 mod 100) or [p45] mod 100=([p17] div 10000 mod 100) or [p47]=([p17] div 10000 mod 100)) and [p17] div 1000 mod 10>2}
       эффект: P17(Mercenary in a hat) = {((([p17] div 1000000)-[p43]) in [0..99])*(([p17] div 1000000)-[p43])*1000000+([p17] mod 1000000)}
  -> Path266 => Loc120  вер=1 порядок=7
       текст: At the mercenary in a helmet
       ответ: The peleng in a helmet screamed out of pain - he received {[p43]}% damage.
       условия: логика {(([p45] div 100 mod 100)=([p18] div 10000 mod 100) or [p45] mod 100=([p18] div 10000 mod 100) or [p47]=([p18] div 10000 mod 100)) and [p18] div 1000 mod 10>2}
       эффект: P18(Mercenary in a helmet) = {((([p18] div 1000000)-[p43]) in [0..99])*(([p18] div 1000000)-[p43])*1000000+([p18] mod 1000000)}
  -> Path267 => Loc120  вер=1 порядок=5
       текст: At the tall mercenary
       ответ: The tall ranger couldn't dodge such a powerful shot - it took {[p43]}% of his health.
       условия: логика {(([p45] div 100 mod 100)=([p20] div 10000 mod 100) or [p45] mod 100=([p20] div 10000 mod 100) or [p47]=([p20] div 10000 mod 100)) and [p20] div 1000 mod 10>2}
       эффект: P20(Tall mercenary) = {((([p20] div 1000000)-[p43]) in [0..99])*(([p20] div 1000000)-[p43])*1000000+([p20] mod 1000000)}
  -> Path268 => Loc120  вер=1 порядок=1
       текст: At the mercenary in glasses
       ответ: The peleng in glasses got knocked over by the hit. He lost {[p43]}% of his health.
       условия: логика {(([p45] div 100 mod 100)=([p22] div 10000 mod 100) or [p45] mod 100=([p22] div 10000 mod 100) or [p47]=([p22] div 10000 mod 100)) and [p22] div 1000 mod 10>2}
       эффект: P22(Mercenary in glasses) = {((([p22] div 1000000)-[p43]) in [0..99])*(([p22] div 1000000)-[p43])*1000000+([p22] mod 1000000)}
  -> Path269 => Loc120  вер=1 порядок=4
       текст: At the mercenary in coveralls
       ответ: The peleng’s coveralls didn’t help him blend in with his surroundings. His health was reduced by {[p43]}%.
       условия: логика {(([p45] div 100 mod 100)=([p24] div 10000 mod 100) or [p45] mod 100=([p24] div 10000 mod 100) or [p47]=([p24] div 10000 mod 100)) and [p24] div 1000 mod 10>2}
       эффект: P24(Mercenary in coveralls) = {((([p24] div 1000000)-[p43]) in [0..99])*(([p24] div 1000000)-[p43])*1000000+([p24] mod 1000000)}
  -> Path270 => Loc120  вер=1 порядок=8
       текст: At the chunky mercenary
       ответ: You inflicted {[p43]}% damage on the chunky one.
       условия: логика {(([p45] div 100 mod 100)=([p14] div 10000 mod 100) or [p45] mod 100=([p14] div 10000 mod 100) or [p47]=([p14] div 10000 mod 100)) and [p14] div 1000 mod 10>2}
       эффект: P14(Chunky mercenary) = {((([p14] div 1000000)-[p43]) in [0..99])*(([p14] div 1000000)-[p43])*1000000+([p14] mod 1000000)}
  -> Path271 => Loc120  вер=1 порядок=3
       текст: At the mercenary in a mask
       ответ: The shot kicked the masked peleng aside. He received {[p43]}% damage.
       условия: логика {(([p45] div 100 mod 100)=([p16] div 10000 mod 100) or [p45] mod 100=([p16] div 10000 mod 100) or [p47]=([p16] div 10000 mod 100)) and [p16] div 1000 mod 10>2}
       эффект: P16(Mercenary in a mask) = {((([p16] div 1000000)-[p43]) in [0..99])*(([p16] div 1000000)-[p43])*1000000+([p16] mod 1000000)}
  -> Path272 => Loc120  вер=1
       текст: Into the air
       ответ: A hot laser beam pierced the air. Its quiet crackle (like a branch being broken in two) was lost among the other sounds of the forest. However, you may have bee…
  -> Path273 => Loc120  вер=1 порядок=2
       текст: At the one-eyed mercenary
       ответ: The one-eyed mercenary reeled back in pain. He received {[p43]}% damage.
       условия: логика {(([p45] div 100 mod 100)=([p19] div 10000 mod 100) or [p45] mod 100=([p19] div 10000 mod 100) or [p47]=([p19] div 10000 mod 100)) and [p19] div 1000 mod 10>2}
       эффект: P19(One-eyed mercenary) = {((([p19] div 1000000)-[p43]) in [0..99])*(([p19] div 1000000)-[p43])*1000000+([p19] mod 1000000)}
  -> Path274 => Loc120  вер=1 порядок=9
       текст: At the wiry mercenary
       ответ: The laser blast knocked out {[p43]}% of the wiry peleng's health.
       условия: логика {(([p45] div 100 mod 100)=([p21] div 10000 mod 100) or [p45] mod 100=([p21] div 10000 mod 100) or [p47]=([p21] div 10000 mod 100)) and [p21] div 1000 mod 10>2}
       эффект: P21(Wiry mercenary) = {((([p21] div 1000000)-[p43]) in [0..99])*(([p21] div 1000000)-[p43])*1000000+([p21] mod 1000000)}
  -> Path275 => Loc120  вер=1 порядок=2
       текст: At the mercenary with a cigar
       ответ: The peleng with a cigar received {[p43]}% damage.
       условия: логика {(([p45] div 100 mod 100)=([p23] div 10000 mod 100) or [p45] mod 100=([p23] div 10000 mod 100) or [p47]=([p23] div 10000 mod 100)) and [p23] div 1000 mod 10>2}
       эффект: P23(Mercenary with a cigar) = {((([p23] div 1000000)-[p43]) in [0..99])*(([p23] div 1000000)-[p43])*1000000+([p23] mod 1000000)}

### Loc120 [пустая]
    эффект: P6(Weapon) = {([p6] div 10000 mod 1000-[p39])*10000+([p6] div 10000000)*10000000}
  -> Path262 => Loc111  вер=1 порядок=5
       ответ: The rifle clip is empty. Now you have to look for a new weapon.
       условия: логика {([p6] div 10000 mod 1000)=0}
       эффект: P6(Weapon) = {0}
  -> Path263 => Loc111  вер=1 порядок=5
       условия: логика {([p6] div 10000 mod 1000)>0}

### Loc123 [обычная]
    Loc123-1: The visible world changed: the contours of objects became bright, while volumes faded. / You discovered that all the while the <clr>stealth ship<clrEnd> had bee…
    Loc123-2: The <clr>stealth ship<clrEnd> is floating in the hangar in a camouflaged mode. It can only be seen if you're wearing the <clr>"Megavision"<clrEnd> glasses.
    эффект: P1(time) = {[p1]-1}
  -> Path299 => Loc130  вер=1 [всегда видна] порядок=7
       текст: Use the key
       условия: логика {([p9] mod 10)=1}
  -> Path311 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}

### Loc124 [обычная] визитов<=1
    Loc124-1: The main gate was closed, so you got in through the personnel entrance. But the hangar was empty. There was only maintenance equipment for the ship buzzing stea…
  -> Path278 => Loc126  вер=1
       текст: Cancel the mission
  -> Path279 => Loc125  вер=1 порядок=3
       текст: Examine the equipment
  -> Path280 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}
  -> Path300 => Loc123  вер=1 порядок=6
       текст: Use the glasses
       условия: логика {[p9]>9}

### Loc125 [обычная]
    Loc125-1: You sat in a chair at the control panel. One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an …
    Loc125-2: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-3: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-4: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-5: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-6: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-7: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-8: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-9: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    Loc125-10: One of the monitors displayed a translucent image of the stealth ship in middle of the hangar. It looked a bit like an x-ray picture. A photo with two pelengs w…
    эффект: P1(time) = {[p1]-1}
  -> Path281 => Loc126  вер=1
       текст: Cancel the mission
  -> Path282 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}
  -> Path283 => Loc127  вер=1 проходов<=1 порядок=3
       текст: Flick the ball away from the panel
  -> Path361 => Loc129  вер=1 порядок=3
       текст: Get out of the pilot's seat

### Loc126 [ПРОВАЛ]
    Loc126-1: It took nearly a day to get back. You were bleeding from the scratches you received from the thorns in the bushes on planet <ToPlanet>. Starving and infuriated …

### Loc127 [обычная] визитов<=1
    Loc127-1: The ball flew away, hit the wall of the hangar, and rolled toward the closed gate. Out of the corner of your eye you detected <clr>motion on one of the screens<…
    эффект: P1(time) = {[p1]-1}
  -> Path284 => Loc126  вер=1
       текст: Cancel the mission
  -> Path285 => Loc128  вер=1 порядок=3
       текст: Examine the equipment
  -> Path286 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}

### Loc128 [обычная]
    Loc128-1: The "x-ray" monitor showed the little ball moving towards the exit -  right underneath the floating stealth ship. It reached the gate... and you heard the ball …
    эффект: P1(time) = {[p1]-1}
  -> Path287 => Loc126  вер=1
       текст: Cancel the mission
  -> Path288 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}
  -> Path359 => Loc129  вер=1 порядок=3
       текст: Get out of the pilot's seat

### Loc129 [обычная]
    Loc129-1: The maintenance equipment for the ship is buzzing steadily in the dark and empty hangar.
    эффект: P1(time) = {[p1]-1}
  -> Path291 => Loc126  вер=1
       текст: Cancel the mission
  -> Path292 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}
  -> Path296 => Loc123  вер=1 порядок=6
       текст: Use the glasses
       условия: логика {[p9]>9}
  -> Path333 => Loc125  вер=1 порядок=3
       текст: Examine the equipment

### Loc130 [обычная]
    Loc130-1: Without delay, the hatch smoothly slid aside to open the cabin to your view. After looking it over quickly, you decide that all systems are operational and you …
    Loc130-2: Without delay, the hatch smoothly slid aside. You could take off in this thing. However, the <clr>hangar gate is closed<clrEnd>. You climb down and realize that…
    Loc130-3: Without delay, the hatch smoothly slid aside. You could take off in this thing; However, the <clr>hangar gate is closed<clrEnd>. You got out of the ship.
    Loc130-4: Without delay, the hatch smoothly slid aside. You could take off in this thing; However, the <clr>hangar gate is closed<clrEnd>. You got out of the ship.
    Loc130-5: Without delay, the hatch smoothly slid aside. You could take off in this thing; However, the <clr>hangar gate is closed<clrEnd>. You got out of the ship.
    Loc130-6: Without delay, the hatch smoothly slid aside. You could take off in this thing; However, the <clr>hangar gate is closed<clrEnd>. You got out of the ship.
    Loc130-7: Without delay, the hatch smoothly slid aside. You could take off in this thing; However, the <clr>hangar gate is closed<clrEnd>. You got out of the ship.
    эффект: P1(time) = {[p1]-1}
  -> Path312 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}
  -> Path313 => Loc131  вер=1 порядок=5
       текст: Shoot at the gate support
       условия: логика {[p6]>=30000000}
  -> Path314 => Loc134  вер=1 порядок=5
       текст: Hit the gate support
       условия: логика {[p6]<30000000}

### Loc131 [пустая]
  -> Path302 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [30000000..39999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {7}
       эффект: P43(total damage) = {[44..66]}
  -> Path303 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [70000000..79999999]}
       эффект: P2(Camouflage) = {[p2]-[0;0;0;0;0;10;30]}
       эффект: P39(No) = {40}
       эффект: P43(total damage) = {[45..60]-3*[p4]}
  -> Path304 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [40000000..49999999]}
       эффект: P2(Camouflage) = {[p2]-[5..10]}
       эффект: P39(No) = {20}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[25..40]-10*([p4]=4)}
  -> Path305 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [60000000..69999999]}
       эффект: P2(Camouflage) = {[p2]-[15..25]}
       эффект: P39(No) = {2}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[40..70]}
  -> Path306 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [80000000..89999999]}
       эффект: P2(Camouflage) = {[10..30]}
       эффект: P39(No) = {50}
       эффект: P41(noisy location) = {[p47]}
       эффект: P42 = {[p45]}
       эффект: P43(total damage) = {[90..120]-25*([p4]=4)}
  -> Path307 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [50000000..59999999]}
       эффект: P2(Camouflage) = {[p2]-[0;0;0;0;0;0;0;0;10;15;20]}
       эффект: P39(No) = {15}
       эффект: P43(total damage) = {[20..40]-2*[p4]}
  -> Path310 => Loc132  вер=1 порядок=5
       условия: логика {[p6] in [90000000..99999999]}
       эффект: P2(Camouflage) = {[p2]-[0;0;0;0;0;0;10;20]}
       эффект: P39(No) = {1}
       эффект: P43(total damage) = {[100..140]-20*[p4]}

### Loc132 [пустая]
    выбор описания: {[p6] div 10000000+1}
    эффект: P6(Weapon) = {([p6] div 10000 mod 1000-[p39])*10000+([p6] div 10000000)*10000000}
  -> Path315 => Loc135  вер=1 порядок=5
  -> Path319 => Loc137  вер=1000 порядок=5
       условия: логика {([p6] div 10000 mod 1000)=0}

### Loc133 [пустая]
    эффект: P6(Weapon) = {([p6] div 10000 mod 1000-[p39])*10000+([p6] div 10000000)*10000000}
  -> Path316 => Loc137  вер=1 порядок=5

### Loc134 [пустая]
  -> Path301 => Loc133  вер=1 порядок=5
       условия: логика {[p6] in [0..9999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[15..35]}
  -> Path308 => Loc133  вер=1 порядок=5
       условия: логика {[p6] in [20000000..29999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[33..55]}
  -> Path309 => Loc133  вер=1 порядок=5
       условия: логика {[p6] in [10000000..19999999]}
       эффект: P2(Camouflage) = {0}
       эффект: P39(No) = {0}
       эффект: P43(total damage) = {[22..55]}

### Loc135 [обычная]
    Loc135-1: The shot made a hole in the support. It's just take a little bit more effort to open the gate.
    Loc135-2: If you get the support one more time, the gate won't be an obstacle any longer.
    Loc135-3: A little bit more effort is needed to break the support.
    эффект: P1(time) = {[p1]-1}
  -> Path317 => Loc131  вер=1 порядок=5
       текст: Shoot at the gate support
       условия: логика {[p6]>=30000000}
  -> Path327 => Loc134  вер=1 порядок=5
       текст: Hit the gate support
       условия: логика {[p6]<30000000}
  -> Path330 => Loc68  вер=1 порядок=1
       текст: Go out
       эффект: P47(your current location) = {9}
       эффект: P48(destination location of the character) = {9}

### Loc137 [обычная]
    Loc137-1: The support fell off, and the gate started leaning outward. Soon it crashed to the ground, raising clouds of dust... As the dust settled, you could see a peleng…
    скрыт: P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24
  -> Path320 => Loc138  вер=1 порядок=2
       текст: Surrender
  -> Path321 => Loc144  вер=1 [всегда видна]
       текст: Shoot at the peleng
       условия: логика {[p6]>39999999}
  -> Path322 => Loc139  вер=1 порядок=1
       текст: Hit the peleng
  -> Path360 => Loc148  вер=1 [всегда видна] порядок=9
       текст: Try to escape on the ship

### Loc138 [обычная]
    Loc138-1: You put your hands in the air... But, unexpectedly, the peleng puts his gun down and raises one of his four arms. / "And hello to you too,<Ranger>! Sorry I was …
  -> Path325 => Loc142  вер=1
       текст: Sell the tags
  -> Path326 => Loc143  вер=1 порядок=5
       текст: Get into the ship

### Loc139 [обычная]
    Loc139-1: You charged that the peleng desperately, swinging your fists, but he dodged your attack. / "Hey, <Ranger>! What are you doing hitting an ally?!! Yeah, I was lat…
  -> Path323 => Loc142  вер=1
       текст: Sell the tags
  -> Path324 => Loc143  вер=1 порядок=5
       текст: Get into the ship

### Loc142 [УСПЕХ]
    Loc142-1: "So... I owe you {[p11]*50} in cash for the dogtags." The peleng pulled out his credit card ran his fingers over the buttons on it, and pointed it at your credi…
    эффект: P9(Gadgets) = {10}
    эффект: P34(Money) = {[p11]*50+[p34]} [показ]
    скрыт: P1,P2,P3,P4,P5,P6,P8,P10,P11,P12,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48

### Loc143 [УСПЕХ]
    Loc143-1: The peleng hopped in after you and sat down quietly in the back seat. You gave him a passing glance and then skillfully piloted the ship out of the hangar. You …
    эффект: P9(Gadgets) = {10}
    скрыт: P1,P2,P3,P4,P5,P6,P8,P10,P11,P12,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48

### Loc144 [обычная]
    Loc144-1: A traitorous misfire thundered across the hangar. / "Heh, heh. Hey, my clip is full," said the peleng with an evil grin. "Just don't chicken out, <Ranger>. I am…
  -> Path328 => Loc142  вер=1
       текст: Sell the tags
  -> Path329 => Loc143  вер=1 порядок=5
       текст: Get into the ship

### Loc146 [обычная] визитов<=1
    Loc146-1: The rattle of a hoverjet shattered the tranquility of the forest, and you could see the fast combat aircraft flying over the path, leaving a trail of parachutin…
    эффект: P20(Tall mercenary) = {[99094000;99084000;99074000]}
    эффект: P21(Wiry mercenary) = {[99094000;99084000;99074000]}
    эффект: P23(Mercenary with a cigar) = {[99094000;99084000;99074000]}
    эффект: P24(Mercenary in coveralls) = {[99094000;99084000;99074000]}
  -> Path332 => Loc15  вер=1 проходов<=1 порядок=5

### Loc147 [обычная]
    выбор описания: {[p39]}
    Loc147-1: You heavily injured the fat one. He retreats quickly to the base to treat his wounds.
    Loc147-2: The wiry peleng's aggression quickly melts away due to the wounds he sustained. He headed to the east, toward the base.
    Loc147-3: The peleng in a spacesuit is heavily injured; He's stumbling along toward the east.
    Loc147-4: The mercenary in a mask has fallen to the ground. Clutching his side, he crawls away toward the base. You showed him what you are made of!
    Loc147-5: The Ranger in the hat howled with pain and limped off to the east.
    Loc147-6: The peleng in a helmet is heavily injured and is now fleeing to the base.
    Loc147-7: Your hit flipped the one-eyed ranger over, and now he's stumping along to the east, contorted from all the pain he's experiencing.
    Loc147-8: The talk of those heavily injured. He's doing his best to hide behind bushes as he flees to the base.
    Loc147-9: You've heavily injured the wiry peleng. But he's gathered enough strength to flee to the east.
    Loc147-10: The peleng in glasses is clutching his hands to his side as he flees. You heavily injured the bastard!
  -> Path334 => Loc23  вер=1 порядок=5

### Loc148 [УСПЕХ]
    Loc148-1: You climb deftly up the ladder into the ship and immediately secured the hatch. Without any delay, you fired at the back wall of the hangar and quickly flew out…
    эффект: P9(Gadgets) = {10}
    скрыт: P1,P2,P3,P4,P5,P6,P8,P10,P11,P12,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48

### Loc149 [обычная]
    выбор описания: {[p39]-10}
    Loc149-1: The peleng with a cigar stopped in his tracks for a moment and then fell to the ground. "Kill the smoking mercenary - save the forest!"
    Loc149-2: The mercenary in coveralls staggered backward and fell over.
    Loc149-3: Your impeccable shots sent one more peleng to kingdom come.
    эффект: P46(alternating mercenary) = {(([p46] div 10000)*10000)+2000}
  -> Path174 => Loc23  вер=1 порядок=5

### Loc150 [обычная]
    Loc150-1: You chewed on the berries you found. You don’t have an heavy injuries, and the life-giving halluberry juice has no effect on minor wounds.
    Loc150-2: You found a few more halluberries and chewed them thoroughly. You felt no different. Apparently, halluberries can't raise your health above {[p3]}%.
    Loc150-3: Another batch of halluberries went into your mouth, but their pulp was no help given your already moderately healthy state.
  -> Path365 => Loc112  вер=1 порядок=5
       текст: Spit out the chewed up pulp

### Loc151 [обычная]
    Loc151-1: You found a few nutritious berries and, without thinking, started chewing them. In a minute, you felt your heavy wound starting to close up!
    Loc151-2: After eating a few berries, you found that you felt a bit better.
    Loc151-3: Although it's not by much, these halluberries do improve your condition.
    эффект: P3(Health) = {(([p3]+[p39])>70)*[p3]+(([p3]+[p39])<=70)*([p3]+[p39])}
  -> Path366 => Loc112  вер=1 порядок=5
       текст: Spit out the chewed up pulp

### Loc152 [обычная]
    выбор описания: {[p39]-10}
    Loc152-1: You've heavily injured the mercenary with a cigar. He's hiding behind the bushes heading for the base.
    Loc152-2: The mercenary in coveralls is heavily injured. He's fleeing to the east to seek shelter.
    Loc152-3: The enemy got what he deserved; the only thing he's thinking about now is preserving his own life.
  -> Path367 => Loc23  вер=1 порядок=5

### Loc153 [пустая]
  -> Path368 => Loc147  вер=1 порядок=5
       условия: P39(No) 1..10
  -> Path369 => Loc152  вер=1 порядок=5
       условия: P39(No) 11..20

### Loc154 [обычная]
    выбор описания: {[p4]+1+5*([p12]>2)}
    Loc154-1: You are lying down in a secluded spot. You are hardly visible, but you can see everything perfectly. Your shooting accuracy with any kind of weapon is guarantee…
    Loc154-2: You crawl slowly, trying not to give yourself away. And you'll be able to easily pull of accurate shots.
    Loc154-3: You sneak along carefully, trying to hide behind obstacles. At this speed your weapon accuracy is the default.
    Loc154-4: You are walking quickly, trying not to move into exposed locations. Your speed prevents you from aiming well, a deficiency usually compensated for by firing mor…
    Loc154-5: You are running. You can cover a lot of ground quickly, but aiming while you fire is out of the question.
    Loc154-6: You are lying down. Unfortunately, you have been spotted and are now an easy, stationary target. However, your firing accuracy from any kind of weapon is guaran…
    Loc154-7: You are crawling under fire. Of course, this position makes it easy for you to aim. But it's even more convenient for enemies shooting at you.
    Loc154-8: You're trying to find cover, but the enemy is approaching quickly.
    Loc154-9: You move quickly from one place of cover to another. It's difficult for the enemy to aim at you, just as difficult for you to aim of the enemy.
    Loc154-10: You are running under fire. The enemy keeps missing. And so do you. Only a rapid-fire weapon would be able to inflict decent damage on pelengs moving so quickly…
  -> Path106 => Loc70  вер=1 порядок=2
       текст: Sneak
       эффект: P4(Speed) = {2}
  -> Path107 => Loc70  вер=1 порядок=3
       текст: Walk
       эффект: P4(Speed) = {3}
  -> Path108 => Loc70  вер=1 порядок=4
       текст: Run
       эффект: P4(Speed) = {4}

### Loc155 [обычная]
    выбор описания: {[p4]+1+5*([p12]>2)}
    Loc155-1: You are lying down in a secluded spot. You are hardly visible, but you can see everything perfectly.
    Loc155-2: You crawl slowly, trying not to give yourself away.
    Loc155-3: You sneak along carefully, trying to hide behind obstacles when possible. Nearly every weapon has default firing accuracy at this speed. That's if you have a we…
    Loc155-4: You are walking quickly, trying not to move into exposed locations. Your rapid speed will prevent your enemies from aiming well if they suddenly appear.
    Loc155-5: You're running, covering large distances quickly. You are clearly visible, but it’s hard to hit you.
    Loc155-6: You are lying down. Unfortunately, you have been spotted and are now an easy, stationary target.
    Loc155-7: You are crawling under fire: it's easy for your enemies to shoot you.
    Loc155-8: You're trying to find some cover but the enemy is watching you and coming closer.
    Loc155-9: You move quickly from one place of cover to another. This makes it harder for the enemy to aim at you than if you were standing still.
    Loc155-10: You zigzag under fire, trying to avoid being hit.
  -> Path370 => Loc70  вер=1 порядок=3
       текст: Walk
       эффект: P4(Speed) = {3}
  -> Path373 => Loc70  вер=1 порядок=2
       текст: Sneak
       эффект: P4(Speed) = {2}
  -> Path374 => Loc70  вер=1 порядок=4
       текст: Run
       эффект: P4(Speed) = {4}

### Loc156 [пустая]
    эффект: P43(total damage) = {0}
  -> Path85 => Loc87  вер=1 порядок=5

### Loc157 [пустая]
    эффект: P1(time) = {[p1]-[p40]}
    эффект: P3(Health) = {[p3]-[p43]}
    эффект: P41(noisy location) = 0
    эффект: P47(your current location) = {[p48]}
  -> Path335 => Loc41  вер=111 порядок=5
       условия: логика {[p13] div 10000 mod 100=[p47]}
       показ: P13
  -> Path336 => Loc41  вер=1 порядок=5
       скрыт: P13

### Loc158 [обычная]
    выбор описания: {[p39]-10}
    Loc158-1: A shot - and {[p43]}% is gone. The mercenary with a cigar, grinning impishly, is hopping through the bushes and firing at you!
    Loc158-2: The peleng in the coveralls keeps firing at you; he's already taken {[p43]}% of your health. Skirmishing with these mercenaries is a bad habit.
    Loc158-3: The mercenaries have inflicted serious damage on you!
  -> Path377 => Loc156  вер=1 порядок=5

### Loc159 [обычная]
    выбор описания: {([p6] div 10000000)+1}
    Loc159-1: You jumped out from behind your cover and made a few vigorous boxing motions. Of course, the air was devastated by blows, but none of your enemies was hurt...
    Loc159-2: Swinging the bar, you cut through the air - but nothing else. What's worse, you were spotted.
    Loc159-3: You swung your heavy machete a few times. It's glittering blade was seen from far away.
    Loc159-4: You turned on the laser sword and took a swing with it. The beautiful red beam thrilled you.
    Loc159-5: Tracer bullets rushed high into the air. The roar of automatic-weapon fire echoed across the forest.
    Loc159-6: A thin stream of blaster rounds cut softly through the air. The hissing from the cooling system ceased shortly. However, you could have been spotted or heard fr…
    Loc159-7: The shotgun fiercely belched out a swarm of deadly pellets. The shot was heard at a great distance.
    Loc159-8: A thread of plasma, hissing softly, pierced the sky and quickly burst into sparks. You could have been spotted!
    Loc159-9: The barrels of the machine gun started spinning with a swish, and, without begrudging any bullets, they threw lead into the sky, which frightened all the birds …
    Loc159-10: "Bang!" No. “Kaboom!!!” is more like it.
  -> Path381 => Loc73  вер=1 порядок=5

### Loc160 [обычная]
    Loc160-1: There was a syringe filled with a painkiller. You stuck the needle into your biceps and quickly squeezed its contents into your body. The effect was immediate -…
    эффект: P3(Health) = {[p3]+[p39]*([p39]<30)+30*([p39]>=30)}
  -> Path418 => Loc105  вер=1 порядок=1
       текст: Drop the bag

## Анализ
- стартовых: [51]
- концовки: {59: 'ПРОВАЛ', 66: 'СМЕРТЬ', 126: 'ПРОВАЛ', 142: 'УСПЕХ', 143: 'УСПЕХ', 148: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: [35]
