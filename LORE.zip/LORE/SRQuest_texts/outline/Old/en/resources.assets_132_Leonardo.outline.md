# Квест (формат 1111111126)
Сложность 70; стартовая локация: [1]; путей по умолчанию: 1

## Параметры
- P1 'Fatigue' [1..4] тип=обычный
    старт: [1]
    [1..1] You feel fresh as paint!
    [2..2] You aren't tired
    [3..3] You are tired
    [4..4] You are fatigued
    критическое: Сообщение достижения критического значения параметром 17
- P2 'Your abilities:' [0..1] тип=обычный
    старт: [1]
    [0..1] Your abilities:
    критическое: Сообщение достижения критического значения параметром 1
- P3 'Imagination' [1..6] тип=обычный
    старт: [3]
    [1..6] Imagination: <>
    критическое: Сообщение достижения критического значения параметром 2
- P4 'Precision' [1..6] тип=обычный
    старт: [3]
    [1..6] Precision: <>
    критическое: Сообщение достижения критического значения параметром 3
- P5 'Competence' [1..6] тип=обычный
    старт: [3]
    [1..6] Competence: <>
    критическое: Сообщение достижения критического значения параметром 4
- P6 'Painting topic' [0..2] тип=обычный
    старт: [0]
    [0..0] Painting theme - "Fantasy animal"
    [1..1] Painting theme - "Spaceship"
    [2..2] Painting theme - "Imaginative portrait"
    критическое: Сообщение достижения критического значения параметром 5
- P7 'Painting:' [0..1] тип=обычный
    старт: [1]
    [0..1] Your painting:
    критическое: Сообщение достижения критического значения параметром 6
- P8 'Appeal' [0..15] тип=обычный
    старт: [1]
    [0..15] Appeal: <>
    критическое: Сообщение достижения критического значения параметром 7
- P9 'Cleanness' [0..15] тип=обычный
    старт: [1]
    [0..15] Cleanness: <>
    критическое: Сообщение достижения критического значения параметром 8
- P10 'Composition and color' [0..15] тип=обычный
    старт: [1]
    [0..15] Composition and color: <>
    критическое: Сообщение достижения критического значения параметром 9
- P11 'You have:' [0..1] тип=обычный
    старт: [0]
    [0..1] You have:
    критическое: Сообщение достижения критического значения параметром 10
- P12 'Money' [0..9999999] тип=обычный деньги
    старт: [1000]
    [0..9999999] <> cr.
    критическое: Сообщение достижения критического значения параметром 11
- P13 '"Embroidery Manual"' [0..1] тип=обычный
    старт: [0]
    [0..1] "Embroidery Manual"
    критическое: Сообщение достижения критического значения параметром 12
- P14 '"S. Lem. Stories"' [0..1] тип=обычный
    старт: [0]
    [0..1] "S. Lem. Stories"
    критическое: Сообщение достижения критического значения параметром 13
- P15 '"World Art History"' [0..1] тип=обычный
    старт: [0]
    [0..1] "World Art History"
    критическое: Сообщение достижения критического значения параметром 15
- P16 '"How to Draw"' [0..1] тип=обычный
    старт: [0]
    [0..1] "How to Draw"
    критическое: Сообщение достижения критического значения параметром 14
- P17 'Description switcher (Ls)' [0..10] тип=обычный
    старт: [0]
    [0..10] Parameter 16: <>
    критическое: Сообщение достижения критического значения параметром 16
- P18 'x' [0..10] тип=обычный
    старт: [0]
    [0..10] 
    критическое: Сообщение достижения критического значения параметром 18
- P19 'Winner' [0..4] тип=обычный
    старт: [0]
    [0..0] Parameter 19: <>
    [1..1] Kasyak
    [2..2] Roo-bel
    [3..3] Khmelev
    [4..4] Kasyak
    критическое: Сообщение достижения критического значения параметром 19
- P20 'Time' [0..60] тип=обычный
    старт: [0]
    [0..60] <> minutes left before you must submit your work
    критическое: Сообщение достижения критического значения параметром 20
- P21 'Completeness' [0..4] тип=обычный
    старт: [0]
    [0..0] Completeness: 0%
    [1..1] Completeness: 25%
    [2..2] Completeness: 50%
    [3..3] Completeness: 75%
    [4..4] Completeness: 100%
    критическое: Сообщение достижения критического значения параметром 21
- P22 'Style' [0..4] тип=обычный
    старт: [0]
    [0..0] Style: Realism
    [1..1] Style: Surrealism
    [2..2] Style: Cubism
    [3..3] Style: Impressionism
    [4..4] Style: Primitivism
    критическое: Сообщение достижения критического значения параметром 22
- P23 'Paints' [0..2] тип=обычный
    старт: [0]
    [0..0] 
    [1..1] Common paints
    [2..2] Fluorescent paints
    критическое: Сообщение достижения критического значения параметром 23
- P24 'Read the book' [0..3] тип=обычный
    старт: [0]
    [0..0] Parameter 24: <>
    [1..1] Parameter 24: <>
    [2..2] Parameter 24: <>
    [3..3] Parameter 24: <>
    критическое: Сообщение достижения критического значения параметром 24
- P25 'Scores:' [0..1] тип=обычный
    старт: [0]
    [0..1] Scores:
    критическое: Сообщение достижения критического значения параметром 25
- P26 'Gaal' [1..10] тип=обычный
    старт: [1]
    [1..10] Leevi-taan's score: <>
    критическое: Сообщение достижения критического значения параметром 26
- P27 'Human' [1..10] тип=обычный
    старт: [1]
    [1..10] Satimov's score: <>
    критическое: Сообщение достижения критического значения параметром 27
- P28 'Maloq' [1..10] тип=обычный
    старт: [1]
    [1..10] B'Ugarra's score: <>
    критическое: Сообщение достижения критического значения параметром 28
- P29 'Total score 1' [0..100] тип=обычный
    старт: [0]
    [0..100] Your total score: <>
    критическое: Сообщение достижения критического значения параметром 29
- P30 'Total score 2' [0..100] тип=обычный
    старт: [0]
    [0..100] Your total score: <>
    критическое: Сообщение достижения критического значения параметром 30
- P31 'Total score 3' [0..100] тип=обычный
    старт: [0]
    [0..100] Your total score: <>
    критическое: Сообщение достижения критического значения параметром 31
- P32 'Joint' [0..1] тип=обычный
    старт: [0]
    [0..0] Kasyak has a joint
    [1..1] Kasyak doesn't have a joint
    критическое: Сообщение достижения критического значения параметром 44
- P34 "Kasyak's score" [1..30] тип=обычный
    старт: [1]
    [1..30] Kasyak's score: <>
    критическое: Сообщение достижения критического значения параметром 34
- P35 "Roo-bel's score" [1..30] тип=обычный
    старт: [1]
    [1..30] Roo-bel's score: <>
    критическое: Сообщение достижения критического значения параметром 35
- P36 "Khmelev's score" [1..30] тип=обычный
    старт: [1]
    [1..30] Khmelev's score: <>
    критическое: Сообщение достижения критического значения параметром 36
- P37 "Kasyak's score 2" [1..60] тип=обычный
    старт: [1]
    [1..60] Kasyak's score: <>
    критическое: Сообщение достижения критического значения параметром 37
- P38 "Roo-bel's score 2" [1..60] тип=обычный
    старт: [1]
    [1..60] Roo-bel's score: <>
    критическое: Сообщение достижения критического значения параметром 38
- P39 "Khmelev's score 2" [1..60] тип=обычный
    старт: [1]
    [1..60] Khmelev's score: <>
    критическое: Сообщение достижения критического значения параметром 39
- P40 "Kasyak's score 3" [1..90] тип=обычный
    старт: [1]
    [1..90] Kasyak's score: <>
    критическое: Сообщение достижения критического значения параметром 40
- P41 "Roo-bel's score 3" [1..90] тип=обычный
    старт: [1]
    [1..90] Roo-bel's score: <>
    критическое: Сообщение достижения критического значения параметром 41
- P42 "Khmelev's score 3" [1..90] тип=обычный
    старт: [1]
    [1..90] Khmelev's score: <>
    критическое: Сообщение достижения критического значения параметром 42
- P43 'drug1' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 43: <>
    критическое: Сообщение достижения критического значения параметром 43
- P44 'drug2' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 32: <>
    критическое: Сообщение достижения критического значения параметром 32
- P45 'drug3' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 45: <>
    критическое: Сообщение достижения критического значения параметром 45
- P46 'drug4' [0..1] тип=обычный
    старт: [0]
    [0..1] Parameter 46: <>
    критическое: Сообщение достижения критического значения параметром 46
- P47 'Timekeeper' [0..1000] тип=обычный
    старт: [0]
    [0..1000] Parameter 47: <>
    критическое: Сообщение достижения критического значения параметром 47
- P48 'Bought a small book' [0..2] тип=обычный
    старт: [0]
    [0..2] Parameter 48: <>
    критическое: Сообщение достижения критического значения параметром 48

## Локации и переходы

### Loc1 [СТАРТ]
    Loc1-1: You land at planet <ToPlanet>'s spaceport in the evening. It must have been very crowded here earlier in the afternoon - at least there are a lot of empty bottl…
    показ: P2,P3,P4,P5
    скрыт: P6,P7,P8,P9,P10,P11,P12,P17,P18,P19,P20,P21,P22,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48
  -> Path2 => Loc2  вер=1 порядок=4
       текст: Follow the peleng
       эффект: P17(Description switcher (Ls)) = {1}
  -> Path3 => Loc3  вер=1 порядок=5
       текст: I don't care about all these artists and painters. I'd rather have a bottle of beer and vamoose off of this wretched planet.

### Loc2 [обычная]
    выбор описания: {[p17]}
    Loc2-1: As you walk together to the gravicar, the peleng asks, "Do you have any questions about the competition?
    Loc2-2: You'll have three rivals: <clr>Leonid Khmelev<clrEnd>, a rather mediocre artist who usually tries to produce realistic pictures. <clr>Roo-bel<clrEnd> is a very …
    Loc2-3: "The competition has three judges. The first is a <clr>gaal named Leevi-taan<clrEnd>, a very famous <clr>realist artist<clrEnd>. The second is a <clr>human name…
    Loc2-4: "The competition consists of three rounds. In each round you are given a task and must produce a painting to please the judges. They assess the value of each pi…
    Loc2-5: "<clr>Imagination<clrEnd> makes your painting <clr>extraordinary and original<clrEnd>. <clr>Cleanness<clrEnd> depends on your <clr>precision<clrEnd>. Your <clr>…
    Loc2-6: "I'm not very good at art, so I can only say one thing. Style is very important. Before drawing something, think about whether or not it fits the chosen style. …
    показ: P11,P12
  -> Path5 => Loc4  вер=1 порядок=5
       текст: How will the competition be run?
       эффект: P17(Description switcher (Ls)) = {4}
  -> Path6 => Loc4  вер=1 порядок=2
       текст: Who's judging the competition?
       эффект: P17(Description switcher (Ls)) = {3}
  -> Path7 => Loc4  вер=1 порядок=6
       текст: What do the terms imagination, precision, and competence mean?
       эффект: P17(Description switcher (Ls)) = {5}
  -> Path8 => Loc76  вер=1
       текст: I don't have any more questions
       эффект: P17(Description switcher (Ls)) = {1}
  -> Path9 => Loc4  вер=1 порядок=1
       текст: Who will I be competing against?
       эффект: P17(Description switcher (Ls)) = {2}
  -> Path319 => Loc4  вер=1 порядок=7
       текст: Can you give me a piece of advice or some guidelines?
       эффект: P17(Description switcher (Ls)) = {6}

### Loc3 [ПРОВАЛ]
    Loc3-1: You have a good time at the nearest pub and fly away in the morning.
    скрыт: P2,P3,P4,P5

### Loc4 [пустая]
  -> Path4 => Loc2  вер=1000 порядок=5

### Loc5 [обычная]
    Loc5-1: There is nothing interesting in the room. A wide bed sits in the middle with an old nightstand next to it. A middle-sized book with paintings on the cover lies …
    эффект: P15("World Art History") +1
  -> Path11 => Loc6  вер=1 порядок=5
       текст: Read "How to Draw Without Drawing Even a Single Picture"
       ответ: On the first page, you read: "IT'S IMPOSSIBLE!" The rest of the book has information about colors, drawing, painting techniques, and other stuff like that.
       условия: P16("How to Draw") 1..1; P24(Read the book) 0..2
       эффект: P24(Read the book) +1
       эффект: P1(Fatigue) +1
       эффект: P5(Competence) +1
  -> Path12 => Loc6  вер=1 порядок=5
       текст: Read "S. Lem. Stories"
       ответ: "I'm sick and tired of all this fiction trash!" you think as you become engrossed in reading. After a while, you feel bored.
       условия: P14("S. Lem. Stories") 1..1; P24(Read the book) 0..2
       эффект: P24(Read the book) +1
       эффект: P1(Fatigue) +1
       эффект: P3(Imagination) +1
  -> Path13 => Loc6  вер=1 порядок=5
       текст: Read "Embroidery Manual"
       ответ: The book is about various embroidery hoops, needles, and threads. It's extremely boring except to people who are fanatical about embroidery. But after reading i…
       условия: P13("Embroidery Manual") 1..1; P24(Read the book) 0..2
       эффект: P24(Read the book) +1
       эффект: P1(Fatigue) +1
       эффект: P4(Precision) +1
  -> Path14 => Loc7  вер=1 порядок=9
       текст: Sleep
       эффект: P1(Fatigue) -1
  -> Path216 => Loc78  вер=1 порядок=4
       текст: Read "World Art History"
       условия: P15("World Art History") 1..1

### Loc6 [пустая]
  -> Path10 => Loc5  вер=1000 порядок=5
       текст: But the book aside
       условия: P1(Fatigue) 1..3
  -> Path264 => Loc7  вер=1 порядок=5
       текст: Put the book down and go to sleep
       условия: P1(Fatigue) 4..4
       эффект: P1(Fatigue) -1

### Loc7 [обычная]
    Loc7-1: You wake up ready for battle of every kind, even artistic combat. As soon as you've dressed and eaten your breakfast, your guide knocks at the door and escorts …
    Loc7-2: The lighting is very good. Humans and gaals make up most of the audience, but there are occasional representatives of the other races. The stage is right in fro…
    скрыт: P11,P12,P13,P14,P15,P16
  -> Path16 => Loc9  вер=1 порядок=5
       текст: Take the common paints
       условия: P23(Paints) 0..0
       эффект: P23(Paints) +1
       эффект: P8(Appeal) = {[p3]+[p23]-1}
       эффект: P9(Cleanness) = {[p4]-[p23]+1}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60} [показ]
       эффект: P21(Completeness) = {0} [показ]
       показ: P6
  -> Path17 => Loc9  вер=1 порядок=5
       текст: Take fluorescent paints
       условия: P23(Paints) 0..0
       эффект: P23(Paints) +2
       эффект: P8(Appeal) = {[p3]+[p23]+1}
       эффект: P9(Cleanness) = {[p3]+[p23]-1}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60} [показ]
       эффект: P21(Completeness) = 0 [показ]
       показ: P6

### Loc9 [обычная]
    Loc9-1: After choosing your paints, you look around. The other participants have already taken their places. You snatch a glimpse of Kasyak smoking a joint and Khmelev …
    показ: P7,P8,P9,P10
  -> Path19 => Loc10  вер=1 проходов<=1 порядок=6
       текст: Realism
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = {0}
  -> Path20 => Loc10  вер=1 проходов<=1 порядок=7
       текст: Surrealism
       эффект: P8(Appeal) +2
       эффект: P22(Style) = {1}
  -> Path21 => Loc10  вер=1 проходов<=1 порядок=4
       текст: Cubism
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) -1
       эффект: P22(Style) = {2}
  -> Path22 => Loc10  вер=1 проходов<=1 порядок=3
       текст: Impressionism
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = {3}
  -> Path23 => Loc10  вер=1 порядок=5
       текст: Primitivism
       эффект: P8(Appeal) +4
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) -1
       эффект: P22(Style) = {4}

### Loc10 [обычная]
    Loc10-1: In front of you is an empty canvas. What do you want to paint?
    показ: P22
  -> Path24 => Loc11  вер=1 порядок=4
       текст: Draw a sketch
       ответ: You've made an elaborate sketch of an animal. It will help you in your work.
       эффект: P9(Cleanness) +2
       эффект: P20(Time) = {[p20]-[5..12]}
  -> Path25 => Loc12  вер=1 порядок=5
       текст: I don't need any sketches! Let's paint!
       ответ: You take the palette and begin mixing the colors.
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1

### Loc11 [пустая]
  -> Path26 => Loc12  вер=1 порядок=5
       текст: Let's start using the paints!

### Loc12 [обычная]
    Loc12-1: The audience's eyes devour you. It's so difficult to work when somebody's watching!
    Loc12-2: But that's how real rangers paint!
    Loc12-3: Let's show'em how it's done!
    Loc12-4: It's getting hot. It would be nice to open the window, but it's too big. Ok, let's get back to work.
    показ: P7,P8,P9,P10
  -> Path27 => Loc13  вер=1 проходов<=1 порядок=2
       текст: Paint an animal's head
       условия: P20(Time) 1..60; P45(drug3) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P45(drug3) +1
       эффект: P21(Completeness) +1
  -> Path33 => Loc15  вер=1 проходов<=1 порядок=3
       текст: Paint the body
       условия: P20(Time) 1..60; P46(drug4) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P46(drug4) +1
       эффект: P21(Completeness) +1
  -> Path39 => Loc16  вер=1 проходов<=1 порядок=1
       текст: Paint the animal's limbs
       условия: P20(Time) 1..60; P44(drug2) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P44(drug2) +1
       эффект: P21(Completeness) +1
  -> Path45 => Loc17  вер=1 проходов<=1
       текст: Paint the background
       условия: P20(Time) 1..60; P43(drug1) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P43(drug1) +1
       эффект: P21(Completeness) +1
  -> Path52 => Loc21  вер=100 порядок=5
       текст: Hand in your work
       условия: логика {([p21]=4) or ([p20]<30)}
       эффект: P26(Gaal) = {(7*[p9]+2*[p10])/11,5}
       эффект: P27(Human) = {(7*[p8]+2*[p10])/11,5}
       эффект: P28(Maloq) = {(2*[p8]+2*[p9]+5*[p10])/11,5}
  -> Path307 => Loc17  вер=1 порядок=6
       текст: Repaint the background
       условия: P43(drug1) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path308 => Loc16  вер=1 порядок=9
       текст: Repaint the animal's limbs
       условия: P44(drug2) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path309 => Loc13  вер=1 порядок=7
       текст: Repaint the animal's head
       условия: P45(drug3) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path310 => Loc15  вер=1 порядок=8
       текст: Repaint the body
       условия: P46(drug4) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5

### Loc13 [обычная]
    Loc13-1: Some noise coming from the bleachers attracts your attention. A gaal is trying to communicate some point to a maloq who is just blinking dully, obviously not un…
  -> Path28 => Loc14  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide to take the brush and smear the head with paint.
       условия: логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path29 => Loc14  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: Using a medium-sized brush, you decide to quickly smear the head with paint and then touch it up with a smaller brush.
       условия: логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path30 => Loc14  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decided to take your time painting the head.
       условия: логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path31 => Loc14  вер=1 порядок=4
       текст: Paint with precision, taking your time.
       ответ: You feel it would be good to add detail to the head with a small brush.
       условия: логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc14 [пустая]
  -> Path83 => Loc30  вер=1 порядок=5
       текст: Paint a dragon's head
       ответ: Though it's not very original, it does look rather precise and accomplished.
       условия: логика {([p22]<>0 and [p22]<>2) or ([p22]=3 and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path84 => Loc30  вер=1 порядок=5
       текст: Paint the head of one of your maternal aunts
       ответ: The head fits perfectly and makes the creature look severe and furious
       условия: логика {([p22]<>3 and [p22]<>1) or ([p22]=0 and [p3]<>6)}
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path85 => Loc30  вер=1 порядок=5
       текст: Paint a teakettle instead of a head
       ответ: What a fresh and original idea!
       условия: логика {[p22]<>4 or ([p22]=1 and [p4]<>6)}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path257 => Loc91  вер=1 порядок=5
       текст: Paint the head of one of your maternal aunts
       ответ: You try to paint according to your plan, but what you produce doesn't look anything like the assigned theme. You end up with something that resembles a mating p…
       условия: логика {[p22]=3 or [p22]=1}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) -5
       эффект: P10(Composition and color) -2
  -> Path258 => Loc91  вер=1 порядок=5
       текст: Paint a dragon's head
       ответ: The dragon head looks terrible - it seems you've chosen the wrong style.
       условия: логика {[p22]=0 or [p22]=2}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) -2
       эффект: P10(Composition and color) -3
  -> Path259 => Loc91  вер=1 порядок=5
       текст: Paint a teakettle instead of a head
       ответ: The tea-kettle, which you faithfully painted in your chosen style, looks like a poor substitute for a headdress or a head. In any event, you fail to express you…
       условия: логика {[p22]=4}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path273 => Loc91  вер=1 порядок=5
       текст: Paint the head of one of your maternal aunts
       ответ: You succeed in rendering a very good likeness of the subject. Moreover, the painting has a twinge of humor to it. The red harmonizes nicely with the intensity o…
       условия: логика {[p22]=0 and [p3]=6}
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +1
  -> Path274 => Loc91  вер=1 порядок=5
       текст: Paint a dragon's head
       ответ: The monster's head painted impressionistically looks marvelous.
       условия: логика {[p22]=3 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +3
  -> Path275 => Loc91  вер=1 порядок=5
       текст: Paint a teakettle instead of a head
       ответ: You paint a very realistic teakettle. It transitions seamlessly into the neck - a very original and even charming look.
       условия: логика {[p22]=1 and [p4]=6}
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) +3

### Loc15 [обычная]
    Loc15-1: You've chosen a color and started to wonder how you should paint it all...
  -> Path34 => Loc18  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide to use a whitewashing brush to quickly paint the body.
       условия: логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path35 => Loc18  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You make up your mind to use a medium sized brush to quickly paint the animal's body and then add detail using a smaller brush.
       условия: логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path36 => Loc18  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to paint the animal's body slowly.
       условия: логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path37 => Loc18  вер=1 порядок=4
       текст: Paint with precision, taking your time.
       ответ: You decide that it will be okay to use a small brush to carefully paint the body - with all its feathers, spikes, and other features.
       условия: логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc16 [обычная]
    Loc16-1: You notice how Kasyak is working. He holds a huge brush in each of his four hands. With a wild expression on his face, he uses the brushes to daub here and ther…
  -> Path40 => Loc19  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide not to waste any time.
       условия: логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path41 => Loc19  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You don't think you should paint the limbs in detail.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path42 => Loc19  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to paint everything in an average way.
       условия: логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path43 => Loc19  вер=1 порядок=4
       текст: Paint everything as precisely as possible.
       ответ: You've done everything perfectly.
       условия: логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc17 [обычная]
    Loc17-1: You observe Roo-bel as he paints. Looking more closely, you see that, instead of arms, he's painting some sort of sticks with hooks. What an original design!
  -> Path46 => Loc20  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide to quickly gloss over the background.
       условия: логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path47 => Loc20  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You want to work in the background more thoroughly.
       условия: логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path48 => Loc20  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to work on the background more thoroughly.
       условия: логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path49 => Loc20  вер=1 порядок=4
       текст: Paint with precision
       ответ: You decide to work on the background.
       условия: логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc18 [пустая]
  -> Path86 => Loc31  вер=1 порядок=5
       текст: Paint the body of a dragon
       ответ: The dragon's body is painted very precisely. It looks powerful but rather ordinary.
       условия: логика {([p22]<>1 and [p22]<>4) or ([p22]=0 and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path87 => Loc31  вер=1 порядок=5
       текст: Paint a couple more heads instead of the body
       ответ: Three heads growing straight out of the legs look very extraordinary indeed!
       условия: логика {([p22]<>0 and [p22]<>3) or ([p22]=1 and [p3]<>6)}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path88 => Loc31  вер=1 порядок=5
       текст: Draw the body of a coiled snake
       ответ: The spiral coil looks very stylish and fits well in the overall composition.
       условия: логика {[p22]<>2 or ([p22]=4 and [p5]<>6)}
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path261 => Loc92  вер=1 порядок=5
       текст: Paint a couple more heads instead of the body
       ответ: Your style is too realistic to express all your ideas - you'll have to repaint everything. Unfortunately, the different layers of paint smear together, producin…
       условия: логика {[p22]=0 or [p22]=3}
       эффект: P9(Cleanness) -2
       эффект: P10(Composition and color) -4
  -> Path262 => Loc92  вер=1 порядок=5
       текст: Paint the body of a dragon
       ответ: It is impossible to paint a dragon in the chosen style. The result is very strange. But that's not all - your composition leaves much to be desired.
       условия: логика {[p22]=1 or [p22]=4}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) -4
  -> Path263 => Loc92  вер=1 порядок=5
       текст: Draw the body of a coiled snake
       ответ: Snake coils painted in the cubist style will always look grotesque and sloppy.
       условия: логика {[p22]=2}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path276 => Loc31  вер=1 порядок=5
       текст: Paint a couple more heads instead of the body
       ответ: Using your knowledge of anatomy, you draw terrifying - and very realistic - muzzles. The painting's general surrealist style really catches the eye.
       условия: логика {[p22]=1 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +1
  -> Path277 => Loc31  вер=1 порядок=5
       текст: Paint the body of a dragon
       ответ: The fanciful dragon's body is very precise, beautiful, and realistic. As an artist, you can really proud of this great work of art!
       условия: логика {[p22]=0 and [p3]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +1
  -> Path278 => Loc31  вер=1 порядок=5
       текст: Draw the body of a coiled snake
       ответ: The classy coils look very original in your painting style. They are fantastic and harmonize well with the background.
       условия: логика {[p22]=4 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +3

### Loc19 [пустая]
  -> Path80 => Loc29  вер=1 порядок=5
       текст: Paint serpentine hands and legs
       ответ: Strange, but original!
       условия: логика {[p22]<>0 or ([p22]=1 and [p3]<>6)}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path81 => Loc29  вер=1 порядок=5
       текст: Paint hooked legs and wings
       ответ: It's not very original, but it is precise.
       условия: логика {[p22]<>3 or ([p22]=0 and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path82 => Loc29  вер=1 порядок=5
       текст: Paint dragon legs and wings
       ответ: It's not very picturesque, but it's chic and has a beautiful outline.
       условия: логика {([p22]<>1 and [p22]<>4) or ([p22]=3 and [p3]<>6)}
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path253 => Loc90  вер=1 порядок=5
       текст: Paint hooked legs and wings
       ответ: Although impressionist paintings are usually full of energy, sadly, your work is just too strange.
       условия: логика {[p22]=3}
       эффект: P9(Cleanness) -6
  -> Path254 => Loc90  вер=1 порядок=5
       текст: Paint serpentine hands and legs
       ответ: This topic isn't a good match to your painting style. Unfortunately, all your attempts to paint fail miserably.
       условия: логика {[p22]=0 or [p22]=2}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path255 => Loc90  вер=1 порядок=5
       текст: Paint dragon legs and wings
       ответ: This topic isn't a good match to your painting style. Unfortunately, all your attempts to paint fail miserably.
       условия: логика {[p22]=1 or [p22]=4}
       эффект: P8(Appeal) -3
       эффект: P10(Composition and color) -3
  -> Path270 => Loc29  вер=1 порядок=5
       текст: Paint serpentine hands and legs
       ответ: You paint creatively and the result is really outstanding!
       условия: логика {[p22]=1 and [p3]=6}
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) +3
  -> Path271 => Loc29  вер=1 порядок=5
       текст: Paint hooked legs and wings
       ответ: You carefully paint according to your plan and achieve an almost photographic likeness!
       условия: логика {[p22]=0 and [p4]=6}
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +3
  -> Path272 => Loc29  вер=1 порядок=5
       текст: Paint dragon legs and wings
       ответ: You give full scope to your imagination and begin painting with vivid, clean colors. They blend together nicely and the result is enchanting.
       условия: логика {[p22]=3 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P10(Composition and color) +4

### Loc20 [пустая]
  -> Path77 => Loc28  вер=1 порядок=5
       текст: Paint outerspace
       ответ: You do your best to paint a picturesque representation of outerspace with stars, nebulae, and other things like that in the background. Fortunately, you've seen…
       условия: логика {[p22]<>2 and [p22]<>1}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path78 => Loc28  вер=1 порядок=5
       текст: Paint a landscape
       ответ: The recall one of your favorite earth landscapes and try to recreate it.
       условия: логика {[p22]<>4}
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path79 => Loc28  вер=1 порядок=5
       текст: Fill the background with color
       ответ: Don't worry about painting something in detail. Better do with precision!
       условия: логика {[p22]<>3 and [p22]<>0}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path249 => Loc89  вер=1 порядок=5
       текст: Paint a landscape
       ответ: The landscape is not very impressive. It's too vivid. It attracts too much attention to the background. It's also a very careless piece of work.
       условия: логика {[p22]=4}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path250 => Loc89  вер=1 порядок=5
       текст: Paint outerspace
       ответ: It's almost impossible to draw outerspace in the style you chose. It looks very strange and the colors are lacking.
       условия: логика {([p22]=2 or [p22]=1)}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path251 => Loc89  вер=1 порядок=5
       текст: Fill the background with color
       ответ: The color wash on the background of your painting is absolutely out of place. It looks unoriginal and absurd.
       условия: логика {([p22]=3 or [p22]=0)}
       эффект: P8(Appeal) -3
       эффект: P10(Composition and color) -3
  -> Path265 => Loc89  вер=999 порядок=5
       текст: Fill the background with color
       ответ: You think it over and then mix a beautiful color that fits your work perfectly. You use it to fill in the background.
       условия: логика {[p22]=2 and [p5]=6}
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +3
  -> Path266 => Loc89  вер=999 порядок=5
       текст: Paint a landscape
       ответ: You spent the whole night reading and the result is evident - you've done your best and painted a wonderful landscape in the background, following all the rules…
       условия: логика {[p22]=0 and [p5]=6}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +3
  -> Path267 => Loc89  вер=999 порядок=5
       текст: Paint outerspace
       ответ: Your time spent reading fantasy novels about space travel all night long was not in vain. You surrender the reins to your imagination and produce a wonderful pi…
       условия: логика {[p22]=3 and [p3]=6}
       эффект: P8(Appeal) +3
       эффект: P10(Composition and color) +3
  -> Path268 => Loc89  вер=999 порядок=5
       текст: Paint a landscape
       ответ: You try to imagine painting a fantastic landscape in the background, but it looks like what you might see in a state of delirium. However, the realism of your p…
       условия: логика {[p22]=1 and [p3]=6}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +1
  -> Path269 => Loc89  вер=999 порядок=5
       текст: Fill the background with color
       ответ: You decide to fill the background with color. It turns out to be quite idyllic; it makes your beast look better by contrasting one color with another.
       условия: логика {[p22]=4 and [p5]=6}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +3

### Loc21 [обычная]
    Loc21-1: You stand up from your easel and remove your work. Then you place it in the specially prepared slot. It is immediately sent to the judges' panel. The bleachers …
    эффект: P43(drug1) = {0}
    эффект: P44(drug2) = {0}
    эффект: P45(drug3) = {0}
    эффект: P46(drug4) = {0}
    скрыт: P6,P7,P8,P9,P10,P20,P21,P22,P23,P26,P27,P28
    показ: P25
  -> Path53 => Loc22  вер=1000 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "Ingenious! Marvelous! This piece is wonderfully precise; the composition is clear, and the color is fantastic! What more can I say! It…
       условия: P21(Completeness) 4..4; P26(Gaal) 10..10; логика {[p21]=4}
       показ: P26
  -> Path55 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "Magnificent! The work is very clean; it's composition and color are worth a {9}!"
       условия: P21(Completeness) 4..4; P26(Gaal) 9..9; логика {[p21]=4}
       показ: P26
  -> Path56 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "A very nice piece. It's painted in my favorite style, and with great precision. It's worth an {8}."
       условия: P21(Completeness) 4..4; P26(Gaal) 8..8; логика {[p21]=4}
       показ: P26
  -> Path57 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "This is good work. I like it. The colors are pleasant, and all lines are painted carefully and with precision. I give it a {7}!"
       условия: P21(Completeness) 4..4; P26(Gaal) 7..7; логика {[p21]=4}
       показ: P26
  -> Path58 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / The quality of work here is obviously above average, but it's still rather mediocre. I give it a {6}."
       условия: P21(Completeness) 4..4; P26(Gaal) 6..6; логика {[p21]=4}
       показ: P26
  -> Path59 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "This work is mediocre in every respect, and there's nothing of value in it. I give it a {5}."
       условия: P21(Completeness) 4..4; P26(Gaal) 5..5; логика {[p21]=4}
       показ: P26
  -> Path60 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "The quality of work here is below average. The composition leaves much to be desired even though each participant was given plenty of …
       условия: P21(Completeness) 4..4; P26(Gaal) 4..4; логика {[p21]=4}
       показ: P26
  -> Path61 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "This is bad work. I don't like it at all! No precision whatsoever. It's worth no more than {3} out of 10."
       условия: P21(Completeness) 4..4; P26(Gaal) 3..3; логика {[p21]=4}
       показ: P26
  -> Path62 => Loc22  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Leevi-taan's score: /  / "How disgusting! How did this guy even get into the competition? He can hardly hold the brush in his hand properly! [p26]!
       условия: P21(Completeness) 4..4; P26(Gaal) 1..2; логика {[p21]=4}
       показ: P26
  -> Path115 => Loc26  вер=100 порядок=5
       текст: Wait for the first judge's score
       ответ: Your work isn't even judged, because it wasn't finished. You get {0} points!
       условия: P6(Painting topic) 0..0; P21(Completeness) 0..3
       эффект: P23(Paints) -2
       эффект: P29(Total score 1) = {0} [показ]
  -> Path140 => Loc48  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Your work isn't even judged, because it wasn't finished. You get {0} points!
       условия: P6(Painting topic) 1..1; P21(Completeness) 0..3
       эффект: P23(Paints) -2
       эффект: P30(Total score 2) = {[p29]} [показ]
  -> Path208 => Loc72  вер=1 порядок=5
       текст: Wait for the first judge's score
       ответ: Your work isn't even judged, because it wasn't finished. You get {0} points!
       условия: P6(Painting topic) 2..2; P21(Completeness) 0..3
       эффект: P31(Total score 3) = {0} [показ]

### Loc22 [пустая]
  -> Path63 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "It's a real masterpiece of contemporary art! Just look at these expressive strokes! This work is full of energy! Fantastic! It's no less …
       условия: P27(Human) 10..10
       показ: P27
  -> Path64 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "Excellent work! I haven't seen anything this good for ages! My congratulations to its creator! I give it a {9}!"
       условия: P27(Human) 9..9
       показ: P27
  -> Path65 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "This is decent work. The new generation's expressive painting. Very impressive. Of course, there are some flaws, but the work is worth an…
       условия: P27(Human) 8..8
       показ: P27
  -> Path66 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "This work is worthy of respect. The brush strokes are powerful, and the colors are inviting to the eye. It's good. I give it a {7}!"
       условия: P27(Human) 7..7
       показ: P27
  -> Path67 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "It's above average, but hardly ideal. Why do you paint in such an academic fashion, my fellow?  I give it a {6}."
       условия: P27(Human) 6..6
       показ: P27
  -> Path68 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "This work is average. It's neither fish nor fowl, as they say, but there is something special about it - though I can't explain what it i…
       условия: P27(Human) 5..5
       показ: P27
  -> Path69 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "This work is below average. It's unoriginal, and it's trying to be academic. {4} out of 10."
       условия: P27(Human) 4..4
       показ: P27
  -> Path70 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "This is bad work. Absolutely unoriginal. Where's your creativity, man? It's a {3}!
       условия: P27(Human) 3..3
       показ: P27
  -> Path71 => Loc24  вер=1 порядок=5
       текст: Wait for the second judge's score
       ответ: Satimov's score: /  / "I have nothing to say. Words can't convey my feelings. [p27]."
       условия: P27(Human) 1..2
       показ: P27

### Loc24 [пустая]
  -> Path72 => Loc25  вер=1 порядок=5
       текст: Wait for the third judge's score
       ответ: B'ugarra's score: /  / "Err... Hmmm... Good... Eeeeh, I like it! [p28]."
       условия: P28(Maloq) 8..10
       показ: P28
  -> Path73 => Loc25  вер=1 порядок=5
       текст: Wait for the third judge's score
       ответ: B'Ugarra's score: /  / "Hmmm... Errrr... [p28]."
       условия: P28(Maloq) 5..7
       показ: P28
  -> Path74 => Loc25  вер=1 порядок=5
       текст: Wait for the third judge's score
       ответ: B'Ugarra's score: /  / "Whoaaa! Bad! Whoaaa! [p28]."
       условия: P28(Maloq) 1..4
       показ: P28

### Loc25 [пустая]
  -> Path75 => Loc26  вер=1000 порядок=5
       текст: Results of the first round
       условия: P6(Painting topic) 0..0
       эффект: P23(Paints) -2
       эффект: P29(Total score 1) = {[p26]+[p28]+[p27]} [показ]
       показ: P25,P26,P27,P28
  -> Path139 => Loc48  вер=1 порядок=5
       текст: Results of the second round
       условия: P6(Painting topic) 1..1
       эффект: P23(Paints) -2
       эффект: P30(Total score 2) = {[p29]+[p26]+[p28]+[p27]} [показ]
       показ: P25,P26,P27,P28
  -> Path204 => Loc72  вер=1 порядок=5
       текст: Results for the third round
       ответ: You can see a message on the overhead digital display: /  / "Results for the third round: /  / <Ranger>'s score [p31] /  / Kasyak's score: [p40] /  / Roo-bel's …
       условия: P6(Painting topic) 2..2; P32(Joint) 1..1; логика {[p32]=1}
       эффект: P31(Total score 3) = {[p26]+[p28]+[p27]+[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(5 to 12)+[p37]} [показ]
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]} [показ]
       эффект: P42(Khmelev's score 3) = {(10 to 20)+[p39]} [показ]
       показ: P25,P26,P27,P28
  -> Path205 => Loc72  вер=1 порядок=5
       текст: Results for the third round
       ответ: You can see a message on the overhead digital display: /  / "Results for the third round: /  / <Ranger>'s score [p31] /  / Kasyak's score: [p40] /  / Roo-bel's …
       условия: P6(Painting topic) 2..2; P32(Joint) 0..0; логика {[p32]=0}
       эффект: P31(Total score 3) = {[p26]+[p28]+[p27]+[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(19 to 24)+[p37]}
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]}
       эффект: P42(Khmelev's score 3) = {(10 to 20)+[p39]}
       показ: P25,P26,P27,P28

### Loc26 [обычная]
    Loc26-1: You can see a message on the overhead digital display: / "Results of the first round: / <Ranger>'s score: [p29] / Kasyak's score: [p34] / Roo-bel's score: [p35]…
    эффект: P34(Kasyak's score) = {19 to 23} [показ]
    эффект: P35(Roo-bel's score) = {15 to 21} [показ]
    эффект: P36(Khmelev's score) = {10 to 23} [показ]
    скрыт: P25,P26,P27,P28
  -> Path76 => Loc98  вер=1 порядок=5
       текст: Go to your room
       условия: логика {[p13]>0 or [p14]>0 or [p15]>0}
       эффект: P1(Fatigue) -1
       эффект: P17(Description switcher (Ls)) = 1
       скрыт: P29,P34,P35,P36
  -> Path328 => Loc98  вер=1 проходов<=1 порядок=5
       текст: Go to your room
       условия: логика {[p13]=0 and [p14]=0 and [p15]=0}
       эффект: P17(Description switcher (Ls)) = 2

### Loc27 [обычная] визитов<=1
    Loc27-1: Everything is like yesterday morning: several journalists are waiting for you, the to-the-point peleng takes you to the exhibition hall, and you sit near the ea…
  -> Path89 => Loc32  вер=1 порядок=4
       текст: Take the common paints
       ответ: You take the common paints - there's no need to show off. /  / The lights go out and the master of ceremonies appears on the stage. He talks a lot about playing…
       эффект: P6(Painting topic) +1 [показ]
       эффект: P8(Appeal) = {[p3]+[p23]-1}
       эффект: P9(Cleanness) = {[p4]-[p23]+1}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60} [показ]
       эффект: P21(Completeness) = {0} [показ]
       эффект: P23(Paints) +1 [показ]
  -> Path90 => Loc32  вер=1 порядок=5
       текст: Take the fluorescent paints
       ответ: You choose the set of vivid fluorescent paints - it will certainly be more interesting to use these instead of the common paints. /  / The lights go out and the…
       эффект: P6(Painting topic) +1 [показ]
       эффект: P8(Appeal) = {[p3]+[p23]}
       эффект: P9(Cleanness) = {[p3]+[p23]}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60} [показ]
       эффект: P21(Completeness) = {0} [показ]
       эффект: P23(Paints) +2 [показ]

### Loc28 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path50 => Loc12  вер=1 порядок=5
       текст: Continue working

### Loc29 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path44 => Loc12  вер=1 порядок=5
       текст: Continue working
       эффект: P44(drug2) +1

### Loc30 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path32 => Loc12  вер=1 порядок=5
       текст: Continue working
       эффект: P31(Total score 3) +1

### Loc31 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path38 => Loc12  вер=1 порядок=5
       текст: Continue working
       эффект: P30(Total score 2) +1

### Loc32 [пустая]
    показ: P7,P8,P9,P10
  -> Path91 => Loc33  вер=1 порядок=6
       текст: Realism
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = 0
  -> Path92 => Loc33  вер=1 порядок=7
       текст: Surrealism
       эффект: P8(Appeal) +2
       эффект: P22(Style) = 1
  -> Path93 => Loc33  вер=1 порядок=4
       текст: Cubism
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) -1
       эффект: P22(Style) = 2
  -> Path94 => Loc33  вер=1 порядок=3
       текст: Impressionism
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = 3
  -> Path95 => Loc33  вер=1 порядок=5
       текст: Primitivism
       эффект: P8(Appeal) +4
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) -1
       эффект: P22(Style) = 4

### Loc33 [обычная]
    Loc33-1: An absolutely empty canvas is in front of you. You can make a sketch with a pencil first. Or you can use the paint right away.
    показ: P2,P3,P4,P5,P22
  -> Path96 => Loc35  вер=1 порядок=4
       текст: Draw a sketch
       ответ: You pick up a pencil and sketch your best rendition of a highly dangerous destroyer as precisely as possible.
       эффект: P9(Cleanness) +2
       эффект: P20(Time) = {[p20]-[5..12]}
  -> Path99 => Loc34  вер=1 порядок=5
       текст: Who cares about this painting? - I don't need it!
       ответ: You mix the paints and thoughtfully passed the brush over the canvas.

### Loc34 [обычная]
    Loc34-1: You sit in front of the easel. The audience looks at you with curiosity. / "It's like being in the zoo!" you think crossly.
    Loc34-2: You continue to paint a spaceship, despite the irritating curiosity of the audience.
    Loc34-3: Leevi-taan and Satimov look at Kasyak working and whisper enthusiastically to each other. B'Ugarra looks around indifferently. Obviously, he has nothing to do.
    Loc34-4: The audience's eyes devour you. It's so difficult to work when somebody's watching!
  -> Path100 => Loc36  вер=1 проходов<=1 порядок=2
       текст: Paint a flight deck
       условия: P20(Time) 1..60; P43(drug1) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P43(drug1) +1
       эффект: P21(Completeness) +1
  -> Path101 => Loc37  вер=1 проходов<=1
       текст: Paint a main deck
       условия: P20(Time) 1..60; P44(drug2) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P44(drug2) +1
       эффект: P21(Completeness) +1
  -> Path102 => Loc38  вер=1 проходов<=1 порядок=4
       текст: Paint wings, guns, and other parts.
       условия: P20(Time) 1..60; P45(drug3) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P45(drug3) +1
       эффект: P21(Completeness) +1
  -> Path103 => Loc39  вер=1 проходов<=1 порядок=1
       текст: Paint the background
       условия: P20(Time) 1..60; P46(drug4) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P46(drug4) +1
       эффект: P21(Completeness) +1
  -> Path138 => Loc21  вер=100 порядок=5
       текст: Hand in your work
       условия: логика {([p21]=4) or ([p20]<30)}
       эффект: P26(Gaal) = {(7*[p9]+2*[p10])/11,5}
       эффект: P27(Human) = {(7*[p8]+2*[p10])/11,5}
       эффект: P28(Maloq) = {(2*[p8]+2*[p9]+5*[p10])/11,5}
  -> Path311 => Loc36  вер=1 порядок=7
       текст: Repaint the flight deck
       условия: P43(drug1) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path312 => Loc37  вер=1 порядок=8
       текст: Repaint the main deck
       условия: P44(drug2) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path313 => Loc38  вер=1 порядок=9
       текст: Repaint the wings, guns, and other parts
       условия: P45(drug3) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path314 => Loc39  вер=1 порядок=6
       текст: Repaint the background
       условия: P46(drug4) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5

### Loc35 [пустая]
  -> Path97 => Loc34  вер=1 порядок=5
       текст: Now it's time to apply the paint.
       ответ: You hold the brush tightly. You pick up the palette and accidentally topple a can of black paint all over your canvas. What a disaster! It seems you've wasted a…
       эффект: P9(Cleanness) -2
  -> Path98 => Loc34  вер=2 порядок=5
       текст: Now it's time to apply the paint.
       ответ: Gripping the brush tightly, you mix the paints and daub the brush all over the canvas.

### Loc36 [обычная]
    Loc36-1: You remember an artist you saw once at a spaceport. He was drawing a spaceship from life. At the time, you thought that he was simply causing trouble - and that…
  -> Path104 => Loc40  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide not to take it too seriously.
       условия: логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path105 => Loc40  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You decide not to waste too much time on the piece, but you still try to use as much precision as possible.
       условия: логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path106 => Loc40  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to concentrate on painting the flight deck.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path107 => Loc40  вер=1 порядок=4
       текст: Paint with precision, taking your time.
       ответ: You decide to try your best.
       условия: логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc37 [обычная]
    Loc37-1: You remember that in your boyhood you made small models of Coalition and Klissan spaceships.
  -> Path113 => Loc42  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: "There's no point in taking this seriously - it's just a waste of time," you think to yourself.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path114 => Loc42  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You decide not to spend too much time, but to try to be a bit more precise.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path116 => Loc42  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to paint everything in an average way.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path117 => Loc42  вер=1 порядок=4
       текст: Paint with precision, taking your time.
       ответ: You think it will be okay to use a small brush to paint everything in precise detail.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc38 [обычная]
    Loc38-1: After searching your memory, you can recall how your artist friend painted wings.
  -> Path122 => Loc44  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: "It's no use painting everything in great detail - that's not what's important!" you tell yourself.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path123 => Loc44  вер=1 порядок=2
       текст: Paint quickly, but don't forget about precision
       ответ: Time is running out, so you'd better hurry up.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path124 => Loc44  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to take your time and paint everything carefully.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path125 => Loc44  вер=1 порядок=4
       текст: Paint with precision, taking your time.
       ответ: You have enough time to paint everything with a small brush.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc39 [обычная]
    Loc39-1: Background is a funny thing. Sometimes it's there, sometimes it's not.
  -> Path130 => Loc46  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: "The background is of no importance. I'm not going to waste any time on it!" you think to yourself, as usual.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path131 => Loc46  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You got to use a big brush to create an underpainting and then lightly rework it.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path132 => Loc46  вер=1 порядок=3
       текст: Paint regularly
       ответ: You still have time, so you decide to paint everything relatively carefully.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path133 => Loc46  вер=1 порядок=4
       текст: Paint carefully and diligently
       ответ: You decide to use a small brush to paint the background with fine strokes.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc40 [пустая]
  -> Path109 => Loc41  вер=1 порядок=5
       текст: Paint a flight deck that looks like a gaalian destroyer
       ответ: Finally, you see a beautiful and precisely painted flight deck!
       условия: логика {([p22]<>3 and [p22]<>1) or ([p22]=0 and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path110 => Loc41  вер=1 порядок=5
       текст: Paint the Klissan flight deck you've seen in the Gaaldock Museum
       ответ: The stylish, metallic flight deck with greenish reflections looks wonderful, and the composition as a whole is also good.
       условия: логика {[p22]<>4 or ([p22]=1 and [p4]<>6)}
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path111 => Loc41  вер=1 порядок=5
       текст: Paint something random
       ответ: It's a little absurd, but it's very original!
       условия: логика {([p22]<>3 and [p22]<>1) or ([p22]=0 and [p3]<>6)}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path280 => Loc93  вер=999 порядок=5
       текст: Paint a flight deck that looks like a gaalian destroyer
       ответ: You try to depict a flight deck in your chosen style, but you just can't. After several failed attempts to repair your mistake, you choose the easy way out and …
       условия: логика {[p22]=3 or [p22]=1}
       эффект: P9(Cleanness) -5
       эффект: P10(Composition and color) -1
  -> Path281 => Loc93  вер=999 порядок=5
       текст: Paint the Klissan flight deck you've seen in the Gaaldock Museum
       ответ: Primitivism is just not very well suited to painting such detailed objects. What you end up producing hardly resembles a flight deck. The colors are also wild a…
       условия: логика {[p22]=4}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path282 => Loc93  вер=999 порядок=5
       текст: Paint something random
       ответ: It's almost impossible to paint something abstract and fantastic in the realistic style. And you fail when you tried. You produced a rather ordinary cabin that …
       условия: логика {[p22]=0 or [p22]=2}
       эффект: P8(Appeal) -4
       эффект: P10(Composition and color) -2
  -> Path283 => Loc93  вер=999 порядок=5
       текст: Paint a flight deck that looks like a gaalian destroyer
       ответ: You begin to draw the cabin very precisely, considering the effects of lighting and shadows. Then you finish the cabin with enigmatic design. All in all is look…
       условия: логика {[p22]=0 and [p3]=6}
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +3
  -> Path284 => Loc93  вер=999 порядок=5
       текст: Paint the Klissan flight deck you've seen in the Gaaldock Museum
       ответ: A bit of surrealism combined with the familiar green steel design looks brilliant!
       условия: логика {[p22]=1 and [p4]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
  -> Path285 => Loc93  вер=9999 порядок=5
       текст: Paint something random
       ответ: The surrealist style is a suitable match for an improvisation like this. In short order, a wonderful and fantastic cabin appears on your canvas.
       условия: логика {([p22]=3 or [p22]=4) and [p5]=6}
       эффект: P8(Appeal) +3
       эффект: P10(Composition and color) +3

### Loc41 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path108 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc42 [пустая]
  -> Path118 => Loc43  вер=1 порядок=5
       текст: Remember how you used to paint ships as a child
       ответ: The result turned out to be a strange sight.
       условия: логика {([p22]<>0 and [p22]<>2) or ([p22]=4 and [p5]<>6)}
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path119 => Loc43  вер=1 порядок=5
       текст: Paint some stylish stickers on the main hull
       ответ: The colorful part of the spaceship fits beautifully into its surroundings.
       условия: логика {[p22]<>4 or ([p22]=1 and [p4]<>6)}
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path120 => Loc43  вер=1 порядок=5
       текст: Paint the main part to look like an ancient stealth aircraft.
       ответ: This shining, precise outline of your stealth aircraft looks brilliant! /  / You notice Leonid screwing up his face after glancing at your painting.
       условия: логика {[p22]<>1 or (([p22]=0 or [p22]=2) and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path287 => Loc94  вер=999 порядок=5
       текст: Remember how you used to paint ships as a child
       ответ: You spend some time recollecting your childhood and eventually succeed in recreating your fantasies. The result is impressive!
       условия: логика {[p22]=4 and [p5]=6}
       эффект: P8(Appeal) +3
       эффект: P10(Composition and color) +3
  -> Path288 => Loc94  вер=999 порядок=5
       текст: Remember how you used to paint ships as a child
       ответ: You fail to realistically depict your childhood fantasies. You end up with a strange and badly-positioned figure that looks rather stupid.
       условия: логика {[p22]=0 or [p22]=2}
       эффект: P8(Appeal) -2
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) -3
  -> Path289 => Loc94  вер=999 порядок=5
       текст: Paint some stylish stickers on the main hull
       ответ: Your surreal wing design is a total success. And the color matches perfectly!
       условия: логика {[p22]=1 and [p4]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +3
  -> Path290 => Loc94  вер=999 порядок=5
       текст: Paint some stylish stickers on the main hull
       ответ: You finally manage to create a curious design on the wings, but it looks a bit mangled and even a bit stupid. You have to repaint it, but the wet paints intermi…
       условия: логика {[p22]=4}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path291 => Loc94  вер=999 порядок=5
       текст: Paint the main part to look like an ancient stealth aircraft.
       ответ: There is no possibility of painting a cubic form in the surrealistic style. You fail to produce anything decent.
       условия: логика {[p22]=1}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path292 => Loc94  вер=999 порядок=5
       текст: Paint the main part to look like an ancient stealth aircraft.
       ответ: You've put for the effort and can now enjoy a perfect result.
       условия: логика {([p22]=0 or [p22]=2) and [p3]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2

### Loc43 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path112 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc44 [пустая]
  -> Path126 => Loc45  вер=1 порядок=5
       текст: Paint wings that resemble those of the Faeyan Ranger Corps and add some other cool features
       ответ: Now you have very nice and neat purple winglets on both sides of your ship.
       условия: логика {[p22]<>4 or ([p22]=0 and [p5]<>6)}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path127 => Loc45  вер=1 порядок=5
       текст: Paint butterfly wings.
       ответ: The gaal will definitely like it! It looks so stylish!
       условия: логика {[p22]<>4 or ([p22]=3 and [p3]<>6)}
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path128 => Loc45  вер=1 порядок=5
       текст: Don't paint wings. Instead, paint an aggressive-looking hull with spikes on the bottom
       ответ: Now that's an interesting approach.
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path294 => Loc94  вер=999 порядок=5
       текст: Paint wings that resemble those of the Faeyan Ranger Corps and add some other cool features
       ответ: The wings painted in the primitivist style look very strange. The only thing that looks remotely faeyan about them is their color. But even the color doesn't re…
       условия: логика {[p22]=4}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path295 => Loc94  вер=999 порядок=5
       текст: Paint wings that resemble those of the Faeyan Ranger Corps and add some other cool features
       ответ: The wings look very natural. The 	checkered light and shade is marvelous. That all-nighter of book reading was not in vain!
       условия: логика {([p22]=0) and [p5]=6}
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +1
  -> Path296 => Loc94  вер=999 порядок=5
       текст: Paint butterfly wings.
       ответ: The beautiful and fantastic wings are in perfect harmony with the rest of the picture. They look very artistic. Even though the wings are shaped like those on a…
       условия: логика {[p22]=3 and [p3]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +3
  -> Path297 => Loc94  вер=999 порядок=5
       текст: Paint butterfly wings.
       ответ: The vivid wings spice up the painting a bit, but the iridescent paint kills all the other details and attracts too much attention to itself. Your precision also…
       условия: логика {[p22]=4}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) -4
       эффект: P10(Composition and color) -3
  -> Path298 => Loc94  вер=999 порядок=5
       текст: Don't paint wings. Instead, paint an aggressive-looking hull with spikes on the bottom
       ответ: Your creation is formidable and looks threatening. You are quite satisfied with the result.
       условия: логика {([p22]=4 or [p22]=1) and [p3]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
  -> Path299 => Loc94  вер=999 порядок=5
       текст: Don't paint wings. Instead, paint an aggressive-looking hull with spikes on the bottom
       ответ: You really botched things up when working at the form of your painting. The poor quality paint made it impossible to fix the situation; they don't hide the bott…
       условия: логика {[p22]=0}
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) -2
       эффект: P10(Composition and color) -3

### Loc45 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path121 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc46 [пустая]
  -> Path134 => Loc47  вер=1 порядок=5
       текст: Paint outerspace
       ответ: You do your very best and end up with a painting of a beautiful and picturesque representation of outer space - full of nebulae, stars, and asteroids.
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path135 => Loc47  вер=1 порядок=5
       текст: Paint a woodland scene
       ответ: Half broken, overgrown ship looks quite original in the jungle.
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path136 => Loc47  вер=1 порядок=5
       текст: Just do a careful wash of paint
       ответ: A careful wash of paint won't distract the viewer from what's most important!
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path301 => Loc95  вер=1 порядок=5
       текст: Paint outerspace
       ответ: You fail to paint outerspace in the surrealistic style. Although the background conforms to all the rules of the chosen style, it simply doesn't look like outer…
       условия: логика {[p22]=1}
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -3
  -> Path302 => Loc95  вер=1 порядок=5
       текст: Paint outerspace
       ответ: Your impressionistic painting of outerspace looks very striking and interesting! The star in the background is especially impressive.
       условия: логика {[p22]=3 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
  -> Path303 => Loc95  вер=1 порядок=5
       текст: Just do a careful wash of paint
       ответ: Your cubist painting style harmonizes well with your professional color wash in the background. The background does not draw too much attention to itself, and i…
       условия: логика {[p22]=2 and [p5]=6}
       эффект: P9(Cleanness) +3
       эффект: P10(Composition and color) +3
  -> Path304 => Loc95  вер=1 порядок=5
       текст: Just do a careful wash of paint
       ответ: Your vivid style does not go well with the boring and grey color of the background. Consequently, the background does not improve the painting at all.
       условия: логика {[p22]=3 or [p22]=4}
       эффект: P8(Appeal) -3
       эффект: P10(Composition and color) -3
  -> Path305 => Loc95  вер=1 порядок=5
       текст: Paint a woodland scene
       ответ: The forest is impressive. It looks like a tropical jungle. Feeling inspired, you paint some ancient ruins in the picturesque background. The result is excellent…
       условия: логика {[p22]=1 and [p5]=6}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
  -> Path306 => Loc95  вер=1 порядок=5
       текст: Paint a woodland scene
       ответ: You fail to paint the forest in a truly cubistic manner. The trees in the background look like odd spheres on thick legs. It makes the painting look more origin…
       условия: логика {[p22]=2}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) -3
       эффект: P10(Composition and color) -4

### Loc47 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path129 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc48 [обычная]
    Loc48-1: You can see a message on the overhead digital display: /  /  /  / "Results of the second round /  / <Ranger>'s score: [p30] /  / Kasyak's score: [p37] /  / Roo-…
    эффект: P37(Kasyak's score 2) = {(19 to 24)+[p34]} [показ]
    эффект: P38(Roo-bel's score 2) = {(15 to 21)+[p35]} [показ]
    эффект: P39(Khmelev's score 2) = {(10 to 23)+[p36]} [показ]
    скрыт: P25,P26,P27,P28
  -> Path141 => Loc49  вер=1 порядок=5
       скрыт: P30,P37,P38,P39

### Loc49 [обычная]
    Loc49-1: You return to your room and lie down on the sagging bed. The tattered volume of "World Art History" is on the nightstand. The stereovision has been repaired now…
  -> Path142 => Loc50  вер=1 порядок=6
       текст: Watch nothing and go to sleep
       ответ: You turn off the boob tube and go to sleep peacefully. /  / In the morning, you have a slight headache. "I bet it's the Machpella!" you said, repeating what you…
       эффект: P1(Fatigue) -1
  -> Path219 => Loc50  вер=1 порядок=3
       текст: Watch the cooking show
       ответ: You choose the cooking show to calm your nerves. A flaxen-haired woman in her forties or fifties is grimacing on the screen. Her figure is so emaciated that she…
       эффект: P3(Imagination) -1
       эффект: P4(Precision) +1
  -> Path220 => Loc50  вер=1 порядок=4
       текст: Watch the sci-fi film
       ответ: You switch to the film. It is one of those films where they shoot at hostile invaders continuously and blood flows like water. But it can be very stress-relievi…
       эффект: P3(Imagination) +1
       эффект: P5(Competence) -1
  -> Path221 => Loc50  вер=1 порядок=5
       текст: Watch the documentary about art history
       ответ: Some bookish guy on the stereovision is wearing glasses and explaining the expressionist masterpiece "The Shout" by the famous artist Van Gone. For some of aver…
       эффект: P3(Imagination) -1
       эффект: P4(Precision) -1
       эффект: P5(Competence) +2
  -> Path332 => Loc100  вер=1 проходов<=1 порядок=1
       текст: Read "World Art History"

### Loc50 [пустая]
    эффект: P17(Description switcher (Ls)) = 0
  -> Path143 => Loc51  вер=1 порядок=1
       текст: Do nothing and proceed to the competition
       эффект: P17(Description switcher (Ls)) = {5}
  -> Path144 => Loc52  вер=1 порядок=7
       текст: Try to pick the peleng's pocket
       эффект: P18(x) = 1

### Loc51 [обычная]
    выбор описания: {[p17]}
    Loc51-1: You begin probing the walls and suddenly feel something stiff. You carefully take it out, quickly step aside, and take a close look. Hey, it's a joint! You hide…
    Loc51-2: You decide not to push your luck any farther. You take your hand out of your pocket and go to the competition. /  / The hall is filled with noise. The crowd roa…
    Loc51-5: You decide not to push your luck any farther. You take your hand out of your pocket and go to the competition. /  / The hall is filled with noise. The crowd roa…
  -> Path155 => Loc56  вер=1 порядок=5
       текст: Take the common paints
       ответ: You take the common paints and start waiting. The lights go out, and the master of ceremonies appears on stage - even though everybody's had enough of him. A co…
       эффект: P6(Painting topic) +2 [показ]
       эффект: P8(Appeal) = {[p3]+[p23]-1}
       эффект: P9(Cleanness) = {[p4]-[p23]+1}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60} [показ]
       эффект: P21(Completeness) = 0 [показ]
       эффект: P23(Paints) +1 [показ]
  -> Path156 => Loc56  вер=1 порядок=5
       текст: Take the fluorescent paints
       ответ: You decide to make something original and choose the fluorescent paints. The lights go out, and the master of ceremonies appears on stage - even though everybod…
       эффект: P6(Painting topic) +2 [показ]
       эффект: P8(Appeal) = {[p3]+[p23]}
       эффект: P9(Cleanness) = {[p4]-[p23]}
       эффект: P10(Composition and color) = {[p5]}
       эффект: P20(Time) = {60}
       эффект: P21(Completeness) = 0
       эффект: P23(Paints) +2 [показ]

### Loc52 [обычная]
    выбор описания: {[p18]}
    Loc52-1: As you pretend to read something written on the wall, you reach over to pick Kasyak's pocket. His pocket turns out to be much deeper than you had expected.
    Loc52-2: You begin searching the pocket. Unfortunately, you haven't been able to find anything of value. /  /  /  / You must do something before Kasyak spots your illici…
  -> Path145 => Loc53  вер=2 порядок=7
       текст: Plunge deeper into the pocket
       эффект: P18(x) = 1
  -> Path148 => Loc72  вер=0.5 порядок=7
       текст: Plunge deeper into the pocket
       ответ: "Hey, man, somebody's trying to pick your pocket!" cries Kasyak's friend. Turning on his heels, Kasyak gives you a solid blow. His friend appears suddenly behin…
       эффект: P31(Total score 3) = {[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(20 to 25)+[p37]} [показ]
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]}
       эффект: P42(Khmelev's score 3) = {(10 to 18)+[p39]} [показ]
  -> Path224 => Loc81  вер=1 порядок=5
       текст: Search for something else
       эффект: P18(x) = 2
  -> Path334 => Loc51  вер=1 проходов<=1 порядок=1
       текст: Pull out your hand
       эффект: P17(Description switcher (Ls)) = {2}

### Loc53 [обычная]
    выбор описания: {[p18]}
    Loc53-1: You move your hand in even deeper, but you haven't quite reached the bottom of the pocket.
    Loc53-2: You begin searching the pocket. Unfortunately, you haven't been able to find anything of value. /  /  /  / You must do something before Kasyak spots your illici…
  -> Path149 => Loc72  вер=0.5 порядок=5
       текст: Search for something else
       ответ: You begin to search Kasyak's pockets, but he's on his guard and feels it. /  / Turning on his heels, Kasyak gives you a solid blow. His friend appears suddenly …
       эффект: P31(Total score 3) = {[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(20 to 25)+[p37]} [показ]
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]} [показ]
       эффект: P42(Khmelev's score 3) = {(10 to 18)+[p39]} [показ]
  -> Path150 => Loc51  вер=1 порядок=5
       текст: Search for something else
       эффект: P17(Description switcher (Ls)) = {1}
       эффект: P32(Joint) +1
  -> Path151 => Loc55  вер=1 порядок=7
       текст: Reach to the bottom of the pocket
       эффект: P18(x) = 1
  -> Path152 => Loc72  вер=1 порядок=9
       текст: Reach to the bottom of the pocket
       ответ: "Hey, man, somebody's trying to pick your pocket!" cries Kasyak's friend. Turning on his heels, Kasyak gives you a solid blow. His friend appears suddenly behin…
       эффект: P31(Total score 3) = {[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(20 to 25)+[p37]} [показ]
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]} [показ]
       эффект: P42(Khmelev's score 3) = {(10 to 18)+[p39]} [показ]
  -> Path222 => Loc80  вер=2 порядок=5
       текст: Search for something else
  -> Path335 => Loc51  вер=1 проходов<=1 порядок=1
       текст: Pull out your hand
       эффект: P17(Description switcher (Ls)) = {2}

### Loc55 [обычная]
    выбор описания: {[p18]}
    Loc55-1: You carefully reach the bottom of the pocket.
    Loc55-2: You begin searching the pocket. Unfortunately, you haven't been able to find anything of value. /  /  /  / You must do something before Kasyak spots your illici…
  -> Path153 => Loc72  вер=1 порядок=5
       текст: Search for something else
       ответ: You begin to search Kasyak's pockets, but he's on his guard and feels it. /  / Turning on his heels, Kasyak gives you a solid blow. His friend appears suddenly …
       эффект: P31(Total score 3) = {[p30]} [показ]
       эффект: P40(Kasyak's score 3) = {(20 to 25)+[p37]} [показ]
       эффект: P41(Roo-bel's score 3) = {(15 to 21)+[p38]} [показ]
       эффект: P42(Khmelev's score 3) = {(10 to 18)+[p39]} [показ]
  -> Path154 => Loc51  вер=3 порядок=5
       текст: Search for something else
       эффект: P17(Description switcher (Ls)) = {1}
       эффект: P32(Joint) +1
  -> Path226 => Loc82  вер=1 порядок=5
       текст: Search for something else
       эффект: P18(x) = 2
  -> Path336 => Loc51  вер=1 проходов<=1 порядок=1
       текст: Pull out your hand
       эффект: P17(Description switcher (Ls)) = {2}

### Loc56 [пустая]
    показ: P7,P8,P9,P10,P21
  -> Path157 => Loc57  вер=1 порядок=6
       текст: Realism
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = 0
  -> Path158 => Loc57  вер=1 порядок=7
       текст: Surrealism
       эффект: P8(Appeal) +2
       эффект: P22(Style) = 1
  -> Path159 => Loc57  вер=1 порядок=4
       текст: Cubism
       эффект: P8(Appeal) +3
       эффект: P9(Cleanness) -1
       эффект: P22(Style) = 2
  -> Path160 => Loc57  вер=1 порядок=3
       текст: Impressionism
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) +1
       эффект: P22(Style) = 3
  -> Path161 => Loc57  вер=1 порядок=5
       текст: Primitivism
       эффект: P8(Appeal) +4
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) -1
       эффект: P22(Style) = 4

### Loc57 [обычная]
    Loc57-1: There is an empty canvas in front of you. You can make a sketch with a pencil first. Or you can use the paint right away.
    показ: P6,P7,P8,P9,P10,P20,P21
  -> Path162 => Loc58  вер=1 порядок=4
       текст: Draw a sketch with a pencil
       ответ: You take out a pencil and outline the place for a head on your canvas.
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P20(Time) = {[p20]-[5..12]}
  -> Path163 => Loc59  вер=1 порядок=5
       текст: Pencils, schmencils. Give me the paints now!
       ответ: You mix the paints and thoughtfully passed the brush over the canvas.

### Loc58 [пустая]
  -> Path164 => Loc59  вер=1 порядок=5
       текст: Now it's time to apply the paint.

### Loc59 [обычная]
    Loc59-1: The audience's eyes devour you. It's so difficult to work when somebody's watching!
    Loc59-2: You sit in front of the easel. The audience looks at you with curiosity. /  / "It's like being in the zoo!" you think crossly.
    Loc59-3: Let's show'em how it's done!
  -> Path166 => Loc60  вер=1 проходов<=1 порядок=2
       текст: Paint eyes
       условия: P20(Time) 1..60; P43(drug1) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P43(drug1) +1
       эффект: P21(Completeness) +1
  -> Path167 => Loc61  вер=1 проходов<=1 порядок=3
       текст: Paint a nose
       условия: P20(Time) 1..60; P44(drug2) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P44(drug2) +1
       эффект: P21(Completeness) +1
  -> Path168 => Loc62  вер=1 проходов<=1 порядок=4
       текст: Paint a mouth
       условия: P20(Time) 1..60; P45(drug3) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P45(drug3) +1
       эффект: P21(Completeness) +1
  -> Path169 => Loc63  вер=1 проходов<=1 порядок=1
       текст: Paint facial contours, ears, hair, and so on
       условия: P20(Time) 1..60; P46(drug4) 0..0; логика {[p20]>((8*[p1])/2)}
       эффект: P46(drug4) +1
       эффект: P21(Completeness) +1
  -> Path203 => Loc21  вер=1 порядок=5
       текст: Hand in your work
       условия: логика {([p21]=4) or ([p20]<30)}
       эффект: P26(Gaal) = {(7*[p9]+2*[p10])/11,5}
       эффект: P27(Human) = {(7*[p8]+2*[p10])/11,5}
       эффект: P28(Maloq) = {(2*[p8]+2*[p9]+5*[p10])/11,5}
  -> Path315 => Loc60  вер=1 порядок=7
       текст: Repaint the eyes
       условия: P43(drug1) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path316 => Loc61  вер=1 порядок=8
       текст: Repaint the nose
       условия: P44(drug2) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path317 => Loc62  вер=1 порядок=9
       текст: Repaint the mouth
       условия: P45(drug3) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5
  -> Path318 => Loc63  вер=1 порядок=6
       текст: Repaint the facial contours, ears, hair, and so on
       условия: P46(drug4) 1..1; логика {[p20]>((8*[p1])/2)+5}
       эффект: P20(Time) -5

### Loc60 [обычная]
    Loc60-1: You look around and notice Khmelev's painting. It is very detailed, but it is fragmented and the colors are awful. Despite this, the artist seems to be proud of…
  -> Path170 => Loc64  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: "Maybe I should use the bigger brush to rough out and eye and then and the pupil with the smaller brush," you think as you make your plans.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path171 => Loc64  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: "I should use the middle-sized brush and stop wasting time," you decide.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path172 => Loc64  вер=1 порядок=3
       текст: Paint regularly
       ответ: Since you still have time, you decide to paint everything are rather precisely and as beautiful as possible.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path173 => Loc64  вер=1 порядок=4
       текст: Paint precisely and take your time
       ответ: You decide that you should use the small brush to paint the eyes very carefully in full detail.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc61 [обычная]
    Loc61-1: While looking at your paints, a strange label on them catches your eye. It says "ZK". That must be the name of the factory that produced them.
  -> Path180 => Loc66  вер=1 порядок=1
       текст: Paint rapidly and haphazardly
       ответ: You decide to quickly gloss over the nose.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path181 => Loc66  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You decide not to spend too much time, but to try to be a bit more precise.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path182 => Loc66  вер=1 порядок=3
       текст: Paint regularly
       ответ: You want to paint the nose without being rushed.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path183 => Loc66  вер=1 порядок=4
       текст: Paint with precision
       ответ: You decide to paint the nose in great detail.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc62 [обычная]
    Loc62-1: What a shame you didn't bring a mirror with you!
  -> Path187 => Loc68  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: You decide not to waste any time.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path188 => Loc68  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You decide not to spend too much time, but to try to be a bit more precise.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path190 => Loc68  вер=1 порядок=3
       текст: Paint regularly
       ответ: You decide to paint the mouth with some care.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path191 => Loc68  вер=1 порядок=4
       текст: Paint with precision
       ответ: You've done everything perfectly.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc63 [обычная]
    Loc63-1: Just a few moments left before your victory!
  -> Path195 => Loc70  вер=1 порядок=1
       текст: Paint quickly and carelessly
       ответ: "I can't linger on this too long - I'm running out of time," you think to yourself.
       условия: P20(Time) 1..60; логика {[p20]>((8*[p1])/2)}
       эффект: P8(Appeal) +2
       эффект: P9(Cleanness) -1
       эффект: P47(Timekeeper) = {([5..8]*[p1])/2}
  -> Path196 => Loc70  вер=1 порядок=2
       текст: Paint quickly, but accurately
       ответ: You decide to use a middle-sized brush to quickly gloss over the whole painting and then add finer details with a smaller brush.
       условия: P20(Time) 2..60; логика {[p20]>((11*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([8..11]*[p1])/2}
  -> Path197 => Loc70  вер=1 порядок=3
       текст: Paint regularly
       ответ: Since you have time, you should paint it more accurately.
       условия: P20(Time) 3..60; логика {[p20]>((15*[p1])/2)}
       эффект: P8(Appeal) +1
       эффект: P9(Cleanness) +1
       эффект: P10(Composition and color) +1
       эффект: P47(Timekeeper) = {([13..15]*[p1])/2}
  -> Path198 => Loc70  вер=1 порядок=4
       текст: Paint with precision
       ответ: You decide to paint every single detail.
       условия: P20(Time) 4..60; логика {[p20]>((22*[p1])/2)}
       эффект: P9(Cleanness) +2
       эффект: P10(Composition and color) +2
       эффект: P47(Timekeeper) = {([20..22]*[p1])/2}

### Loc64 [пустая]
  -> Path175 => Loc65  вер=1 порядок=5
       текст: Paint the eyes like those of a maloq who hasn't slept in a month.
       ответ: Savage, bloodshot eyes stare back at you with a scowl from the painting.
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path176 => Loc65  вер=1 порядок=5
       текст: Paint three eyes like gaals have
       ответ: The painting is rather precise and beautiful.
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
       эффект: P10(Composition and color) -1
  -> Path177 => Loc65  вер=1 порядок=5
       текст: Paint ordinary human eyes
       ответ: You use a flat paintbrush to add stylish, highly-detailed, dark blue eyes.
       условия: P32(Joint) 0..0
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p3]-2}
  -> Path209 => Loc65  вер=1 порядок=5
       текст: Paint ordinary human eyes
       ответ: You cast a furtive glance at Kasyak. He is frantically searching his pockets. Finding nothing, he gazes sadly at his canvas and begins to daub it with paint.
       условия: P32(Joint) 1..1
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p3]-2}

### Loc65 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path174 => Loc59  вер=1 порядок=5
       текст: Continue working

### Loc66 [пустая]
  -> Path178 => Loc67  вер=1 порядок=5
       текст: Paint a nose that looks like that of Anta Claus, an ancient idol.
       ответ: It looks more like a drunk maloq's nose, but it's inflamed reddish-purple color matches well with the face's other features.
       эффект: P9(Cleanness) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}
  -> Path184 => Loc67  вер=1 порядок=5
       текст: Paint a round clown nose
       ответ: It's simple and original
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P10(Composition and color) -1
  -> Path185 => Loc67  вер=1 порядок=5
       текст: Paint an ordinary human nose
       ответ: As you concentrate, the millions of different noses you've seen in your life all surface in your memory. You choose an appropriate nose and depict on the canvas…
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
       эффект: P10(Composition and color) -1

### Loc67 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path179 => Loc59  вер=1 порядок=5
       текст: Continue working

### Loc68 [пустая]
  -> Path192 => Loc69  вер=1 порядок=5
       текст: Paint puckered lips
       ответ: You look at your work and smile. The lips are especially funny.
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path193 => Loc69  вер=1 порядок=5
       текст: Portray beautifully-shaped lips
       ответ: You've been having a bit of trouble with the lips, but ultimately you're able to restrain your hyperactive imagination and paint some ordinary, normal-looking l…
       эффект: P8(Appeal) -1
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
  -> Path194 => Loc69  вер=1 порядок=5
       текст: Paint the jaws of a maloq
       ответ: Using a middle sized brush, you paint stylish and highly-detailed lips in the middle of your canvas.
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}

### Loc69 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path186 => Loc59  вер=1 порядок=5
       текст: Continue working

### Loc70 [пустая]
  -> Path199 => Loc71  вер=1 порядок=5
       текст: Paint a bowler hat and a toothbrush moustache
       ответ: The portrait has a strong resemblance to somebody - but you can't think of who exactly.
       эффект: P8(Appeal) = {[p8]+[p3]-2}
       эффект: P9(Cleanness) -1
  -> Path200 => Loc71  вер=1 порядок=5
       текст: Paint a low-key haircut
       ответ: The hair looks nice and tidy, but the ears are a real failure. They jut out from the hair; it looks very funny.
       эффект: P9(Cleanness) = {[p9]+[p4]-2}
       эффект: P10(Composition and color) -15
  -> Path201 => Loc71  вер=1 порядок=5
       текст: Paint snakes instead of hair and make it look like Medusa's head
       ответ: The intricately-detailed coiled snakes look very modern on the white background.
       эффект: P8(Appeal) -1
       эффект: P10(Composition and color) = {[p10]+[p5]-2}

### Loc71 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path189 => Loc59  вер=1 порядок=5
       текст: Continue working

### Loc72 [пустая]
    Loc72-1: You can see a message on the overhead digital display: /  / "Results of the second round /  / <Ranger>'s score: [p31] /  / Kasyak's score: [p40] /  / Roo-bel's …
    скрыт: P19,P26,P27,P28
  -> Path206 => Loc73  вер=1 порядок=5
       условия: логика {[p31]<[p40] or [p31]<[p41] or [p31]<[p42]}
  -> Path207 => Loc74  вер=1 порядок=5
       условия: логика {[p31]>[p40] and [p31]>[p41] and [p31]>[p42]}
  -> Path228 => Loc83  вер=100 порядок=5
       условия: логика {([p31]=[p40] and [p40]>[p41] and [p40]>[p42]) or ([p31]=[p41] and [p41]>[p40] and [p41]>[p42]) or ([p31]=[p42] and [p42]>[p40] and [p42]>[p41])}
       эффект: P17(Description switcher (Ls)) = 1
  -> Path322 => Loc83  вер=1 порядок=5
       условия: логика {[p31]=[p40] and [p40]=[p41] and [p40]=[p42]}
       эффект: P17(Description switcher (Ls)) = 2
       эффект: P19(Winner) = {[1..3]}
  -> Path325 => Loc83  вер=1 порядок=5
       условия: логика {[p31]=[p40] and [p40]=[p41] and [p40]>[p42]}
       эффект: P17(Description switcher (Ls)) = 2
       эффект: P19(Winner) = {[1..2]}
  -> Path326 => Loc83  вер=1 порядок=5
       условия: логика {[p31]=[p41] and [p41]>[p40] and [p41]=[p42]}
       эффект: P17(Description switcher (Ls)) = 2
       эффект: P19(Winner) = {[2..3]}
  -> Path327 => Loc83  вер=1 порядок=5
       условия: логика {[p31]=[p42] and [p42]=[p40] and [p42]>[p41]}
       эффект: P17(Description switcher (Ls)) = 2
       эффект: P19(Winner) = {[3..4]}

### Loc73 [ПРОВАЛ]
    Loc73-1: A mob of journalists attacks the winner and the award ceremony follows. You slip past everyone, trying to hide your shame, and go to the spaceport. Sometimes it…

### Loc74 [УСПЕХ]
    Loc74-1: You are thrilled. You begin dancing, knocking over a couple of cans of paint onto yourself. A horde of journalists attack you and ask stupid questions about how…

### Loc76 [обычная]
    выбор описания: {[p17]}
    Loc76-1: You start to get into the peleng's gravicar, but you are suddenly accosted by an insane bookseller - one of those booksellers who prowls the streets trying to f…
    Loc76-2: Then salesman drags out a huge leather-bound, moldy tome. "It's just missing a wrought-iron lock," you think to yourself. Standing in awe, you try to take the b…
    Loc76-3: You decide it would be better for your library to buy a book of good fiction instead of some stupid manual. The book itself is rather thick - a good one to read…
    Loc76-4: The salesman pulls a shabby brochure out of his bottomless pocket. It looks like he found it somewhere in the garbage. Anyway, it's something to read, and range…
    Loc76-5: "This book might be very useful, given what I'm here for," you think to yourself as you hand the salesman another bill. He pulls a very thin paperback from his …
    Loc76-6: The bookseller looks at his watch and cries, "Oh my! It's almost six o'clock! My workday is done! Well, take it easy. Goodbye!" You hardly have time to look up …
  -> Path210 => Loc77  вер=1 проходов<=1 порядок=2
       текст: Buy "Embroidery Manual" ({100} cr.)
       условия: P12(Money) 100..9999999; P48(Bought a small book) 0..1
       эффект: P12(Money) -100
       эффект: P48(Bought a small book) +1
       эффект: P13("Embroidery Manual") +1
       эффект: P17(Description switcher (Ls)) = {4}
  -> Path212 => Loc77  вер=1 проходов<=1 порядок=1
       текст: Buy "S. Lem. Stories" ({100} cr.)
       условия: P12(Money) 100..9999999; P48(Bought a small book) 0..1
       эффект: P12(Money) -100
       эффект: P48(Bought a small book) +1
       эффект: P14("S. Lem. Stories") +1
       эффект: P17(Description switcher (Ls)) = {3}
  -> Path213 => Loc77  вер=1 проходов<=1 порядок=4
       текст: Buy "How to Draw Without Drawing Even a Single Picture!" ({100} cr.)
       условия: P12(Money) 100..9999999; P48(Bought a small book) 0..1
       эффект: P12(Money) -100
       эффект: P48(Bought a small book) +1
       эффект: P16("How to Draw") +1
       эффект: P17(Description switcher (Ls)) = {5}
  -> Path215 => Loc97  вер=1 порядок=9
       текст: No, thanks. I don't want any of them
       ответ: "Here's home sweet home. I'll drop by for you tomorrow," your guide says as he turns around. /  / The peleng takes you to his gravicar. It's an early model with…
       условия: P48(Bought a small book) 1..1
  -> Path337 => Loc97  вер=1 проходов<=1 порядок=5
       текст: Thanks, but I don't want any of these things.
       ответ: "Here's home sweet home. I'll drop by for you tomorrow," your guide says as he turns around. /  / The peleng takes you to his gravicar. It's an early model with…
       условия: P48(Bought a small book) 0..0

### Loc77 [пустая]
  -> Path211 => Loc76  вер=100 порядок=5
       условия: P48(Bought a small book) 0..1
  -> Path320 => Loc96  вер=100 порядок=5
       условия: P48(Bought a small book) 2..2

### Loc78 [обычная]
    Loc78-1: You've been taken in by the book… /  / ...<clr>Realism<clrEnd> is an artistic school of thought that depicts reality truthfully and in detail. "It must be very …
    эффект: P15("World Art History") -1
  -> Path217 => Loc5  вер=1000 порядок=5
       текст: But the book aside
       условия: P1(Fatigue) 1..3

### Loc79 [пустая]
    Loc79-1: "Leonardo" version 1.3a /  / A memorial. /  / Author: Ivan Alexeev aka .vanoM /  / Thanks so much! Thanks to my mom, my dad, my manager, and all my friends ... …

### Loc80 [пустая]
  -> Path223 => Loc53  вер=1 порядок=5

### Loc81 [пустая]
  -> Path225 => Loc52  вер=1 порядок=5

### Loc82 [пустая]
  -> Path227 => Loc55  вер=1 порядок=5

### Loc83 [обычная]
    выбор описания: {[p17]}
    Loc83-1: The judges whisper between themselves for a long time and then call for the master of ceremonies. He listens attentively and then goes to the stage and 	announc…
    Loc83-2: The judges whisper between themselves for a long time and then call for the master of ceremonies. He listens attentively and then goes to the stage and 	announc…
    эффект: P19(Winner) = {} [скрыт]
  -> Path229 => Loc86  вер=1 порядок=5
       текст: Open the envelope
  -> Path230 => Loc85  вер=1 порядок=5
       текст: Open the envelope
  -> Path231 => Loc84  вер=1 порядок=5
       текст: Open the envelope

### Loc84 [обычная]
    Loc84-1: Inside, there is a piece of <clr>violet blue<clrEnd> paper.  /  / So what's the minimum number of times you need to mix the paints to produce this color?
  -> Path237 => Loc87  вер=1 порядок=1
       текст: 1
  -> Path238 => Loc88  вер=1 порядок=2
       текст: 2
  -> Path239 => Loc87  вер=1 порядок=4
       текст: 4
  -> Path240 => Loc87  вер=1 порядок=5
       текст: 5
  -> Path241 => Loc87  вер=1 порядок=6
       текст: 6
  -> Path323 => Loc87  вер=1 порядок=3
       текст: 3

### Loc85 [обычная]
    Loc85-1: Inside, there is a piece of <clr>brown<clrEnd> paper.  /  / So what's the minimum number of times you need to mix the paints to produce this color?
  -> Path242 => Loc88  вер=1 порядок=1
       текст: 1
  -> Path243 => Loc87  вер=1 порядок=2
       текст: 2
  -> Path244 => Loc87  вер=1 порядок=3
       текст: 3
  -> Path245 => Loc87  вер=1 порядок=4
       текст: 4
  -> Path246 => Loc87  вер=1 порядок=5
       текст: 5
  -> Path247 => Loc87  вер=1 порядок=6
       текст: 6

### Loc86 [обычная]
    Loc86-1: Inside, there is a piece of <clr>turquoise<clrEnd> paper.  /  / So what's the minimum number of times you need to mix the paints to produce this color?
  -> Path232 => Loc87  вер=1 порядок=2
       текст: 2
  -> Path233 => Loc87  вер=1 порядок=4
       текст: 4
  -> Path234 => Loc88  вер=1 порядок=3
       текст: 3
  -> Path235 => Loc87  вер=1 порядок=5
       текст: 5
  -> Path236 => Loc87  вер=1 порядок=6
       текст: 6
  -> Path324 => Loc87  вер=1 порядок=1
       текст: 1

### Loc87 [ПРОВАЛ]
    выбор описания: {[p17]}
    Loc87-1: Ten minutes later, the same assistant approaches you again. You return the envelope along with the number of mixes. He nods and goes to the judges' conference r…
    Loc87-2: Ten minutes later, the same assistant approaches you again. You return the envelope along with the number of mixes. He nods and goes to the judges' conference r…

### Loc88 [УСПЕХ]
    выбор описания: {[p17]}
    Loc88-1: Ten minutes later, the same assistant approaches you again. You return the envelope along with the number of mixes. He nods and goes to the judges' conference r…
    Loc88-2: Ten minutes later, the same assistant approaches you again. You return the envelope along with the number of mixes. He nods and goes to the judges' conference r…

### Loc89 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path248 => Loc12  вер=1 порядок=5
       текст: Continue working

### Loc90 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path252 => Loc12  вер=1 порядок=5
       текст: Continue working

### Loc91 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path256 => Loc12  вер=1 порядок=5
       текст: Continue working

### Loc92 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path260 => Loc12  вер=1 порядок=5
       текст: Continue working

### Loc93 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path286 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc94 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path293 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc95 [пустая]
    эффект: P20(Time) = {[p20]-[p47]}
  -> Path300 => Loc34  вер=1 порядок=5
       текст: Continue working

### Loc96 [обычная]
    выбор описания: {[p17]}
    Loc96-1: You start to get into the peleng's gravicar, but you are suddenly accosted by an insane bookseller - one of those booksellers who prowls the streets trying to f…
    Loc96-2: Then salesman drags out a huge leather-bound, moldy tome. "It's just missing a wrought-iron lock," you think to yourself. Standing in awe, you try to take the b…
    Loc96-3: You decide it would be better for your library to buy a book of good fiction instead of some stupid manual. The book itself is rather thick - a good one to read…
    Loc96-4: The salesman pulls a shabby brochure out of his bottomless pocket. It looks like he found it somewhere in the garbage. Anyway, it's something to read, and range…
    Loc96-5: "This book might be very useful, given what I'm here for," you think to yourself as you hand the salesman another bill. He pulls a very thin paperback from his …
    Loc96-7: The bookseller looks at his watch and cries, "Oh my! It's almost six o'clock! My workday is done! Well, take it easy. Goodbye!" You hardly have time to look up …
  -> Path218 => Loc97  вер=1 порядок=9
       текст: Go to the gravicar
       ответ: "Here's home sweet home. I'll drop by for you tomorrow," your guide says as he turns around. /  / The peleng takes you to his gravicar. It's an early model with…
       условия: P48(Bought a small book) 2..2

### Loc97 [пустая]
  -> Path321 => Loc5  вер=1 порядок=5

### Loc98 [обычная] визитов<=2
    выбор описания: {[p17]}
    Loc98-1: You arrive back at the hotel very quickly. You drag yourself to your room. Once inside, you fall in the bed as if you are exhausted. The stereovision still hasn…
    Loc98-2: You arrive back at the hotel very quickly. You drag yourself to your room. Once inside, you fall in the bed as if you are exhausted. The stereovision still hasn…
  -> Path329 => Loc99  вер=1 проходов<=1 порядок=4
       текст: Read "World Art History"
  -> Path331 => Loc27  вер=1 проходов<=1 порядок=5
       текст: Sleep
       эффект: P1(Fatigue) -1
       эффект: P17(Description switcher (Ls)) = 0

### Loc99 [обычная] визитов<=1
    Loc99-1: You've been taken in by the book… /  / ...<clr>Realism<clrEnd> is an artistic school of thought that depicts reality truthfully and in detail. "It must be very …
  -> Path330 => Loc98  вер=1 проходов<=1 порядок=5
       текст: But the book aside

### Loc100 [обычная] визитов<=1
    Loc100-1: You've been taken in by the book… /  / ...<clr>Realism<clrEnd> is an artistic school of thought that depicts reality truthfully and in detail. "It must be very …
  -> Path333 => Loc49  вер=1 проходов<=1 порядок=5
       текст: But the book aside

## Анализ
- стартовых: [1]
- концовки: {3: 'ПРОВАЛ', 73: 'ПРОВАЛ', 74: 'УСПЕХ', 87: 'ПРОВАЛ', 88: 'УСПЕХ'}
- недостижимые локации: [79]
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
