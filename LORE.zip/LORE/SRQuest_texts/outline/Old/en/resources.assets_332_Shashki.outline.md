# Квест (формат 1111111126)
Сложность 30; стартовая локация: [4]; путей по умолчанию: 1

## Параметры
- P1 'Checkers position' [0..1] тип=обычный
    старт: [0]
    [0..1] Checkers position:
    критическое: Сообщение достижения критического значения параметром 1
- P2 '1' [0..2] тип=обычный
    старт: [1]
    [0..0] Square 1 - Empty
    [1..1] Square 1 - W
    [2..2] Square 1 - B
    критическое: Сообщение достижения критического значения параметром 2
- P3 '2' [0..2] тип=обычный
    старт: [1]
    [0..0] Square 2 - Empty
    [1..1] Square 2 - W
    [2..2] Square 2 - B
    критическое: Сообщение достижения критического значения параметром 3
- P4 '3' [0..2] тип=обычный
    старт: [1]
    [0..0] Square 3 - Empty
    [1..1] Square 3 - W
    [2..2] Square 3 - B
    критическое: Сообщение достижения критического значения параметром 4
- P5 '4' [0..2] тип=обычный
    старт: [0]
    [0..0] Square 4 - Empty
    [1..1] Square 4 - W
    [2..2] Square 4 - B
    критическое: Сообщение достижения критического значения параметром 5
- P6 '5' [0..2] тип=обычный
    старт: [2]
    [0..0] Square 5 - Empty
    [1..1] Square 5 - W
    [2..2] Square 5 - B
    критическое: Сообщение достижения критического значения параметром 6
- P7 '6' [0..2] тип=обычный
    старт: [2]
    [0..0] Square 6 - Empty
    [1..1] Square 6 - W
    [2..2] Square 6 - B
    критическое: Сообщение достижения критического значения параметром 7
- P8 '7' [0..2] тип=обычный
    старт: [2]
    [0..0] Square 7 - Empty
    [1..1] Square 7 - W
    [2..2] Square 7 - B
    критическое: Сообщение достижения критического значения параметром 8
- P9 'Moves' [0..15] тип=обычный
    старт: [15]
    [0..0] All moves are made
    [1..1] <> move left
    [2..4] <> moves left
    [5..15] <> moves left
    критическое: Сообщение достижения критического значения параметром 9
- P10 'x' [0..7] тип=обычный
    старт: [0]
    [0..7] 
    критическое: Сообщение достижения критического значения параметром 10
- P11 'y' [1..10] тип=обычный
    старт: [1]
    [1..10] 
    критическое: Сообщение достижения критического значения параметром 11

## Локации и переходы

### Loc4 [СТАРТ]
    Loc4-1: You went to the <ToPlanet>' sports centre right upon arrival to the planet. /  /  - Hewo, dear <Ranger>, - a nice, slightly burring man with moustache said. - W…
    эффект: P2(1) = 1 [скрыт]
    эффект: P3(2) = 1 [скрыт]
    эффект: P4(3) = 1 [скрыт]
    эффект: P5(4) = 0 [скрыт]
    эффект: P6(5) = 2 [скрыт]
    эффект: P7(6) = 2 [скрыт]
    эффект: P8(7) = 2 [скрыт]
    эффект: P9(Moves) = 15 [скрыт]
    эффект: P11(y) = 1 [скрыт]
    скрыт: P1,P10
  -> Path5 => Loc10  вер=1 порядок=5
       текст: Go to the hotel library
       ответ: You came to the library and at once saw an interesting book, <clr>"Rules of Hyper-jumping Plasma-checkers. Brief edition "<clrEnd>. Naturally, you started readi…
       скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9
  -> Path6 => Loc10  вер=1 порядок=5
       текст: Go to bed
       скрыт: P1,P2,P3,P4,P5,P6,P7,P8,P9

### Loc10 [обычная]
    выбор описания: {[p11]}
    Loc10-1: In the morning, after a light breakfast, you went to the sports centre. /  / - Hewo, <Ranger>, - the bearded man who turned out to be the president of the jury …
    Loc10-2: - Tense moment... The player is deciding which checker it is going to be, - the sports commentator barged in. /  / Moves left: [p9]. Which checker is it going t…
    Loc10-3: - A very unexpected move! - the caster said. - What do you have in mind, <Ranger>? /  / Moves left: [p9]. Which checker is it going to be?
    Loc10-4: - An expected move, - the caster explained authoritatively. - I would make it myself here! /  / Moves left: [p9]. Which checker is it going to be?
    Loc10-5: Judging from the spectators' reaction, your move was one of those unexpected. The caster didn't comment on it though. /  / Moves left: [p9]. Which checker is it…
    Loc10-6: - A similar situation occurred during the final game for the champion title about, {[5..20]} years ago, - the caster was getting carried away in his own memorie…
    Loc10-7: An excellent move! - the caster said. - At least, it seems to me, it doesn't spoil the situation. And even if it does, then not too much... /  / Moves left: [p9…
    Loc10-8: - A strange move, very strange... - the caster murmured. - I refuse to understand what our dear <Ranger> wants to achieve making it... /  / Moves left: [p9]. Wh…
    Loc10-9: - Do you know what does the current situation remind me of? - the caster exclaimed. - I visited the exhibition "Idiotic inventions" last year, and there was a s…
    Loc10-10: - We will know the name of the new champion within several moves, can you imagine that?- and the caster fell silent stunned by the depth of his own revelation. …
    показ: P1,P2,P3,P4,P5,P6,P7,P8,P9
  -> Path13 => Loc11  вер=1
       текст: 1st
       условия: логика {[p3]=0 or [p4]=0}
       эффект: P10(x) = {[p2]}
  -> Path14 => Loc12  вер=1 порядок=1
       текст: 2nd
       условия: логика {[p2]=0 or [p4]=0 or [p5]=0}
       эффект: P10(x) = {[p3]}
  -> Path15 => Loc13  вер=1 порядок=2
       текст: 3d
       условия: логика {[p2]=0 or [p3]=0 or [p5]=0 or [p6]=0}
       эффект: P10(x) = {[p4]}
  -> Path16 => Loc14  вер=1 порядок=4
       текст: 4th
       условия: логика {[p3]=0 or [p4]=0 or [p6]=0 or [p7]=0}
       эффект: P10(x) = {[p5]}
  -> Path17 => Loc15  вер=1 порядок=5
       текст: 5th
       условия: логика {[p4]=0 or [p5]=0 or [p7]=0 or [p8]=0}
       эффект: P10(x) = {[p6]}
  -> Path18 => Loc16  вер=1 порядок=6
       текст: 6th
       условия: логика {[p5]=0 or [p6]=0 or [p8]=0}
       эффект: P10(x) = {[p7]}
  -> Path19 => Loc17  вер=1 порядок=7
       текст: 7th
       условия: логика {[p6]=0 or [p7]=0}
       эффект: P10(x) = {[p8]}

### Loc11 [пустая]
  -> Path20 => Loc25  вер=1 порядок=5
       условия: P3(2) ∈[0]
       эффект: P3(2) = {[p10]}
       эффект: P2(1) = 0
  -> Path21 => Loc25  вер=1 порядок=5
       условия: P4(3) ∈[0]
       эффект: P4(3) = {[p10]}
       эффект: P2(1) = 0

### Loc12 [пустая]
  -> Path22 => Loc25  вер=1 порядок=5
       условия: P5(4) ∈[0]
       эффект: P5(4) = {[p10]}
       эффект: P3(2) = 0
  -> Path23 => Loc25  вер=1 порядок=5
       условия: P4(3) ∈[0]
       эффект: P4(3) = {[p10]}
       эффект: P3(2) = 0
  -> Path24 => Loc25  вер=1 порядок=5
       условия: P2(1) ∈[0]
       эффект: P2(1) = {[p10]}
       эффект: P3(2) = 0

### Loc13 [пустая]
  -> Path31 => Loc25  вер=1 порядок=5
       условия: P3(2) ∈[0]
       эффект: P3(2) = {[p10]}
       эффект: P4(3) = 0
  -> Path32 => Loc25  вер=1 порядок=5
       условия: P5(4) ∈[0]
       эффект: P5(4) = {[p10]}
       эффект: P4(3) = 0
  -> Path33 => Loc25  вер=1 порядок=5
       условия: P2(1) ∈[0]
       эффект: P2(1) = {[p10]}
       эффект: P4(3) = 0
  -> Path34 => Loc25  вер=1 порядок=5
       условия: P6(5) ∈[0]
       эффект: P6(5) = {[p10]}
       эффект: P4(3) = 0

### Loc14 [пустая]
  -> Path35 => Loc25  вер=1 порядок=5
       условия: P4(3) ∈[0]
       эффект: P4(3) = {[p10]}
       эффект: P5(4) = 0
  -> Path36 => Loc25  вер=1 порядок=5
       условия: P6(5) ∈[0]
       эффект: P6(5) = {[p10]}
       эффект: P5(4) = 0
  -> Path37 => Loc25  вер=1 порядок=5
       условия: P3(2) ∈[0]
       эффект: P3(2) = {[p10]}
       эффект: P5(4) = 0
  -> Path38 => Loc25  вер=1 порядок=5
       условия: P7(6) ∈[0]
       эффект: P7(6) = {[p10]}
       эффект: P5(4) = 0

### Loc15 [пустая]
  -> Path39 => Loc25  вер=1 порядок=5
       условия: P5(4) ∈[0]
       эффект: P5(4) = {[p10]}
       эффект: P6(5) = 0
  -> Path40 => Loc25  вер=1 порядок=5
       условия: P7(6) ∈[0]
       эффект: P7(6) = {[p10]}
       эффект: P6(5) = 0
  -> Path41 => Loc25  вер=1 порядок=5
       условия: P4(3) ∈[0]
       эффект: P4(3) = {[p10]}
       эффект: P6(5) = 0
  -> Path42 => Loc25  вер=1 порядок=5
       условия: P8(7) ∈[0]
       эффект: P8(7) = {[p10]}
       эффект: P6(5) = 0

### Loc16 [пустая]
  -> Path27 => Loc25  вер=1 порядок=5
       условия: P8(7) ∈[0]
       эффект: P8(7) = {[p10]}
       эффект: P7(6) = 0
  -> Path28 => Loc25  вер=1 порядок=5
       условия: P6(5) ∈[0]
       эффект: P6(5) = {[p10]}
       эффект: P7(6) = 0
  -> Path29 => Loc25  вер=1 порядок=5
       условия: P5(4) ∈[0]
       эффект: P5(4) = {[p10]}
       эффект: P7(6) = 0

### Loc17 [пустая]
  -> Path25 => Loc25  вер=1 порядок=5
       условия: P7(6) ∈[0]
       эффект: P7(6) = {[p10]}
       эффект: P8(7) = 0
  -> Path26 => Loc25  вер=1 порядок=5
       условия: P6(5) ∈[0]
       эффект: P6(5) = {[p10]}
       эффект: P8(7) = 0

### Loc25 [пустая]
    эффект: P9(Moves) -1
  -> Path43 => Loc10  вер=1 порядок=5
       условия: P9(Moves) ∉[0]
       эффект: P11(y) = {[2..10]}
  -> Path44 => Loc26  вер=1 порядок=5
       условия: P9(Moves) ∈[0]

### Loc26 [пустая]
  -> Path45 => Loc27  вер=1 порядок=5
       условия: логика {[p2]<>2 or [p3]<>2 or [p4]<>2 or [p6]<>1 or [p7]<>1 or [p8]<>1}
  -> Path46 => Loc28  вер=1 порядок=5
       условия: логика {[p2]=2 and [p3]=2 and [p4]=2 and [p6]=1 and [p7]=1 and [p8]=1}

### Loc27 [ПРОВАЛ]
    Loc27-1: - No more moves! - the caster reported. The jury appeared from the door in the wall and hunched over the table. In a couple of minutes the president of the jury…

### Loc28 [УСПЕХ]
    Loc28-1: - No more moves! - the caster reported. The jury appeared from the door in the wall and hunched over the table. In a couple of minutes the president of the jury…

## Анализ
- стартовых: [4]
- концовки: {27: 'ПРОВАЛ', 28: 'УСПЕХ'}
- недостижимые локации: []
- тупики без концовки: []
- пути в несуществующую локацию: []
- параметры без использования: []
